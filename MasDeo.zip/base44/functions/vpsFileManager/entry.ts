import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const { action, file_url, new_vps_url } = await req.json();
    const uploadUrl = Deno.env.get('VPS_UPLOAD_URL'); // e.g. https://media.mastersdeovex.co.za/upload
    const uploadSecret = Deno.env.get('VPS_UPLOAD_SECRET');
    const baseMediaUrl = uploadUrl ? uploadUrl.replace('/upload', '') : '';

    // LIST files on VPS
    if (action === 'list') {
      const listUrl = `${baseMediaUrl}/list`;
      const res = await fetch(listUrl, {
        headers: { 'X-Upload-Secret': uploadSecret }
      });
      if (!res.ok) return Response.json({ error: 'VPS list failed', status: res.status }, { status: 502 });
      const data = await res.json();
      return Response.json({ files: data.files || [] });
    }

    // DELETE file on VPS
    if (action === 'delete') {
      const deleteUrl = `${baseMediaUrl}/delete`;
      const res = await fetch(deleteUrl, {
        method: 'POST',
        headers: { 'X-Upload-Secret': uploadSecret, 'Content-Type': 'application/json' },
        body: JSON.stringify({ file_url })
      });
      if (!res.ok) return Response.json({ error: 'VPS delete failed' }, { status: 502 });
      return Response.json({ success: true });
    }

    // RESTORE: fetch file from Base44/old VPS URL and re-upload to new VPS
    if (action === 'restore') {
      if (!file_url) return Response.json({ error: 'file_url required' }, { status: 400 });

      const fileRes = await fetch(file_url);
      if (!fileRes.ok) return Response.json({ error: 'Cannot fetch backup file' }, { status: 502 });

      const blob = await fileRes.blob();
      const contentType = fileRes.headers.get('content-type') || 'application/octet-stream';
      const filename = file_url.split('/').pop().split('?')[0] || 'restored_file';

      const vpsForm = new FormData();
      vpsForm.append('file', new File([blob], filename, { type: contentType }));

      const vpsRes = await fetch(uploadUrl, {
        method: 'POST',
        headers: { 'X-Upload-Secret': uploadSecret },
        body: vpsForm
      });

      if (!vpsRes.ok) {
        const err = await vpsRes.text();
        return Response.json({ error: `VPS restore failed: ${err}` }, { status: 502 });
      }

      const result = await vpsRes.json();
      return Response.json({ success: true, new_url: result.file_url });
    }

    // BULK REPLACE: update old URL → new URL across ALL entities
    if (action === 'bulk_replace_url') {
      if (!file_url || !new_vps_url) return Response.json({ error: 'file_url and new_vps_url required' }, { status: 400 });

      let updated = 0;

      // VpnFile
      const vpnFiles = await base44.asServiceRole.entities.VpnFile.list();
      for (const f of vpnFiles) {
        if (f.file_url === file_url) {
          await base44.asServiceRole.entities.VpnFile.update(f.id, { file_url: new_vps_url });
          updated++;
        }
      }

      // CreatorVpnFile
      const creatorVpnFiles = await base44.asServiceRole.entities.CreatorVpnFile.list();
      for (const f of creatorVpnFiles) {
        if (f.file_url === file_url) {
          await base44.asServiceRole.entities.CreatorVpnFile.update(f.id, { file_url: new_vps_url });
          updated++;
        }
      }

      // UserProfile (profile pictures)
      const profiles = await base44.asServiceRole.entities.UserProfile.list();
      for (const p of profiles) {
        if (p.profile_picture_url === file_url) {
          await base44.asServiceRole.entities.UserProfile.update(p.id, { profile_picture_url: new_vps_url });
          updated++;
        }
      }

      // Subscription (payment proofs)
      const subs = await base44.asServiceRole.entities.Subscription.list();
      for (const s of subs) {
        if (s.payment_proof_url === file_url) {
          await base44.asServiceRole.entities.Subscription.update(s.id, { payment_proof_url: new_vps_url });
          updated++;
        }
      }

      // CreatorItem (file_url, icon_image_url)
      const items = await base44.asServiceRole.entities.CreatorItem.list();
      for (const item of items) {
        const updates = {};
        if (item.file_url === file_url) updates.file_url = new_vps_url;
        if (item.icon_image_url === file_url) updates.icon_image_url = new_vps_url;
        if (Object.keys(updates).length > 0) {
          await base44.asServiceRole.entities.CreatorItem.update(item.id, updates);
          updated++;
        }
      }

      // CreatorResource
      const resources = await base44.asServiceRole.entities.CreatorResource.list();
      for (const r of resources) {
        if (r.file_url === file_url) {
          await base44.asServiceRole.entities.CreatorResource.update(r.id, { file_url: new_vps_url });
          updated++;
        }
        if (r.thumbnail_url === file_url) {
          await base44.asServiceRole.entities.CreatorResource.update(r.id, { thumbnail_url: new_vps_url });
          updated++;
        }
      }

      // CreatorCourse (thumbnail_url)
      const courses = await base44.asServiceRole.entities.CreatorCourse.list();
      for (const c of courses) {
        if (c.thumbnail_url === file_url) {
          await base44.asServiceRole.entities.CreatorCourse.update(c.id, { thumbnail_url: new_vps_url });
          updated++;
        }
      }

      return Response.json({ success: true, updated });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});