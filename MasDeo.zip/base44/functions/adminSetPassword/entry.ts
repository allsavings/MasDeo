import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

function encode(password) {
  const key = 'MDV2025XK';
  let result = '';
  for (let i = 0; i < password.length; i++) {
    result += String.fromCharCode(password.charCodeAt(i) ^ key.charCodeAt(i % key.length));
  }
  return btoa(result);
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const body = await req.json();
    const { email, newPassword } = body;

    if (!email || !newPassword) {
      return Response.json({ error: 'Email and new password are required' }, { status: 400 });
    }
    if (newPassword.length < 6) {
      return Response.json({ error: 'Password must be at least 6 characters' }, { status: 400 });
    }

    const encoded = encode(newPassword);

    // 1. Update the main vault with the new password
    const existing = await base44.asServiceRole.entities.PasswordVault.filter({ email });
    if (existing.length > 0) {
      await base44.asServiceRole.entities.PasswordVault.update(existing[0].id, {
        encoded_password: encoded,
        updated_at: new Date().toISOString()
      });
    } else {
      await base44.asServiceRole.entities.PasswordVault.create({
        email,
        encoded_password: encoded,
        updated_at: new Date().toISOString()
      });
    }

    // 2. Store a pending entry (keyed as "pending_{email}") so ResetPassword page can auto-apply it
    const pendingKey = `pending_${email}`;
    const existingPending = await base44.asServiceRole.entities.PasswordVault.filter({ email: pendingKey });
    if (existingPending.length > 0) {
      await base44.asServiceRole.entities.PasswordVault.update(existingPending[0].id, {
        encoded_password: encoded,
        updated_at: new Date().toISOString()
      });
    } else {
      await base44.asServiceRole.entities.PasswordVault.create({
        email: pendingKey,
        encoded_password: encoded,
        updated_at: new Date().toISOString()
      });
    }

    // 3. DO NOT call resetPasswordRequest here — we don't want the platform's raw email going to the user.
    //    Instead, send the full details ONLY to the admin so they can forward a branded version.
    const adminEmail = user.email;

    await base44.asServiceRole.integrations.Core.SendEmail({
      to: adminEmail,
      from_name: 'DeoVex Admin System',
      subject: `🔐 [Forward to User] Password Set for ${email}`,
      body: `Hi Admin,

You have set a new password for the following user:

  📧 User Email: ${email}
  🔑 New Password: ${newPassword}

NEXT STEP — Forward this to the user from your custom domain:
──────────────────────────────────────────────
To trigger their reset link, visit the app admin panel and use the
"Auto Reset" button for this user, OR manually ask them to request
a password reset at your app login page.

Alternatively, copy the message below and send it from your branded email:

---
Subject: Your New Password — Clone Masters | DeoVex

Hi there,

Your account password has been updated by the DeoVex team.

New Password: ${newPassword}

You can log in at: https://clonemastersdeovex.base44.app/auth

If you have any issues, contact us.

— Clone Masters | DeoVex Team
---

Set at: ${new Date().toLocaleString('en-ZA', { timeZone: 'Africa/Johannesburg' })}

— DeoVex Admin Panel`
    });

    return Response.json({
      success: true,
      message: `Password saved in vault. Email sent to YOU (${adminEmail}) — forward it to ${email} from your custom domain.`
    });
  } catch (error) {
    return Response.json({ error: error.message || 'Failed to set password' }, { status: 500 });
  }
});