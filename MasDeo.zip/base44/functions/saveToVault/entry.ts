import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// Simple XOR obfuscation — keeps it out of plain text in the DB
function encode(str) {
  const key = 'MDV2025XK';
  let result = '';
  for (let i = 0; i < str.length; i++) {
    result += String.fromCharCode(str.charCodeAt(i) ^ key.charCodeAt(i % key.length));
  }
  return btoa(result);
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { email, password } = body;

    if (!email || !password) {
      return Response.json({ error: 'Email and password required' }, { status: 400 });
    }

    const encoded_password = encode(password);
    const now = new Date().toISOString();

    // Upsert: remove old entry for this email, then create new
    const existing = await base44.asServiceRole.entities.PasswordVault.filter({ email });
    for (const old of existing) {
      await base44.asServiceRole.entities.PasswordVault.delete(old.id);
    }

    await base44.asServiceRole.entities.PasswordVault.create({
      email,
      encoded_password,
      updated_at: now
    });

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});