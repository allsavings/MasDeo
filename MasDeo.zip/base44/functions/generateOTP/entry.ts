import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const body = await req.json();
    const { email } = body;

    if (!email) {
      return Response.json({ error: 'Email is required' }, { status: 400 });
    }

    const base44 = createClientFromRequest(req);

    // Generate 6-digit OTP
    const code = String(Math.floor(Math.random() * 900000) + 100000);
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();

    // Delete any existing unused OTP for this email
    try {
      const existing = await base44.asServiceRole.entities.OTPToken.filter({ email, used: false });
      for (const token of existing) {
        await base44.asServiceRole.entities.OTPToken.delete(token.id);
      }
    } catch (_) {}

    // Create new OTP token
    await base44.asServiceRole.entities.OTPToken.create({
      email,
      code,
      expires_at: expiresAt,
      used: false
    });

    // Send email with OTP — Masters | DeoVex format
    await base44.asServiceRole.integrations.Core.SendEmail({
      to: email,
      subject: 'Masters | DeoVex — Account Recovery Code',
      body: `This code is: ${code}. This code expires in 15 minutes. If you did not request this, ignore this email. — Masters | DeoVex Team`
    });

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message || 'Failed to send OTP' }, { status: 500 });
  }
});