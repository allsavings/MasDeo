import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { backup_url, dry_run } = await req.json();
    if (!backup_url) {
      return Response.json({ error: 'backup_url is required' }, { status: 400 });
    }

    const fetchRes = await fetch(backup_url);
    if (!fetchRes.ok) {
      return Response.json({ error: `Cannot fetch backup file: ${fetchRes.status}` }, { status: 502 });
    }

    const payload = await fetchRes.json();
    if (!payload.data || !payload.app) {
      return Response.json({ error: 'Invalid backup file format' }, { status: 400 });
    }

    if (dry_run) {
      return Response.json({
        success: true,
        dry_run: true,
        snapshot_info: {
          version: payload.version,
          backed_up_at: payload.backed_up_at,
          backed_up_by: payload.backed_up_by,
          total_records: payload.total_records,
        },
        stats: payload.stats,
      });
    }

    const restored = {};
    const skipped = {};

    for (const [entityName, records] of Object.entries(payload.data)) {
      if (!Array.isArray(records) || records.length === 0) {
        restored[entityName] = 0;
        skipped[entityName] = 0;
        continue;
      }

      let created = 0;
      let skip = 0;

      for (const record of records) {
        // Strip built-in system fields — let new app generate fresh IDs/dates
        const { id, created_date, updated_date, created_by, ...rest } = record;
        try {
          await base44.asServiceRole.entities[entityName].create(rest);
          created++;
        } catch {
          skip++;
        }
      }

      restored[entityName] = created;
      skipped[entityName] = skip;
    }

    const totalRestored = Object.values(restored).reduce((a, b) => a + b, 0);
    const totalSkipped = Object.values(skipped).reduce((a, b) => a + b, 0);

    return Response.json({
      success: true,
      total_restored: totalRestored,
      total_skipped: totalSkipped,
      restored,
      skipped,
      snapshot_info: {
        version: payload.version,
        backed_up_at: payload.backed_up_at,
        backed_up_by: payload.backed_up_by,
      },
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});