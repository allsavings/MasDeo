import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

function decode(encoded) {
  const key = 'MDV2025XK';
  try {
    const str = atob(encoded);
    let result = '';
    for (let i = 0; i < str.length; i++) {
      result += String.fromCharCode(str.charCodeAt(i) ^ key.charCodeAt(i % key.length));
    }
    return result;
  } catch {
    return null;
  }
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { email } = body;

    if (!email) {
      return Response.json({ error: 'Email required' }, { status: 400 });
    }

    // Look up the pending password entry
    const pendingKey = `pending_${email}`;
    const results = await base44.asServiceRole.entities.PasswordVault.filter({ email: pendingKey });

    if (results.length === 0) {
      return Response.json({ password: null });
    }

    const password = decode(results[0].encoded_password);

    // Clean up the pending entry after retrieval
    await base44.asServiceRole.entities.PasswordVault.delete(results[0].id);

    return Response.json({ password });
  } catch (error) {
    return Response.json({ error: error.message || 'Failed' }, { status: 500 });
  }
});