import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

function decode(encoded) {
  const key = 'MDV2025XK';
  try {
    const str = atob(encoded);
    let result = '';
    for (let i = 0; i < str.length; i++) {
      result += String.fromCharCode(str.charCodeAt(i) ^ key.charCodeAt(i % key.length));
    }
    return result;
  } catch {
    return null;
  }
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { email, code } = body;

    if (!email || !code) {
      return Response.json({ error: 'Email and code are required' }, { status: 400 });
    }

    // Find valid, unused OTPs for this email
    const otpTokens = await base44.asServiceRole.entities.OTPToken.filter({ email, used: false });

    if (otpTokens.length === 0) {
      return Response.json({ error: 'Invalid or expired recovery code. Please request a new one.' }, { status: 400 });
    }

    // Find matching code
    const otpToken = otpTokens.find(t => t.code === String(code));
    if (!otpToken) {
      return Response.json({ error: 'Incorrect recovery code. Please try again.' }, { status: 400 });
    }

    // Check expiry
    if (new Date(otpToken.expires_at) < new Date()) {
      await base44.asServiceRole.entities.OTPToken.update(otpToken.id, { used: true });
      return Response.json({ error: 'Code has expired. Please request a new one.' }, { status: 400 });
    }

    // Mark OTP as used
    await base44.asServiceRole.entities.OTPToken.update(otpToken.id, { used: true });

    // Look up stored password from vault
    const vaultEntries = await base44.asServiceRole.entities.PasswordVault.filter({ email });
    if (vaultEntries.length === 0) {
      return Response.json({ error: 'No stored password found for this account. Please contact support.' }, { status: 404 });
    }

    const password = decode(vaultEntries[0].encoded_password);
    if (!password) {
      return Response.json({ error: 'Could not retrieve password. Please contact support.' }, { status: 500 });
    }

    // Send the stored password to user's email
    await base44.asServiceRole.integrations.Core.SendEmail({
      to: email,
      subject: 'Masters | DeoVex — Your Account Password',
      body: `Hello,\n\nYour Masters | DeoVex account password is:\n\n  ${password}\n\nLogin here: https://mastersdeovex.co.za\n\n— Masters | DeoVex Team`
    });

    return Response.json({ success: true, message: 'Your password has been sent to your email.' });
  } catch (error) {
    return Response.json({ error: error.message || 'Verification failed' }, { status: 500 });
  }
});