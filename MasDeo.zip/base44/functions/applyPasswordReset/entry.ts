import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { reset_token, newPassword } = body;

    if (!reset_token || !newPassword) {
      return Response.json({ error: 'Token and new password are required' }, { status: 400 });
    }

    if (newPassword.length < 6) {
      return Response.json({ error: 'Password must be at least 6 characters' }, { status: 400 });
    }

    // Find the recovery request by our custom token (stored as 'auth_code')
    const requests = await base44.asServiceRole.entities.RecoveryRequest.filter({
      auth_code: reset_token,
      used: false
    });

    if (requests.length === 0) {
      return Response.json({
        error: 'Invalid or already used reset link. Please request a new one.'
      }, { status: 400 });
    }

    const request = requests[0];

    // Check expiry
    if (new Date(request.expires_at) < new Date()) {
      await base44.asServiceRole.entities.RecoveryRequest.update(request.id, { used: true });
      return Response.json({
        error: 'Reset link has expired. Please request a new one.'
      }, { status: 400 });
    }

    // Mark our token as used
    await base44.asServiceRole.entities.RecoveryRequest.update(request.id, {
      used: true,
      status: 'processed'
    });

    // Trigger the platform password reset email for this user.
    // The ResetPassword page will auto-apply the password when the user clicks the link.
    await base44.auth.resetPasswordRequest(request.email);

    return Response.json({ success: true, email: request.email });
  } catch (error) {
    return Response.json({ error: error.message || 'Password reset failed' }, { status: 500 });
  }
});