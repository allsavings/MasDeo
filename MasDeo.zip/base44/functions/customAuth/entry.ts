import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  try {
    const body = await req.json();
    const { action, email, password, full_name } = body;

    if (!email || !password) {
      return Response.json({ error: 'Email and password required' }, { status: 400 });
    }

    // Use your media.mastersdeovex.co.za as middleman for auth
    const VPS_URL = Deno.env.get('VPS_UPLOAD_URL') || 'https://media.mastersdeovex.co.za';
    
    if (action === 'signin') {
      try {
        // Call your VPS backend to handle signin
        const response = await fetch(`${VPS_URL}/api/auth/signin`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password }),
        });

        if (!response.ok) {
          const error = await response.json().catch(() => ({ error: 'Invalid credentials' }));
          return Response.json(
            { success: false, error: error.error || 'Sign in failed' },
            { status: 401 }
          );
        }

        const data = await response.json();
        return Response.json({ success: true, user: data.user, token: data.token });
      } catch (error) {
        return Response.json(
          { success: false, error: 'Connection error. Please try again.' },
          { status: 500 }
        );
      }
    }

    if (action === 'signup') {
      if (!full_name) {
        return Response.json({ error: 'Full name required' }, { status: 400 });
      }

      try {
        // Call your VPS backend to handle signup
        const response = await fetch(`${VPS_URL}/api/auth/signup`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password, full_name }),
        });

        if (!response.ok) {
          const error = await response.json().catch(() => ({ error: 'Signup failed' }));
          return Response.json(
            { success: false, error: error.error || 'Account creation failed' },
            { status: 400 }
          );
        }

        const data = await response.json();
        return Response.json({ success: true, user: data.user, token: data.token });
      } catch (error) {
        return Response.json(
          { success: false, error: 'Connection error. Please try again.' },
          { status: 500 }
        );
      }
    }

    return Response.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error) {
    return Response.json(
      { error: error.message || 'Server error' },
      { status: 500 }
    );
  }
});