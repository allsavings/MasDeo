import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const LOGO_URL = 'https://media.base44.com/images/public/69fbae3c9d10c5e17ae8e806/f700d3528_FinalMastersDeoVex.png';

// ── Send in-app notification ──────────────────────────────────────────────────
async function sendNotification(base44, userEmail, title, message, type = 'success', extra = {}) {
  try {
    await base44.asServiceRole.entities.AppNotification.create({
      user_email: userEmail,
      title,
      message,
      body: message,
      type,
      is_read: false,
      read_by: [],
      read_count: 0,
      ...extra,
    });
  } catch (e) {
    console.error('Notification error:', e.message);
  }
}

// ── HTML Email builder ────────────────────────────────────────────────────────
function buildHtmlEmail({ title, preheader, heading, subheading, bodyLines = [], ctaText, ctaUrl, fileUrl, fileName, footerNote }) {
  const cta = ctaUrl ? `
    <table width="100%" cellpadding="0" cellspacing="0" style="margin-top:28px;">
      <tr><td align="center">
        <a href="${ctaUrl}" style="display:inline-block;background:linear-gradient(135deg,#7c3aed,#06b6d4);color:#ffffff;text-decoration:none;font-weight:800;font-size:15px;padding:14px 36px;border-radius:12px;letter-spacing:0.5px;">
          ${ctaText || 'Open App'}
        </a>
      </td></tr>
    </table>` : '';

  const fileBtn = fileUrl ? `
    <table width="100%" cellpadding="0" cellspacing="0" style="margin-top:20px;">
      <tr><td align="center">
        <a href="${fileUrl}" download style="display:inline-block;background:linear-gradient(135deg,#ea580c,#f59e0b);color:#ffffff;text-decoration:none;font-weight:800;font-size:14px;padding:13px 32px;border-radius:12px;letter-spacing:0.5px;">
          ⬇️ Download ${fileName || 'Config File'}
        </a>
      </td></tr>
    </table>` : '';

  const bodyHtml = bodyLines.map(line =>
    line.startsWith('---')
      ? `<hr style="border:none;border-top:1px solid #2d2d3a;margin:18px 0;" />`
      : `<p style="margin:0 0 10px;font-size:13px;color:#c4c4d4;line-height:1.7;">${line}</p>`
  ).join('');

  return `<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>${title}</title></head>
<body style="margin:0;padding:0;background:#0a0a0f;font-family:'Segoe UI',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#0a0a0f;padding:40px 16px;">
    <tr><td align="center">
      <table width="100%" style="max-width:560px;" cellpadding="0" cellspacing="0">

        <!-- Logo Header -->
        <tr><td align="center" style="padding-bottom:28px;">
          <img src="${LOGO_URL}" alt="Masters DeoVex" width="90" height="90" style="border-radius:50%;display:block;" />
          <p style="margin:10px 0 0;font-size:11px;color:#7c7c99;letter-spacing:2px;text-transform:uppercase;font-weight:600;">Masters DeoVex</p>
        </td></tr>

        <!-- Card -->
        <tr><td style="background:#13131f;border:1px solid #1e1e30;border-radius:20px;overflow:hidden;">

          <!-- Gradient top bar -->
          <table width="100%" cellpadding="0" cellspacing="0">
            <tr><td style="height:4px;background:linear-gradient(90deg,#7c3aed,#06b6d4);"></td></tr>
          </table>

          <!-- Card body -->
          <table width="100%" cellpadding="0" cellspacing="0">
            <tr><td style="padding:32px 32px 28px;">

              <!-- Heading -->
              <h1 style="margin:0 0 6px;font-size:22px;font-weight:900;color:#ffffff;letter-spacing:-0.5px;">${heading}</h1>
              ${subheading ? `<p style="margin:0 0 20px;font-size:13px;color:#7c3aed;font-weight:600;">${subheading}</p>` : ''}

              <!-- Body -->
              ${bodyHtml}

              <!-- File Download Button (primary) -->
              ${fileBtn}

              <!-- CTA Button -->
              ${cta}

            </td></tr>
          </table>
        </td></tr>

        <!-- Footer -->
        <tr><td style="padding:24px 16px 8px;text-align:center;">
          <p style="margin:0 0 4px;font-size:12px;color:#4a4a5a;">Masters DeoVex — Lets VPN Go Paid Version</p>
          <p style="margin:0;font-size:11px;color:#3a3a4a;">
            <a href="https://mastersdeovex.co.za" style="color:#7c3aed;text-decoration:none;">mastersdeovex.co.za</a>
          </p>
          ${footerNote ? `<p style="margin:8px 0 0;font-size:11px;color:#3a3a4a;">${footerNote}</p>` : ''}
          <p style="margin:12px 0 0;font-size:10px;color:#2a2a3a;">⚠️ Do not share your config — account sharing is monitored and will result in a permanent ban.</p>
        </td></tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`;
}

// ── Send HTML email ───────────────────────────────────────────────────────────
async function sendEmail(base44, to, subject, htmlBody) {
  try {
    await base44.asServiceRole.integrations.Core.SendEmail({
      to,
      subject,
      body: htmlBody,
      from_name: 'Masters DeoVex',
    });
  } catch (e) {
    console.error('Email error:', e.message);
  }
}

const ADMIN_EMAIL = '772mastersunlimited@gmail.com';

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const body = await req.json();
  const { action, nodeId, vlessOverride, adminNote, fileUrl, fileName, title, message } = body;

  // ── ACTION: on_order ─────────────────────────────────────────────────────
  if (action === 'on_order') {
    const rows = await base44.asServiceRole.entities.ISPNode.filter({ id: nodeId });
    const node = rows[0];
    if (!node) return Response.json({ error: 'Node not found' }, { status: 404 });

    const planLabel = node.plan === '7days' ? '7 Days (R20)' : node.plan === '30days' ? '30 Days (R50)' : '14 Days (R30)';

    // Build payment proof / voucher lines for admin email
    const paymentLines = [
      `<strong style="color:#fff;">Name:</strong> ${node.user_name}`,
      `<strong style="color:#fff;">Email:</strong> ${node.user_email}`,
      `<strong style="color:#fff;">WhatsApp:</strong> ${node.whatsapp || '—'}`,
      `<strong style="color:#fff;">Plan:</strong> ${planLabel}`,
      `<strong style="color:#fff;">Payment Method:</strong> ${(node.payment_method || '').replace('_', ' ')}`,
      `<strong style="color:#fff;">Amount:</strong> R${node.amount_paid || '—'}`,
    ];
    if (node.voucher_pin) {
      paymentLines.push(`<strong style="color:#f59e0b;">1Voucher PIN:</strong> <span style="font-family:monospace;font-size:16px;color:#fbbf24;letter-spacing:2px;">${node.voucher_pin}</span>`);
    }
    if (node.payment_proof_url) {
      paymentLines.push(`<strong style="color:#fff;">Proof/Voucher Image:</strong> <a href="${node.payment_proof_url}" style="color:#06b6d4;">View Image ↗</a>`);
    }
    paymentLines.push(`<strong style="color:#fff;">Notes:</strong> ${node.admin_notes || '—'}`);

    // Admin email (plain)
    await sendEmail(base44, ADMIN_EMAIL,
      `🔔 New Paid Order — ${node.user_name} (${planLabel})`,
      buildHtmlEmail({
        title: 'New Order Received',
        heading: '🔔 New Paid Order',
        subheading: `From: ${node.user_name}`,
        bodyLines: paymentLines,
        fileUrl: node.payment_proof_url || null,
        fileName: node.voucher_pin ? `Voucher-${node.voucher_pin}` : 'Payment Proof',
        ctaText: 'Open Admin Dashboard',
        ctaUrl: 'https://mastersdeovex.co.za/ISPNodeAdmin',
      })
    );

    // User confirmation notification
    await sendNotification(base44, node.user_email,
      '🎉 Order Received — Verification in Progress',
      `Hi ${node.user_name}! Your Lets VPN Go Paid order (${planLabel}) has been received. Our team will verify your payment within 10 minutes to 6 hours. You'll be notified once approved. 🚀`,
      'info'
    );

    // User confirmation email
    await sendEmail(base44, node.user_email,
      '🎉 Lets VPN Go — Order Received & Being Verified',
      buildHtmlEmail({
        title: 'Order Received',
        heading: '🎉 Order Received!',
        subheading: 'Your payment is being verified',
        bodyLines: [
          `Hi <strong style="color:#fff;">${node.user_name}</strong>, thank you for your order!`,
          '---',
          `<strong style="color:#fff;">Plan:</strong> ${planLabel}`,
          `<strong style="color:#fff;">Payment Method:</strong> ${(node.payment_method || '').replace('_', ' ')}`,
          `<strong style="color:#fff;">Amount:</strong> R${node.amount_paid}`,
          '---',
          '✅ Verification takes 10 minutes – 6 hours.',
          '📦 Your VPN config will be delivered via Masters DeoVex, Email & WhatsApp.',
          '⚡ To speed up: Send <strong style="color:#06b6d4;">"Paid@DeoVex"</strong> on WhatsApp to <strong style="color:#fff;">+27 69 298 7836</strong>',
        ],
        ctaText: 'View My Dashboard',
        ctaUrl: 'https://mastersdeovex.co.za/ISPNodeDashboard',
      })
    );

    return Response.json({ ok: true });
  }

  // ── ACTION: on_renewal_request ───────────────────────────────────────────
  if (action === 'on_renewal_request') {
    const rows = await base44.asServiceRole.entities.ISPNode.filter({ id: nodeId });
    const node = rows[0];
    if (!node) return Response.json({ error: 'Node not found' }, { status: 404 });

    const renewalLines = [
      `<strong style="color:#fff;">Email:</strong> ${node.user_email}`,
      `<strong style="color:#fff;">WhatsApp:</strong> ${node.whatsapp || '—'}`,
      `<strong style="color:#fff;">Renewal Plan:</strong> ${node.renewal_plan || node.plan}`,
      `<strong style="color:#fff;">Payment Method:</strong> ${node.renewal_payment_method || '—'}`,
      `<strong style="color:#fff;">Amount:</strong> R${node.renewal_amount || '—'}`,
    ];
    if (node.renewal_voucher_pin) {
      renewalLines.push(`<strong style="color:#f59e0b;">1Voucher PIN:</strong> <span style="font-family:monospace;font-size:16px;color:#fbbf24;letter-spacing:2px;">${node.renewal_voucher_pin}</span>`);
    }
    if (node.renewal_payment_proof_url) {
      renewalLines.push(`<strong style="color:#fff;">Proof/Voucher Image:</strong> <a href="${node.renewal_payment_proof_url}" style="color:#06b6d4;">View Image ↗</a>`);
    }

    await sendEmail(base44, ADMIN_EMAIL,
      `🔄 Renewal Request — ${node.user_name}`,
      buildHtmlEmail({
        title: 'Renewal Request',
        heading: '🔄 Renewal Request',
        subheading: `From: ${node.user_name}`,
        bodyLines: renewalLines,
        fileUrl: node.renewal_payment_proof_url || null,
        fileName: node.renewal_voucher_pin ? `Voucher-${node.renewal_voucher_pin}` : 'Renewal Proof',
        ctaText: 'Open Admin Dashboard',
        ctaUrl: 'https://mastersdeovex.co.za/ISPNodeAdmin',
      })
    );

    return Response.json({ ok: true });
  }

  // ── ACTION: check_expiry ─────────────────────────────────────────────────
  if (action === 'check_expiry') {
    const now = Date.now();
    const window48h = 48 * 60 * 60 * 1000;
    const allActive = await base44.asServiceRole.entities.ISPNode.filter({ status: 'active' });

    let notified = 0;
    for (const node of allActive) {
      if (!node.expiry_epoch) continue;
      const timeLeft = node.expiry_epoch - now;
      if (timeLeft > 0 && timeLeft <= window48h + 60 * 60 * 1000 && timeLeft > window48h - 60 * 60 * 1000) {
        const planLabel = node.plan === '7days' ? '7 Days' : node.plan === '30days' ? '30 Days' : '14 Days';
        await sendNotification(base44, node.user_email,
          '⚠️ Your VPN Subscription Expires in 48 Hours!',
          `Your Lets VPN Go Paid subscription (${planLabel}) expires on ${node.expiry_date}. Renew now in your dashboard to avoid losing access!`,
          'warning'
        );
        await sendEmail(base44, node.user_email,
          '⚠️ Lets VPN Go — Subscription Expiring in 48 Hours',
          buildHtmlEmail({
            title: 'Subscription Expiring',
            heading: '⚠️ Subscription Expiring Soon',
            subheading: 'Renew now to keep your access',
            bodyLines: [
              `Hi <strong style="color:#fff;">${node.user_name}</strong>, your subscription is expiring soon!`,
              '---',
              `<strong style="color:#fff;">Plan:</strong> ${planLabel}`,
              `<strong style="color:#fff;">Expiry Date:</strong> ${node.expiry_date}`,
              '---',
              '🔄 Open your dashboard and submit a renewal to keep uninterrupted access.',
              '📱 Or WhatsApp us: <strong style="color:#fff;">+27 69 298 7836</strong>',
            ],
            ctaText: 'Renew Now',
            ctaUrl: 'https://mastersdeovex.co.za/ISPNodeDashboard',
          })
        );
        notified++;
      }

      // Mark expired
      if (timeLeft <= 0) {
        await base44.asServiceRole.entities.ISPNode.update(node.id, { status: 'expired' });
      }
    }

    return Response.json({ ok: true, notified });
  }

  const user = await base44.auth.me();
  if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

  const getNode = async (id) => {
    const rows = await base44.asServiceRole.entities.ISPNode.filter({ id });
    return rows[0] || null;
  };

  // ── ACTION: approve ──────────────────────────────────────────────────────
  if (action === 'approve') {
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });

    const node = await getNode(nodeId);
    if (!node) return Response.json({ error: 'Node not found' }, { status: 404 });

    // Config string is optional — admin might only attach a file
    const finalVless = vlessOverride || '';

    const planDays    = node.plan === '30days' ? 30 : node.plan === '7days' ? 7 : 14;
    const expiryEpoch = Date.now() + planDays * 24 * 60 * 60 * 1000;
    const expiryDate  = new Date(expiryEpoch).toLocaleDateString('en-ZA', { year: 'numeric', month: 'long', day: 'numeric' });

    await base44.asServiceRole.entities.ISPNode.update(nodeId, {
      status:       'active',
      vless_string: finalVless,
      expiry_epoch: expiryEpoch,
      expiry_date:  expiryDate,
      admin_notes:  adminNote || node.admin_notes || '',
      renewal_status: 'none',
    });

    const planLabel = node.plan === '7days' ? '7 Days' : node.plan === '30days' ? '30 Days' : '14 Days';
    const noteParts = (adminNote || '').split('|');
    const configTypeLabel = noteParts[0]?.trim() || '';
    const adminNoteText = noteParts.slice(1).join('|').trim();

    let notifMessage = `Your Lets VPN Go Paid subscription (${planLabel}) has been activated! Open your dashboard to access your config.`;
    if (adminNoteText) notifMessage += `\n\n📝 Note: ${adminNoteText}`;
    if (fileUrl) notifMessage += `\n\n📎 Your config file is ready — tap to download.`;

    await sendNotification(base44, node.user_email,
      '✅ Your VPN Config is Active!',
      notifMessage,
      'success',
      fileUrl ? { file_url: fileUrl, file_name: fileName || 'config-file' } : {}
    );

    const bodyLines = [
      `Hi <strong style="color:#fff;">${node.user_name}</strong>, great news! Your subscription is now active.`,
      '---',
      `<strong style="color:#fff;">Plan:</strong> ${planLabel}`,
      `<strong style="color:#fff;">Expires:</strong> ${expiryDate}`,
    ];
    if (configTypeLabel) bodyLines.push(`<strong style="color:#fff;">Config Type:</strong> ${configTypeLabel}`);
    if (adminNoteText) bodyLines.push('---', `📝 <strong style="color:#fff;">Admin Note:</strong> ${adminNoteText}`);
    if (!fileUrl) bodyLines.push('---', '📲 Open your dashboard to copy your VPN config string and get started.');

    await sendEmail(base44, node.user_email,
      '✅ Your Lets VPN Go Config is Ready!',
      buildHtmlEmail({
        title: 'Subscription Activated',
        heading: '✅ Config is Ready!',
        subheading: 'Your Lets VPN Go Paid subscription is active',
        bodyLines,
        fileUrl: fileUrl || null,
        fileName: fileName || 'Config File',
        ctaText: 'Open My Dashboard',
        ctaUrl: 'https://mastersdeovex.co.za/ISPNodeDashboard',
        footerNote: '🔍 Paid Version is highly monitored. Do NOT share your config.',
      })
    );

    return Response.json({ ok: true, expiryDate });
  }

  // ── ACTION: reject ───────────────────────────────────────────────────────
  if (action === 'reject') {
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });

    const node = await getNode(nodeId);
    if (!node) return Response.json({ error: 'Node not found' }, { status: 404 });

    await base44.asServiceRole.entities.ISPNode.update(nodeId, {
      status: 'rejected',
      admin_notes: adminNote || '',
    });

    await sendNotification(base44, node.user_email,
      '❌ Payment Verification Failed',
      `Your Lets VPN Go Paid order could not be verified. ${adminNote ? 'Admin note: ' + adminNote : 'Please contact support via WhatsApp: +27 69 298 7836.'}`,
      'error'
    );

    await sendEmail(base44, node.user_email,
      '❌ Lets VPN Go — Order Issue',
      buildHtmlEmail({
        title: 'Order Issue',
        heading: '❌ Verification Failed',
        subheading: 'Your order could not be processed',
        bodyLines: [
          `Hi <strong style="color:#fff;">${node.user_name}</strong>, unfortunately we couldn't verify your payment.`,
          adminNote ? `<strong style="color:#f87171;">Reason:</strong> ${adminNote}` : '',
          '---',
          '📱 WhatsApp: <strong style="color:#fff;">+27 69 298 7836</strong>',
          'Please contact us so we can resolve this quickly.',
        ].filter(Boolean),
      })
    );

    return Response.json({ ok: true });
  }

  // ── ACTION: renew (admin approves renewal) ───────────────────────────────
  if (action === 'renew') {
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });

    const node = await getNode(nodeId);
    if (!node) return Response.json({ error: 'Node not found' }, { status: 404 });

    const renewPlan = node.renewal_plan || node.plan;
    const planDays  = renewPlan === '30days' ? 30 : renewPlan === '7days' ? 7 : 14;
    // If still active, extend from current expiry; otherwise from now
    const baseEpoch = (node.expiry_epoch && node.expiry_epoch > Date.now()) ? node.expiry_epoch : Date.now();
    const expiryEpoch = baseEpoch + planDays * 24 * 60 * 60 * 1000;
    const expiryDate  = new Date(expiryEpoch).toLocaleDateString('en-ZA', { year: 'numeric', month: 'long', day: 'numeric' });

    await base44.asServiceRole.entities.ISPNode.update(nodeId, {
      status: 'active',
      plan: renewPlan,
      expiry_epoch: expiryEpoch,
      expiry_date: expiryDate,
      renewal_status: 'approved',
      admin_notes: adminNote || node.admin_notes || '',
      vless_string: vlessOverride || node.vless_string || '',
    });

    await sendNotification(base44, node.user_email,
      '🔄 Subscription Renewed!',
      `Your Lets VPN Go Paid subscription has been renewed and is active until ${expiryDate}. Enjoy! 🚀`,
      'success'
    );

    await sendEmail(base44, node.user_email,
      '🔄 Lets VPN Go — Subscription Renewed!',
      buildHtmlEmail({
        title: 'Renewal Confirmed',
        heading: '🔄 Subscription Renewed!',
        subheading: 'Your access continues uninterrupted',
        bodyLines: [
          `Hi <strong style="color:#fff;">${node.user_name}</strong>, your renewal has been approved!`,
          '---',
          `<strong style="color:#fff;">New Expiry:</strong> ${expiryDate}`,
          '---',
          '📲 Open your dashboard to view your updated config.',
        ],
        ctaText: 'Open Dashboard',
        ctaUrl: 'https://mastersdeovex.co.za/ISPNodeDashboard',
      })
    );

    return Response.json({ ok: true, expiryDate });
  }

  // ── ACTION: set_vless ────────────────────────────────────────────────────
  if (action === 'set_vless') {
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });

    const node = await getNode(nodeId);
    if (!node) return Response.json({ error: 'Node not found' }, { status: 404 });

    await base44.asServiceRole.entities.ISPNode.update(nodeId, {
      vless_string: vlessOverride,
      admin_notes:  adminNote || node.admin_notes || '',
    });

    await sendNotification(base44, node.user_email,
      '🔧 Your Config Has Been Updated',
      'Your VPN config has been updated by the admin. Open your dashboard to copy the new config.',
      'info'
    );

    return Response.json({ ok: true });
  }

  // ── ACTION: notify ───────────────────────────────────────────────────────
  if (action === 'notify') {
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });

    const node = await getNode(nodeId);
    if (!node) return Response.json({ error: 'Node not found' }, { status: 404 });

    await sendNotification(base44, node.user_email, title, message, 'info',
      fileUrl ? { file_url: fileUrl, file_name: fileName || 'package-file' } : {}
    );

    await sendEmail(base44, node.user_email, title,
      buildHtmlEmail({
        title: title,
        heading: title,
        subheading: 'Message from Masters DeoVex',
        bodyLines: [message],
        fileUrl: fileUrl || null,
        fileName: fileName || 'Config File',
        ctaText: 'Open Dashboard',
        ctaUrl: 'https://mastersdeovex.co.za/ISPNodeDashboard',
      })
    );

    return Response.json({ ok: true });
  }

  // ── ACTION: remove ───────────────────────────────────────────────────────
  if (action === 'remove') {
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });

    const node = await getNode(nodeId);
    if (!node) return Response.json({ error: 'Node not found' }, { status: 404 });

    const reason = adminNote || 'Your subscription has been removed by the administrator.';

    await base44.asServiceRole.entities.ISPNode.update(nodeId, {
      status: 'rejected',
      vless_string: '',
      admin_notes: reason,
    });

    await sendNotification(base44, node.user_email,
      '🚫 Subscription Removed',
      `Your Lets VPN Go Paid subscription has been removed.\n\nReason: ${reason}\n\nContact support: +27 69 298 7836.`,
      'error'
    );

    await sendEmail(base44, node.user_email,
      '🚫 Lets VPN Go — Subscription Removed',
      buildHtmlEmail({
        title: 'Subscription Removed',
        heading: '🚫 Subscription Removed',
        subheading: 'Your access has been revoked',
        bodyLines: [
          `Hi <strong style="color:#fff;">${node.user_name}</strong>, your subscription has been removed by the administrator.`,
          '---',
          `<strong style="color:#f87171;">Reason:</strong> ${reason}`,
          '---',
          '📱 If you believe this is an error, contact us: <strong style="color:#fff;">+27 69 298 7836</strong>',
        ],
      })
    );

    return Response.json({ ok: true });
  }

  return Response.json({ error: 'Unknown action' }, { status: 400 });
});