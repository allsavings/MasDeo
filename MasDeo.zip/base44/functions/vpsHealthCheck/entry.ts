import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { action, vps_host, vps_token } = await req.json();

    // ── PING SCANNER VPS (fx.tkmaster.qzz.io) ─────────────────────────────
    if (action === 'ping_scanner') {
      if (!vps_host || !vps_token) {
        return Response.json({ error: 'vps_host and vps_token required' }, { status: 400 });
      }

      const apiBase = `https://${vps_host}`;
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 15000);

      let pingOk = false;
      let pingLatency = 0;
      let pingError = null;

      // Step 1: Basic connectivity check
      const t0 = Date.now();
      try {
        const res = await fetch(`${apiBase}/health`, {
          method: 'GET',
          headers: { 'Authorization': `Bearer ${vps_token}` },
          signal: controller.signal,
        });
        clearTimeout(timeout);
        pingLatency = Date.now() - t0;
        pingOk = res.ok || res.status < 500;
      } catch (e) {
        clearTimeout(timeout);
        pingLatency = Date.now() - t0;
        pingError = e.name === 'AbortError' ? 'Timed out (>15s)' : e.message;
        pingOk = false;
      }

      // Step 2: Integration test — try the actual scanner plugin endpoint
      let integrationOk = false;
      let integrationError = null;
      let integrationLatency = 0;

      if (pingOk || pingError) {
        // We test even if basic ping failed (server might block /health but allow /run)
        const ic = new AbortController();
        const it = setTimeout(() => ic.abort(), 20000);
        const t1 = Date.now();
        try {
          const res = await fetch(`${apiBase}/run/M@☆`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${vps_token}`,
            },
            body: JSON.stringify({
              domain: 'google.com',
              hosts_content: 'google.com',
              enable_ip_lookup: false,
              ip_lookup: false,
              full_headers: false,
              enable_full_headers: false,
            }),
            signal: ic.signal,
          });
          clearTimeout(it);
          integrationLatency = Date.now() - t1;
          integrationOk = res.status < 500;
          if (!integrationOk) {
            const txt = await res.text();
            integrationError = `HTTP ${res.status}: ${txt.slice(0, 100)}`;
          }
        } catch (e) {
          clearTimeout(it);
          integrationLatency = Date.now() - t1;
          integrationError = e.name === 'AbortError' ? 'Timed out (>20s)' : e.message;
          integrationOk = false;
        }
      }

      return Response.json({
        vps: 'scanner',
        host: vps_host,
        ping: { ok: pingOk, latency_ms: pingLatency, error: pingError },
        integration: { ok: integrationOk, latency_ms: integrationLatency, error: integrationError, plugin: 'CDNWAF_Scanner [M@☆]' },
        overall: integrationOk,
      });
    }

    // ── PING MEDIA VPS (media.mastersdeovex.co.za) ────────────────────────
    if (action === 'ping_media') {
      const uploadUrl = Deno.env.get('VPS_UPLOAD_URL');
      const uploadSecret = Deno.env.get('VPS_UPLOAD_SECRET');

      if (!uploadUrl || !uploadSecret) {
        return Response.json({ error: 'VPS_UPLOAD_URL or VPS_UPLOAD_SECRET not configured' }, { status: 500 });
      }

      const baseUrl = uploadUrl.replace('/upload', '');

      // Step 1: Upload a dummy test file
      let uploadOk = false;
      let uploadError = null;
      let uploadLatency = 0;
      let testFileUrl = null;

      const dummyContent = `VPS Health Check — ${new Date().toISOString()}`;
      const dummyBlob = new Blob([dummyContent], { type: 'text/plain' });
      const dummyFile = new File([dummyBlob], `healthcheck_${Date.now()}.txt`, { type: 'text/plain' });

      const vpsForm = new FormData();
      vpsForm.append('file', dummyFile);

      const uc = new AbortController();
      const ut = setTimeout(() => uc.abort(), 20000);
      const t2 = Date.now();

      try {
        const res = await fetch(uploadUrl, {
          method: 'POST',
          headers: { 'X-Upload-Secret': uploadSecret },
          body: vpsForm,
          signal: uc.signal,
        });
        clearTimeout(ut);
        uploadLatency = Date.now() - t2;
        if (res.ok) {
          const data = await res.json();
          testFileUrl = data.file_url || null;
          uploadOk = !!testFileUrl;
        } else {
          const errText = await res.text();
          uploadError = `HTTP ${res.status}: ${errText.slice(0, 100)}`;
        }
      } catch (e) {
        clearTimeout(ut);
        uploadLatency = Date.now() - t2;
        uploadError = e.name === 'AbortError' ? 'Upload timed out (>20s)' : e.message;
      }

      // Step 2: Read back the uploaded file to confirm retrieval works
      let retrieveOk = false;
      let retrieveError = null;
      let retrieveLatency = 0;
      let retrievedContent = null;

      if (uploadOk && testFileUrl) {
        const rc = new AbortController();
        const rt = setTimeout(() => rc.abort(), 10000);
        const t3 = Date.now();
        try {
          const res = await fetch(testFileUrl, { signal: rc.signal });
          clearTimeout(rt);
          retrieveLatency = Date.now() - t3;
          if (res.ok) {
            retrievedContent = await res.text();
            retrieveOk = retrievedContent === dummyContent;
            if (!retrieveOk) retrieveError = 'Content mismatch — file retrieved but content differs';
          } else {
            retrieveError = `HTTP ${res.status}`;
          }
        } catch (e) {
          clearTimeout(rt);
          retrieveLatency = Date.now() - t3;
          retrieveError = e.name === 'AbortError' ? 'Retrieve timed out (>10s)' : e.message;
        }
      }

      // Step 3: Clean up the dummy test file
      if (testFileUrl) {
        try {
          await fetch(`${baseUrl}/delete`, {
            method: 'POST',
            headers: { 'X-Upload-Secret': uploadSecret, 'Content-Type': 'application/json' },
            body: JSON.stringify({ file_url: testFileUrl }),
          });
        } catch { /* cleanup failure is non-critical */ }
      }

      return Response.json({
        vps: 'media',
        host: baseUrl.replace('https://', ''),
        upload: { ok: uploadOk, latency_ms: uploadLatency, error: uploadError, test_file: testFileUrl },
        retrieve: { ok: retrieveOk, latency_ms: retrieveLatency, error: retrieveError, content_match: retrieveOk },
        overall: uploadOk && retrieveOk,
      });
    }

    return Response.json({ error: 'Unknown action. Use ping_scanner or ping_media' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});