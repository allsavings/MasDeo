import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { message } = await req.json();

    // Use LLM to understand intent and determine action
    const intentResponse = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an AI assistant managing a Masters DeoVex admin dashboard. 
      
User request: "${message}"

Analyze this request and respond with a JSON object with:
- action: one of [get_stats, toggle_ads, toggle_premium_ads, toggle_free_ads, get_users, get_subscriptions, view_config, help]
- params: object with parameters for the action (if applicable)
- explanation: brief explanation of what you'll do

Respond ONLY with valid JSON, no markdown.`,
      response_json_schema: {
        type: 'object',
        properties: {
          action: { type: 'string' },
          params: { type: 'object' },
          explanation: { type: 'string' }
        }
      },
      model: 'gemini_3_flash'
    });

    let actionResult = '';

    // Execute the identified action
    switch (intentResponse.action) {
      case 'get_stats': {
        const users = await base44.entities.UserProfile.list();
        const subs = await base44.entities.Subscription.list();
        const config = await base44.entities.AppConfig.list();
        actionResult = `📊 Current Stats:\n- Total Users: ${users.length}\n- Active Subscriptions: ${subs.filter(s => s.status === 'active').length}\n- App Config: ${JSON.stringify(config[0] || {})}`;
        break;
      }

      case 'toggle_ads': {
        const config = await base44.entities.AppConfig.list();
        const current = config[0];
        if (!current) {
          await base44.asServiceRole.entities.AppConfig.create({ key: 'global', ads_enabled: false });
          actionResult = '✓ Ads disabled globally';
        } else {
          await base44.asServiceRole.entities.AppConfig.update(current.id, { ads_enabled: !current.ads_enabled });
          actionResult = `✓ Ads ${!current.ads_enabled ? 'enabled' : 'disabled'} globally`;
        }
        break;
      }

      case 'toggle_premium_ads': {
        const config = await base44.entities.AppConfig.list();
        const current = config[0];
        if (!current) {
          await base44.asServiceRole.entities.AppConfig.create({ key: 'global', premium_ads_enabled: true });
          actionResult = '✓ Premium ads enabled';
        } else {
          await base44.asServiceRole.entities.AppConfig.update(current.id, { premium_ads_enabled: !current.premium_ads_enabled });
          actionResult = `✓ Premium ads ${!current.premium_ads_enabled ? 'enabled' : 'disabled'}`;
        }
        break;
      }

      case 'toggle_free_ads': {
        const config = await base44.entities.AppConfig.list();
        const current = config[0];
        if (!current) {
          await base44.asServiceRole.entities.AppConfig.create({ key: 'global', free_ads_enabled: true });
          actionResult = '✓ Free user ads enabled';
        } else {
          await base44.asServiceRole.entities.AppConfig.update(current.id, { free_ads_enabled: !current.free_ads_enabled });
          actionResult = `✓ Free user ads ${!current.free_ads_enabled ? 'enabled' : 'disabled'}`;
        }
        break;
      }

      case 'get_users': {
        const users = await base44.entities.UserProfile.list();
        const summary = users.slice(0, 5).map(u => `- ${u.nickname} (${u.membership_type})`).join('\n');
        actionResult = `👥 Recent Users (showing 5 of ${users.length}):\n${summary}`;
        break;
      }

      case 'get_subscriptions': {
        const subs = await base44.entities.Subscription.list();
        const active = subs.filter(s => s.status === 'active');
        const pending = subs.filter(s => s.status === 'pending');
        actionResult = `📋 Subscriptions:\n- Active: ${active.length}\n- Pending: ${pending.length}\n- Total: ${subs.length}`;
        break;
      }

      case 'view_config': {
        const config = await base44.entities.AppConfig.list();
        const current = config[0] || {};
        actionResult = `⚙️ Current Configuration:\n${Object.entries(current).map(([k, v]) => `- ${k}: ${v}`).join('\n')}`;
        break;
      }

      default: {
        actionResult = `I understood your request: "${intentResponse.explanation}" but I need more specific admin actions available. Try asking me to: toggle ads, show user stats, view subscriptions, or access configuration.`;
      }
    }

    // Generate natural response combining action + result
    const finalResponse = await base44.integrations.Core.InvokeLLM({
      prompt: `You're an admin AI assistant. The user asked: "${message}"

You performed this action: ${intentResponse.explanation}

Result: ${actionResult}

Respond naturally and conversationally, incorporating the result. Keep it concise and friendly.`,
      model: 'gemini_3_flash'
    });

    return Response.json({ response: finalResponse });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});