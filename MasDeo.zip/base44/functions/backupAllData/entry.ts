import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const ENTITIES = [
  'UserProfile', 'Subscription', 'CreatorProfile', 'CreatorSettings',
  'Follow', 'Withdrawal', 'VpnFile', 'CreatorVpnFile', 'CreatorVpsServer',
  'CreatorCourse', 'CreatorResource', 'HostedWebsite', 'VpsServer',
  'AppNotification', 'ContentView', 'ContentDownload', 'ContentReaction',
  'ContentComment', 'ForexSignal', 'CourseContent', 'PasswordVault'
];

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const backupData = {};
    const stats = {};

    for (const entity of ENTITIES) {
      try {
        const records = await base44.asServiceRole.entities[entity].list('-created_date', 1000);
        backupData[entity] = records;
        stats[entity] = records.length;
      } catch {
        backupData[entity] = [];
        stats[entity] = 0;
      }
    }

    const payload = {
      version: '2.0',
      app: 'MastersDeoVex',
      backed_up_by: user.email,
      backed_up_at: new Date().toISOString(),
      total_records: Object.values(stats).reduce((a, b) => a + b, 0),
      stats,
      data: backupData,
    };

    const jsonStr = JSON.stringify(payload);
    const filename = `snapshot_${new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)}.json`;

    const uploadUrl = Deno.env.get('VPS_UPLOAD_URL');
    const uploadSecret = Deno.env.get('VPS_UPLOAD_SECRET');

    const blob = new Blob([jsonStr], { type: 'application/json' });
    const form = new FormData();
    form.append('file', new File([blob], filename, { type: 'application/json' }));

    const vpsRes = await fetch(uploadUrl, {
      method: 'POST',
      headers: { 'X-Upload-Secret': uploadSecret },
      body: form,
    });

    if (!vpsRes.ok) {
      const err = await vpsRes.text();
      return Response.json({ error: `VPS upload failed: ${err}` }, { status: 502 });
    }

    const result = await vpsRes.json();

    return Response.json({
      success: true,
      snapshot_url: result.file_url,
      filename,
      stats,
      total: payload.total_records,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});