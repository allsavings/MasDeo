import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const formData = await req.formData();
    const file = formData.get('file');

    if (!file) {
      return Response.json({ error: 'No file provided' }, { status: 400 });
    }

    const uploadUrl = Deno.env.get('VPS_UPLOAD_URL');
    const uploadSecret = Deno.env.get('VPS_UPLOAD_SECRET');

    if (!uploadUrl || !uploadSecret) {
      return Response.json({ error: 'VPS upload not configured' }, { status: 500 });
    }

    // Forward the file to the VPS upload endpoint
    const vpsForm = new FormData();
    vpsForm.append('file', file);

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000); // 30s timeout

    let vpsResponse;
    try {
      vpsResponse = await fetch(uploadUrl, {
        method: 'POST',
        headers: { 'X-Upload-Secret': uploadSecret },
        body: vpsForm,
        signal: controller.signal,
      });
    } catch (fetchErr) {
      clearTimeout(timeout);
      if (fetchErr.name === 'AbortError') {
        return Response.json({ error: 'Upload timed out — VPS did not respond in time' }, { status: 504 });
      }
      return Response.json({ error: `Cannot reach VPS: ${fetchErr.message}` }, { status: 502 });
    }
    clearTimeout(timeout);

    if (!vpsResponse.ok) {
      const errText = await vpsResponse.text();
      return Response.json({ error: `VPS upload failed: ${errText}` }, { status: 502 });
    }

    const result = await vpsResponse.json();
    // Expect VPS to return { file_url: "https://media.mastersdeovex.co.za/uploads/filename.ext" }
    return Response.json({ file_url: result.file_url });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});