import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    // Try calling resetPasswordRequest to see what token format it triggers
    // and whether we can then call resetPassword from backend
    const body = await req.json();
    const { email, token, newPassword } = body;
    
    if (token && newPassword) {
      // Try calling resetPassword from backend context
      const result = await base44.auth.resetPassword({ resetToken: token, newPassword });
      return Response.json({ result });
    }
    
    if (email) {
      await base44.auth.resetPasswordRequest(email);
      return Response.json({ sent: true });
    }
    
    return Response.json({ error: 'provide email or token+newPassword' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message, stack: error.stack }, { status: 500 });
  }
});