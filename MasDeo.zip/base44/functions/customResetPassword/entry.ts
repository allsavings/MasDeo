import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    if (req.method !== 'POST') {
      return Response.json({ error: 'Method not allowed' }, { status: 405 });
    }

    const base44 = createClientFromRequest(req);
    const { email } = await req.json();

    if (!email) {
      return Response.json({ error: 'Email is required' }, { status: 400 });
    }

    // Use Base44's resetPasswordRequest which returns a token
    // Then we construct the custom domain reset URL
    try {
      await base44.auth.resetPasswordRequest(email);
      
      // Return success — the reset email will be sent by Base44
      // Note: Base44 will send the email with its default domain
      // To use a custom domain for the reset link, you need to:
      // 1. Set up mastersdeovex.co.za as a custom domain in Base44 dashboard
      // 2. Configure the reset password URL in Base44 settings
      // 3. Or implement a custom email service to intercept and modify the reset URL
      
      return Response.json({
        success: true,
        message: 'Reset link sent to email'
      });
    } catch (err) {
      return Response.json({
        error: err.message || 'Failed to send reset link'
      }, { status: 400 });
    }
  } catch (error) {
    return Response.json({
      error: error.message || 'Server error'
    }, { status: 500 });
  }
});