import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

function decode(encoded) {
  const key = 'MDV2025XK';
  const str = atob(encoded);
  let result = '';
  for (let i = 0; i < str.length; i++) {
    result += String.fromCharCode(str.charCodeAt(i) ^ key.charCodeAt(i % key.length));
  }
  return result;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Admin-only: must be authenticated as admin
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const body = await req.json();
    const { email, action } = body; // action: 'send_email' | 'auto_reset'

    if (!email || !action) {
      return Response.json({ error: 'Email and action required' }, { status: 400 });
    }

    // Look up vault entry
    const entries = await base44.asServiceRole.entities.PasswordVault.filter({ email });
    if (entries.length === 0) {
      return Response.json({ error: 'No vault entry found for this email' }, { status: 404 });
    }

    const password = decode(entries[0].encoded_password);

    if (action === 'send_email') {
      // Email the user their password
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: email,
        subject: 'Masters | DeoVex — Your Account Password',
        body: `Hello,\n\nYour current account password for Masters | DeoVex is:\n\n  ${password}\n\nIf you did not request this, please contact support immediately and change your password.\n\nStay safe,\nMasters | DeoVex Team`
      });
      return Response.json({ success: true, message: `Password sent to ${email}` });
    }

    if (action === 'auto_reset') {
      // Trigger platform password reset email for this user
      // The ResetPassword page will auto-apply the vault password when they click the link
      sessionStorage_key_ignored: true; // note: this is backend, we store it differently

      // Store a recovery request with the vault password so the reset page can use it
      // Actually: trigger resetPasswordRequest — user clicks email — they get the standard form
      // Better: email them their password + a reset link so they can change it
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: email,
        subject: 'Masters | DeoVex — Password Reset',
        body: `Hello,\n\nYour account password has been reset by the Masters | DeoVex admin team.\n\nYour current password is:\n\n  ${password}\n\nYou can use this to sign in at: https://app.base44.com\n\nWe recommend changing your password after signing in.\n\nMasters | DeoVex Team`
      });

      // Also trigger the platform reset so they can choose a new password via the standard flow
      await base44.auth.resetPasswordRequest(email);

      return Response.json({ success: true, message: `Password emailed and reset link sent to ${email}` });
    }

    return Response.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});