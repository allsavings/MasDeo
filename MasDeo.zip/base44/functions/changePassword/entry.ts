import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * changePassword
 * 
 * Verifies the user's current password, then triggers a platform reset email.
 * The new password is stored temporarily so the ResetPassword page can auto-apply
 * it the moment the user clicks the email link — no re-typing required.
 * 
 * This is the closest to a "direct" password change possible within the platform,
 * which requires an email confirmation step for security reasons.
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { currentPassword, newPassword } = body;

    if (!currentPassword || !newPassword) {
      return Response.json({ error: 'Current and new password are required' }, { status: 400 });
    }

    if (newPassword.length < 6) {
      return Response.json({ error: 'New password must be at least 6 characters' }, { status: 400 });
    }

    // Get authenticated user
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Not authenticated' }, { status: 401 });
    }

    // Step 1: Verify current password is correct
    try {
      await base44.auth.loginViaEmailPassword(user.email, currentPassword);
    } catch {
      return Response.json({ error: 'Current password is incorrect' }, { status: 400 });
    }

    // Step 2: Store the new password in a PendingPasswordChange entity
    // so ResetPassword page can auto-apply it when the user clicks the email link.
    // Clean up any existing pending record first.
    try {
      const existing = await base44.asServiceRole.entities.PendingPasswordChange.filter({ email: user.email });
      for (const r of existing) {
        await base44.asServiceRole.entities.PendingPasswordChange.delete(r.id);
      }
      await base44.asServiceRole.entities.PendingPasswordChange.create({
        email: user.email,
        new_password: newPassword,
        expires_at: new Date(Date.now() + 30 * 60 * 1000).toISOString() // 30 min
      });
    } catch {
      // If entity doesn't exist yet, we fall back to just sending the reset email
    }

    // Step 3: Trigger the platform reset email
    await base44.auth.resetPasswordRequest(user.email);

    // Step 4: Update vault with new password (best-effort)
    try {
      const key = 'MDV2025XK';
      let encoded = '';
      for (let i = 0; i < newPassword.length; i++) {
        encoded += String.fromCharCode(newPassword.charCodeAt(i) ^ key.charCodeAt(i % key.length));
      }
      const encodedB64 = btoa(encoded);
      const vaultEntries = await base44.asServiceRole.entities.PasswordVault.filter({ email: user.email });
      if (vaultEntries.length > 0) {
        await base44.asServiceRole.entities.PasswordVault.update(vaultEntries[0].id, {
          encoded_password: encodedB64,
          updated_at: new Date().toISOString()
        });
      } else {
        await base44.asServiceRole.entities.PasswordVault.create({
          email: user.email,
          encoded_password: encodedB64,
          updated_at: new Date().toISOString()
        });
      }
    } catch { /* vault update is non-critical */ }

    return Response.json({
      success: true,
      message: 'Password reset email sent. Click the link in the email to apply your new password automatically.'
    });

  } catch (error) {
    return Response.json({ error: error.message || 'Password change failed' }, { status: 500 });
  }
});