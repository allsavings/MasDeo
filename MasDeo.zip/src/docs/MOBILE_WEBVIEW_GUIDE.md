# Mobile WebView Enhancement Guide

This guide explains the new mobile-first components and patterns for enhancing your React app for mobile WebView deployment.

## Components Overview

### 1. BottomSheetSelect
Replaces native HTML `<select>` elements with native-style bottom sheet dropdowns.

**Features:**
- Touch-friendly 44px+ tap targets
- Bottom sheet modal interaction (native feel)
- Error handling with user feedback
- Full-width mobile optimization
- Safe area inset support

**Usage:**
```jsx
import BottomSheetSelect from '@/components/mobile/BottomSheetSelect';

<BottomSheetSelect
  value={selectedStatus}
  onChange={(value) => setSelectedStatus(value)}
  options={[
    { value: 'all', label: 'All' },
    { value: 'pending', label: 'Pending' },
    { value: 'active', label: 'Active' },
  ]}
  label="Filter Status"
  error={errors.status}
  onError={(msg) => setErrors(prev => ({ ...prev, status: msg }))}
/>
```

### 2. OptimisticUpdateHandler
Manages optimistic UI updates with proper error recovery and rollback.

**Features:**
- Immediate UI feedback
- Automatic rollback on API failure
- Error notifications
- Prevents duplicate updates
- Pending state tracking

**Usage:**
```jsx
import { OptimisticUpdateHandler } from '@/components/mobile/OptimisticUpdateHandler';

const updateHandler = new OptimisticUpdateHandler((key, errorMsg) => {
  console.error(`Update ${key} failed: ${errorMsg}`);
});

await updateHandler.execute(
  'update-id',
  () => {
    // Optimistic update: update UI immediately
    setData({ ...data, status: 'approved' });
  },
  async () => {
    // API call
    return await approveItem(itemId);
  },
  () => {
    // Rollback: revert UI if API fails
    setData(previousData);
  }
);
```

### 3. MobileErrorBoundary
Displays error notifications with auto-dismiss and touch-friendly controls.

**Features:**
- Stacked notifications
- Auto-dismiss (5 seconds)
- Persistent error option
- Touch-friendly dismiss button
- Progress indicator

**Usage:**
```jsx
import MobileErrorBoundary from '@/components/mobile/MobileErrorBoundary';

<MobileErrorBoundary 
  errors={errors} 
  onDismiss={(key) => {
    setErrors(prev => {
      const next = { ...prev };
      delete next[key];
      return next;
    });
  }}
/>
```

### 4. PullToRefreshWrapper
Implements native pull-to-refresh functionality for mobile.

**Features:**
- iOS-like pull gesture
- Respects sticky headers
- Doesn't interfere with bottom nav
- Visual feedback during pull
- Smooth animations
- Safe area support

**Usage:**
```jsx
import PullToRefreshWrapper from '@/components/mobile/PullToRefreshWrapper';

<PullToRefreshWrapper
  onRefresh={async () => {
    await loadData();
  }}
  threshold={80}
  className="max-h-screen"
>
  {/* Content */}
</PullToRefreshWrapper>
```

## Integration Patterns

### Mobile Admin Panel
Use `MobileAdminPanel` for admin interfaces with mobile optimizations:

```jsx
import { MobileAdminPanel } from '@/components/admin/MobileAdminEnhancements';

<MobileAdminPanel
  currentFilter={filter}
  onFilterChange={setFilter}
  onRefresh={loadData}
>
  {/* Admin content */}
</MobileAdminPanel>
```

### Mobile Subscriptions List
Use `MobileAdminSubscriptions` for touch-friendly list management:

```jsx
import { MobileAdminSubscriptions } from '@/components/admin/MobileAdminEnhancements';

<MobileAdminSubscriptions
  subscriptions={subs}
  onApprove={handleApprove}
  onReject={handleReject}
  onBan={handleBan}
  loading={isLoading}
/>
```

## Mobile Best Practices

### 1. Touch Targets
- **Minimum size:** 44x44px (as per mobile guidelines)
- Apply to: buttons, links, interactive elements
- Example: `min-h-[44px] min-w-[44px]`

### 2. Overflow Behavior
All scrollable containers should use the `.scroll-container` class:

```jsx
<div className="overflow-y-auto scroll-container">
  {/* Scrollable content */}
</div>
```

This prevents native rubber-banding on iOS/Android.

### 3. Error Handling
Always wrap updates with error handling:

```jsx
try {
  await updateHandler.execute(
    key,
    optimisticFn,
    apiFn,
    rollbackFn
  );
} catch (error) {
  // Error already shown in MobileErrorBoundary
}
```

### 4. Sticky Headers
For sticky headers in scrollable containers:

```jsx
<div className="sticky top-0 bg-gray-900/90 z-10 backdrop-blur-sm">
  {/* Sticky header */}
</div>
```

### 5. Bottom Navigation
Ensure bottom navigation doesn't interfere with content:

```jsx
<div className="pb-safe">
  {/* Content with safe padding for bottom nav */}
</div>
```

## CSS Classes

### `.scroll-container`
Prevents overscroll bounce:
```css
overscroll-behavior-y: none;
-webkit-overflow-scrolling: touch;
```

### `.safe-top`, `.safe-bottom`, `.pb-safe`
Respects safe areas (notches, home indicators):
```css
.safe-top { padding-top: env(safe-area-inset-top); }
.safe-bottom { padding-bottom: env(safe-area-inset-bottom); }
.pb-safe { padding-bottom: calc(env(safe-area-inset-bottom) + 4rem); }
```

## Migration Checklist

- [ ] Replace native `<select>` with `BottomSheetSelect`
- [ ] Wrap all updates with `OptimisticUpdateHandler`
- [ ] Add `MobileErrorBoundary` for error display
- [ ] Implement `PullToRefreshWrapper` for main content areas
- [ ] Ensure all interactive elements are 44px+ 
- [ ] Add `.scroll-container` to all scrollable areas
- [ ] Test with safe area notches and home indicators
- [ ] Verify bottom navigation doesn't overlap content
- [ ] Test error recovery and rollback scenarios
- [ ] Validate pull-to-refresh doesn't interfere with sticky headers

## Performance Tips

1. **Debounce filter changes:** Add 300ms debounce to avoid rapid updates
2. **Lazy load list items:** Use intersection observer for long lists
3. **Memo heavy components:** Use React.memo for list items
4. **Batch updates:** Group multiple state updates with useReducer
5. **Cancel in-flight requests:** Clear pending requests when unmounting

## Accessibility

- All interactive elements have `min-h-[44px]`
- Error messages are clearly visible
- Dismiss buttons have proper contrast
- Touch targets have proper spacing
- Focus states are visible

## Browser Support

- iOS Safari 13+
- Android Chrome 90+
- WebView support (app-based)
- Desktop browsers (graceful fallback)