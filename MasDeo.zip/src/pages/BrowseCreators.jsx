import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { ArrowLeft, Search } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Input } from '@/components/ui/input';
import ExploreCreatorsView from '../components/creator/ExploreCreatorsView';

export default function BrowseCreators() {
  const [creators, setCreators] = useState([]);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    loadCreators();
  }, []);

  const loadCreators = async () => {
    const allCreators = await base44.entities.CreatorProfile.filter({ banned: false });
    
    // Fetch user profiles, creator settings, and follower counts for each creator
    const creatorsWithProfiles = await Promise.all(
      allCreators.map(async (creator) => {
        const [profiles, settings, followers] = await Promise.all([
          base44.entities.UserProfile.filter({ created_by: creator.user_email }),
          base44.entities.CreatorSettings.filter({ user_email: creator.user_email }),
          base44.entities.Follow.filter({ creator_id: creator.id })
        ]);
        return {
          ...creator,
          profile: profiles[0] || null,
          settings: settings[0] || null,
          followerCount: followers.length
        };
      })
    );
    
    // Filter only creators who are public and not banned
    const publicCreators = creatorsWithProfiles.filter(creator => {
      return !creator.banned &&
             creator.settings?.is_public === true && 
             (creator.settings?.platforms?.length > 0 || creator.settings?.all_platforms === true);
    });
    
    setCreators(publicCreators);
  };

  const filteredCreators = creators.filter(creator => {
    if (filter === 'all') return true;
    
    // Map filter values to platform names
    const filterMap = {
      'ethical_free_internet': 'ethical',
      'learn_digital_skills': 'learn',
      'earn_online': 'earn'
    };
    
    const platformName = filterMap[filter];
    if (!platformName) return false;
    
    // Check if creator is on all platforms OR this specific platform
    return creator.settings?.all_platforms === true || 
           creator.settings?.platforms?.includes(platformName);
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center gap-4 mb-6">
          <Link to={createPageUrl("Home")} className="p-2 bg-gray-800/50 rounded-xl">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-xl font-bold">Browse Creators</h1>
        </div>

        <div className="mb-6">
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
            <Input
              placeholder="Search creators..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 bg-gray-800/50 border-gray-700"
            />
          </div>

          <div className="flex gap-2 overflow-x-auto pb-2">
            {['all', 'ethical_free_internet', 'learn_digital_skills', 'earn_online'].map((type) => (
              <button
                key={type}
                onClick={() => setFilter(type)}
                className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-colors ${
                  filter === type
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-800/50 text-gray-400 hover:bg-gray-700/50'
                }`}
              >
                {type === 'all' ? 'All' : type.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
              </button>
            ))}
          </div>
        </div>

        <ExploreCreatorsView 
          creators={filteredCreators} 
          loading={false}
          theme="ethical"
        />
      </div>
    </div>
  );
}