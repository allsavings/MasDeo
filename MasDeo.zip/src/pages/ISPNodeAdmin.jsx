import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft, CheckCircle, XCircle, RefreshCw, Clock, Loader, Server,
  Eye, ChevronDown, ChevronUp, Copy, Check, Bell, Mail, Edit3,
  Users, TrendingUp, DollarSign, Calendar, Shield, Zap, Filter,
  MessageSquare, Send, X, AlertCircle, Activity, Package, Upload,
  Share2, Trash2
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';

const TABS = ['Pending', 'Active', 'Expired', 'All'];

const STATUS_CFG = {
  pending_payment:  { label: 'Pending Payment',  color: 'text-yellow-400', bg: 'bg-yellow-500/10 border-yellow-500/30' },
  pending_approval: { label: 'Awaiting Approval', color: 'text-amber-400',  bg: 'bg-amber-500/10 border-amber-500/30' },
  active:           { label: 'Active',             color: 'text-green-400',  bg: 'bg-green-500/10 border-green-500/30' },
  expired:          { label: 'Expired',            color: 'text-red-400',    bg: 'bg-red-500/10 border-red-500/30' },
  rejected:         { label: 'Rejected',           color: 'text-red-400',    bg: 'bg-red-500/10 border-red-500/30' },
};

function CopyBtn({ text, size = 'sm' }) {
  const [copied, setCopied] = useState(false);
  const handle = () => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 1500); };
  return (
    <button onClick={handle} className="flex-shrink-0 p-1.5 rounded-lg bg-gray-700/60 hover:bg-gray-600/60 transition-all">
      {copied ? <Check className={`text-green-400 ${size === 'xs' ? 'w-3 h-3' : 'w-3.5 h-3.5'}`} /> : <Copy className={`text-gray-400 ${size === 'xs' ? 'w-3 h-3' : 'w-3.5 h-3.5'}`} />}
    </button>
  );
}

// ── Approve Modal ─────────────────────────────────────────────────────────────
function ApproveModal({ node, onClose, onDone }) {
  const [vless, setVless] = useState(node.vless_string || '');
  const [note, setNote] = useState('');
  const [loading, setLoading] = useState(false);
  const [fileUrl, setFileUrl] = useState('');
  const [fileName, setFileName] = useState('');
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef();

  const detectType = () => {
    const n = (node.admin_notes || '').toLowerCase();
    if (n.includes('netmod')) return 'NetMod Config';
    if (n.includes('npv')) return 'NPV Tunnel Config';
    if (n.includes('letsvpngo')) return 'Lets VPN Go Config';
    return 'NPV Tunnel Config';
  };
  const [configType, setConfigType] = useState(detectType);

  const handleUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    setFileName(file.name);
    try {
      const { uploadFile } = await import('@/components/vpsAPI');
      const result = await uploadFile(file);
      setFileUrl(result.url);
    } catch {
      setFileUrl('');
    }
    setUploading(false);
  };

  const handle = async () => {
    // Allow approve with just a file (no config string required)
    if (!vless && !fileUrl) {
      alert('Please enter a config string or attach a config file.');
      return;
    }
    setLoading(true);
    await base44.functions.invoke('ispNodeDeploy', {
      action: 'approve',
      nodeId: node.id,
      vlessOverride: vless || undefined,
      adminNote: `${configType}|${note}`,
      fileUrl: fileUrl || undefined,
      fileName: fileName || undefined,
    });
    setLoading(false);
    onDone();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm px-4 pb-6" onClick={onClose}>
      <motion.div initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 60, opacity: 0 }}
        className="w-full max-w-lg bg-[#13131f] border border-green-500/30 rounded-3xl p-5 shadow-2xl max-h-[90vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-white">✅ Approve Node</h3>
          <button onClick={onClose} className="p-1.5 rounded-xl bg-gray-800/60 text-gray-400"><X className="w-4 h-4" /></button>
        </div>
        <div className="bg-gray-900/60 rounded-xl p-3 mb-3 text-xs space-y-1.5">
          <p className="text-gray-400">User: <span className="text-white font-bold">{node.user_name}</span></p>
          <p className="text-gray-400">Email: <span className="text-gray-300 font-mono">{node.user_email}</span></p>
          <p className="text-gray-400">Plan: <span className="text-cyan-400 font-bold">{node.plan === '7days' ? 'R20 / 7 days' : node.plan === '30days' ? 'R50 / 30 days' : 'R30 / 14 days'}</span></p>
          <p className="text-gray-400">WhatsApp: <span className="text-green-400 font-bold">{node.whatsapp || '—'}</span></p>
          {node.admin_notes && <p className="text-gray-400">Notes: <span className="text-gray-300">{node.admin_notes}</span></p>}
        </div>
        <p className="text-xs text-gray-400 mb-1.5">Config Type <span className="text-gray-600">(shown to user)</span></p>
        <div className="flex flex-wrap gap-1.5 mb-3">
          {['NPV Tunnel Config', 'NetMod Config', 'Lets VPN Go Config', 'Generic Paid Config'].map(t => (
            <button key={t} onClick={() => setConfigType(t)}
              className={`px-2.5 py-1.5 rounded-xl border text-[11px] font-semibold transition-all ${configType === t ? 'border-green-500/60 bg-green-500/15 text-green-300' : 'border-gray-700/50 bg-gray-800/40 text-gray-400'}`}>
              {t}
            </button>
          ))}
        </div>
        <p className="text-xs text-gray-400 mb-1.5">Config String <span className="text-gray-600">(paste from server — or attach file below)</span></p>
        <textarea value={vless} onChange={e => setVless(e.target.value)} rows={4}
          placeholder="vless://uuid@host:port?... (optional if attaching file)"
          className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-3 py-2.5 text-xs font-mono text-cyan-200 focus:outline-none focus:border-green-500/50 resize-none mb-3" />

        {/* File Attachment */}
        <p className="text-xs text-gray-400 mb-1.5">📎 Attach Config File <span className="text-gray-600">(optional — .ovpn, .json, .txt, etc.)</span></p>
        <input ref={fileRef} type="file" accept="*/*" className="hidden" onChange={handleUpload} />
        <button onClick={() => fileRef.current?.click()}
          className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border text-xs font-semibold transition-all mb-3 ${fileUrl ? 'border-green-500/50 bg-green-500/10 text-green-300' : 'border-gray-600/50 bg-gray-800/40 text-gray-400 hover:border-green-500/40'}`}>
          {uploading ? <Loader className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
          {uploading ? 'Uploading to media.mastersdeovex.co.za...' : fileUrl ? `✓ ${fileName}` : 'Upload Config File'}
        </button>

        <p className="text-xs text-gray-400 mb-1.5">Admin Note <span className="text-gray-600">(sent to user)</span></p>
        <input value={note} onChange={e => setNote(e.target.value)} placeholder="e.g. Config activated — enjoy!"
          className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-green-500/50 mb-4" />
        <p className="text-[10px] text-gray-600 mb-2">Config string OR file is required — both are optional together.</p>
        <button onClick={handle} disabled={loading || uploading}
          className="w-full py-3 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-green-600 to-emerald-600 disabled:opacity-50 flex items-center justify-center gap-2">
          {loading ? <><Loader className="w-4 h-4 animate-spin" /> Approving & Notifying...</> : '✅ Approve + Send Notification'}
        </button>
      </motion.div>
    </div>
  );
}

// ── Reject Modal ──────────────────────────────────────────────────────────────
function RejectModal({ node, onClose, onDone }) {
  const [note, setNote] = useState('');
  const [loading, setLoading] = useState(false);

  const handle = async () => {
    setLoading(true);
    await base44.functions.invoke('ispNodeDeploy', { action: 'reject', nodeId: node.id, adminNote: note });
    setLoading(false);
    onDone();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm px-4 pb-6" onClick={onClose}>
      <motion.div initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 60, opacity: 0 }}
        className="w-full max-w-lg bg-[#13131f] border border-red-500/30 rounded-3xl p-5 shadow-2xl"
        onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-white">❌ Reject Order</h3>
          <button onClick={onClose} className="p-1.5 rounded-xl bg-gray-800/60 text-gray-400"><X className="w-4 h-4" /></button>
        </div>
        <p className="text-xs text-gray-400 mb-1.5">Reason <span className="text-gray-600">(sent to user via notification + email)</span></p>
        <textarea value={note} onChange={e => setNote(e.target.value)} rows={3}
          placeholder="e.g. Payment screenshot unclear. Please resend to +27 69 298 7836"
          className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-red-500/50 resize-none mb-4" />
        <button onClick={handle} disabled={loading}
          className="w-full py-3 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-red-600 to-rose-600 disabled:opacity-50 flex items-center justify-center gap-2">
          {loading ? <><Loader className="w-4 h-4 animate-spin" /> Rejecting...</> : '❌ Reject + Notify User'}
        </button>
      </motion.div>
    </div>
  );
}

// ── Notify Modal ──────────────────────────────────────────────────────────────
function NotifyModal({ node, onClose }) {
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handle = async () => {
    if (!title || !message) return;
    setLoading(true);
    await base44.functions.invoke('ispNodeDeploy', { action: 'notify', nodeId: node.id, title, message });
    setLoading(false);
    setSent(true);
    setTimeout(onClose, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm px-4 pb-6" onClick={onClose}>
      <motion.div initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 60, opacity: 0 }}
        className="w-full max-w-lg bg-[#13131f] border border-blue-500/30 rounded-3xl p-5 shadow-2xl"
        onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-white">📣 Send Notification</h3>
          <button onClick={onClose} className="p-1.5 rounded-xl bg-gray-800/60 text-gray-400"><X className="w-4 h-4" /></button>
        </div>
        <p className="text-[10px] text-gray-500 mb-3">Sends in-app notification + email to <span className="text-white">{node.user_email}</span></p>
        <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Notification title..."
          className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-blue-500/50 mb-2" />
        <textarea value={message} onChange={e => setMessage(e.target.value)} rows={3} placeholder="Message body..."
          className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-blue-500/50 resize-none mb-4" />
        {sent ? (
          <div className="text-center py-2 text-green-400 font-bold text-sm">✅ Sent!</div>
        ) : (
          <button onClick={handle} disabled={loading || !title || !message}
            className="w-full py-3 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-blue-600 to-cyan-600 disabled:opacity-40 flex items-center justify-center gap-2">
            {loading ? <><Loader className="w-4 h-4 animate-spin" /> Sending...</> : <><Send className="w-4 h-4" /> Send Notification + Email</>}
          </button>
        )}
      </motion.div>
    </div>
  );
}

// ── Send Package Modal ────────────────────────────────────────────────────────
function SendPackageModal({ node, onClose }) {
  const [fileUrl, setFileUrl] = useState('');
  const [fileName, setFileName] = useState('');
  const [instructions, setInstructions] = useState('');
  const [title, setTitle] = useState('📦 Your VPN Package is Ready!');
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const fileRef = useRef();

  const handleUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    setUploadError('');
    setFileName(file.name);
    try {
      const { uploadFile } = await import('@/components/vpsAPI');
      const result = await uploadFile(file);
      setFileUrl(result.url);
    } catch (err) {
      setUploadError(`Upload failed: ${err.message}`);
    }
    setUploading(false);
  };

  const handle = async () => {
    if (!instructions && !fileUrl) return;
    setLoading(true);
    await base44.functions.invoke('ispNodeDeploy', {
      action: 'notify',
      nodeId: node.id,
      title,
      message: instructions,
      fileUrl: fileUrl || undefined,
      fileName: fileName || undefined,
    });
    setLoading(false);
    setSent(true);
    setTimeout(onClose, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm px-4 pb-6" onClick={onClose}>
      <motion.div initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 60, opacity: 0 }}
        className="w-full max-w-lg bg-[#13131f] border border-orange-500/30 rounded-3xl p-5 shadow-2xl max-h-[85vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-white">📦 Send Package to User</h3>
          <button onClick={onClose} className="p-1.5 rounded-xl bg-gray-800/60 text-gray-400"><X className="w-4 h-4" /></button>
        </div>
        <div className="bg-gray-900/60 rounded-xl p-3 mb-3 text-xs space-y-1">
          <p className="text-gray-400">To: <span className="text-white font-bold">{node.user_name}</span> <span className="text-gray-500 font-mono">({node.user_email})</span></p>
          {node.whatsapp && <p className="text-gray-400">WhatsApp: <span className="text-green-400">{node.whatsapp}</span></p>}
        </div>

        {/* Notification Title */}
        <p className="text-xs text-gray-400 mb-1.5">Notification Title</p>
        <input value={title} onChange={e => setTitle(e.target.value)}
          className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-orange-500/50 mb-3" />

        {/* Instructions */}
        <p className="text-xs text-gray-400 mb-1.5">Setup Instructions / Message</p>
        <textarea value={instructions} onChange={e => setInstructions(e.target.value)} rows={5}
          placeholder="e.g. Here is your VPN config package. Steps to install:&#10;1. Download the file below&#10;2. Open NPV Tunnel → Import → paste/load file&#10;3. Connect and enjoy!"
          className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-orange-500/50 resize-none mb-3" />

        {/* File Upload */}
        <p className="text-xs text-gray-400 mb-1.5">📎 Attach Package File <span className="text-gray-600">(optional — .zip, .ovpn, .txt, image, etc.)</span></p>
        <input ref={fileRef} type="file" accept="*/*" className="hidden" onChange={handleUpload} />
        <button onClick={() => fileRef.current?.click()}
          className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl border text-xs font-semibold transition-all mb-1 ${fileUrl ? 'border-green-500/50 bg-green-500/10 text-green-300' : 'border-gray-600/50 bg-gray-800/40 text-gray-400 hover:border-orange-500/40'}`}>
          {uploading ? <Loader className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
          {uploading ? 'Uploading to media.mastersdeovex.co.za...' : fileUrl ? `✓ ${fileName}` : 'Upload Package File'}
        </button>
        {uploadError && <p className="text-[10px] text-red-400 mb-2">{uploadError}</p>}
        {fileUrl && <p className="text-[10px] text-green-400 mb-3 truncate">📎 {fileUrl}</p>}
        {!fileUrl && !uploadError && <div className="mb-3" />}

        {sent ? (
          <div className="text-center py-2 text-green-400 font-bold text-sm">✅ Package Sent!</div>
        ) : (
          <button onClick={handle} disabled={loading || uploading || (!instructions && !fileUrl)}
            className="w-full py-3 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-orange-600 to-amber-600 disabled:opacity-40 flex items-center justify-center gap-2">
            {loading ? <><Loader className="w-4 h-4 animate-spin" /> Sending...</> : <><Package className="w-4 h-4" /> Send Package + Notify User</>}
          </button>
        )}
      </motion.div>
    </div>
  );
}

// ── Remove Subscription Modal ─────────────────────────────────────────────────
function RemoveModal({ node, onClose, onDone }) {
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);

  const QUICK_REASONS = [
    'Violated community rules',
    'Fraudulent payment / chargeback',
    'Account sharing detected',
    'Abusive behaviour reported',
  ];

  const handle = async () => {
    if (!reason) return;
    setLoading(true);
    await base44.functions.invoke('ispNodeDeploy', { action: 'remove', nodeId: node.id, adminNote: reason });
    setLoading(false);
    onDone();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm px-4 pb-6" onClick={onClose}>
      <motion.div initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 60, opacity: 0 }}
        className="w-full max-w-lg bg-[#13131f] border border-red-600/40 rounded-3xl p-5 shadow-2xl max-h-[85vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-base font-bold text-white">🚫 Remove Subscription</h3>
          <button onClick={onClose} className="p-1.5 rounded-xl bg-gray-800/60 text-gray-400"><X className="w-4 h-4" /></button>
        </div>
        <div className="bg-gray-900/60 rounded-xl p-3 mb-3 text-xs space-y-1">
          <p className="text-gray-400">User: <span className="text-white font-bold">{node.user_name}</span></p>
          <p className="text-gray-400">Email: <span className="text-gray-300 font-mono">{node.user_email}</span></p>
          <p className="text-gray-400">Plan: <span className="text-cyan-400 font-bold">{node.plan}</span></p>
        </div>
        <p className="text-xs text-gray-400 mb-2">Quick reason <span className="text-gray-600">(tap to fill)</span></p>
        <div className="flex flex-wrap gap-1.5 mb-3">
          {QUICK_REASONS.map(r => (
            <button key={r} onClick={() => setReason(r)}
              className={`px-2.5 py-1.5 rounded-xl border text-[11px] font-semibold transition-all ${reason === r ? 'border-red-500/60 bg-red-500/15 text-red-300' : 'border-gray-700/50 bg-gray-800/40 text-gray-400 hover:border-gray-600'}`}>
              {r}
            </button>
          ))}
        </div>
        <p className="text-xs text-gray-400 mb-1.5">Custom reason <span className="text-red-400">*</span></p>
        <textarea value={reason} onChange={e => setReason(e.target.value)} rows={3}
          placeholder="Explain why this subscription is being removed — this will be sent to the user."
          className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-red-500/50 resize-none mb-4" />
        <div className="bg-red-500/10 border border-red-500/30 rounded-xl px-3 py-2 mb-4">
          <p className="text-[11px] text-red-300">⚠️ This will revoke access, wipe the VLESS config, and notify the user via app + email.</p>
        </div>
        <button onClick={handle} disabled={loading || !reason}
          className="w-full py-3 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-red-700 to-red-600 disabled:opacity-40 flex items-center justify-center gap-2">
          {loading ? <><Loader className="w-4 h-4 animate-spin" /> Removing...</> : <><Trash2 className="w-4 h-4" /> Remove & Notify User</>}
        </button>
      </motion.div>
    </div>
  );
}

// ── Set VLESS Modal ───────────────────────────────────────────────────────────
function SetVlessModal({ node, onClose, onDone }) {
  const [vless, setVless] = useState(node.vless_string || '');
  const [note, setNote] = useState('');
  const [loading, setLoading] = useState(false);

  const handle = async () => {
    if (!vless) return;
    setLoading(true);
    await base44.functions.invoke('ispNodeDeploy', { action: 'set_vless', nodeId: node.id, vlessOverride: vless, adminNote: note });
    setLoading(false);
    onDone();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm px-4 pb-6" onClick={onClose}>
      <motion.div initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 60, opacity: 0 }}
        className="w-full max-w-lg bg-[#13131f] border border-violet-500/30 rounded-3xl p-5 shadow-2xl"
        onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-white">🔧 Update VLESS Config</h3>
          <button onClick={onClose} className="p-1.5 rounded-xl bg-gray-800/60 text-gray-400"><X className="w-4 h-4" /></button>
        </div>
        <textarea value={vless} onChange={e => setVless(e.target.value)} rows={5}
          placeholder="vless://uuid@host:port?..."
          className="w-full bg-gray-800/60 border border-violet-500/30 rounded-xl px-3 py-2.5 text-xs font-mono text-violet-200 focus:outline-none focus:border-violet-500/60 resize-none mb-3" />
        <input value={note} onChange={e => setNote(e.target.value)} placeholder="Note to user (optional)"
          className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-violet-500/50 mb-4" />
        <button onClick={handle} disabled={loading || !vless}
          className="w-full py-3 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-violet-600 to-purple-600 disabled:opacity-40 flex items-center justify-center gap-2">
          {loading ? <><Loader className="w-4 h-4 animate-spin" /> Saving...</> : '🔧 Save + Notify User'}
        </button>
      </motion.div>
    </div>
  );
}

// ── Share Button ──────────────────────────────────────────────────────────────
function ShareBtn({ node }) {
  const [shared, setShared] = useState(false);
  const SHARE_URL = 'https://mastersdeovex.co.za/PaidVersion';
  const shareText = `🚀 Hey ${node.user_name?.split(' ')[0] || 'friend'}! Check out Lets VPN Go Paid — fast SA VPN from R20 for 7 days 📶\n\nSign up here → ${SHARE_URL}`;

  const handle = async () => {
    if (navigator.share) {
      await navigator.share({ title: 'Lets VPN Go — Paid Version', text: shareText, url: SHARE_URL }).catch(() => {});
    } else {
      navigator.clipboard.writeText(shareText);
    }
    setShared(true);
    setTimeout(() => setShared(false), 2000);
  };

  return (
    <button onClick={handle}
      className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl border text-xs font-bold transition-all ${shared ? 'border-green-500/40 bg-green-500/15 text-green-300' : 'border-gray-700/40 bg-gray-800/30 text-gray-400 hover:border-gray-600'}`}>
      {shared ? <Check className="w-3 h-3" /> : <Share2 className="w-3 h-3" />}
      {shared ? 'Copied!' : 'Share'}
    </button>
  );
}

// ── Node Card ─────────────────────────────────────────────────────────────────
function NodeCard({ node, onApprove, onReject, onRenew, onNotify, onSetVless, onSendPackage, onRemove, onRenewApprove, processing }) {
  const [expanded, setExpanded] = useState(false);
  const cfg = STATUS_CFG[node.status] || STATUS_CFG.pending_payment;
  const isExpiring = node.expiry_epoch && (node.expiry_epoch - Date.now()) < 3 * 24 * 60 * 60 * 1000 && node.status === 'active';

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
      className="bg-gray-900/70 border border-gray-700/50 rounded-2xl overflow-hidden mb-3">
      <div className="p-4">
        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-0.5">
              <p className="text-sm font-bold text-white truncate">{node.user_name}</p>
              {isExpiring && <span className="text-[9px] bg-orange-500/20 border border-orange-500/30 text-orange-300 px-1.5 py-0.5 rounded-full font-bold">Expiring Soon</span>}
            </div>
            <p className="text-xs text-gray-500 font-mono truncate">{node.user_email}</p>
            {node.whatsapp && <p className="text-xs text-green-400 mt-0.5">📱 {node.whatsapp}</p>}
          </div>
          <div className="text-right ml-3 flex-shrink-0">
            <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold border ${cfg.bg} ${cfg.color}`}>
              {cfg.label}
            </span>
            <p className="text-xs font-bold text-cyan-400 mt-1">{node.plan === '7days' ? 'R20 / 7d' : node.plan === '30days' ? 'R50 / 30d' : 'R30 / 14d'}</p>
          </div>
        </div>

        {/* Info Grid */}
        <div className="grid grid-cols-3 gap-2 mb-3 text-xs">
          <div className="bg-gray-800/50 rounded-xl px-2.5 py-2">
            <p className="text-gray-500 text-[10px]">Type</p>
            <p className="text-white font-bold capitalize text-[11px]">{node.node_type}-Access</p>
          </div>
          <div className="bg-gray-800/50 rounded-xl px-2.5 py-2">
            <p className="text-gray-500 text-[10px]">Payment</p>
            <p className="text-white font-bold capitalize text-[11px]">{node.payment_method?.replace('_', ' ')}</p>
          </div>
          <div className="bg-gray-800/50 rounded-xl px-2.5 py-2">
            <p className="text-gray-500 text-[10px]">Expires</p>
            <p className={`font-bold text-[11px] ${isExpiring ? 'text-orange-400' : 'text-white'}`}>{node.expiry_date || '—'}</p>
          </div>
        </div>

        {/* Voucher PIN */}
        {node.voucher_pin && (
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl px-3 py-2 mb-3 flex items-center justify-between">
            <div>
              <p className="text-[10px] text-amber-400 font-bold">1Voucher PIN</p>
              <p className="text-sm font-mono text-white">{node.voucher_pin}</p>
            </div>
            <CopyBtn text={node.voucher_pin} />
          </div>
        )}

        {/* Proof of Payment */}
        {node.payment_proof_url && (
          <a href={node.payment_proof_url} target="_blank" rel="noopener noreferrer"
            className="flex items-center gap-2 text-xs text-blue-400 underline mb-3 hover:text-blue-300 transition-colors">
            <Eye className="w-3.5 h-3.5" /> View Proof of Payment
          </a>
        )}

        {/* VLESS String */}
        {node.vless_string && (
          <div className="bg-green-500/8 border border-green-500/25 rounded-xl p-3 mb-3">
            <div className="flex items-center justify-between mb-1">
              <p className="text-[10px] text-green-400 uppercase tracking-wider font-bold">Paid Config</p>
              <CopyBtn text={node.vless_string} size="xs" />
            </div>
            <p className="text-[10px] font-mono text-green-200 break-all leading-relaxed">{node.vless_string.slice(0, 100)}...</p>
          </div>
        )}

        {/* Renewal pending badge */}
        {node.renewal_status === 'pending' && (
          <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-xl px-3 py-2 mb-3">
            <p className="text-[10px] text-cyan-400 font-black uppercase tracking-wider mb-0.5">🔄 Renewal Pending</p>
            <p className="text-xs text-gray-300">Plan: <span className="text-cyan-300 font-bold">{node.renewal_plan}</span> · Method: {node.renewal_payment_method} · R{node.renewal_amount}</p>
            {node.renewal_payment_proof_url && (
              <a href={node.renewal_payment_proof_url} target="_blank" rel="noopener noreferrer"
                className="text-[10px] text-blue-400 underline mt-0.5 block">View Renewal Proof →</a>
            )}
          </div>
        )}

        {/* Admin Notes */}
        {node.admin_notes && (
          <div className="bg-gray-800/40 border border-gray-700/30 rounded-xl px-3 py-2 mb-3">
            <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wider mb-0.5">Admin Notes</p>
            <p className="text-xs text-gray-300">{node.admin_notes}</p>
          </div>
        )}

        {/* Technical Details */}
        <button onClick={() => setExpanded(v => !v)}
          className="flex items-center gap-1 text-xs text-gray-600 hover:text-gray-400 transition-all mb-3">
          {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          Technical Details
        </button>

        <AnimatePresence>
          {expanded && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden mb-3">
              <div className="bg-gray-950/60 border border-gray-700/40 rounded-xl p-3 space-y-2">
                {[
                  { label: 'UUID', val: node.uuid },
                  { label: 'Project', val: node.project_name },
                  { label: 'Vercel URL', val: node.vercel_url },
                  { label: 'Expiry Date', val: node.expiry_date },
                  { label: 'Amount Paid', val: node.amount_paid ? `R${node.amount_paid}` : null },
                  { label: 'Created', val: node.created_date ? new Date(node.created_date).toLocaleDateString('en-ZA') : null },
                ].map(r => r.val && (
                  <div key={r.label} className="flex items-center justify-between gap-2">
                    <p className="text-[10px] text-gray-500 w-20 flex-shrink-0">{r.label}</p>
                    <p className="text-[10px] font-mono text-gray-300 flex-1 truncate">{r.val}</p>
                    <CopyBtn text={r.val} size="xs" />
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Action Buttons */}
        <div className="space-y-2">
          {/* Primary actions */}
          <div className="flex gap-2">
            {(node.status === 'pending_approval' || node.status === 'pending_payment') && (
              <>
                <button onClick={() => onApprove(node)} disabled={processing === node.id}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-green-600/30 hover:bg-green-600/50 border border-green-500/40 text-green-300 font-bold text-xs transition-all disabled:opacity-50">
                  {processing === node.id ? <Loader className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle className="w-3.5 h-3.5" />}
                  Approve
                </button>
                <button onClick={() => onReject(node)} disabled={processing === node.id}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-red-600/20 hover:bg-red-600/40 border border-red-500/30 text-red-300 font-bold text-xs transition-all disabled:opacity-50">
                  <XCircle className="w-3.5 h-3.5" /> Reject
                </button>
              </>
            )}
            {(node.status === 'expired' || (node.status === 'active' && node.renewal_status === 'pending')) && (
              <button onClick={() => onRenewApprove ? onRenewApprove(node) : onApprove(node)} disabled={processing === node.id}
                className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-cyan-600/30 hover:bg-cyan-600/50 border border-cyan-500/40 text-cyan-300 font-bold text-xs transition-all disabled:opacity-50">
                {processing === node.id ? <Loader className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
                Approve Renewal {node.renewal_plan ? `(${node.renewal_plan})` : ''}
              </button>
            )}
          </div>

          {/* Secondary actions: always available */}
          <div className="flex gap-2">
            <button onClick={() => onSetVless(node)}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-violet-600/20 hover:bg-violet-600/40 border border-violet-500/30 text-violet-300 font-bold text-xs transition-all">
              <Edit3 className="w-3 h-3" /> Set VLESS
            </button>
            <button onClick={() => onNotify(node)}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-blue-600/20 hover:bg-blue-600/40 border border-blue-500/30 text-blue-300 font-bold text-xs transition-all">
              <Bell className="w-3 h-3" /> Notify
            </button>
            <button onClick={() => onSendPackage(node)}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-orange-600/20 hover:bg-orange-600/40 border border-orange-500/30 text-orange-300 font-bold text-xs transition-all">
              <Package className="w-3 h-3" /> Package
            </button>
          </div>
          {/* Remove + Share row */}
          <div className="flex gap-2">
            <button onClick={() => onRemove(node)}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-red-700/20 hover:bg-red-700/40 border border-red-600/30 text-red-400 font-bold text-xs transition-all">
              <Trash2 className="w-3 h-3" /> Remove Sub
            </button>
            <ShareBtn node={node} />
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// ── Main Admin Page ───────────────────────────────────────────────────────────
export default function ISPNodeAdmin() {
  const [tab, setTab] = useState('Pending');
  const [nodes, setNodes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(null);
  const [user, setUser] = useState(null);
  const [search, setSearch] = useState('');
  const [approveModal, setApproveModal] = useState(null);
  const [rejectModal, setRejectModal] = useState(null);
  const [notifyModal, setNotifyModal] = useState(null);
  const [vlessModal, setVlessModal] = useState(null);
  const [packageModal, setPackageModal] = useState(null);
  const [removeModal, setRemoveModal] = useState(null);

  useEffect(() => {
    base44.auth.me().then(u => { setUser(u); loadNodes(); });
  }, []);

  const loadNodes = async () => {
    setLoading(true);
    const data = await base44.entities.ISPNode.list('-created_date', 500);
    setNodes(data);
    setLoading(false);
  };

  const handleDone = async () => {
    setApproveModal(null);
    setRejectModal(null);
    setVlessModal(null);
    setProcessing(null);
    await loadNodes();
  };

  const handleRenewApprove = async (node) => {
    setProcessing(node.id);
    await base44.functions.invoke('ispNodeDeploy', { action: 'renew', nodeId: node.id });
    setProcessing(null);
    await loadNodes();
  };

  const tabFiltered = {
    Pending: nodes.filter(n => ['pending_payment', 'pending_approval'].includes(n.status) || (n.status === 'active' && n.renewal_status === 'pending')),
    Active:  nodes.filter(n => n.status === 'active'),
    Expired: nodes.filter(n => ['expired', 'rejected'].includes(n.status)),
    All:     nodes,
  }[tab] || [];

  const filtered = tabFiltered.filter(n =>
    !search || n.user_name?.toLowerCase().includes(search.toLowerCase()) ||
    n.user_email?.toLowerCase().includes(search.toLowerCase()) ||
    n.whatsapp?.includes(search)
  );

  // Revenue stats
  const totalRevenue = nodes.filter(n => n.status === 'active').reduce((sum, n) => sum + (n.amount_paid || 0), 0);
  const activeCount  = nodes.filter(n => n.status === 'active').length;
  const pendingCount = nodes.filter(n => ['pending_payment','pending_approval'].includes(n.status) || (n.status === 'active' && n.renewal_status === 'pending')).length;
  const expiredCount = nodes.filter(n => n.status === 'expired').length;
  const expiringCount = nodes.filter(n => n.expiry_epoch && (n.expiry_epoch - Date.now()) < 3 * 24 * 60 * 60 * 1000 && n.status === 'active').length;

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center text-white">
        <div className="text-center">
          <Shield className="w-12 h-12 text-red-400 mx-auto mb-3" />
          <p className="font-bold text-white mb-1">Admin Access Required</p>
          <p className="text-sm text-gray-400">This area is restricted to administrators.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      {/* Modals */}
      <AnimatePresence>
        {approveModal && <ApproveModal node={approveModal} onClose={() => setApproveModal(null)} onDone={handleDone} />}
        {rejectModal  && <RejectModal  node={rejectModal}  onClose={() => setRejectModal(null)}  onDone={handleDone} />}
        {notifyModal  && <NotifyModal  node={notifyModal}  onClose={() => setNotifyModal(null)} />}
        {vlessModal   && <SetVlessModal node={vlessModal}  onClose={() => setVlessModal(null)}   onDone={handleDone} />}
        {packageModal && <SendPackageModal node={packageModal} onClose={() => setPackageModal(null)} />}
        {removeModal  && <RemoveModal node={removeModal} onClose={() => setRemoveModal(null)} onDone={() => { setRemoveModal(null); handleDone(); }} />}
      </AnimatePresence>

      {/* Header */}
      <div className="px-4 pt-6 pb-4">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-3">
            <Link to="/Admin" className="p-2 bg-gray-800/50 rounded-xl">
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div>
              <h1 className="text-lg font-bold">Lets VPN Go | Paid</h1>
              <p className="text-xs text-violet-400 font-mono">Subscriptions Dashboard</p>
            </div>
          </div>
          <button onClick={loadNodes} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-all">
            <RefreshCw className="w-4 h-4 text-gray-400" />
          </button>
        </div>
      </div>

      {/* Stats Dashboard */}
      <div className="px-4 mb-4">
        <div className="grid grid-cols-2 gap-2 mb-2">
          <div className="bg-gradient-to-r from-green-600/20 to-emerald-600/20 border border-green-500/30 rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-1">
              <DollarSign className="w-4 h-4 text-green-400" />
              <p className="text-xs text-green-400 font-bold uppercase tracking-wider">Revenue</p>
            </div>
            <p className="text-2xl font-black text-white">R{totalRevenue}</p>
            <p className="text-[10px] text-gray-500">{activeCount} active subscriber{activeCount !== 1 ? 's' : ''}</p>
          </div>
          <div className="bg-gradient-to-r from-amber-600/20 to-orange-600/20 border border-amber-500/30 rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-1">
              <Activity className="w-4 h-4 text-amber-400" />
              <p className="text-xs text-amber-400 font-bold uppercase tracking-wider">Needs Action</p>
            </div>
            <p className="text-2xl font-black text-white">{pendingCount}</p>
            <p className="text-[10px] text-gray-500">pending orders</p>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {[
            { label: 'Total Users', val: nodes.length, color: 'text-cyan-400' },
            { label: 'Expiring ≤3d', val: expiringCount, color: 'text-orange-400' },
            { label: 'Expired', val: expiredCount, color: 'text-red-400' },
          ].map(s => (
            <div key={s.label} className="bg-gray-900/60 border border-gray-700/40 rounded-xl p-3 text-center">
              <p className={`text-xl font-black ${s.color}`}>{s.val}</p>
              <p className="text-[10px] text-gray-500">{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* WhatsApp Group Link */}
      <div className="px-4 mb-4">
        <a href="https://mspy.qzz.io/letsvpngopaidversion" target="_blank" rel="noopener noreferrer"
          className="flex items-center gap-3 bg-green-500/10 border border-green-500/30 rounded-2xl px-4 py-3 hover:bg-green-500/15 transition-all">
          <div className="w-9 h-9 rounded-xl bg-green-500/20 flex items-center justify-center flex-shrink-0">
            <MessageSquare className="w-5 h-5 text-green-400" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-bold text-white">Paid Members WhatsApp Group</p>
            <p className="text-xs text-green-400">mspy.qzz.io/letsvpngopaidversion</p>
          </div>
          <span className="text-xs text-gray-500">Open ↗</span>
        </a>
      </div>

      {/* Search */}
      <div className="px-4 mb-3">
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="🔍 Search by name, email, or WhatsApp..."
          className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-500/50" />
      </div>

      {/* Tabs */}
      <div className="px-4 mb-4">
        <div className="flex gap-1 bg-gray-800/50 rounded-xl p-1 border border-gray-700/40">
          {TABS.map(t => {
            const counts = {
              Pending: pendingCount,
              Active: activeCount,
              Expired: expiredCount,
              All: nodes.length,
            };
            return (
              <button key={t} onClick={() => setTab(t)}
                className={`flex-1 py-2 rounded-lg text-xs font-semibold transition-all relative ${tab === t ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white' : 'text-gray-500 hover:text-gray-300'}`}>
                {t}
                {counts[t] > 0 && (
                  <span className={`absolute -top-1 -right-0.5 w-4 h-4 rounded-full text-[9px] font-black flex items-center justify-center ${tab === t ? 'bg-white text-blue-700' : 'bg-gray-600 text-white'}`}>
                    {counts[t] > 9 ? '9+' : counts[t]}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Node List */}
      <div className="px-4">
        {loading ? (
          <div className="text-center py-12"><Loader className="w-6 h-6 text-cyan-400 animate-spin mx-auto" /></div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12">
            <Server className="w-10 h-10 text-gray-700 mx-auto mb-3" />
            <p className="text-gray-500 text-sm">No {tab.toLowerCase()} subscriptions{search ? ' matching search' : ''}.</p>
          </div>
        ) : (
          <>
            <p className="text-xs text-gray-600 mb-3">{filtered.length} record{filtered.length !== 1 ? 's' : ''}</p>
            {filtered.map(node => (
              <NodeCard
                key={node.id}
                node={node}
                processing={processing}
                onApprove={setApproveModal}
                onReject={setRejectModal}
                onNotify={setNotifyModal}
                onSetVless={setVlessModal}
                onSendPackage={setPackageModal}
                onRemove={setRemoveModal}
                onRenewApprove={handleRenewApprove}
              />
            ))}
          </>
        )}
      </div>
    </div>
  );
}