import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { ArrowLeft, Plus, Play, Eye } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';

export default function CreatorSkills() {
  const [user, setUser] = useState(null);
  const [courses, setCourses] = useState([]);
  const [showAdd, setShowAdd] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    video_url: '',
    is_free: true,
    price: 0
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const userData = await base44.auth.me();
    setUser(userData);
    const myCourses = await base44.entities.CourseContent.filter({ creator_email: userData.email });
    setCourses(myCourses);
  };

  const handleSubmit = async () => {
    await base44.entities.CourseContent.create({
      creator_email: user.email,
      ...formData
    });
    
    await loadData();
    setShowAdd(false);
    setFormData({ title: '', description: '', video_url: '', is_free: true, price: 0 });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("CreatorDashboard")} className="p-2 bg-gray-800/50 rounded-xl">
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <h1 className="text-xl font-bold">Skills Content Panel</h1>
          </div>
          <Button onClick={() => setShowAdd(!showAdd)} className="bg-purple-600">
            <Plus className="w-4 h-4 mr-2" />
            Add Course
          </Button>
        </div>

        {showAdd && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50 mb-6"
          >
            <h3 className="font-semibold mb-4">Add Course Content</h3>
            <div className="space-y-3">
              <Input
                placeholder="Course Title"
                value={formData.title}
                onChange={(e) => setFormData({...formData, title: e.target.value})}
                className="bg-gray-700/50 border-gray-600"
              />
              <Textarea
                placeholder="Description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                className="bg-gray-700/50 border-gray-600"
              />
              <Input
                placeholder="YouTube URL or Video URL"
                value={formData.video_url}
                onChange={(e) => setFormData({...formData, video_url: e.target.value})}
                className="bg-gray-700/50 border-gray-600"
              />
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-400">Free Course</span>
                <Switch
                  checked={formData.is_free}
                  onCheckedChange={(checked) => setFormData({...formData, is_free: checked})}
                />
              </div>
              {!formData.is_free && (
                <Input
                  type="number"
                  placeholder="Price"
                  value={formData.price}
                  onChange={(e) => setFormData({...formData, price: parseFloat(e.target.value)})}
                  className="bg-gray-700/50 border-gray-600"
                />
              )}
              <Button onClick={handleSubmit} className="w-full bg-purple-600">
                Add Course
              </Button>
            </div>
          </motion.div>
        )}

        <div className="space-y-4">
          {courses.map((course) => (
            <motion.div
              key={course.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-semibold text-white">{course.title}</h4>
                    {!course.is_free && (
                      <span className="bg-amber-500/20 text-amber-400 text-xs px-2 py-0.5 rounded-full">
                        ${course.price}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-gray-400 mb-2">{course.description}</p>
                  <div className="flex items-center gap-4 text-xs text-gray-500">
                    <span className="flex items-center gap-1">
                      <Eye className="w-3 h-3" />
                      {course.views} views
                    </span>
                    <span className="flex items-center gap-1">
                      <Play className="w-3 h-3" />
                      Video
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}