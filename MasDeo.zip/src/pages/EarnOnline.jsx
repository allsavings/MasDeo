import React, { useState, useEffect } from 'react';
import { useWIPLock } from '@/lib/WIPLockContext';
import { motion } from 'framer-motion';
import { ArrowLeft, DollarSign, Briefcase, TrendingUp, Users, Gift, ExternalLink, BarChart3, Star, Shield, Eye, Heart } from 'lucide-react';
import ExploreCreatorsView from '../components/creator/ExploreCreatorsView';
import CreatorSectionDisplay from '../components/creator/CreatorSectionDisplay';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useCreatorMode } from '../components/useCreatorMode';
import CreatorModeToggle from '../components/creator/CreatorModeToggle';
import CreatorSectionEditor from '../components/creator/CreatorSectionEditor';
import { base44 } from '@/api/base44Client';


export default function EarnOnline() {
  const navigate = useNavigate();
  const { isRouteLocked } = useWIPLock();
  const { isCreatorMode, isCreatorEligible, canCreatorForSection, toggleCreatorMode, user } = useCreatorMode();
  const showCreator = isCreatorMode && canCreatorForSection('earn_online') && !isRouteLocked('/CreatorMode');
  const [exploreMode, setExploreMode] = useState(() => localStorage.getItem('explore_creators_mode') === 'true');
  const [creators, setCreators] = useState([]);
  const [loadingCreators, setLoadingCreators] = useState(false);
  const [selectedCreatorEmail, setSelectedCreatorEmail] = useState(null);
  const [isFreemium, setIsFreemium] = useState(false);

  useEffect(() => {
    checkUserFreemiumStatus();
  }, []);



  useEffect(() => {
    const checkExploreMode = () => {
      setExploreMode(localStorage.getItem('explore_creators_mode') === 'true');
    };
    window.addEventListener('storage', checkExploreMode);
    const interval = setInterval(checkExploreMode, 500);
    return () => {
      window.removeEventListener('storage', checkExploreMode);
      clearInterval(interval);
    };
  }, []);

  const checkUserFreemiumStatus = async () => {
    try {
      const user = await base44.auth.me();
      const userProfile = await base44.entities.UserProfile.filter({ created_by: user.email });
      if (userProfile[0]) {
        setIsFreemium(!userProfile[0].is_premium);
      }
    } catch (error) {
      console.error('Error checking freemium status:', error);
      setIsFreemium(true);
    }
  };

  useEffect(() => {
    if (exploreMode) {
      loadCreatorsAndResources();
    }
  }, [exploreMode]);

  const loadCreatorsAndResources = async () => {
    setLoadingCreators(true);
    try {
      const [allCreators, allSettings, allFollows] = await Promise.all([
        base44.entities.CreatorProfile.list(),
        base44.entities.CreatorSettings.list(),
        base44.entities.Follow.list()
      ]);

      const eligibleCreators = allCreators.filter(creator => {
        const setting = allSettings.find(s => s.user_email === creator.user_email);
        return setting?.is_public && (setting.all_platforms || setting.platforms?.includes('earn'));
      });

      const profiles = await Promise.all(
        eligibleCreators.map(creator =>
          base44.entities.UserProfile.filter({ created_by: creator.user_email })
        )
      );

      const publicCreators = eligibleCreators.map((creator, i) => ({
        ...creator,
        profile: profiles[i][0] || null,
        followerCount: allFollows.filter(f => f.creator_email === creator.user_email).length
      }));

      setCreators(publicCreators);
    } catch (error) {
      console.error('Error loading creators:', error);
    } finally {
      setLoadingCreators(false);
    }
  };

  const opportunities = [
    { title: "Forex Trading", description: "Trade currencies and earn from market movements", icon: BarChart3, color: "from-green-500 to-emerald-500", potential: "$1,000 - $50,000/mo", page: "Forex" },
    { title: "Freelancing", description: "Offer your skills on platforms like Fiverr & Upwork", icon: Briefcase, color: "from-emerald-500 to-green-500", potential: "$500 - $5,000/mo" },
    { title: "Affiliate Marketing", description: "Earn commissions by promoting products", icon: TrendingUp, color: "from-blue-500 to-cyan-500", potential: "$100 - $10,000/mo" },
    { title: "Content Creation", description: "Monetize YouTube, TikTok, or blogs", icon: Users, color: "from-purple-500 to-pink-500", potential: "$200 - $20,000/mo" },
    { title: "Referral Programs", description: "Get paid for referring new users", icon: Gift, color: "from-amber-500 to-orange-500", potential: "$50 - $1,000/mo" }
  ];

  const handleAdRequiredClick = (e) => {
    if (!isFreemium) return;
    
    const clickedLink = e.target.closest('a');
    if (!clickedLink) return;
    
    // Check if ads are globally disabled or user has disabled them
    const globalAdsEnabled = localStorage.getItem('global_ads_enabled') !== 'false';
    const userAdsDisabled = localStorage.getItem('user_ads_disabled') === 'true';
    if (!globalAdsEnabled || userAdsDisabled) return;
    
    const isFreeClick = sessionStorage.getItem('next_click_free') === 'true';
    if (isFreeClick) {
      sessionStorage.removeItem('next_click_free');
      return;
    }

    e.preventDefault();
    navigate('/AdView', { state: { from: '/EarnOnline' } });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32" onClick={isFreemium ? handleAdRequiredClick : undefined}>

      {/* Header */}
      <div className="px-6 pt-6 pb-4 relative z-40">
        <div className="flex items-center gap-4 mb-4">
          <Link to={createPageUrl("Home")} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors" onClick={e => e.stopPropagation()}>
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-xl font-bold">Earn Online</h1>
        </div>
      </div>

      {/* Creator Mode Toggle */}
      {!isRouteLocked('/CreatorMode') && (
        <div className="relative z-40">
          <CreatorModeToggle
            isCreatorMode={isCreatorMode}
            isCreatorEligible={isCreatorEligible && canCreatorForSection('earn_online')}
            onToggle={toggleCreatorMode}
          />
        </div>
      )}

      {/* CREATOR MODE CONTENT */}
      {showCreator ? (
        <CreatorSectionEditor user={user} sectionPage="earn" />
      ) : selectedCreatorEmail ? (
        <CreatorSectionDisplay 
          creatorEmail={selectedCreatorEmail} 
          sectionPage="earn" 
          theme="earn" 
          onBack={() => setSelectedCreatorEmail(null)}
          isFreemium={isFreemium}
          navigate={navigate}
        />
      ) : exploreMode && !isRouteLocked('/ExploreCreators') ? (
        <ExploreCreatorsView creators={creators} loading={loadingCreators} theme="earn" prioritySection="earn" onSelectCreator={setSelectedCreatorEmail} />
      ) : (
        <>
          {/* Hero */}
          <div className="px-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gradient-to-r from-emerald-600/30 to-cyan-600/30 rounded-2xl p-6 border border-emerald-500/30 mb-6"
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="font-bold text-lg">Start Earning Today</h2>
                  <p className="text-sm text-gray-400">Multiple income streams</p>
                </div>
              </div>
              <p className="text-sm text-gray-300">Discover legitimate ways to earn money online using the skills you've learned.</p>
            </motion.div>
          </div>

          {/* Opportunities */}
          <div className="px-6 space-y-4">
            <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider">Opportunities</h3>
            {opportunities.map((opp, index) => (
              <motion.div key={opp.title} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}>
                {opp.page ? (
                  <Link to={createPageUrl(opp.page)}>
                    <div className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50 hover:border-emerald-500/50 transition-all cursor-pointer group">
                      <div className="flex items-start gap-4">
                        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${opp.color} flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                          <opp.icon className="w-6 h-6 text-white" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-1">
                            <h4 className="font-semibold text-white">{opp.title}</h4>
                            <ExternalLink className="w-4 h-4 text-gray-500 group-hover:text-emerald-400 transition-colors" />
                          </div>
                          <p className="text-sm text-gray-400 mb-2">{opp.description}</p>
                          <div className="inline-flex items-center gap-1 bg-emerald-500/10 text-emerald-400 px-3 py-1 rounded-full text-xs font-medium">
                            <DollarSign className="w-3 h-3" />
                            {opp.potential}
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                ) : (
                  <div className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50 hover:border-emerald-500/50 transition-all cursor-pointer group">
                    <div className="flex items-start gap-4">
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${opp.color} flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                        <opp.icon className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="font-semibold text-white">{opp.title}</h4>
                          <ExternalLink className="w-4 h-4 text-gray-500 group-hover:text-emerald-400 transition-colors" />
                        </div>
                        <p className="text-sm text-gray-400 mb-2">{opp.description}</p>
                        <div className="inline-flex items-center gap-1 bg-emerald-500/10 text-emerald-400 px-3 py-1 rounded-full text-xs font-medium">
                          <DollarSign className="w-3 h-3" />
                          {opp.potential}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </motion.div>
            ))}

            {/* CTA */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="mt-6">
              <div className="bg-gradient-to-r from-emerald-500/20 to-cyan-500/20 rounded-2xl p-5 border border-emerald-500/30 text-center">
                <h4 className="font-semibold text-white mb-2">Ready to Start?</h4>
                <p className="text-sm text-gray-400 mb-4">Learn the skills first, then apply them to earn.</p>
                <Link to={createPageUrl("LearnSkills")} className="inline-flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-cyan-500 text-white px-6 py-3 rounded-xl font-medium hover:opacity-90 transition-opacity">
                  Learn Skills First
                </Link>
              </div>
            </motion.div>
          </div>
        </>
      )}
    </div>
  );
}