import React from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Globe, BookOpen, DollarSign, Users } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function Discover() {
  const sections = [
    {
      id: 'ethical',
      title: 'Ethical Free Internet',
      description: 'Access VPN configs, servers, and ethical internet resources',
      icon: Globe,
      color: 'from-blue-500 to-cyan-400',
      bgColor: 'bg-blue-500/10',
      borderColor: 'border-blue-500/30',
      page: 'EthicalInternet'
    },
    {
      id: 'learn',
      title: 'Learn Digital Skills',
      description: 'Master new technologies and digital skills',
      icon: BookOpen,
      color: 'from-purple-500 to-blue-500',
      bgColor: 'bg-purple-500/10',
      borderColor: 'border-purple-500/30',
      page: 'LearnSkills'
    },
    {
      id: 'earn',
      title: 'Earn Online',
      description: 'Monetize your skills and earn income online',
      icon: DollarSign,
      color: 'from-emerald-500 to-cyan-400',
      bgColor: 'bg-emerald-500/10',
      borderColor: 'border-emerald-500/30',
      page: 'EarnOnline'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      {/* Header */}
      <div className="px-6 pt-6 pb-4 sticky top-0 bg-[#0a0a0f]/95 backdrop-blur-xl z-10 border-b border-gray-800/50">
        <div className="flex items-center gap-4 mb-2">
          <Link to={createPageUrl('Home')} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-800 transition-all">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-2xl font-bold">Search</h1>
        </div>
        <p className="text-sm text-gray-400 ml-16">Explore main app sections</p>
      </div>

      {/* Main Sections */}
      <div className="px-6 pt-6 space-y-4">
        {sections.map((section, index) => {
          const Icon = section.icon;
          return (
            <motion.div
              key={section.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Link to={createPageUrl(section.page)}>
                <div className={`${section.bgColor} rounded-2xl p-6 border ${section.borderColor} hover:border-opacity-70 transition-all group`}>
                  <div className="flex items-start gap-4">
                    <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${section.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-white mb-2">{section.title}</h3>
                      <p className="text-sm text-gray-400">{section.description}</p>
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          );
        })}

        {/* Browse Creators Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="pt-4"
        >
          <h2 className="text-sm font-semibold text-gray-400 mb-3">EXPLORE CREATORS</h2>
          <Link to={createPageUrl('BrowseCreators')}>
            <div className="bg-purple-500/10 rounded-2xl p-6 border border-purple-500/30 hover:border-purple-500/50 transition-all group">
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Users className="w-8 h-8 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-white mb-2">Browse Creators</h3>
                  <p className="text-sm text-gray-400">Discover verified creators and their content</p>
                </div>
              </div>
            </div>
          </Link>
        </motion.div>
      </div>
    </div>
  );
}