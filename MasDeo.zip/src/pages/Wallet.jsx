import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Wallet, DollarSign, Eye, EyeOff, TrendingUp, TrendingDown, ArrowDownLeft, ArrowUpRight, Landmark, RefreshCw } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';

export default function WalletPage() {
  const [profile, setProfile] = useState(null);
  const [user, setUser] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [showBalance, setShowBalance] = useState(() => localStorage.getItem('show_credit') === 'true');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const userData = await base44.auth.me();
      setUser(userData);
      const [profiles, watches, withdrawals] = await Promise.all([
        base44.entities.UserProfile.filter({ created_by: userData.email }),
        base44.entities.VideoWatch.filter({ user_email: userData.email }),
        base44.entities.Withdrawal.filter({ user_email: userData.email }),
      ]);
      if (profiles.length > 0) setProfile(profiles[0]);

      // Merge watches + withdrawals into a unified transaction list
      const txWatches = watches.map(w => ({
        id: w.id,
        type: (w.credit_deducted || 0) < 0 ? 'earn' : 'spend',
        label: (w.credit_deducted || 0) < 0 ? 'Reward Earned' : 'Premium Video Unlocked',
        amount: Math.abs(w.credit_deducted || 0),
        date: w.watched_at || w.created_date,
        icon: (w.credit_deducted || 0) < 0 ? 'earn' : 'spend',
      }));
      const txWithdrawals = withdrawals.map(w => ({
        id: w.id,
        type: 'withdraw',
        label: `Withdrawal (${w.status || 'pending'})`,
        amount: w.amount || 0,
        date: w.created_date,
        icon: 'withdraw',
      }));

      const all = [...txWatches, ...txWithdrawals].sort((a, b) => new Date(b.date) - new Date(a.date));
      setTransactions(all);
    } catch (e) {
      console.log(e);
    } finally {
      setLoading(false);
    }
  };

  const toggleBalance = () => {
    const next = !showBalance;
    setShowBalance(next);
    localStorage.setItem('show_credit', next ? 'true' : 'false');
  };

  const fmt = (n) => `R${(Number(n) || 0).toFixed(2)}`;

  const quickActions = [
    { label: 'Hide Balance', icon: showBalance ? EyeOff : Eye, color: 'from-gray-600 to-gray-700', action: toggleBalance },
    { label: 'Earn Free', icon: TrendingUp, color: 'from-emerald-600 to-cyan-600', page: 'EarnCredits?from=Wallet' },
    { label: 'Buy Credits', icon: Wallet, color: 'from-blue-600 to-purple-600', page: 'BuyCredits?from=Wallet' },
    { label: 'Withdraw', icon: ArrowUpRight, color: 'from-orange-600 to-red-600', page: 'WithdrawCredits?from=Wallet' },
    { label: 'Bank Credit', icon: Landmark, color: 'from-purple-600 to-pink-600', page: 'BuyCredits?from=Wallet' },
  ];

  const txIcon = (type) => {
    if (type === 'earn') return <ArrowDownLeft className="w-4 h-4 text-emerald-400" />;
    if (type === 'withdraw') return <ArrowUpRight className="w-4 h-4 text-orange-400" />;
    return <ArrowUpRight className="w-4 h-4 text-red-400" />;
  };

  const txColor = (type) => {
    if (type === 'earn') return 'text-emerald-400';
    if (type === 'withdraw') return 'text-orange-400';
    return 'text-red-400';
  };

  const txSign = (type) => type === 'earn' ? '+' : '-';

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      {/* Header */}
      <div className="px-6 pt-6 pb-4 sticky top-0 bg-[#0a0a0f]/95 backdrop-blur-xl z-10 border-b border-gray-800/50">
        <div className="flex items-center gap-4">
          <Link to={createPageUrl('Home')} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-800 transition-all">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-xl font-bold">My Wallet</h1>
          <button onClick={loadData} className="ml-auto p-2 bg-gray-800/50 rounded-xl hover:bg-gray-800 transition-all">
            <RefreshCw className="w-4 h-4 text-gray-400" />
          </button>
        </div>
      </div>

      {/* Balance Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mx-6 mt-6 bg-gradient-to-br from-blue-600/30 to-purple-600/30 rounded-2xl p-6 border border-blue-500/30"
      >
        <div className="flex items-center justify-between mb-2">
          <p className="text-sm text-gray-400">Available Balance</p>
          <button onClick={toggleBalance} className="p-1.5 bg-white/5 rounded-lg hover:bg-white/10 transition-all">
            {showBalance ? <EyeOff className="w-4 h-4 text-gray-400" /> : <Eye className="w-4 h-4 text-gray-400" />}
          </button>
        </div>
        <div className="flex items-end gap-2">
          <span className="text-4xl font-bold text-white">
            {showBalance ? fmt(profile?.credits) : 'R••••'}
          </span>
        </div>
        <p className="text-xs text-gray-500 mt-2">Credits · South African Rand</p>
      </motion.div>

      {/* Quick Actions */}
      <div className="px-6 mt-6">
        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">Quick Actions</p>
        <div className="grid grid-cols-5 gap-2">
          {quickActions.map((action, i) => {
            const Icon = action.icon;
            const content = (
              <motion.div
                key={action.label}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="flex flex-col items-center gap-1.5"
              >
                <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${action.color} flex items-center justify-center shadow-lg`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <span className="text-[10px] text-gray-400 text-center leading-tight">{action.label}</span>
              </motion.div>
            );

            if (action.action) {
              return <button key={action.label} onClick={action.action}>{content}</button>;
            }
            return (
              <Link key={action.label} to={createPageUrl(action.page)}>
                {content}
              </Link>
            );
          })}
        </div>
      </div>

      {/* Bank Credit Info */}
      <div className="px-6 mt-6">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-2xl p-4 border border-purple-500/20"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
              <Landmark className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Bank Credit</h3>
              <p className="text-xs text-gray-400">Top up via EFT or bank transfer</p>
            </div>
          </div>
          <p className="text-xs text-gray-400 mb-3">Send payment proof after transferring to receive credits in your wallet.</p>
          <Link to={createPageUrl('BuyCredits?from=Wallet')}>
            <button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white text-sm font-semibold py-2.5 rounded-xl hover:opacity-90 transition-all">
              Add Bank Credit
            </button>
          </Link>
        </motion.div>
      </div>

      {/* Transaction History */}
      <div className="px-6 mt-6">
        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">Transaction History</p>

        {loading ? (
          <div className="flex justify-center py-10">
            <div className="w-6 h-6 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
          </div>
        ) : transactions.length === 0 ? (
          <div className="text-center py-10">
            <DollarSign className="w-10 h-10 text-gray-700 mx-auto mb-2" />
            <p className="text-gray-500 text-sm">No transactions yet</p>
          </div>
        ) : (
          <div className="space-y-2">
            {transactions.map((tx) => (
              <motion.div
                key={tx.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-center gap-3 bg-gray-800/40 rounded-xl px-4 py-3 border border-gray-700/30"
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  tx.type === 'earn' ? 'bg-emerald-500/20' : tx.type === 'withdraw' ? 'bg-orange-500/20' : 'bg-red-500/20'
                }`}>
                  {txIcon(tx.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-white font-medium truncate">{tx.label}</p>
                  <p className="text-xs text-gray-500">{tx.date ? new Date(tx.date).toLocaleDateString() : ''}</p>
                </div>
                <span className={`text-sm font-bold ${txColor(tx.type)}`}>
                  {txSign(tx.type)}{fmt(tx.amount)}
                </span>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}