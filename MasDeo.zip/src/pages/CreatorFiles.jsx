import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { ArrowLeft, Plus, Download, Trash2, Eye, EyeOff } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';

export default function CreatorFiles() {
  const [user, setUser] = useState(null);
  const [files, setFiles] = useState([]);
  const [showAdd, setShowAdd] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [formData, setFormData] = useState({
    file_name: '',
    file_type: 'ovpn',
    description: '',
    server_location: '',
    protocol: '',
    is_public: false
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const userData = await base44.auth.me();
    setUser(userData);
    const myFiles = await base44.entities.VpnFile.filter({ creator_email: userData.email });
    setFiles(myFiles);
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setUploading(true);
    const { uploadFile } = await import('@/components/vpsAPI');
    const result = await uploadFile(file);
    const file_url = result.url;
    
    await base44.entities.VpnFile.create({
      creator_email: user.email,
      file_url,
      ...formData
    });
    
    await loadData();
    setShowAdd(false);
    setFormData({ file_name: '', file_type: 'ovpn', description: '', server_location: '', protocol: '', is_public: false });
    setUploading(false);
  };

  const handleTogglePublic = async (file) => {
    await base44.entities.VpnFile.update(file.id, {
      is_public: !file.is_public
    });
    await loadData();
  };

  const handleDelete = async (fileId) => {
    if (confirm('Delete this file? This action cannot be undone.')) {
      await base44.entities.VpnFile.delete(fileId);
      await loadData();
    }
  };

  const handleDownload = async (file) => {
    await base44.entities.VpnFile.update(file.id, {
      download_count: (file.download_count || 0) + 1
    });
    window.open(file.file_url, '_blank');
    await loadData();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("CreatorMode")} className="p-2 bg-gray-800/50 rounded-xl">
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <h1 className="text-xl font-bold">VPN Files</h1>
          </div>
          <Button onClick={() => setShowAdd(!showAdd)} className="bg-blue-600">
            <Plus className="w-4 h-4 mr-2" />
            Upload
          </Button>
        </div>

        {showAdd && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50 mb-6"
          >
            <h3 className="font-semibold mb-4">Upload VPN File</h3>
            <div className="space-y-3">
              <Input
                placeholder="File Name"
                value={formData.file_name}
                onChange={(e) => setFormData({...formData, file_name: e.target.value})}
                className="bg-gray-700/50 border-gray-600"
              />
              <Select value={formData.file_type} onValueChange={(value) => setFormData({...formData, file_type: value})}>
                <SelectTrigger className="bg-gray-700/50 border-gray-600">
                  <SelectValue placeholder="File Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ovpn">OpenVPN (.ovpn)</SelectItem>
                  <SelectItem value="wireguard">WireGuard</SelectItem>
                  <SelectItem value="ssh">SSH Config</SelectItem>
                  <SelectItem value="v2ray">V2Ray</SelectItem>
                  <SelectItem value="xray">XRay</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
              <Textarea
                placeholder="Description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                className="bg-gray-700/50 border-gray-600"
              />
              <Input
                placeholder="Server Location"
                value={formData.server_location}
                onChange={(e) => setFormData({...formData, server_location: e.target.value})}
                className="bg-gray-700/50 border-gray-600"
              />
              <Input
                placeholder="Protocol (optional)"
                value={formData.protocol}
                onChange={(e) => setFormData({...formData, protocol: e.target.value})}
                className="bg-gray-700/50 border-gray-600"
              />
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-400">Make Public</span>
                <Switch
                  checked={formData.is_public}
                  onCheckedChange={(checked) => setFormData({...formData, is_public: checked})}
                />
              </div>
              <input
                type="file"
                onChange={handleFileUpload}
                disabled={uploading || !formData.file_name}
                className="text-sm text-gray-400"
              />
            </div>
          </motion.div>
        )}

        <div className="space-y-4">
          {files.map((file) => (
            <motion.div
              key={file.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-semibold text-white">{file.file_name}</h4>
                    {file.is_public ? (
                      <span className="bg-green-500/20 text-green-400 text-xs px-2 py-0.5 rounded-full flex items-center gap-1">
                        <Eye className="w-3 h-3" />
                        Public
                      </span>
                    ) : (
                      <span className="bg-gray-500/20 text-gray-400 text-xs px-2 py-0.5 rounded-full flex items-center gap-1">
                        <EyeOff className="w-3 h-3" />
                        Private
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-gray-400 mb-2">{file.description}</p>
                  <div className="flex gap-3 text-xs text-gray-500">
                    <span>{file.file_type.toUpperCase()}</span>
                    <span>•</span>
                    <span>{file.server_location}</span>
                    <span>•</span>
                    <span>{file.download_count || 0} downloads</span>
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={() => handleDownload(file)}
                  size="sm"
                  className="flex-1 bg-blue-600"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
                <Button
                  onClick={() => handleTogglePublic(file)}
                  size="sm"
                  variant="outline"
                  className="flex-1"
                >
                  {file.is_public ? 'Make Private' : 'Make Public'}
                </Button>
                <Button
                  onClick={() => handleDelete(file.id)}
                  size="sm"
                  variant="ghost"
                  className="text-red-400"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}