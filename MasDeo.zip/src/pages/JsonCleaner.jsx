import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Upload, Trash2, Copy, Check, Download, FileJson, AlertCircle, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const OUTPUT_MODES = [
  { id: 'host', label: 'Host Only', desc: 'subdomain / domain' },
  { id: 'ip',   label: 'IP Only',   desc: 'IP address(es)' },
  { id: 'both', label: 'Both',      desc: 'host then IP' },
];

function CopyBtn({ text }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      onClick={() => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
      className="flex items-center gap-1 text-xs text-gray-400 hover:text-white px-2 py-1 rounded-lg hover:bg-gray-700/50 transition-all"
    >
      {copied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
      {copied ? 'Copied!' : 'Copy'}
    </button>
  );
}

// Regex patterns — same engine as TXT Cleaner
const IP_REGEX   = /\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b/g;
const HOST_REGEX = /\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+(?:com|net|org|io|co|za|info|biz|me|app|dev|tech|xyz|online|site|web|cloud|edu|gov|mil|int|uk|us|de|fr|au|cn|ru|br|in|jp|kr|ng|gh|ke|tz|ug|rw|zm|zw|bw|na|mw|ls|sz|mu|mg|sc|cv|sn|ci|cm|cd|ao|mz)[a-zA-Z0-9\/\-]*\b/gi;

// Recursively walk any JSON value and collect all string leaves
function collectStrings(val, out = []) {
  if (typeof val === 'string') { out.push(val); }
  else if (Array.isArray(val)) { val.forEach(v => collectStrings(v, out)); }
  else if (val && typeof val === 'object') { Object.values(val).forEach(v => collectStrings(v, out)); }
  return out;
}

function extractFromAny(val) {
  const strings = collectStrings(val).join('\n');
  const hosts = [...new Set((strings.match(HOST_REGEX) || [])
    .map(h => h.trim().toLowerCase().replace(/\/$/, ''))
    .filter(h => !/^\d+\.\d+\.\d+\.\d+$/.test(h))
  )];
  const ips = [...new Set((strings.match(IP_REGEX) || []).map(s => s.trim()))];
  return { hosts, ips };
}

// Robust parser: handles NDJSON, JSON arrays, and plain JSON objects
function parseJsonInput(raw) {
  const allHosts = new Set();
  const allIps   = new Set();
  let skipped = 0;
  let mode = 'ndjson';

  // Try full JSON parse first
  try {
    const parsed = JSON.parse(raw.trim());
    mode = Array.isArray(parsed) ? 'array' : 'object';
    const { hosts, ips } = extractFromAny(parsed);
    hosts.forEach(h => allHosts.add(h));
    ips.forEach(ip => allIps.add(ip));
    return { hosts: [...allHosts], ips: [...allIps], skipped, mode };
  } catch { /* fall through to line-by-line */ }

  // Line-by-line NDJSON
  const lines = raw.split('\n').map(l => l.trim()).filter(Boolean);
  lines.forEach(line => {
    if (line.startsWith('//') || line.startsWith('#')) return;
    try {
      const obj = JSON.parse(line);
      const { hosts, ips } = extractFromAny(obj);
      hosts.forEach(h => allHosts.add(h));
      ips.forEach(ip => allIps.add(ip));
    } catch { skipped++; }
  });

  return { hosts: [...allHosts], ips: [...allIps], skipped, mode };
}

function buildOutput(hosts, ips, mode) {
  let lines = [];
  if (mode === 'host') lines = hosts;
  else if (mode === 'ip') lines = ips;
  else { lines = [...hosts, ...ips]; }
  return [...new Set(lines.filter(Boolean))].join('\n');
}

export default function JsonCleaner() {
  const [input, setInput] = useState('');
  const [mode, setMode] = useState('host');
  const [output, setOutput] = useState('');
  const [stats, setStats] = useState(null);
  const [parseInfo, setParseInfo] = useState(null);
  const [downloading, setDownloading] = useState(false);
  const [showRename, setShowRename] = useState(false);
  const [downloadName, setDownloadName] = useState('');
  const fileInputRef = useRef(null);

  const process = (raw, selectedMode) => {
    const m = selectedMode || mode;
    const { hosts, ips, skipped, mode: parseMode } = parseJsonInput(raw);
    const out = buildOutput(hosts, ips, m);
    setOutput(out);
    setParseInfo({ skipped, parseMode });
    setStats({
      records: hosts.length + ips.length,
      lines: out ? out.split('\n').filter(Boolean).length : 0,
      skippedCount: skipped,
    });
  };

  const handleInput = (val) => {
    setInput(val);
    if (val.trim()) process(val);
    else { setOutput(''); setStats(null); setParseInfo(null); }
  };

  const handleMode = (m) => {
    setMode(m);
    if (input.trim()) process(input, m);
  };

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    const texts = await Promise.all(files.map(f => f.text()));

    const allHosts = new Set();
    const allIps   = new Set();
    let totalSkipped = 0;
    texts.forEach(text => {
      const { hosts, ips, skipped } = parseJsonInput(text.trim());
      hosts.forEach(h => allHosts.add(h));
      ips.forEach(ip => allIps.add(ip));
      totalSkipped += skipped;
    });

    const hosts = [...allHosts];
    const ips   = [...allIps];
    const out   = buildOutput(hosts, ips, mode);
    setInput(texts.join('\n'));
    setOutput(out);
    setParseInfo({ skipped: totalSkipped, parseMode: 'array', fileCount: files.length });
    setStats({
      records: hosts.length + ips.length,
      lines: out ? out.split('\n').filter(Boolean).length : 0,
      skippedCount: totalSkipped,
    });
    e.target.value = '';
  };

  const defaultFilename = () => `cleaned_${mode}_${new Date().toISOString().slice(0,10)}.txt`;

  const triggerDownload = (name) => {
    const filename = (name || '').trim() ? (name.trim().endsWith('.txt') ? name.trim() : name.trim() + '.txt') : defaultFilename();
    setDownloading(true);
    const blob = new Blob([output], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setShowRename(false);
    setTimeout(() => setDownloading(false), 1500);
  };

  const downloadOutput = () => {
    if (!output) return;
    setDownloadName(defaultFilename().replace('.txt', ''));
    setShowRename(true);
  };

  const parseModeLabel = {
    array: parseInfo?.fileCount > 1 ? `📦 ${parseInfo.fileCount} files merged` : '📦 JSON Array detected',
    object: '📄 Single JSON object',
    ndjson: '📋 NDJSON (line-by-line)',
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      {/* Header */}
      <div className="px-4 pt-6 pb-3">
        <div className="flex items-center gap-3">
          <Link to={createPageUrl("HostScanner")} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-lg font-bold leading-tight">JSON Cleaner</h1>
            <p className="text-xs text-amber-400">Extract hosts & IPs from any JSON format</p>
          </div>
        </div>
      </div>

      <div className="px-4 space-y-4">
        {/* Info Banner */}
        <div className="bg-gradient-to-r from-amber-600/10 to-orange-600/10 rounded-2xl p-4 border border-amber-500/20 flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500/30 to-orange-500/30 border border-amber-500/30 flex items-center justify-center flex-shrink-0 mt-0.5">
            <FileJson className="w-4 h-4 text-amber-400" />
          </div>
          <div>
            <p className="text-xs font-semibold text-amber-300 mb-0.5">Smart JSON Parser — Multiple Formats</p>
            <p className="text-xs text-gray-400">
              Supports <span className="text-amber-300 font-mono">NDJSON</span> (one per line), <span className="text-amber-300 font-mono">JSON arrays</span>, and <span className="text-amber-300 font-mono">single objects</span>.
              Keys detected: <span className="text-amber-300 font-mono">subdomain</span>, <span className="text-amber-300 font-mono">host</span>, <span className="text-amber-300 font-mono">domain</span>, <span className="text-amber-300 font-mono">ip</span>, <span className="text-amber-300 font-mono">ip_address</span>, <span className="text-amber-300 font-mono">hostname</span> & more.
            </p>
          </div>
        </div>

        {/* Output Mode Selector */}
        <div>
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Output Mode</p>
          <div className="grid grid-cols-3 gap-2">
            {OUTPUT_MODES.map(m => (
              <button
                key={m.id}
                onClick={() => handleMode(m.id)}
                className={`rounded-xl px-3 py-2.5 border text-center transition-all ${
                  mode === m.id
                    ? 'bg-amber-500/15 border-amber-500/40 text-amber-300'
                    : 'bg-gray-800/40 border-gray-700/40 text-gray-500 hover:text-gray-300'
                }`}
              >
                <p className="text-xs font-semibold">{m.label}</p>
                <p className="text-[10px] opacity-70">{m.desc}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Input */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Input</p>
            <div className="flex items-center gap-2">
              <button onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-1 text-xs bg-gray-700/60 hover:bg-gray-600/60 text-gray-300 px-2.5 py-1 rounded-lg transition-all">
                <Upload className="w-3 h-3" /> Upload file
              </button>
              <button onClick={() => { setInput(''); setOutput(''); setStats(null); setParseInfo(null); }}
                className="text-xs bg-gray-700/60 hover:bg-red-900/40 text-gray-400 hover:text-red-400 p-1.5 rounded-lg transition-all">
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          </div>
          <input ref={fileInputRef} type="file" accept=".json,.txt,.ndjson" multiple className="hidden" onChange={handleFileUpload} />
          <textarea
            value={input}
            onChange={e => handleInput(e.target.value)}
            rows={8}
            placeholder={`Paste any JSON format here:\n\n// NDJSON (one per line):\n{"subdomain":"example.com","ip":"1.2.3.4"}\n\n// JSON Array:\n[{"host":"site.com","ip":"5.6.7.8"},{"host":"test.org"}]`}
            className="w-full bg-gray-900/70 border border-gray-700/50 rounded-xl px-4 py-3 text-xs text-gray-200 font-mono resize-none focus:outline-none focus:border-amber-500/50"
          />
        </div>

        {/* Parse Info Badge */}
        <AnimatePresence>
          {parseInfo && (
            <motion.div initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              className="flex items-center justify-between">
              <span className="text-[11px] text-gray-500 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-400" />
                {parseModeLabel[parseInfo.parseMode] || 'Parsed'}
              </span>
              {parseInfo.skipped > 0 && (
                <span className="flex items-center gap-1 text-[10px] text-orange-400">
                  <AlertCircle className="w-3 h-3" />
                  {parseInfo.skipped} line{parseInfo.skipped > 1 ? 's' : ''} skipped
                </span>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Stats */}
        <AnimatePresence>
          {stats && (
            <motion.div initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              className="grid grid-cols-3 gap-2">
              <div className="bg-gray-800/40 rounded-xl p-3 border border-gray-700/40 text-center">
                <p className="text-lg font-bold text-white">{stats.records}</p>
                <p className="text-[10px] text-gray-500">Hosts+IPs</p>
              </div>
              <div className="bg-amber-500/10 rounded-xl p-3 border border-amber-500/20 text-center">
                <p className="text-lg font-bold text-amber-400">{stats.lines}</p>
                <p className="text-[10px] text-gray-500">Output Lines</p>
              </div>
              <div className={`rounded-xl p-3 border text-center ${stats.skippedCount > 0 ? 'bg-orange-500/10 border-orange-500/20' : 'bg-green-500/10 border-green-500/20'}`}>
                <p className={`text-lg font-bold ${stats.skippedCount > 0 ? 'text-orange-400' : 'text-green-400'}`}>{stats.skippedCount}</p>
                <p className="text-[10px] text-gray-500">Skipped</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Output */}
        <AnimatePresence>
          {output && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                  Clean Output — <span className="text-amber-300 normal-case">{OUTPUT_MODES.find(m2 => m2.id === mode)?.label}</span>
                </p>
                <div className="flex items-center gap-2">
                  <CopyBtn text={output} />
                  <button
                    onClick={downloadOutput}
                    disabled={downloading}
                    className={`flex items-center gap-1.5 text-xs border px-3 py-1.5 rounded-lg transition-all font-medium ${
                      downloading
                        ? 'bg-green-600/20 border-green-500/40 text-green-300'
                        : 'bg-amber-600/20 hover:bg-amber-600/40 text-amber-300 border-amber-500/30 hover:border-amber-500/60'
                    }`}
                  >
                    {downloading
                      ? <><Check className="w-3 h-3" /> Saved!</>
                      : <><Download className="w-3 h-3" /> Download .txt</>
                    }
                  </button>
                </div>
              </div>
              <textarea
                readOnly
                value={output}
                rows={10}
                className="w-full bg-gray-900/80 border border-amber-500/20 rounded-xl px-4 py-3 text-xs text-amber-200 font-mono resize-none focus:outline-none"
              />
              {/* Big Download Button at bottom */}
              <motion.button
                whileTap={{ scale: 0.97 }}
                onClick={downloadOutput}
                disabled={downloading}
                className={`mt-3 w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all border ${
                  downloading
                    ? 'bg-green-500/20 border-green-500/40 text-green-300'
                    : 'bg-gradient-to-r from-amber-500/20 to-orange-500/20 hover:from-amber-500/30 hover:to-orange-500/30 border-amber-500/30 text-amber-300'
                }`}
              >
                {downloading ? (
                  <><Check className="w-4 h-4" /> File Downloaded!</>
                ) : (
                  <><Download className="w-4 h-4" /> Download Clean Output ({stats?.lines} lines)</>
                )}
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Rename & Download Modal */}
      <AnimatePresence>
        {showRename && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
              onClick={() => setShowRename(false)}
            />
            <motion.div
              initial={{ opacity: 0, y: 40, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 40, scale: 0.96 }}
              className="fixed bottom-0 left-0 right-0 z-50 bg-gray-900 border-t border-gray-700/60 rounded-t-3xl p-5"
            >
              <div className="w-10 h-1 bg-gray-700 rounded-full mx-auto mb-5" />
              <h3 className="text-base font-bold text-white mb-1 flex items-center gap-2">
                <Download className="w-4 h-4 text-amber-400" /> Save File
              </h3>
              <p className="text-xs text-gray-400 mb-4">Rename your file or keep the default name.</p>
              <div className="flex items-center bg-gray-800/70 border border-gray-700/50 rounded-xl overflow-hidden mb-4">
                <input
                  type="text"
                  value={downloadName}
                  onChange={e => setDownloadName(e.target.value)}
                  placeholder="filename"
                  className="flex-1 bg-transparent px-4 py-3 text-sm text-white outline-none placeholder-gray-600"
                  autoFocus
                />
                <span className="text-xs text-gray-500 font-mono">.txt</span>
                <button
                  onClick={() => triggerDownload(downloadName)}
                  className="mx-2 px-3 py-1.5 bg-amber-500/30 hover:bg-amber-500/50 border border-amber-500/40 text-amber-300 text-xs font-semibold rounded-lg transition-all"
                >
                  Save
                </button>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <button onClick={() => setShowRename(false)}
                  className="py-3 rounded-xl border border-gray-700/50 text-sm text-gray-400 hover:text-white hover:border-gray-600 transition-all">
                  Cancel
                </button>
                <button onClick={() => triggerDownload(downloadName)}
                  className="py-3 rounded-xl bg-gradient-to-r from-amber-500/30 to-orange-500/30 border border-amber-500/40 text-amber-300 font-semibold text-sm hover:from-amber-500/50 hover:to-orange-500/50 transition-all flex items-center justify-center gap-2">
                  <Download className="w-4 h-4" /> Download
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}