import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Server, Wrench, Info, ChevronDown, ChevronUp } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const sections = [
  {
    id: 'servers',
    icon: Server,
    title: 'Servers Info',
    color: 'from-cyan-500 to-blue-500',
    borderColor: 'border-cyan-500/30',
    bgColor: 'bg-cyan-500/10',
    items: [
      { title: 'South Africa Server', desc: 'Best for local browsing and low ping. Use SA servers for fastest speeds within South Africa.' },
      { title: 'US/EU Servers', desc: 'Great for accessing international content, streaming and bypassing geo-restrictions.' },
      { title: 'Asia Servers', desc: 'Use for accessing Asian content or when other servers are congested.' },
      { title: 'Auto-Select', desc: 'Let the app automatically pick the fastest server based on your location and network.' },
      { title: 'Free vs Premium Servers', desc: 'Free servers are available to all users. Premium servers offer faster speeds and more stability.' },
    ]
  },
  {
    id: 'tweaks',
    icon: Wrench,
    title: 'Tweaks Info',
    color: 'from-orange-500 to-pink-500',
    borderColor: 'border-orange-500/30',
    bgColor: 'bg-orange-500/10',
    items: [
      { title: 'Protocol: V2Ray', desc: 'Use V2Ray protocol for better bypassing on restricted networks. Go to Settings → Protocol → V2Ray.' },
      { title: 'Protocol: OpenVPN', desc: 'More stable on mobile data. Recommended for Telkom and MTN users.' },
      { title: 'Split Tunneling', desc: 'Route only specific apps through the VPN. Saves data and improves speed for other apps.' },
      { title: 'DNS Settings', desc: 'Change DNS to 1.1.1.1 (Cloudflare) or 8.8.8.8 (Google) for faster and more private browsing.' },
      { title: 'Kill Switch', desc: 'Automatically cuts internet if VPN drops — keeps you safe from accidental exposure.' },
      { title: 'Obfuscation Mode', desc: 'Disguises VPN traffic as normal web traffic. Use this on networks that block VPNs.' },
    ]
  },
  {
    id: 'more',
    icon: Info,
    title: 'More Info',
    color: 'from-violet-500 to-purple-600',
    borderColor: 'border-violet-500/30',
    bgColor: 'bg-violet-500/10',
    items: [
      { title: 'How to Update Offline', desc: 'Download the Offline Update File, open Lets VPN Go, go to Settings → Update → Manual Update, and select the downloaded file.' },
      { title: 'How to Use on Zero-Rated Apps', desc: 'Connect to VPN first, then open your zero-rated app. Some networks allow tunneling through zero-rated domains.' },
      { title: 'Battery & Data Usage', desc: 'Enable Battery Saver mode in the app settings. This reduces background checks and uses less data.' },
      { title: 'Connecting Issues', desc: 'If you can\'t connect: try switching protocols, change server, or toggle airplane mode and reconnect.' },
      { title: 'Free Account Limits', desc: 'Free accounts may have speed limits or daily data caps depending on server load.' },
      { title: 'Privacy Policy', desc: 'Lets VPN Go does not log your browsing activity. Always verify privacy policies on the official site.' },
    ]
  }
];

function InfoSection({ section }) {
  const [open, setOpen] = useState(false);
  const [expandedItem, setExpandedItem] = useState(null);
  const Icon = section.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className={`rounded-2xl border ${section.borderColor} ${section.bgColor} overflow-hidden`}
    >
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-4 p-5"
      >
        <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${section.color} flex items-center justify-center flex-shrink-0`}>
          <Icon className="w-5 h-5 text-white" />
        </div>
        <span className="flex-1 text-left font-bold text-white text-base">{section.title}</span>
        {open ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="px-5 pb-5 space-y-2"
          >
            {section.items.map((item, i) => (
              <div key={i} className="bg-gray-900/50 rounded-xl overflow-hidden border border-gray-700/40">
                <button
                  onClick={() => setExpandedItem(expandedItem === i ? null : i)}
                  className="w-full flex items-center gap-3 px-4 py-3 text-left"
                >
                  <span className={`text-xs font-bold w-6 h-6 rounded-full bg-gradient-to-br ${section.color} flex items-center justify-center flex-shrink-0 text-white`}>
                    {i + 1}
                  </span>
                  <span className="flex-1 font-semibold text-sm text-white">{item.title}</span>
                  {expandedItem === i ? <ChevronUp className="w-3.5 h-3.5 text-gray-400" /> : <ChevronDown className="w-3.5 h-3.5 text-gray-400" />}
                </button>
                <AnimatePresence>
                  {expandedItem === i && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.15 }}
                      className="px-4 pb-3"
                    >
                      <p className="text-sm text-gray-400 leading-relaxed">{item.desc}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function LetsVPNGoInfo() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      {/* Header */}
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center gap-4 mb-4">
          <button
            onClick={() => navigate(-1)}
            className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-bold">Lets VPN Go — Info</h1>
        </div>
      </div>

      {/* Hero */}
      <div className="px-6 mb-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl p-5 border border-pink-500/30 bg-gradient-to-r from-pink-600/20 to-orange-600/20 flex items-center gap-4"
        >
          <img src="https://media.base44.com/images/public/69ab75e75a89c53cd29e052d/982659b51_Iconimage.png" alt="Lets VPN Go" className="w-16 h-16 rounded-2xl object-cover flex-shrink-0" />
          <div>
            <h2 className="font-bold text-white text-lg">Lets VPN Go</h2>
            <p className="text-sm text-gray-400">Servers, tweaks and tips to get the best out of your VPN</p>
          </div>
        </motion.div>
      </div>

      {/* Sections */}
      <div className="px-6 space-y-4">
        {sections.map((section, i) => (
          <motion.div key={section.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}>
            <InfoSection section={section} />
          </motion.div>
        ))}
      </div>
    </div>
  );
}