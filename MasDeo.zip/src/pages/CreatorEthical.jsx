import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { ArrowLeft, Globe } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import CreatorPublicView from '../components/creator/CreatorPublicView';

export default function CreatorEthical() {
  const [creatorEmail, setCreatorEmail] = useState(null);
  const [loading, setLoading] = useState(true);
  
  const params = new URLSearchParams(window.location.search);
  const creatorId = params.get('id');

  useEffect(() => {
    if (!creatorId) return;
    base44.entities.CreatorProfile.filter({ id: creatorId }).then(profiles => {
      if (profiles.length > 0) setCreatorEmail(profiles[0].user_email);
      setLoading(false);
    });
  }, [creatorId]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] flex items-center justify-center">
        <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center gap-4 mb-6">
          <Link to={createPageUrl("CreatorProfile") + `?id=${creatorId}`} className="p-2 bg-gray-800/50 rounded-xl">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-lg flex items-center justify-center">
              <Globe className="w-5 h-5" />
            </div>
            <h1 className="text-xl font-bold">Ethical Free Internet</h1>
          </div>
        </div>
      </div>
      {creatorEmail && <CreatorPublicView creatorEmail={creatorEmail} sectionPage="ethical" />}
    </div>
  );
}