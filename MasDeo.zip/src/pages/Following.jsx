import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Heart, Users, ArrowLeft } from 'lucide-react';
import ContentItem from '../components/creator/ContentItem';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import PullToRefresh from '../components/PullToRefresh';

export default function Following() {
  const [user, setUser] = useState(null);
  const [followedContent, setFollowedContent] = useState([]);
  const [followedCreators, setFollowedCreators] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadFollowingFeed();
  }, []);

  const loadFollowingFeed = async () => {
    try {
      const userData = await base44.auth.me();
      setUser(userData);

      // Get all creators this user follows
      const follows = await base44.entities.Follow.filter({ user_email: userData.email });
      
      if (follows.length === 0) {
        setLoading(false);
        return;
      }

      const creatorEmails = follows.map(f => f.creator_email);
      const creatorIds = follows.map(f => f.creator_id);

      // Load creator profiles with user profile info
       const creatorProfiles = await base44.entities.CreatorProfile.filter({});
       const followedCreatorProfiles = creatorProfiles.filter(cp => creatorIds.includes(cp.id));

       // Load user profiles for each creator to get nickname and profile picture
       const creatorsWithProfiles = await Promise.all(
         followedCreatorProfiles.map(async (creator) => {
           const userProfiles = await base44.entities.UserProfile.filter({ created_by: creator.user_email });
           return {
             ...creator,
             userProfile: userProfiles.length > 0 ? userProfiles[0] : null
           };
         })
       );

       setFollowedCreators(creatorsWithProfiles);

      // Load all content from followed creators
      const [vpnFiles, vpsServers, courses, resources] = await Promise.all([
        base44.entities.CreatorVpnFile.filter({ is_public: true }),
        base44.entities.CreatorVpsServer.filter({ is_public: true }),
        base44.entities.CreatorCourse.filter({ is_published: true }),
        base44.entities.CreatorResource.filter({ is_published: true })
      ]);

      // Filter content by followed creators
      const allContent = [
        ...vpnFiles.filter(f => creatorEmails.includes(f.creator_email)).map(item => ({ ...item, category: 'ethical' })),
        ...vpsServers.filter(s => creatorEmails.includes(s.creator_email)).map(item => ({ ...item, category: 'ethical' })),
        ...courses.filter(c => creatorEmails.includes(c.creator_email)).map(item => ({ ...item, category: 'learn' })),
        ...resources.filter(r => creatorEmails.includes(r.creator_email)).map(item => ({ ...item, category: 'earn' }))
      ];

      // Sort by newest first
      allContent.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
      setFollowedContent(allContent);
    } catch (error) {
      console.error('Error loading following feed:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0a0a0f]/95 backdrop-blur-xl border-b border-gray-800/50 px-6 py-4">
        <div className="flex items-center gap-4">
          <Link to={createPageUrl('Home')} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-800 transition-all">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-pink-500 to-red-500 rounded-lg flex items-center justify-center">
              <Heart className="w-5 h-5 fill-current" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Following</h1>
              <p className="text-xs text-gray-400">{followedCreators.length} creators</p>
            </div>
          </div>
        </div>
      </div>

      <PullToRefresh onRefresh={loadFollowingFeed} className="min-h-[calc(100vh-72px)] pb-32">
      {followedCreators.length === 0 ? (
        <div className="px-6 pt-24 text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-pink-500/20 to-red-500/20 rounded-2xl mx-auto mb-4 flex items-center justify-center">
            <Users className="w-10 h-10 text-pink-400 opacity-50" />
          </div>
          <h3 className="text-lg font-bold text-white mb-2">No Followed Creators</h3>
          <p className="text-sm text-gray-400 mb-6">Start following creators to see their latest content here</p>
          <Link to={createPageUrl('BrowseCreators')}>
            <button className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white px-6 py-3 rounded-xl font-medium hover:opacity-90 transition-all">
              Browse Creators
            </button>
          </Link>
        </div>
      ) : (
        <div className="px-6 py-6 space-y-8">
          {/* Followed Creators Section */}
          <div>
            <h2 className="text-xs font-semibold text-gray-400 mb-4 uppercase tracking-widest">Your Creators</h2>
            <div className="flex gap-4 overflow-x-auto pb-2 no-scrollbar">
              {followedCreators.map((creator) => (
                <Link
                  key={creator.id}
                  to={createPageUrl('CreatorProfile') + `?id=${creator.id}&back=Following`}
                  className="flex-shrink-0"
                >
                  <div className="bg-gray-800/40 rounded-2xl p-4 border border-gray-700/50 hover:border-pink-500/50 transition-all w-36 text-center">
                     {creator.userProfile?.profile_picture_url ? (
                       <img
                         src={creator.userProfile.profile_picture_url}
                         alt={creator.userProfile.nickname}
                         className="w-14 h-14 rounded-full mx-auto mb-3 object-cover"
                       />
                     ) : (
                       <div className="w-14 h-14 bg-gradient-to-br from-pink-500 to-purple-500 rounded-full mx-auto mb-3 flex items-center justify-center">
                         <Users className="w-7 h-7 text-white" />
                       </div>
                     )}
                     <p className="text-sm font-semibold text-white truncate">
                       {creator.userProfile?.nickname || creator.user_email.split('@')[0]}
                     </p>
                   </div>
                </Link>
              ))}
            </div>
          </div>

          {/* Latest Content */}
          <div>
            <h2 className="text-xs font-semibold text-gray-400 mb-4 uppercase tracking-widest">Latest Content</h2>
            {followedContent.length === 0 ? (
               <div className="text-center py-16 bg-gray-800/20 rounded-2xl">
                 <p className="text-gray-500 text-sm">No content yet from followed creators</p>
               </div>
             ) : (
               <div className="space-y-3.5">
                 {followedContent.map((item, index) => (
                   <motion.div
                     key={item.id}
                     initial={{ opacity: 0, y: 20 }}
                     animate={{ opacity: 1, y: 0 }}
                     transition={{ delay: index * 0.03 }}
                   >
                     <ContentItem item={item} />
                   </motion.div>
                 ))}
               </div>
             )}
            </div>
            </div>
            )}
            </PullToRefresh>
            </div>
            );
            }