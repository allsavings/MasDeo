import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { ArrowLeft, Star, Shield, Heart, Users, CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import CreatorPublicView from '../components/creator/CreatorPublicView';
import { toast } from 'sonner';

export default function CreatorProfile() {
  const [creator, setCreator] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [isFollowing, setIsFollowing] = useState(false);
  const [followRecord, setFollowRecord] = useState(null);
  const [followerCount, setFollowerCount] = useState(0);
  
  const params = new URLSearchParams(window.location.search);
  const creatorId = params.get('id');
  const backPage = params.get('back') || 'BrowseCreators';

  useEffect(() => {
    loadCreatorData();
  }, [creatorId]);

  const loadCreatorData = async () => {
    if (!creatorId) return;
    
    try {
      // Get current user
      const userData = await base44.auth.me();
      setUser(userData);

      // Get creator profile by ID first
      const creatorProfiles = await base44.entities.CreatorProfile.filter({ id: creatorId });
      if (creatorProfiles.length === 0) {
        setCreator(null);
        setLoading(false);
        return;
      }
      
      const creatorEmail = creatorProfiles[0].user_email;
      
      const [userProfiles, creatorSettings] = await Promise.all([
        base44.entities.UserProfile.filter({ created_by: creatorEmail }),
        base44.entities.CreatorSettings.filter({ user_email: creatorEmail })
      ]);

      // Check if creator is public
      if (creatorSettings.length > 0) {
        const settings = creatorSettings[0];
        if (!settings.is_public || (!settings.all_platforms && (!settings.platforms || settings.platforms.length === 0))) {
          setCreator(null);
          setLoading(false);
          return;
        }
      } else {
        // No settings means not public
        setCreator(null);
        setLoading(false);
        return;
      }

      if (creatorProfiles.length > 0) {
        setCreator(creatorProfiles[0]);
        
      }
      
      if (userProfiles.length > 0) {
        setProfile(userProfiles[0]);
      }

      // Check if current user is following this creator
      const [follows, allFollowers] = await Promise.all([
        base44.entities.Follow.filter({ user_email: userData.email, creator_id: creatorId }),
        base44.entities.Follow.filter({ creator_id: creatorId })
      ]);
      if (follows.length > 0) {
        setIsFollowing(true);
        setFollowRecord(follows[0]);
      }
      setFollowerCount(allFollowers.length);
    } catch (error) {
      console.log('Error loading creator:', error);
    }
    
    setLoading(false);
  };

  const toggleFollow = async () => {
    if (!user || !creator) return;

    try {
      if (isFollowing && followRecord) {
        await base44.entities.Follow.delete(followRecord.id);
        setIsFollowing(false);
        setFollowRecord(null);
        toast.success('Unfollowed creator');
      } else {
        const newFollow = await base44.entities.Follow.create({
          user_email: user.email,
          creator_id: creatorId,
          creator_email: creator.user_email
        });
        setIsFollowing(true);
        setFollowRecord(newFollow);
        toast.success('Following creator! You\'ll see their latest content in your Following feed');
      }
    } catch (error) {
      console.error('Error toggling follow:', error);
      toast.error('Failed to update follow status');
    }
  };

  const nickname = profile?.nickname || creator?.user_email?.split('@')[0] || 'Creator';
  const handle = profile?.username ? `@${profile.username}` : profile?.handle || `@${creator?.user_email?.split('@')[0]}`;

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!creator) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] text-white p-6">
        <div className="text-center mt-20">
          <Shield className="w-16 h-16 mx-auto mb-4 text-gray-600" />
          <p className="text-gray-400 mb-2">Creator Profile Not Available</p>
          <Link to={createPageUrl(backPage)} className="text-blue-400 text-sm">← Back</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white pb-32">
      {/* Header */}
      <div className="px-4 pt-6 pb-2 flex items-center gap-3">
        <Link to={createPageUrl(backPage)} className="p-2 bg-gray-800/60 rounded-xl">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <h1 className="text-lg font-bold">Creator Profile</h1>
      </div>

      {/* Profile Card */}
      <div className="px-4 mt-3 mb-5">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#0f1621]/90 rounded-2xl border border-gray-700/50 overflow-hidden"
        >
          {/* Top banner */}
          <div className="h-1.5 w-full bg-gradient-to-r from-blue-500 via-purple-500 to-cyan-500" />

          <div className="p-4">
            <div className="flex items-center gap-4 mb-4">
              {/* Avatar */}
              {profile?.profile_picture_url ? (
                <img
                  src={profile.profile_picture_url}
                  alt={nickname}
                  className="w-16 h-16 rounded-2xl object-cover ring-2 ring-blue-500/30"
                />
              ) : (
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center ring-2 ring-blue-500/20">
                  <span className="text-white font-bold text-2xl">{nickname.charAt(0)}</span>
                </div>
              )}

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="font-bold text-white text-lg leading-tight">{nickname}</h2>
                  {creator.verified && (
                    <CheckCircle className="w-4 h-4 text-blue-400 flex-shrink-0" />
                  )}
                </div>
                <p className="text-sm text-cyan-400 truncate">{handle}</p>
                {/* Stats row */}
                <div className="flex items-center gap-3 mt-1.5">
                  {creator.average_rating > 0 && (
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3 text-amber-400 fill-current" />
                      <span className="text-xs text-amber-400 font-semibold">{creator.average_rating.toFixed(1)}</span>
                      {creator.total_ratings > 0 && <span className="text-xs text-gray-500">({creator.total_ratings})</span>}
                    </div>
                  )}
                  <div className="flex items-center gap-1">
                    <Users className="w-3 h-3 text-gray-400" />
                    <span className="text-xs text-gray-400">{followerCount} followers</span>
                  </div>
                  {creator.trust_score > 0 && (
                    <div className="flex items-center gap-1">
                      <Shield className="w-3 h-3 text-green-400" />
                      <span className="text-xs text-green-400">{creator.trust_score}%</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {creator.bio && (
              <p className="text-sm text-gray-400 mb-4 leading-relaxed">{creator.bio}</p>
            )}

            {/* Follow Button */}
            <button
              onClick={toggleFollow}
              className={`w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm transition-all ${
                isFollowing
                  ? 'bg-pink-500/15 border border-pink-500/40 text-pink-400'
                  : 'bg-gradient-to-r from-pink-500 to-red-500 text-white hover:opacity-90'
              }`}
            >
              <Heart className={`w-4 h-4 ${isFollowing ? 'fill-current' : ''}`} />
              {isFollowing ? 'Following' : 'Follow Creator'}
            </button>
          </div>
        </motion.div>
      </div>

      {/* Creator's customized content */}
      <div className="px-4">
        <div className="mb-6">
          <p className="text-xs text-cyan-400 uppercase tracking-widest font-bold mb-3">🛡️ Ethical Free Internet</p>
          <CreatorPublicView creatorEmail={creator.user_email} sectionPage="ethical" />
        </div>
        <div className="mb-6">
          <p className="text-xs text-purple-400 uppercase tracking-widest font-bold mb-3">📚 Learn Digital Skills</p>
          <CreatorPublicView creatorEmail={creator.user_email} sectionPage="learn" />
        </div>
        <div className="mb-6">
          <p className="text-xs text-emerald-400 uppercase tracking-widest font-bold mb-3">💰 Earn Online</p>
          <CreatorPublicView creatorEmail={creator.user_email} sectionPage="earn" />
        </div>
      </div>
    </div>
  );
}