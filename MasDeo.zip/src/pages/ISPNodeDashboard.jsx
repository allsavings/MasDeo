import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft, Copy, Check, RefreshCw, Clock, CheckCircle, XCircle,
  Loader, MessageSquare, Zap, Star, Download,
  Package, ChevronDown, ChevronUp, Users, Send, Upload
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';

const STATUS_CFG = {
  pending_payment:  { label: 'Pending Payment',   color: 'text-yellow-400', bg: 'bg-yellow-500/10 border-yellow-500/30', icon: Clock },
  pending_approval: { label: 'Awaiting Approval', color: 'text-amber-400',  bg: 'bg-amber-500/10 border-amber-500/30',  icon: Clock },
  active:           { label: 'Active ✅',           color: 'text-green-400',  bg: 'bg-green-500/10 border-green-500/30',  icon: CheckCircle },
  expired:          { label: 'Expired',            color: 'text-red-400',    bg: 'bg-red-500/10 border-red-500/30',      icon: XCircle },
  rejected:         { label: 'Rejected',           color: 'text-red-400',    bg: 'bg-red-500/10 border-red-500/30',      icon: XCircle },
};

const PLAN_DAYS = { '7days': 7, '14days': 14, '30days': 30 };
const PLAN_LABEL = { '7days': '7 Days', '14days': '14 Days', '30days': '30 Days' };
const PLAN_PRICE = { '7days': 'R20', '14days': 'R30', '30days': 'R50' };

function CopyBtn({ text, label }) {
  const [copied, setCopied] = useState(false);
  const handle = () => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 1800); };
  return (
    <button onClick={handle}
      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${copied ? 'bg-green-500/20 border-green-500/40 text-green-300' : 'bg-gray-700/60 border-gray-600/40 text-gray-300 hover:bg-gray-600/60'}`}>
      {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
      {copied ? 'Copied!' : (label || 'Copy')}
    </button>
  );
}

// ── Real-time countdown ───────────────────────────────────────────────────────
function ExpiryCountdown({ node }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  if (!node.expiry_epoch) return <p className="text-sm font-bold text-white">—</p>;
  const diff = node.expiry_epoch - now;
  const isExpired = diff <= 0;
  const isExpiring = diff > 0 && diff < 3 * 24 * 60 * 60 * 1000;

  if (isExpired) return <p className="text-sm font-bold text-red-400">Expired</p>;

  const d = Math.floor(diff / (1000 * 60 * 60 * 24));
  const h = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  const s = Math.floor((diff % (1000 * 60)) / 1000);

  return (
    <div>
      <p className={`text-sm font-black font-mono ${isExpiring ? 'text-orange-400' : 'text-green-400'}`}>
        {d}d {String(h).padStart(2,'0')}:{String(m).padStart(2,'0')}:{String(s).padStart(2,'0')}
      </p>
      <p className="text-[10px] text-gray-500">{isExpiring ? '⚠️ Expiring soon' : 'remaining'}</p>
    </div>
  );
}

// ── Parse admin_notes ─────────────────────────────────────────────────────────
function parseAdminNote(adminNotes) {
  const notes = adminNotes || '';
  const notesLower = notes.toLowerCase();
  const LABELS = ['npv tunnel config', 'netmod config', 'lets vpn go config', 'generic paid config'];
  for (const lbl of LABELS) {
    if (notesLower.startsWith(lbl)) {
      const parts = notes.split('|');
      return { configLabel: parts[0].trim(), noteText: parts.slice(1).join('|').trim() };
    }
  }
  let configLabel = 'Lets VPN Go Paid Config';
  if (notesLower.includes('npv')) configLabel = 'NPV Tunnel Config';
  else if (notesLower.includes('netmod')) configLabel = 'NetMod Config';
  else if (notesLower.includes('letsvpngo') || notesLower.includes('lets vpn go')) configLabel = 'Lets VPN Go Config';
  return { configLabel, noteText: notes };
}

// ── Config card ───────────────────────────────────────────────────────────────
function ConfigCards({ node }) {
  const { configLabel, noteText } = parseAdminNote(node.admin_notes);
  const hint = configLabel.toLowerCase().includes('npv')
    ? 'Open NPV Tunnel → Import → paste this config string'
    : configLabel.toLowerCase().includes('netmod')
    ? 'Open NetMod → Settings → import this config'
    : 'Open Lets VPN Go → Add Server → paste this config';

  return (
    <div className="space-y-3">
      {noteText && (
        <div className="bg-blue-500/10 border border-blue-500/25 rounded-xl px-3 py-2.5">
          <p className="text-[10px] text-blue-400 font-bold uppercase tracking-wider mb-1">📝 Admin Note</p>
          <p className="text-xs text-gray-200 leading-relaxed whitespace-pre-line">{noteText}</p>
        </div>
      )}
      {node.vless_string && (
        <div className="bg-green-500/8 border border-green-500/25 rounded-xl p-4">
          <div className="flex items-center justify-between mb-3">
            <p className="text-xs text-green-400 uppercase tracking-wider font-bold">{configLabel}</p>
            <CopyBtn text={node.vless_string} label="Copy" />
          </div>
          <div className="bg-gray-950/60 rounded-xl px-3 py-2.5 mb-2">
            <p className="text-[10px] font-mono text-green-200 break-all leading-relaxed">{node.vless_string}</p>
          </div>
          <p className="text-[10px] text-gray-500">💡 {hint}</p>
        </div>
      )}
    </div>
  );
}

// ── Renewal Form ──────────────────────────────────────────────────────────────
function RenewalForm({ node, userEmail, onDone }) {
  const [plan, setPlan] = useState(node.plan);
  const [paymentMethod, setPaymentMethod] = useState('bank_transfer');
  const [popUrl, setPopUrl] = useState('');
  const [popFile, setPopFile] = useState('');
  const [voucherPin, setVoucherPin] = useState('');
  const [voucherUrl, setVoucherUrl] = useState('');
  const [voucherFile, setVoucherFile] = useState('');
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const fileRef = useRef();
  const voucherRef = useRef();

  const AMOUNT_MAP = { '7days': 20, '14days': 30, '30days': 50 };

  const handleUpload = async (e, type) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    if (type === 'pop') { setPopUrl(file_url); setPopFile(file.name); }
    else { setVoucherUrl(file_url); setVoucherFile(file.name); }
    setUploading(false);
  };

  const submit = async () => {
    if (paymentMethod === 'bank_transfer' && !popUrl) return alert('Please upload proof of payment.');
    if (paymentMethod === '1voucher' && !voucherPin && !voucherUrl) return alert('Please enter your 1Voucher PIN or upload a photo.');
    setSubmitting(true);
    await base44.entities.ISPNode.update(node.id, {
      renewal_plan: plan,
      renewal_payment_method: paymentMethod,
      renewal_payment_proof_url: paymentMethod === 'bank_transfer' ? popUrl : (voucherUrl || ''),
      renewal_voucher_pin: paymentMethod === '1voucher' ? voucherPin : '',
      renewal_amount: AMOUNT_MAP[plan],
      renewal_status: 'pending',
    });
    // Notify admin
    base44.functions.invoke('ispNodeDeploy', { action: 'on_renewal_request', nodeId: node.id }).catch(() => {});
    setSubmitting(false);
    setDone(true);
    setTimeout(onDone, 2000);
  };

  if (done) return <div className="text-center py-4 text-green-400 font-bold text-sm">✅ Renewal Submitted! Admin will review shortly.</div>;

  return (
    <div className="space-y-3">
      <p className="text-xs font-bold text-cyan-300 uppercase tracking-wider">🔄 Renewal Plan</p>
      <div className="flex gap-2">
        {[{ val: '7days', label: '7d', price: 'R20' }, { val: '14days', label: '14d', price: 'R30' }, { val: '30days', label: '30d', price: 'R50' }].map(p => (
          <button key={p.val} onClick={() => setPlan(p.val)}
            className={`flex-1 py-2.5 rounded-xl border text-xs font-bold transition-all text-center ${plan === p.val ? 'border-cyan-500/60 bg-cyan-500/10 text-cyan-300' : 'border-gray-700/40 bg-gray-800/40 text-gray-400'}`}>
            {p.label}<br /><span className="text-[10px]">{p.price}</span>
          </button>
        ))}
      </div>
      <div className="flex gap-2">
        {[{ val: 'bank_transfer', label: '🏦 Bank' }, { val: '1voucher', label: '🎟️ Voucher' }].map(m => (
          <button key={m.val} onClick={() => setPaymentMethod(m.val)}
            className={`flex-1 py-2 rounded-xl border text-xs font-semibold transition-all ${paymentMethod === m.val ? 'border-cyan-500/60 bg-cyan-500/10 text-cyan-300' : 'border-gray-700/40 bg-gray-800/40 text-gray-400'}`}>
            {m.label}
          </button>
        ))}
      </div>
      {paymentMethod === 'bank_transfer' && (
        <div className="bg-gray-900/70 border border-green-500/30 rounded-xl p-3 text-xs space-y-1.5">
          <p className="text-green-400 font-bold">🏦 Capitec: 2453250201 — Ref: Your WhatsApp</p>
          <p className="text-gray-400">Amount: <span className="text-green-400 font-black">R{AMOUNT_MAP[plan]}</span></p>
          <input ref={fileRef} type="file" accept="image/*,.pdf" className="hidden" onChange={e => handleUpload(e, 'pop')} />
          <button onClick={() => fileRef.current?.click()}
            className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border text-xs font-semibold transition-all ${popUrl ? 'border-green-500/50 bg-green-500/10 text-green-300' : 'border-gray-600/50 bg-gray-800/40 text-gray-400'}`}>
            {uploading ? <Loader className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
            {uploading ? 'Uploading...' : popUrl ? `✓ ${popFile}` : 'Upload Proof of Payment'}
          </button>
        </div>
      )}
      {paymentMethod === '1voucher' && (
        <div className="space-y-2">
          <input value={voucherPin} onChange={e => setVoucherPin(e.target.value)} placeholder="1Voucher PIN (optional)"
            className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-3 py-2.5 text-xs font-mono text-white focus:outline-none focus:border-cyan-500/50" />
          <input ref={voucherRef} type="file" accept="image/*" className="hidden" onChange={e => handleUpload(e, 'voucher')} />
          <button onClick={() => voucherRef.current?.click()}
            className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border text-xs font-semibold transition-all ${voucherUrl ? 'border-green-500/50 bg-green-500/10 text-green-300' : 'border-gray-600/50 bg-gray-800/40 text-gray-400'}`}>
            {uploading ? <Loader className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
            {uploading ? 'Uploading...' : voucherUrl ? `✓ ${voucherFile}` : 'Upload Voucher Photo'}
          </button>
        </div>
      )}
      <button onClick={submit} disabled={submitting || uploading}
        className="w-full py-3 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-cyan-600 to-blue-600 disabled:opacity-40 flex items-center justify-center gap-2">
        {submitting ? <><Loader className="w-4 h-4 animate-spin" /> Submitting...</> : '🔄 Submit Renewal'}
      </button>
    </div>
  );
}

// ── Inline Updates from Admin (inside NodeCard) ───────────────────────────────
function PackageNotificationsInline({ userEmail, approvedAt }) {
  const [packages, setPackages] = useState([]);
  const [collapsed, setCollapsed] = useState(true);

  useEffect(() => {
    const load = async () => {
      const notifs = await base44.entities.AppNotification.filter({ user_email: userEmail }, '-created_date', 50);
      // Only show packages sent AFTER this subscription was approved
      const cutoff = approvedAt || 0;
      setPackages(notifs.filter(n => n.file_url && new Date(n.created_date).getTime() >= cutoff));
    };
    load();
    const unsub = base44.entities.AppNotification.subscribe(() => load());
    return unsub;
  }, [userEmail, approvedAt]);

  if (packages.length === 0) return null;

  return (
    <div className="mb-4 bg-orange-500/8 border border-orange-500/25 rounded-xl overflow-hidden">
      <button onClick={() => setCollapsed(v => !v)}
        className="w-full flex items-center justify-between px-3 py-2.5">
        <div className="flex items-center gap-2">
          <Package className="w-3 h-3 text-orange-400" />
          <p className="text-[11px] font-bold text-orange-400 uppercase tracking-wider">Updates from Admin</p>
          <span className="text-[9px] bg-orange-500/20 text-orange-300 border border-orange-500/30 px-1.5 py-0.5 rounded-full font-bold">{packages.length}</span>
        </div>
        {collapsed ? <ChevronDown className="w-3.5 h-3.5 text-orange-400" /> : <ChevronUp className="w-3.5 h-3.5 text-orange-400" />}
      </button>
      <AnimatePresence initial={false}>
        {!collapsed && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }} className="overflow-hidden">
            <div className="px-3 pb-3 space-y-2">
              {packages.map(n => (
                <div key={n.id} className="bg-orange-500/10 border border-orange-500/30 rounded-xl p-3">
                  <p className="text-xs font-bold text-white mb-1.5">{n.title}</p>
                  {(n.message || n.body) && <p className="text-[10px] text-gray-300 leading-relaxed mb-2 whitespace-pre-line">{n.message || n.body}</p>}
                  <a href={n.file_url} target="_blank" rel="noopener noreferrer" download
                    className="flex items-center justify-center gap-1.5 py-2 bg-gradient-to-r from-orange-600 to-amber-600 rounded-xl text-[11px] font-bold text-white">
                    <Download className="w-3.5 h-3.5" /> Download {n.file_name || 'Config File'}
                  </a>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ── Active Node Card ──────────────────────────────────────────────────────────
function NodeCard({ node, userEmail }) {
  const cfg = STATUS_CFG[node.status] || STATUS_CFG.pending_payment;
  const Icon = cfg.icon;
  const [collapsed, setCollapsed] = useState(true); // default collapsed
  const [showRenewal, setShowRenewal] = useState(false);
  const isExpiring = node.expiry_epoch && (node.expiry_epoch - Date.now()) < 3 * 24 * 60 * 60 * 1000 && node.status === 'active';

  // Parse device info from admin_notes
  const deviceLine = (node.admin_notes || '').match(/Device[s]?:\s*([^|]+)/i)?.[1]?.trim() || '';
  const networkLine = (node.admin_notes || '').match(/Network[s]?:\s*([^|]+)/i)?.[1]?.trim() || '';

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
      className={`rounded-2xl border overflow-hidden mb-4 ${node.status === 'active' ? 'bg-gradient-to-b from-gray-900/70 to-gray-900/50 border-green-500/30' : 'bg-gray-900/70 border-gray-700/50'}`}>

      {/* Card Header — always visible */}
      <div className={`px-4 py-3 flex items-center justify-between ${node.status === 'active' ? 'border-b border-green-500/20' : 'border-b border-gray-700/40'}`}>
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <div className="w-8 h-8 rounded-xl flex items-center justify-center bg-cyan-500/20 flex-shrink-0">
            <Zap className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-bold text-white">Lets VPN Go — Paid</p>
            <p className="text-[10px] text-gray-500">{PLAN_LABEL[node.plan] || node.plan} · {PLAN_PRICE[node.plan] || ''}</p>
            {deviceLine && <p className="text-[10px] text-violet-400 truncate">{deviceLine}</p>}
          </div>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <span className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold border ${cfg.bg} ${cfg.color}`}>
            <Icon className="w-3 h-3" />
            {cfg.label}
          </span>
          <button onClick={() => setCollapsed(v => !v)}
            className="p-1.5 rounded-xl bg-gray-800/60 text-gray-400 hover:text-white transition-colors">
            {collapsed ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Collapsible body */}
      <AnimatePresence initial={false}>
        {!collapsed && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }} className="overflow-hidden">
            <div className="p-4">
              {/* Plan Info + Updates from Admin */}
              <div className="grid grid-cols-2 gap-2 mb-4">
                <div className="bg-gray-800/50 rounded-xl px-3 py-2.5">
                  <p className="text-[10px] text-gray-500 mb-0.5">Plan</p>
                  <p className="text-sm font-bold text-white">{PLAN_LABEL[node.plan] || node.plan}</p>
                  <p className="text-[10px] text-cyan-400">{node.amount_paid ? `R${node.amount_paid} paid` : ''}</p>
                </div>
                <div className={`rounded-xl px-3 py-2.5 ${isExpiring ? 'bg-orange-500/15 border border-orange-500/30' : 'bg-gray-800/50'}`}>
                  <p className="text-[10px] text-gray-500 mb-0.5">Time Left</p>
                  {node.status === 'active' ? <ExpiryCountdown node={node} /> : <p className="text-sm font-bold text-white">{node.expiry_date || '—'}</p>}
                </div>
              </div>
              {/* Updates from Admin — shown inside the active card, only packages sent after this node was approved */}
              {node.status === 'active' && (
                <PackageNotificationsInline
                  userEmail={node.user_email}
                  approvedAt={node.created_date ? new Date(node.created_date).getTime() : 0}
                />
              )}

              {/* PENDING APPROVAL */}
              {node.status === 'pending_approval' && (
                <div className="space-y-3">
                  <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl px-3 py-3 text-xs text-amber-300">
                    <p className="font-bold mb-1">⏳ Awaiting Verification — up to 24 hours</p>
                    <p className="text-gray-400 mb-2">Once verified, you'll get a notification + email with your config.</p>
                    <a href="https://wa.me/27692987836?text=Paid%40DeoVex" target="_blank" rel="noopener noreferrer"
                      className="flex items-center justify-center gap-2 py-2.5 bg-green-600/30 border border-green-500/40 text-green-300 font-bold rounded-xl hover:bg-green-600/50 transition-all">
                      <MessageSquare className="w-4 h-4" /> Send "Paid@DeoVex" to Admin
                    </a>
                  </div>
                </div>
              )}

              {/* ACTIVE */}
              {node.status === 'active' && (
                <div className="space-y-3">
                  <ConfigCards node={node} />

                  {!node.vless_string && !node.admin_notes && (
                    <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl px-3 py-3 text-xs text-blue-300">
                      <Loader className="w-3.5 h-3.5 inline mr-1.5 animate-spin" />
                      Config is being prepared. Please refresh in a moment.
                    </div>
                  )}

                  {/* Renewal when expiring */}
                  {isExpiring && (
                    <div className="bg-orange-500/10 border border-orange-500/30 rounded-xl p-3">
                      <p className="text-xs font-bold text-orange-400 mb-2">⚠️ Expiring Soon — Renew Now</p>
                      {node.renewal_status === 'pending' ? (
                        <p className="text-[11px] text-amber-300">✅ Renewal submitted — awaiting admin approval. You won't lose access.</p>
                      ) : (
                        <button onClick={() => setShowRenewal(v => !v)}
                          className="w-full py-2 bg-orange-600/30 border border-orange-500/40 text-orange-300 font-bold rounded-xl text-xs">
                          {showRenewal ? 'Hide Renewal' : '🔄 Submit Renewal Now'}
                        </button>
                      )}
                      {showRenewal && node.renewal_status !== 'pending' && (
                        <div className="mt-3">
                          <RenewalForm node={node} userEmail={userEmail} onDone={() => setShowRenewal(false)} />
                        </div>
                      )}
                    </div>
                  )}

                  <a href="https://mspy.qzz.io/letsvpngopaidversion" target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-3 bg-green-500/10 border border-green-500/30 rounded-xl px-4 py-3 hover:bg-green-500/15 transition-all">
                    <MessageSquare className="w-5 h-5 text-green-400 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="text-xs font-bold text-white">Join Paid Members WhatsApp Group</p>
                      <p className="text-[10px] text-green-400">Get updates, new configs & support</p>
                    </div>
                    <span className="text-xs text-gray-500">Join ↗</span>
                  </a>
                </div>
              )}

              {/* EXPIRED */}
              {node.status === 'expired' && (
                <div className="space-y-2">
                  <div className="bg-red-500/10 border border-red-500/30 rounded-xl px-3 py-2.5 text-xs text-red-300">
                    This subscription has expired.
                  </div>
                  {node.renewal_status === 'pending' ? (
                    <p className="text-[11px] text-amber-300 text-center">✅ Renewal submitted — awaiting admin approval.</p>
                  ) : (
                    <>
                      <button onClick={() => setShowRenewal(v => !v)}
                        className="w-full py-2.5 bg-cyan-600/30 border border-cyan-500/40 text-cyan-300 font-bold rounded-xl text-xs">
                        {showRenewal ? 'Hide' : '🔄 Renew Subscription'}
                      </button>
                      {showRenewal && (
                        <div className="mt-2">
                          <RenewalForm node={node} userEmail={userEmail} onDone={() => setShowRenewal(false)} />
                        </div>
                      )}
                    </>
                  )}
                  <a href="https://wa.me/27692987836?text=renew" target="_blank" rel="noopener noreferrer"
                    className="block text-center py-2 bg-green-600/20 border border-green-500/30 text-green-300 font-bold rounded-xl text-xs">
                    📱 WhatsApp to Renew: +27 69 298 7836
                  </a>
                </div>
              )}

              {/* REJECTED */}
              {node.status === 'rejected' && (
                <div className="space-y-2">
                  <div className="bg-red-500/10 border border-red-500/30 rounded-xl px-3 py-2.5 text-xs text-red-300">
                    {node.admin_notes ? `❌ ${node.admin_notes}` : 'Your order was rejected. Please contact support.'}
                  </div>
                  <a href="https://wa.me/27692987836" target="_blank" rel="noopener noreferrer"
                    className="block text-center py-2 bg-green-600/20 border border-green-500/30 text-green-300 font-bold rounded-xl text-xs">
                    📱 Contact Support: +27 69 298 7836
                  </a>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

// ── In-App Group Chat ─────────────────────────────────────────────────────────
const ADMIN_EMAIL = 'waynetk7@gmail.com';

function GroupChat({ userEmail, nickname, joinedAt }) {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [filterAdmin, setFilterAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [collapsed, setCollapsed] = useState(true);
  const bottomRef = useRef();

  const load = async () => {
    const all = await base44.entities.AppNotification.filter({ user_email: 'group_chat' }, '-created_date', 200);
    // Only show messages from after the user was approved (joinedAt epoch)
    const cutoff = joinedAt || 0;
    const visible = all.filter(m => !cutoff || new Date(m.created_date).getTime() >= cutoff);
    setMessages(visible.reverse());
    setLoading(false);
  };

  useEffect(() => {
    load();
    const unsub = base44.entities.AppNotification.subscribe(() => load());
    return unsub;
  }, [joinedAt]);

  useEffect(() => {
    if (!collapsed) bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, collapsed]);

  const send = async () => {
    const trimmed = text.trim();
    if (!trimmed) return;
    setSending(true);
    const isAdmin = userEmail === ADMIN_EMAIL;
    await base44.entities.AppNotification.create({
      user_email: 'group_chat',
      title: nickname || userEmail?.split('@')[0] || 'Member',
      message: trimmed,
      body: trimmed,
      type: isAdmin ? 'success' : 'info',
      is_read: true,
      read_by: [],
      read_count: 0,
    });
    setText('');
    setSending(false);
  };

  const displayed = filterAdmin ? messages.filter(m => m.created_by === ADMIN_EMAIL) : messages;
  const isAdminUser = userEmail === ADMIN_EMAIL;

  return (
    <div className="bg-gray-900/70 border border-gray-700/50 rounded-2xl overflow-hidden">
      {/* Header — collapsible */}
      <button onClick={() => setCollapsed(v => !v)}
        className="w-full px-4 py-3 border-b border-gray-700/40 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Users className="w-4 h-4 text-cyan-400" />
          <p className="text-sm font-bold text-white">Paid Members Group</p>
        </div>
        {collapsed ? <ChevronDown className="w-4 h-4 text-gray-400" /> : <ChevronUp className="w-4 h-4 text-gray-400" />}
      </button>

      <AnimatePresence initial={false}>
      {!collapsed && (<motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }} className="overflow-hidden">

      {/* Filter row */}
      <div className="px-4 pt-2 flex justify-end">
        <button onClick={() => setFilterAdmin(v => !v)}
          className={`flex items-center gap-1.5 text-[10px] font-bold px-2.5 py-1 rounded-xl border transition-all ${filterAdmin ? 'border-violet-500/60 bg-violet-500/15 text-violet-300' : 'border-gray-700/40 bg-gray-800/40 text-gray-500'}`}>
          {filterAdmin ? '⭐ Tk Master Only' : 'All Messages'}
        </button>
      </div>

      {/* Messages */}
      <div className="h-64 overflow-y-auto px-4 py-3 space-y-2">
        {loading ? (
          <div className="flex items-center justify-center h-full"><Loader className="w-5 h-5 text-cyan-400 animate-spin" /></div>
        ) : displayed.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <p className="text-gray-600 text-xs">No messages yet. Say hello! 👋</p>
          </div>
        ) : (
          displayed.map(msg => {
            const isMine = msg.created_by === userEmail;
            const isAdmin = msg.created_by === ADMIN_EMAIL;
            const senderName = msg.title || msg.created_by?.split('@')[0] || 'Member';
            return (
              <div key={msg.id} className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[75%] px-3 py-2 rounded-2xl ${isMine ? 'bg-violet-600/30 border border-violet-500/30 rounded-br-sm' : isAdmin ? 'bg-gradient-to-br from-cyan-600/30 to-blue-600/30 border border-cyan-500/40 rounded-bl-sm' : 'bg-gray-800/60 border border-gray-700/40 rounded-bl-sm'}`}>
                  {!isMine && (
                    <p className={`text-[10px] font-black mb-0.5 ${isAdmin ? 'text-cyan-400' : 'text-violet-400'}`}>
                      {isAdmin ? '⭐ Tk Master' : senderName}
                    </p>
                  )}
                  <p className="text-xs text-gray-200 leading-relaxed">{msg.message || msg.body}</p>
                  <p className="text-[9px] text-gray-600 mt-0.5 text-right">
                    {msg.created_date ? new Date(msg.created_date).toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' }) : ''}
                  </p>
                </div>
              </div>
            );
          })
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="px-4 py-3 border-t border-gray-700/40 flex gap-2">
        <input
          value={text}
          onChange={e => setText(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()}
          placeholder={isAdminUser ? 'Send as Tk Master...' : 'Type a message...'}
          className="flex-1 bg-gray-800/60 border border-gray-700/50 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-violet-500/50"
        />
        <button onClick={send} disabled={sending || !text.trim()}
          className="p-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-600 text-white disabled:opacity-40">
          {sending ? <Loader className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
        </button>
      </div>

      </motion.div>)}
      </AnimatePresence>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function ISPNodeDashboard() {
  const [nodes, setNodes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [activeNodeNickname, setActiveNodeNickname] = useState('');

  useEffect(() => {
    base44.auth.me().then(u => { setUser(u); loadNodes(u.email); });
  }, []);

  const loadNodes = async (email) => {
    setLoading(true);
    const data = await base44.entities.ISPNode.filter({ user_email: email }, '-created_date');
    setNodes(data);
    // Get nickname from most recent active node
    const activeNode = data.find(n => n.status === 'active' || n.nickname);
    if (activeNode?.nickname) setActiveNodeNickname(activeNode.nickname);
    setLoading(false);
  };

  const ADMIN_CHAT_EMAIL = 'waynetk7@gmail.com';
  const isAdmin = user?.email === ADMIN_CHAT_EMAIL;

  const activeNodes  = nodes.filter(n => n.status === 'active');
  const pendingNodes = nodes.filter(n => ['pending_payment', 'pending_approval'].includes(n.status));
  const otherNodes   = nodes.filter(n => ['expired', 'rejected'].includes(n.status));

  // Group chat access: only active nodes OR admin
  const chatNode = activeNodes[0] || null;
  // joinedAt = when the active node was last approved (use expiry_epoch - plan days as proxy, or created_date of node)
  const joinedAt = chatNode?.created_date ? new Date(chatNode.created_date).getTime() : 0;

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      {/* Header */}
      <div className="px-4 pt-6 pb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link to="/EthicalInternet" className="p-2 bg-gray-800/50 rounded-xl">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-lg font-bold">Paid Version Dashboard</h1>
            <p className="text-xs text-violet-400 font-mono">Lets VPN Go 🚀</p>
          </div>
        </div>
        <button onClick={() => user && loadNodes(user.email)} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-all">
          <RefreshCw className="w-4 h-4 text-gray-400" />
        </button>
      </div>

      <div className="px-4">
        {/* New Subscription CTA */}
        <Link to="/PaidVersionSetup"
          className="flex items-center justify-center gap-2 w-full mb-5 py-3.5 rounded-2xl font-bold text-sm text-white"
          style={{ background: 'linear-gradient(135deg, #7c3aed, #06b6d4)', boxShadow: '0 0 20px rgba(124,58,237,0.25)' }}>
          <Star className="w-4 h-4" /> New Subscription — from R20
        </Link>

        {/* Active nodes */}
        {activeNodes.length > 0 && (
          <>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              <p className="text-xs font-bold text-green-400 uppercase tracking-wider">Active Subscriptions</p>
            </div>
            {activeNodes.map(n => <NodeCard key={n.id} node={n} userEmail={user?.email} />)}
          </>
        )}

        {/* Pending nodes */}
        {pendingNodes.length > 0 && (
          <>
            <div className="flex items-center gap-2 mb-3 mt-2">
              <div className="w-2 h-2 bg-amber-400 rounded-full animate-pulse" />
              <p className="text-xs font-bold text-amber-400 uppercase tracking-wider">Pending Orders</p>
            </div>
            {pendingNodes.map(n => <NodeCard key={n.id} node={n} userEmail={user?.email} />)}
          </>
        )}

        {/* Group Chat — only for active subscribers OR admin */}
        {(chatNode || isAdmin) && user && (
          <div className="mb-4 mt-2">
            <GroupChat userEmail={user.email} nickname={activeNodeNickname || user.full_name} joinedAt={isAdmin ? 0 : joinedAt} />
          </div>
        )}

        {/* Empty state */}
        {loading ? (
          <div className="text-center py-12"><Loader className="w-6 h-6 text-cyan-400 animate-spin mx-auto" /></div>
        ) : nodes.length === 0 ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-violet-500/20 to-cyan-500/20 border border-violet-500/30 flex items-center justify-center mb-4">
              <Star className="w-8 h-8 text-violet-400" />
            </div>
            <p className="text-white font-bold mb-1">No Active Subscriptions</p>
            <p className="text-xs text-gray-500 mb-4">Subscribe to get your VPN config and start saving on data.</p>
          </div>
        ) : null}

        {/* History */}
        {otherNodes.length > 0 && (
          <>
            <p className="text-xs font-bold text-gray-600 uppercase tracking-wider mb-3 mt-2">History</p>
            {otherNodes.map(n => <NodeCard key={n.id} node={n} userEmail={user?.email} />)}
          </>
        )}
      </div>
    </div>
  );
}