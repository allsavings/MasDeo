import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Globe, Shield, Lock, Eye, Server, Wifi, Download, Terminal, Code, Search, Gauge, Star, Heart, ChevronRight, Gift, Smartphone, ShieldCheck, AlertTriangle, BookOpen, UserCheck, Zap } from 'lucide-react';

import ExploreCreatorsView from '../components/creator/ExploreCreatorsView';
import CreatorSectionDisplay from '../components/creator/CreatorSectionDisplay';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useCreatorMode } from '../components/useCreatorMode';
import CreatorModeToggle from '../components/creator/CreatorModeToggle';
import CreatorSectionEditor from '../components/creator/CreatorSectionEditor';
import { base44 } from '@/api/base44Client';
import LockedSectionOverlay from '../components/LockedSectionOverlay';
import { useWIPLock } from '@/lib/WIPLockContext';

export default function EthicalInternet() {
  const navigate = useNavigate();
  const { isRouteLocked } = useWIPLock();
  const { isCreatorMode, isCreatorEligible, canCreatorForSection, toggleCreatorMode, user, loading } = useCreatorMode();
  const showCreator = isCreatorMode && canCreatorForSection('ethical_internet') && !isRouteLocked('/CreatorMode');
  const [exploreMode, setExploreMode] = useState(() => localStorage.getItem('explore_creators_mode') === 'true');
  const [creators, setCreators] = useState([]);
  const [loadingCreators, setLoadingCreators] = useState(false);
  const [selectedCreatorEmail, setSelectedCreatorEmail] = useState(null);
  const [isFreemium, setIsFreemium] = useState(false);
  const [showSpeedTest, setShowSpeedTest] = useState(false);

  useEffect(() => {
    // Check freemium status
    checkUserFreemiumStatus();
  }, []);

  useEffect(() => {
    // Listen for changes to explore mode from other tabs/pages
    const checkExploreMode = () => {
      setExploreMode(localStorage.getItem('explore_creators_mode') === 'true');
    };
    window.addEventListener('storage', checkExploreMode);
    const interval = setInterval(checkExploreMode, 500);
    return () => {
      window.removeEventListener('storage', checkExploreMode);
      clearInterval(interval);
    };
  }, []);

  const checkUserFreemiumStatus = async () => {
    try {
      const user = await base44.auth.me();
      const userProfile = await base44.entities.UserProfile.filter({ created_by: user.email });
      if (userProfile[0]) {
        setIsFreemium(!userProfile[0].is_premium);
      }
    } catch (error) {
      console.error('Error checking freemium status:', error);
      setIsFreemium(true);
    }
  };



  useEffect(() => {
    if (exploreMode) {
      loadCreatorsAndContent();
    }
  }, [exploreMode]);

  const loadCreatorsAndContent = async () => {
    setLoadingCreators(true);
    try {
      const [allCreators, allSettings, allFollows] = await Promise.all([
        base44.entities.CreatorProfile.list(),
        base44.entities.CreatorSettings.list(),
        base44.entities.Follow.list()
      ]);

      const eligibleCreators = allCreators.filter(creator => {
        const setting = allSettings.find(s => s.user_email === creator.user_email);
        return setting?.is_public && (setting.all_platforms || setting.platforms?.includes('ethical'));
      });

      const profiles = await Promise.all(
        eligibleCreators.map(creator =>
          base44.entities.UserProfile.filter({ created_by: creator.user_email })
        )
      );

      const publicCreators = eligibleCreators.map((creator, i) => ({
        ...creator,
        profile: profiles[i][0] || null,
        followerCount: allFollows.filter(f => f.creator_email === creator.user_email).length
      }));

      setCreators(publicCreators);
    } catch (error) {
      console.error('Error loading creators:', error);
    } finally {
      setLoadingCreators(false);
    }
  };

  const topics = [
    { title: "Privacy Basics", description: "Learn how to protect your personal data online", icon: Shield, color: "from-blue-500 to-indigo-500" },
    { title: "Secure Browsing", description: "Use the internet safely and anonymously", icon: Lock, color: "from-green-500 to-emerald-500" },
    { title: "Digital Footprint", description: "Understand and manage your online presence", icon: Eye, color: "from-purple-500 to-pink-500" },
    { title: "Free Resources", description: "Access legitimate free tools and services", icon: Server, color: "from-cyan-500 to-blue-500" },
    { title: "Network Security", description: "Protect your devices and connections", icon: Wifi, color: "from-amber-500 to-orange-500" }
  ];

  const handleAdRequiredClick = (e) => {
    if (!isFreemium) return;
    
    const clickedLink = e.target.closest('a');
    if (!clickedLink) return;
    
    // Check if ads are globally disabled or user has disabled them
    const globalAdsEnabled = localStorage.getItem('global_ads_enabled') !== 'false';
    const userAdsDisabled = localStorage.getItem('user_ads_disabled') === 'true';
    if (!globalAdsEnabled || userAdsDisabled) return;
    
    const isFreeClick = sessionStorage.getItem('next_click_free') === 'true';
    if (isFreeClick) {
      sessionStorage.removeItem('next_click_free');
      return;
    }

    e.preventDefault();
    navigate('/AdView', { state: { from: '/EthicalInternet' } });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32" onClick={isFreemium ? handleAdRequiredClick : undefined}>

      {/* Header */}
      <div className="px-6 pt-6 pb-4 relative z-40">
        <div className="flex items-center gap-4 mb-4">
          <Link to={createPageUrl("Home")} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors" onClick={e => e.stopPropagation()}>
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-xl font-bold">Ethical Free Internet</h1>
        </div>
      </div>

      {/* Creator Mode Toggle */}
      {!isRouteLocked('/CreatorMode') && (
        <div className="relative z-40">
          <CreatorModeToggle
            isCreatorMode={isCreatorMode}
            isCreatorEligible={isCreatorEligible && canCreatorForSection('ethical_internet')}
            onToggle={toggleCreatorMode}
          />
        </div>
      )}

      {/* CREATOR MODE CONTENT */}
      {showCreator ? (
        <CreatorSectionEditor user={user} sectionPage="ethical" />
      ) : selectedCreatorEmail ? (
        <CreatorSectionDisplay 
          creatorEmail={selectedCreatorEmail} 
          sectionPage="ethical" 
          theme="ethical" 
          onBack={() => setSelectedCreatorEmail(null)}
          isFreemium={isFreemium}
          navigate={navigate}
        />
      ) : exploreMode && !isRouteLocked('/ExploreCreators') ? (
        <ExploreCreatorsView creators={creators} loading={loadingCreators} theme="ethical" prioritySection="ethical" onSelectCreator={setSelectedCreatorEmail} />
      ) : (
        <>
          {/* Ethical Internet Principles Card */}
          <div className="px-6 mb-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gradient-to-r from-blue-600/30 to-cyan-600/30 rounded-2xl p-5 border border-blue-500/30"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center flex-shrink-0">
                  <Globe className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="font-bold text-lg">Ethical Internet Principles</h2>
                  <p className="text-xs text-gray-400">The foundation of this platform</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { icon: Shield, label: 'Stay Safe', color: 'text-cyan-400' },
                  { icon: Eye, label: 'Respect Privacy', color: 'text-blue-400' },
                  { icon: UserCheck, label: 'Use Tools Legally', color: 'text-green-400' },
                  { icon: AlertTriangle, label: 'Avoid Scams', color: 'text-amber-400' },
                  { icon: Zap, label: 'Build Digital Independence', color: 'text-purple-400' },
                  { icon: BookOpen, label: 'Keep Learning', color: 'text-pink-400' },
                ].map((p, i) => (
                  <div key={i} className="flex items-center gap-2 bg-white/5 rounded-xl px-3 py-2">
                    <p.icon className={`w-4 h-4 ${p.color} flex-shrink-0`} />
                    <span className="text-xs text-gray-300 font-medium">{p.label}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Internet Protection — FIRST */}
          <div className="px-6 mb-6">
            <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider mb-3">🛡️ Internet Protection — Start Here</h3>
            <Link to={createPageUrl("InternetProtection")}>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-gradient-to-r from-red-600/30 to-rose-600/30 rounded-2xl p-5 border border-red-500/40 hover:border-red-500/70 transition-all group cursor-pointer"
              >
                <div className="flex items-center gap-4 mb-3">
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-red-500 to-rose-600 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                    <ShieldCheck className="w-7 h-7 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-white text-lg mb-1">Internet Protection</h4>
                    <p className="text-sm text-gray-400">SAFETY FIRST — Your safety is our first priority</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-red-400 group-hover:translate-x-1 transition-transform" />
                </div>
                <div className="flex items-center justify-around mt-1">
                  {['🔏', '🔒', '⚠️', '📶'].map((emoji, i) => (
                    <div key={i} className="w-10 h-10 rounded-xl bg-red-500/15 border border-red-500/20 flex items-center justify-center text-lg">
                      {emoji}
                    </div>
                  ))}
                </div>
              </motion.div>
            </Link>
          </div>

          {/* Recommended VPN */}
          <div className="px-6 mb-6">
            <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider mb-3">Recommended VPN</h3>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gradient-to-r from-pink-600/20 to-orange-600/20 rounded-2xl p-5 border border-pink-500/30"
            >
              <div className="flex items-start gap-4 mb-4">
                <img src="https://media.base44.com/images/public/69ab75e75a89c53cd29e052d/982659b51_Iconimage.png" alt="Lets VPN Go" className="w-14 h-14 rounded-xl flex-shrink-0 object-cover" />
                <div className="flex-1">
                  <h4 className="font-bold text-white text-lg mb-1">Lets VPN Go</h4>
                  <p className="text-sm text-gray-400 mb-3">Fast, secure, and free VPN service. Protect your privacy and access content worldwide.</p>
                  <div className="space-y-2">
                    <a href="https://play.google.com/store/apps/details?id=smith.vpn.ko.ni.pro" target="_blank" rel="noopener noreferrer"
                      className="flex items-center gap-2 bg-green-500/20 border border-green-500/30 rounded-xl px-4 py-2.5 hover:bg-green-500/30 transition-colors">
                      <Download className="w-4 h-4 text-green-400" />
                      <span className="text-sm font-medium text-white">Download from PlayStore</span>
                    </a>
                    <a href="https://www.mediafire.com/file/gemdp60vslrqsuc/LetsVPNGo_v5.apk/file" target="_blank" rel="noopener noreferrer"
                      className="flex items-center gap-2 bg-blue-500/20 border border-blue-500/30 rounded-xl px-4 py-2.5 hover:bg-blue-500/30 transition-colors">
                      <Download className="w-4 h-4 text-blue-400" />
                      <span className="text-sm font-medium text-white">Download APK Direct</span>
                    </a>
                    <a href="https://drive.google.com/file/d/1_aCPn-c6EllepWGfGFfC22wy0W4uWLEX/view?usp=drivesdk" target="_blank" rel="noopener noreferrer"
                      className="flex items-center gap-2 bg-purple-500/20 border border-purple-500/30 rounded-xl px-4 py-2.5 hover:bg-purple-500/30 transition-colors">
                      <Download className="w-4 h-4 text-purple-400" />
                      <span className="text-sm font-medium text-white">Offline Update File</span>
                    </a>
                    <Link to={createPageUrl("LetsVPNGoInfo")}
                      className="flex items-center gap-2 bg-pink-500/20 border border-pink-500/30 rounded-xl px-4 py-2.5 hover:bg-pink-500/30 transition-colors">
                      <Star className="w-4 h-4 text-pink-400" />
                      <span className="text-sm font-medium text-white">INFO</span>
                      <ChevronRight className="w-4 h-4 text-pink-400 ml-auto" />
                    </Link>
                  </div>
                </div>
              </div>
              <div className="bg-pink-500/10 rounded-xl p-3 border border-pink-500/20">
                <p className="text-xs text-pink-300">✓ No registration required • ✓ Unlimited bandwidth • ✓ Multiple servers</p>
              </div>
            </motion.div>
          </div>

          {/* Resources & Deals Nav Cards */}
          <div className="px-6 space-y-3">
            <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider mb-1">Resources & Deals</h3>

            {/* Lets VPN Go | Paid Version — combined card */}
            <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0 }}>
              <div className="bg-gradient-to-r from-violet-600/25 to-cyan-600/25 rounded-2xl p-5 border border-violet-500/50 relative overflow-hidden">
                <div className="absolute top-2 right-2 bg-gradient-to-r from-violet-500 to-cyan-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">Paid</div>
                <div className="flex items-center gap-4 mb-3">
                  <img src="https://media.base44.com/images/public/69ab75e75a89c53cd29e052d/982659b51_Iconimage.png" alt="Lets VPN Go" className="w-14 h-14 rounded-xl object-cover flex-shrink-0" style={{ boxShadow: '0 0 16px rgba(139,92,246,0.4)' }} />
                  <div className="flex-1">
                    <h4 className="font-bold text-white text-base mb-0.5">Lets VPN Go | Paid Version</h4>
                    <p className="text-xs text-violet-300">AllNet Unlimited — from R20 / 7 days</p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-1.5 mb-4">
                  {['🚀 Super-Fast Servers', '📶 AllNet Unlimited', '🌍 Android/iPhone/PC', '⚡ From R20'].map((f, i) => (
                    <span key={i} className="text-[10px] bg-violet-500/15 border border-violet-500/25 text-violet-200 px-2 py-0.5 rounded-full">{f}</span>
                  ))}
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Link to="/PaidVersionDashboard" onClick={e => e.stopPropagation()}
                    className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-violet-600/30 border border-violet-500/40 text-violet-200 font-bold text-xs hover:bg-violet-600/50 transition-all">
                    <Star className="w-3.5 h-3.5" /> Lets Go
                  </Link>
                  <LockedSectionOverlay isLocked={isRouteLocked('/PaidVersionSetup')} sectionName="Join Paid Version" compact path="/PaidVersionSetup">
                    <Link to="/PaidVersionSetup" onClick={e => e.stopPropagation()}
                      className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-600 text-white font-bold text-xs hover:opacity-90 transition-all">
                      <Zap className="w-3.5 h-3.5" /> Join Paid Version
                    </Link>
                  </LockedSectionOverlay>
                </div>
              </div>
            </motion.div>

            {[
              { key: 'rewards', icon: Gift, label: 'Rewards Platforms', desc: 'Verified cashback & earning platforms', color: 'from-amber-500 to-orange-500', border: 'hover:border-amber-500/60' },
              { key: 'cheap_data', icon: Smartphone, label: 'Cheap Data Deals', desc: 'Best prepaid & postpaid bundles in SA', color: 'from-cyan-500 to-blue-500', border: 'hover:border-cyan-500/60' },
              { key: 'wifi_fibre', icon: Wifi, label: 'Affordable WiFi & Fibre', desc: 'Budget fibre & community WiFi options', color: 'from-blue-500 to-indigo-500', border: 'hover:border-blue-500/60' },
              { key: 'protection', icon: ShieldCheck, label: 'Device Protection Tools', desc: 'Free tools to keep your device safe', color: 'from-red-500 to-rose-500', border: 'hover:border-red-500/60' },
            ].map((item, i) => (
              <motion.div key={item.key} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: (i + 1) * 0.07 }}>
                <LockedSectionOverlay isLocked={isRouteLocked(`/ServiceDirectory`)} sectionName={item.label} path="/ServiceDirectory">
                  <Link to={createPageUrl(`ServiceDirectory?section=${item.key}`)}>
                    <div className={`bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50 ${item.border} transition-all cursor-pointer group`}>
                      <div className="flex items-center gap-4">
                        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${item.color} flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                          <item.icon className="w-6 h-6 text-white" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-white mb-0.5">{item.label}</h4>
                          <p className="text-sm text-gray-400">{item.desc}</p>
                        </div>
                        <ChevronRight className="w-4 h-4 text-gray-500 group-hover:text-white transition-colors" />
                      </div>
                    </div>
                  </Link>
                </LockedSectionOverlay>
              </motion.div>
            ))}
          </div>

          {/* Tools */}
          <div className="px-6 space-y-4 mt-6">
            <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider">Essential Tools</h3>
            {/* 1. Website Verification Recon */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0 }}>
              <LockedSectionOverlay isLocked={isRouteLocked('/HostScanner')} sectionName="Website Verification Recon" path="/HostScanner">
                <Link to={createPageUrl("HostScanner")}>
                  <div className="bg-gradient-to-r from-cyan-600/20 to-blue-600/20 rounded-2xl p-5 border border-cyan-500/30 hover:border-cyan-500/60 transition-all cursor-pointer group">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                        <Search className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-white mb-1">Website Verification Recon</h4>
                        <p className="text-sm text-gray-400">High-speed bulk scanner to discover & verify live websites</p>
                      </div>
                      <ChevronRight className="w-4 h-4 text-gray-500 group-hover:text-cyan-400 transition-colors" />
                    </div>
                  </div>
                </Link>
              </LockedSectionOverlay>
            </motion.div>

            {/* Speed Test — iframe */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
              <div onClick={() => setShowSpeedTest(true)} className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50 hover:border-amber-500/50 transition-all cursor-pointer group">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                    <Gauge className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-white mb-1">Speed Test</h4>
                    <p className="text-sm text-gray-400">Test your internet connection speed</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-500 group-hover:text-amber-400 transition-colors" />
                </div>
              </div>
            </motion.div>

            {/* Scripts & Termux */}
            {[
              { icon: Code, color: "from-purple-500 to-pink-500", title: "Scripts", desc: "Automation scripts for various tasks", border: "hover:border-purple-500/50" },
              { icon: Terminal, color: "from-green-500 to-emerald-500", title: "Termux", desc: "Terminal emulator and Linux environment", border: "hover:border-green-500/50" },
            ].map((tool, i) => (
              <motion.div key={tool.title} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: (i + 2) * 0.1 }}>
                <div className={`bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50 ${tool.border} transition-all cursor-pointer group`}>
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${tool.color} flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                      <tool.icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-white mb-1">{tool.title}</h4>
                      <p className="text-sm text-gray-400">{tool.desc}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Topics */}
          <div className="px-6 space-y-4 mt-6">
            <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider">Topics</h3>
            {topics.map((topic, index) => (
              <motion.div key={topic.title} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 + index * 0.1 }}>
                <div className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50 hover:border-blue-500/50 transition-all cursor-pointer group">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${topic.color} flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                      <topic.icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-white mb-1">{topic.title}</h4>
                      <p className="text-sm text-gray-400">{topic.description}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* 🌐 FN Sites — at the end */}
          <div className="px-6 mt-6 mb-6 space-y-3">
            <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider mb-3">🌐 FN Sites</h3>
            {[
              { title: 'CHAOS CONFIG HUB', desc: 'Free VPN configs & tools hub', url: 'https://vpnconfighub.netlify.app', color: 'from-orange-500 to-red-600', border: 'hover:border-orange-500/50' },
              { title: 'ITACHI CFG DROP', desc: 'Config drops by Itachi Goat', url: 'https://cfg.itachigoat.co.za', color: 'from-violet-500 to-purple-700', border: 'hover:border-violet-500/50' },
            ].map((site, i) => (
              <motion.div key={site.title} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
                <a href={site.url} target="_blank" rel="noopener noreferrer" className={`flex items-center gap-4 bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50 ${site.border} transition-all cursor-pointer group`}>
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${site.color} flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                    <Globe className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-white mb-1">{site.title}</h4>
                    <p className="text-sm text-gray-400">{site.desc}</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-500 group-hover:text-white transition-colors" />
                </a>
              </motion.div>
            ))}
          </div>
        </>
      )}

      {/* Speed Test iframe modal */}
      {showSpeedTest && (
        <div className="fixed inset-0 z-[9999] bg-black flex flex-col">
          <div className="flex items-center justify-between px-4 py-3 bg-[#0a0a0f] border-b border-gray-800/60 flex-shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center">
                <Gauge className="w-4 h-4 text-white" />
              </div>
              <p className="text-sm font-bold text-white">Speed Test</p>
            </div>
            <button onClick={() => setShowSpeedTest(false)} className="p-2 rounded-xl bg-gray-800/60 text-gray-400 hover:text-white transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
          </div>
          <iframe
            src="https://fast.com"
            className="flex-1 w-full border-none"
            title="Speed Test"
            allow="geolocation"
            sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
          />
        </div>
      )}
    </div>
  );
}