import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { ArrowLeft, CheckCircle, Clock, XCircle, Plus, Zap, ZapOff, CalendarDays, Globe, BookOpen, DollarSign, Sparkles, RefreshCw } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { format, parseISO, isAfter, isBefore } from 'date-fns';

const PLAN_META = {
  ethical_internet: { name: 'Ethical Free Internet', icon: Globe, color: 'from-blue-500 to-cyan-400', border: 'border-blue-500/30' },
  learn_skills:     { name: 'Learn Digital Skills',  icon: BookOpen, color: 'from-purple-500 to-blue-500', border: 'border-purple-500/30' },
  earn_online:      { name: 'Earn Online',            icon: DollarSign, color: 'from-emerald-500 to-cyan-400', border: 'border-emerald-500/30' },
  all_in_one:       { name: 'All In One',             icon: Sparkles, color: 'from-amber-500 to-orange-500', border: 'border-amber-500/30' }
};

const STATUS_CONFIG = {
  pending:   { icon: Clock,        color: 'text-amber-400',  bg: 'bg-amber-500/15',  label: 'Pending Review' },
  active:    { icon: CheckCircle,  color: 'text-green-400',  bg: 'bg-green-500/15',  label: 'Active' },
  rejected:  { icon: XCircle,      color: 'text-red-400',    bg: 'bg-red-500/15',    label: 'Rejected' },
  cancelled: { icon: XCircle,      color: 'text-gray-400',   bg: 'bg-gray-500/15',   label: 'Cancelled' }
};

export default function MySubscription() {
  const [user, setUser] = useState(null);
  const [subscriptions, setSubscriptions] = useState([]);
  const [creatorModeActive, setCreatorModeActive] = useState(() => localStorage.getItem('creator_mode_active') === 'true');
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    const userData = await base44.auth.me();
    setUser(userData);
    const subs = await base44.entities.Subscription.filter({ user_email: userData.email }, '-created_date');
    setSubscriptions(subs);
    setLoading(false);
  };

  // Group by plan to show per-plan history
  const planGroups = Object.keys(PLAN_META).map(planId => ({
    planId,
    subs: subscriptions.filter(s => s.plan === planId)
  })).filter(g => g.subs.length > 0);

  const getActiveSub = (planSubs) => planSubs.find(s => s.status === 'active');

  const isExpired = (sub) => {
    if (!sub.end_date) return false;
    return isBefore(parseISO(sub.end_date), new Date());
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white flex items-center justify-center">
        <div className="text-gray-400">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center gap-4 mb-5">
          <Link to={createPageUrl("Home")} className="p-2 bg-gray-800/50 rounded-xl">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-xl font-bold">Premium Subscription</h1>
            {user && <p className="text-xs text-gray-500">{user.email}</p>}
          </div>
        </div>

        {/* Subscribe CTA Banner */}
        <Link to={createPageUrl("Subscribe")}>
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/40 rounded-2xl p-4 flex items-center justify-between group hover:border-amber-500/70 transition-all"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-sm font-bold text-white">Subscribe / Renew a Plan</p>
                <p className="text-xs text-gray-400">Unlock exclusive features</p>
              </div>
            </div>
            <div className="flex items-center gap-1 bg-amber-500 text-white text-xs font-semibold px-3 py-1.5 rounded-xl">
              <Plus className="w-3 h-3" /> New
            </div>
          </motion.div>
        </Link>

        {planGroups.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-gray-800/60 rounded-full flex items-center justify-center mx-auto mb-4">
              <Sparkles className="w-8 h-8 text-gray-500" />
            </div>
            <p className="text-gray-400 mb-2 font-medium">No subscriptions yet</p>
            <p className="text-gray-600 text-sm mb-6">Subscribe to unlock premium features</p>
            <Link to={createPageUrl("Subscribe")}>
              <Button className="bg-blue-600">Subscribe Now</Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-5">
            {planGroups.map(({ planId, subs }, gi) => {
              const meta = PLAN_META[planId];
              const activeSub = getActiveSub(subs);
              const latestSub = subs[0]; // sorted by created_date desc
              const expired = activeSub ? isExpired(activeSub) : false;

              return (
                <motion.div
                  key={planId}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: gi * 0.08 }}
                  className={`rounded-2xl border overflow-hidden ${meta.border} bg-gray-800/30`}
                >
                  {/* Plan Header */}
                  <div className={`bg-gradient-to-r ${meta.color} p-px`}>
                    <div className="bg-gray-900/95 rounded-t-2xl px-5 py-4 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${meta.color} flex items-center justify-center`}>
                          <meta.icon className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <h3 className="font-bold text-white">{meta.name}</h3>
                          <p className="text-xs text-gray-400">{subs.length} subscription{subs.length > 1 ? 's' : ''}</p>
                        </div>
                      </div>
                      {activeSub && !expired && (
                        <span className="flex items-center gap-1 bg-green-500/20 text-green-400 text-xs px-2 py-1 rounded-full border border-green-500/30 font-medium">
                          <CheckCircle className="w-3 h-3" /> Active
                        </span>
                      )}
                      {activeSub && expired && (
                        <span className="flex items-center gap-1 bg-red-500/20 text-red-400 text-xs px-2 py-1 rounded-full border border-red-500/30 font-medium">
                          <XCircle className="w-3 h-3" /> Expired
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="px-5 py-4 space-y-3">
                    {/* Active sub date range */}
                    {activeSub && activeSub.start_date && activeSub.end_date && (
                      <div className={`flex items-center gap-3 rounded-xl px-4 py-3 ${expired ? 'bg-red-500/10 border border-red-500/20' : 'bg-green-500/10 border border-green-500/20'}`}>
                        <CalendarDays className={`w-5 h-5 flex-shrink-0 ${expired ? 'text-red-400' : 'text-green-400'}`} />
                        <div>
                          <p className="text-xs text-gray-400 mb-0.5">Subscription period</p>
                          <p className={`text-sm font-semibold ${expired ? 'text-red-300' : 'text-green-300'}`}>
                            {format(parseISO(activeSub.start_date), 'dd MMM yyyy')} → {format(parseISO(activeSub.end_date), 'dd MMM yyyy')}
                          </p>
                          {!expired && (
                            <p className="text-xs text-gray-500 mt-0.5">
                              Renewing will continue from {format(parseISO(activeSub.end_date), 'dd MMM yyyy')}
                            </p>
                          )}
                        </div>
                      </div>
                    )}

                    {/* All subscription history for this plan */}
                    <div className="space-y-2">
                      {subs.map((sub, i) => {
                        const sc = STATUS_CONFIG[sub.status] || STATUS_CONFIG.pending;
                        return (
                          <div key={sub.id} className="flex items-center justify-between bg-gray-900/50 rounded-xl px-3 py-2.5">
                            <div className="flex items-center gap-2">
                              {i > 0 && <RefreshCw className="w-3 h-3 text-gray-600" />}
                              <div>
                                <div className="flex items-center gap-2">
                                  <span className="text-xs text-white font-medium">R{sub.amount_paid}</span>
                                  {sub.start_date && sub.end_date && (
                                    <span className="text-xs text-gray-500">
                                      {format(parseISO(sub.start_date), 'dd MMM yy')} – {format(parseISO(sub.end_date), 'dd MMM yy')}
                                    </span>
                                  )}
                                </div>
                                <p className="text-xs text-gray-600">
                                  Submitted {format(new Date(sub.created_date), 'dd MMM yyyy')}
                                  {sub.approved_date ? ` · Approved ${format(parseISO(sub.approved_date), 'dd MMM yyyy')}` : ''}
                                </p>
                              </div>
                            </div>
                            <div className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs ${sc.bg}`}>
                              <sc.icon className={`w-3 h-3 ${sc.color}`} />
                              <span className={sc.color}>{sc.label}</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Notes */}
                    {latestSub.notes && (
                      <p className="text-xs text-amber-400 bg-amber-500/10 rounded-xl px-3 py-2">Note: {latestSub.notes}</p>
                    )}

                    {/* Creator mode toggle */}
                    {activeSub && activeSub.status === 'active' && !expired && (
                      <div className="space-y-2 pt-1">
                        <button
                          onClick={() => {
                            const next = !creatorModeActive;
                            setCreatorModeActive(next);
                            localStorage.setItem('creator_mode_active', next ? 'true' : 'false');
                          }}
                          className={`w-full flex items-center justify-between px-4 py-3 rounded-xl border transition-all ${
                            creatorModeActive
                              ? 'bg-purple-600/20 border-purple-500/50 text-purple-300'
                              : 'bg-gray-800/50 border-gray-700/50 text-gray-400'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            {creatorModeActive ? <Zap className="w-4 h-4" /> : <ZapOff className="w-4 h-4" />}
                            <span className="text-sm font-medium">Creator Mode: {creatorModeActive ? 'ON' : 'OFF'}</span>
                          </div>
                          <div className={`relative w-10 h-5 rounded-full transition-all ${creatorModeActive ? 'bg-purple-500' : 'bg-gray-700'}`}>
                            <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all ${creatorModeActive ? 'left-5' : 'left-0.5'}`} />
                          </div>
                        </button>
                        <Link to={createPageUrl("CreatorMode")}>
                          <Button className="w-full bg-purple-600/80 hover:bg-purple-600 text-sm">Open Creator Dashboard</Button>
                        </Link>
                      </div>
                    )}

                    {/* Renew button */}
                    {(expired || !activeSub) && (
                      <Link to={createPageUrl("Subscribe")}>
                        <Button className={`w-full bg-gradient-to-r ${meta.color} text-white font-semibold`}>
                          <RefreshCw className="w-4 h-4 mr-2" />
                          {expired ? 'Renew Subscription' : 'Subscribe'}
                        </Button>
                      </Link>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}