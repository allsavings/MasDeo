import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft, Zap, Shield, CheckCircle, Upload, Copy, Loader,
  MessageSquare, Smartphone, Monitor, ChevronRight, Star, Wifi,
  Users, UserCheck, Info, X, Sparkles
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0;
    return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
  });
}

const PLANS = [
  { val: '7days',  label: '7 Days',  price: 'R20', desc: 'Try it out — perfect starter' },
  { val: '14days', label: '14 Days', price: 'R30', desc: 'Most popular — great value' },
  { val: '30days', label: '30 Days', price: 'R50', desc: 'Best deal — full month' },
];

const NETWORKS = [
  { val: 'cellc',   label: 'Cell C',   color: 'border-blue-500/50 bg-blue-500/10 text-blue-300',     selColor: 'border-blue-500 bg-blue-500/20' },
  { val: 'mtn',     label: 'MTN',      color: 'border-yellow-500/50 bg-yellow-500/10 text-yellow-300', selColor: 'border-yellow-500 bg-yellow-500/20' },
  { val: 'vodacom', label: 'VodaCom',  color: 'border-red-500/50 bg-red-500/10 text-red-300',         selColor: 'border-red-500 bg-red-500/20' },
  { val: 'telkom',  label: 'Telkom',   color: 'border-sky-500/50 bg-sky-500/10 text-sky-300',         selColor: 'border-sky-500 bg-sky-500/20' },
  { val: 'rain',    label: 'Rain',     color: 'border-purple-500/50 bg-purple-500/10 text-purple-300', selColor: 'border-purple-500 bg-purple-500/20' },
];

// Device ID instructions per VPN app
const DEVICE_ID_INSTRUCTIONS = {
  npv: {
    title: 'How to find your NPV Tunnel Device ID',
    steps: [
      'Open NPV Tunnel on your device.',
      'Tap the ☰ menu (top-left) or go to Settings.',
      'Look for "Device ID" or "About" section.',
      'Copy the Device ID shown there.',
      'Paste it in the field below + take a screenshot of it.',
    ],
    screenshotNote: 'Screenshot must clearly show the Device ID inside the NPV Tunnel app.',
  },
  netmod: {
    title: 'How to find your NetMod Hardware ID',
    steps: [
      'Open NetMod Socks on your PC / device.',
      'Click on "Settings" or the gear icon.',
      'Find "Hardware ID" or "Device Key" listed there.',
      'Copy it and paste below.',
      'Take a screenshot showing the Hardware ID clearly.',
    ],
    screenshotNote: 'Screenshot must show the Hardware ID inside NetMod settings.',
  },
};

const DEVICES = [
  {
    val: 'android', label: 'Android', icon: Smartphone,
    vpns: [
      { val: 'letsvpngo', label: 'Lets VPN Go', url: 'https://play.google.com/store/apps/details?id=smith.vpn.ko.ni.pro', needsDeviceId: false },
      { val: 'npv',       label: 'NPV Tunnel',  url: 'https://play.google.com/store/search?q=npv+tunnel', needsDeviceId: true, idType: 'npv' },
    ],
  },
  {
    val: 'iphone', label: 'iPhone', icon: Smartphone,
    vpns: [
      { val: 'npv', label: 'NPV Tunnel', url: 'https://apps.apple.com/search?term=npv+tunnel', needsDeviceId: true, idType: 'npv' },
    ],
  },
  {
    val: 'pc', label: 'PC / Laptop', icon: Monitor,
    vpns: [
      { val: 'netmod', label: 'NetMod', url: 'https://play.google.com/store/search?q=netmod', needsDeviceId: true, idType: 'netmod' },
    ],
  },
];

const AMOUNT_MAP = { '7days': 20, '14days': 30, '30days': 50 };
const MAX_DEVICES = 2;

// ── Device ID Instructions Modal ──────────────────────────────────────────────
function DeviceIdInstructions({ idType, onClose }) {
  const info = DEVICE_ID_INSTRUCTIONS[idType];
  if (!info) return null;
  return (
    <div className="fixed inset-0 z-[99999] flex items-center justify-center bg-black/70 backdrop-blur-sm px-4" onClick={onClose}>
      <motion.div initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 60, opacity: 0 }}
        className="w-full max-w-lg bg-[#13131f] border border-cyan-500/30 rounded-3xl p-5 shadow-2xl max-h-[85vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-bold text-cyan-300">{info.title}</h3>
          <button onClick={onClose} className="p-1.5 rounded-xl bg-gray-800/60 text-gray-400"><X className="w-4 h-4" /></button>
        </div>
        <div className="space-y-2 mb-4">
          {info.steps.map((s, i) => (
            <div key={i} className="flex gap-3">
              <div className="w-5 h-5 rounded-full bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-[10px] font-black text-cyan-400">{i + 1}</span>
              </div>
              <p className="text-xs text-gray-300 leading-relaxed">{s}</p>
            </div>
          ))}
        </div>
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl px-3 py-2">
          <p className="text-[11px] text-amber-300">📸 {info.screenshotNote}</p>
        </div>
      </motion.div>
    </div>
  );
}

// ── What's New section ─────────────────────────────────────────────────────────
function WhatsNewSection() {
  const [items, setItems] = useState([]);
  useEffect(() => {
    base44.entities.PaidVersionAnnouncement.list('-sort_order', 10).then(data => {
      setItems(data.filter(i => i.is_published !== false));
    });
  }, []);
  if (items.length === 0) return null;
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Sparkles className="w-4 h-4 text-violet-400" />
        <p className="text-xs font-bold text-violet-300 uppercase tracking-wider">What's New</p>
      </div>
      {items.map(item => (
        <div key={item.id} className="bg-gray-900/60 border border-violet-500/20 rounded-2xl overflow-hidden">
          {item.image_url && (
            <img src={item.image_url} alt="" className="w-full max-h-48 object-cover" />
          )}
          <div className="p-4">
            <p className="text-sm font-bold text-white mb-1.5">{item.title}</p>
            <p className="text-xs text-gray-300 leading-relaxed whitespace-pre-line">{item.body}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Social Proof Bar ───────────────────────────────────────────────────────────
function TrustBar() {
  const [stats, setStats] = useState({ paid: 0, visitors: 0 });
  useEffect(() => {
    base44.entities.ISPNode.list('-created_date', 500).then(nodes => {
      // Unique paid members = unique emails with at least one active/approved/deploying sub
      const paidEmails = new Set(
        nodes
          .filter(n => ['active', 'pending_approval', 'deploying'].includes(n.status))
          .map(n => n.user_email)
      );
      // Unique total submitters (everyone who ever placed an order)
      const allEmails = new Set(nodes.map(n => n.user_email));
      const paid = paidEmails.size;
      const totalSubmitters = allEmails.size;
      // Visitors = total unique submitters (actual real number, no inflation)
      setStats({ paid, visitors: totalSubmitters });
    });
  }, []);
  return (
    <div className="flex gap-2 mb-4">
      <div className="flex-1 bg-green-500/10 border border-green-500/25 rounded-2xl px-3 py-3 text-center">
        <div className="flex items-center justify-center gap-1.5 mb-0.5">
          <UserCheck className="w-4 h-4 text-green-400" />
          <p className="text-xl font-black text-green-400">{stats.paid}</p>
        </div>
        <p className="text-[10px] text-gray-400">Paid Members</p>
      </div>
      <div className="flex-1 bg-blue-500/10 border border-blue-500/25 rounded-2xl px-3 py-3 text-center">
        <div className="flex items-center justify-center gap-1.5 mb-0.5">
          <Users className="w-4 h-4 text-blue-400" />
          <p className="text-xl font-black text-blue-400">{stats.visitors}</p>
        </div>
        <p className="text-[10px] text-gray-400">Total Visits</p>
      </div>
    </div>
  );
}

export default function ISPNodeSetup() {
  const navigate = useNavigate();
  const [step, setStep] = useState('welcome');
  const [plan, setPlan] = useState(null);
  // Multi-select networks (array)
  const [networks, setNetworks] = useState([]);
  // Multi-select devices (array, max 2), each with its own vpn + deviceId + screenshot
  const [selectedDevices, setSelectedDevices] = useState([]); // [{val, vpn, deviceId, screenshotUrl, screenshotFile}]
  const [fullName, setFullName] = useState('');
  const [nickname, setNickname] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [secondEmail, setSecondEmail] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('bank_transfer');
  const [voucherPin, setVoucherPin] = useState('');
  const [voucherFile, setVoucherFile] = useState(null);
  const [voucherUrl, setVoucherUrl] = useState('');
  const [popFile, setPopFile] = useState(null);
  const [popUrl, setPopUrl] = useState('');
  const [reference, setReference] = useState('');
  const [uploading, setUploading] = useState(false);
  const [uploadingVoucher, setUploadingVoucher] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [user, setUser] = useState(null);
  const [uuid] = useState(generateUUID);
  const [instructionsModal, setInstructionsModal] = useState(null); // idType string
  const [uploadingScreenshot, setUploadingScreenshot] = useState({}); // {deviceVal: bool}
  const fileRef = useRef();
  const voucherRef = useRef();
  const screenshotRefs = useRef({});

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      setFullName(u?.full_name || '');
    });
  }, []);

  // ── Network multi-select toggle ─────────────────────────────────────────────
  const toggleNetwork = (val) => {
    setNetworks(prev => prev.includes(val) ? prev.filter(n => n !== val) : [...prev, val]);
  };

  // ── Device multi-select (max 2) ─────────────────────────────────────────────
  const toggleDevice = (val) => {
    setSelectedDevices(prev => {
      const exists = prev.find(d => d.val === val);
      if (exists) return prev.filter(d => d.val !== val);
      if (prev.length >= MAX_DEVICES) return prev; // limit 2
      const deviceConfig = DEVICES.find(d => d.val === val);
      const defaultVpn = deviceConfig?.vpns[0]?.val || null;
      return [...prev, { val, vpn: defaultVpn, deviceId: '', screenshotUrl: '', screenshotFile: '' }];
    });
  };

  const updateDeviceField = (deviceVal, field, value) => {
    setSelectedDevices(prev => prev.map(d => d.val === deviceVal ? { ...d, [field]: value } : d));
  };

  const handleScreenshotUpload = async (e, deviceVal) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingScreenshot(prev => ({ ...prev, [deviceVal]: true }));
    updateDeviceField(deviceVal, 'screenshotFile', file.name);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    updateDeviceField(deviceVal, 'screenshotUrl', file_url);
    setUploadingScreenshot(prev => ({ ...prev, [deviceVal]: false }));
  };

  const handleFileUpload = async (e, type) => {
    const file = e.target.files[0];
    if (!file) return;
    if (type === 'pop') {
      setPopFile(file.name);
      setUploading(true);
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setPopUrl(file_url);
      setUploading(false);
    } else {
      setVoucherFile(file.name);
      setUploadingVoucher(true);
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setVoucherUrl(file_url);
      setUploadingVoucher(false);
    }
  };

  const handleSubmit = async () => {
    if (!whatsapp) return alert('Please enter your WhatsApp number.');
    if (paymentMethod === 'bank_transfer' && !popUrl) return alert('Please upload your proof of payment.');
    if (paymentMethod === '1voucher' && !voucherPin && !voucherUrl) return alert('Please enter your 1Voucher PIN or upload a photo.');
    setSubmitting(true);

    const deviceSummary = selectedDevices.map(sd => {
      const deviceCfg = DEVICES.find(d => d.val === sd.val);
      const vpnCfg = deviceCfg?.vpns.find(v => v.val === sd.vpn);
      return `${sd.val}/${vpnCfg?.label || sd.vpn}${sd.deviceId ? `/ID:${sd.deviceId}` : ''}`;
    }).join(' | ');

    const newNode = await base44.entities.ISPNode.create({
      user_email: user.email,
      user_name: fullName || user?.full_name || user?.email?.split('@')[0] || 'user',
      nickname: nickname || fullName?.split(' ')[0] || 'Member',
      whatsapp,
      node_type: 'full',
      plan,
      status: 'pending_approval',
      uuid,
      project_name: `${networks.join('-')}-${selectedDevices.map(d => d.val).join('-')}-${Date.now()}`,
      payment_method: paymentMethod,
      payment_proof_url: paymentMethod === 'bank_transfer' ? popUrl : (voucherUrl || ''),
      voucher_pin: paymentMethod === '1voucher' ? voucherPin : '',
      amount_paid: AMOUNT_MAP[plan] || 30,
      admin_notes: `Networks: ${networks.join(', ')} | Devices: ${deviceSummary} | Ref: ${reference}${secondEmail ? ` | Alt Email: ${secondEmail}` : ''} | DeviceScreenshots: ${selectedDevices.filter(d => d.screenshotUrl).map(d => d.screenshotUrl).join(', ')}`,
    });

    // Fire order notifications (admin email + user confirmation) — non-blocking
    base44.functions.invoke('ispNodeDeploy', { action: 'on_order', nodeId: newNode.id }).catch(() => {});

    setSubmitting(false);
    setStep('submitted');
  };

  const StepHeader = ({ title, sub, onBack }) => (
    <div className="flex items-center gap-3 px-4 pt-6 pb-4">
      <button onClick={onBack} className="p-2 bg-gray-800/50 rounded-xl flex-shrink-0">
        <ArrowLeft className="w-5 h-5" />
      </button>
      <div>
        <h1 className="text-base font-bold leading-tight text-white">{title}</h1>
        {sub && <p className="text-xs text-violet-400">{sub}</p>}
      </div>
    </div>
  );

  // Can proceed from device step?
  const deviceStepValid = selectedDevices.length > 0 && selectedDevices.every(sd => {
    const deviceCfg = DEVICES.find(d => d.val === sd.val);
    const vpnCfg = deviceCfg?.vpns.find(v => v.val === sd.vpn);
    if (!sd.vpn) return false;
    if (vpnCfg?.needsDeviceId) return true; // deviceId optional but instructions shown
    return true;
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      <AnimatePresence>
        {instructionsModal && (
          <DeviceIdInstructions idType={instructionsModal} onClose={() => setInstructionsModal(null)} />
        )}
      </AnimatePresence>

      <AnimatePresence mode="wait">

        {/* ── WELCOME ── */}
        {step === 'welcome' && (
          <motion.div key="welcome" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div className="flex items-center gap-3 px-4 pt-6 pb-4">
              <Link to="/EthicalInternet" className="p-2 bg-gray-800/50 rounded-xl flex-shrink-0">
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <div>
                <h1 className="text-base font-bold text-white">Lets VPN Go | Paid Version</h1>
                <p className="text-xs text-violet-400">Premium Subscription</p>
              </div>
            </div>

            <div className="px-4 space-y-5">
              {/* Hero */}
              <div className="text-center py-4">
                <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-br from-violet-600 to-cyan-500 flex items-center justify-center mb-4" style={{ boxShadow: '0 0 32px rgba(139,92,246,0.4)' }}>
                  <img src="https://media.base44.com/images/public/69ab75e75a89c53cd29e052d/982659b51_Iconimage.png" alt="Lets VPN Go" className="w-14 h-14 rounded-2xl object-cover" />
                </div>
                <p className="text-xs text-violet-400 uppercase tracking-widest font-bold mb-2">Welcome To</p>
                <h2 className="text-2xl font-black text-white leading-tight mb-1">Lets VPN Go</h2>
                <h3 className="text-xl font-black bg-gradient-to-r from-violet-400 to-cyan-400 bg-clip-text text-transparent mb-3">Paid Version</h3>
                <p className="text-sm text-gray-300 font-medium italic">"Data & Privacy shouldn't be expensive."</p>
              </div>

              {/* Trust Stats */}
              <TrustBar />

              {/* What's New */}
              <WhatsNewSection />

              {/* About */}
              <div className="bg-gray-900/60 border border-violet-500/20 rounded-2xl p-4">
                <p className="text-xs text-gray-300 leading-relaxed mb-3">
                  Did you know that <span className="text-violet-300 font-semibold">Lets VPN Go is completely free</span> for basic privacy? This Premium section is for users who want <span className="text-cyan-300 font-semibold">maximum Speed, Unlimited Tweaks & Config Files</span> while helping us support the community!
                </p>
                <p className="text-xs text-gray-400 leading-relaxed">
                  Your paid subscription <span className="text-amber-300 font-semibold">acts as a donation</span> to improve our free services for those who need it most.
                </p>
              </div>

              {/* Who is it for */}
              <div className="bg-gradient-to-r from-violet-600/15 to-cyan-600/15 border border-violet-500/25 rounded-2xl p-4">
                <p className="text-xs font-bold text-violet-300 uppercase tracking-wider mb-3">Built For Serious Users</p>
                <p className="text-xs text-gray-300 leading-relaxed mb-3">
                  Perfect for <span className="text-white font-semibold">traders, Betway users, online students & remote workers</span>. Our plans are highly affordable — starting at just <span className="text-green-400 font-black">R20 for 7 days</span>.
                </p>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { icon: '🚀', text: 'Lightning-Fast ZA Servers' },
                    { icon: '🫟', text: 'Optimized for Betway & 4K' },
                    { icon: '📶', text: 'AllNet Unlimited Support' },
                    { icon: '⏳', text: 'No Time Limits' },
                    { icon: '💡', text: 'MTN, VodaCom, CellC, Telkom & Rain' },
                    { icon: '🌍', text: 'Android, iPhone & PC' },
                  ].map((b, i) => (
                    <div key={i} className="flex items-start gap-2 bg-white/4 rounded-xl px-2.5 py-2">
                      <span className="text-base flex-shrink-0">{b.icon}</span>
                      <p className="text-[11px] text-gray-300 leading-tight">{b.text}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Pricing teaser */}
              <div className="bg-green-500/8 border border-green-500/20 rounded-2xl p-4">
                <p className="text-xs font-bold text-green-400 uppercase tracking-wider mb-3">💰 Affordable Plans</p>
                <div className="flex gap-2 justify-center">
                  {PLANS.map(p => (
                    <div key={p.val} className="flex-1 text-center bg-gray-800/60 rounded-xl py-3 px-2 border border-gray-700/40">
                      <p className="text-xl font-black text-cyan-400">{p.price}</p>
                      <p className="text-[10px] text-gray-400">{p.label}</p>
                    </div>
                  ))}
                </div>
              </div>

              <motion.button
                whileTap={{ scale: 0.97 }}
                onClick={() => setStep('plan')}
                className="w-full py-4 rounded-2xl font-black text-base text-white"
                style={{ background: 'linear-gradient(135deg, #7c3aed, #06b6d4)', boxShadow: '0 0 24px rgba(124,58,237,0.35)' }}>
                Get Started — Choose Your Plan →
              </motion.button>
            </div>
          </motion.div>
        )}

        {/* ── STEP 1: PLAN ── */}
        {step === 'plan' && (
          <motion.div key="plan" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }}>
            <StepHeader title="Choose Your Plan" sub="Step 1 of 5" onBack={() => setStep('welcome')} />
            <div className="px-4 space-y-3">
              <p className="text-xs text-gray-400 mb-4">Plans act as a donation to keep the free version alive for the community.</p>
              {PLANS.map(p => (
                <button key={p.val} onClick={() => setPlan(p.val)}
                  className={`w-full flex items-center gap-4 p-5 rounded-2xl border transition-all text-left ${plan === p.val ? 'border-cyan-500/60 bg-cyan-500/10' : 'border-gray-700/50 bg-gray-800/40'}`}>
                  <div className={`w-14 h-14 rounded-2xl flex flex-col items-center justify-center flex-shrink-0 ${plan === p.val ? 'bg-gradient-to-br from-cyan-500 to-blue-600' : 'bg-gray-700/60'}`}>
                    <p className="text-lg font-black text-white">{p.price}</p>
                  </div>
                  <div className="flex-1">
                    <p className={`font-bold text-base ${plan === p.val ? 'text-cyan-300' : 'text-white'}`}>{p.label}</p>
                    <p className="text-xs text-gray-400 mt-0.5">{p.desc}</p>
                  </div>
                  {plan === p.val && <CheckCircle className="w-5 h-5 text-cyan-400 flex-shrink-0" />}
                </button>
              ))}
              <button onClick={() => plan && setStep('network')} disabled={!plan}
                className="w-full py-4 rounded-2xl font-bold text-sm text-white mt-2 disabled:opacity-40"
                style={{ background: 'linear-gradient(135deg, #7c3aed, #06b6d4)' }}>
                Continue → Choose Network
              </button>
            </div>
          </motion.div>
        )}

        {/* ── STEP 2: NETWORK (multi-select) ── */}
        {step === 'network' && (
          <motion.div key="network" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }}>
            <StepHeader title="Your Network Provider" sub="Step 2 of 5" onBack={() => setStep('plan')} />
            <div className="px-4 space-y-3">
              <p className="text-xs text-gray-400 mb-1">Select all networks / SIMs you use <span className="text-cyan-400 font-bold">(you can pick multiple)</span>:</p>
              <div className="grid grid-cols-2 gap-3">
                {NETWORKS.map(n => {
                  const selected = networks.includes(n.val);
                  return (
                    <button key={n.val} onClick={() => toggleNetwork(n.val)}
                      className={`flex items-center gap-3 p-4 rounded-2xl border transition-all text-left ${selected ? n.selColor + ' ' + n.color : 'border-gray-700/50 bg-gray-800/40 text-gray-300'}`}>
                      <Wifi className="w-5 h-5 flex-shrink-0" />
                      <div className="flex-1">
                        <p className="font-bold text-sm">{n.label}</p>
                      </div>
                      {selected && <CheckCircle className="w-4 h-4 flex-shrink-0 text-current" />}
                    </button>
                  );
                })}
              </div>
              {networks.length > 0 && (
                <p className="text-[11px] text-cyan-400">✓ Selected: {networks.map(v => NETWORKS.find(n => n.val === v)?.label).join(', ')}</p>
              )}
              <button onClick={() => networks.length > 0 && setStep('device')} disabled={networks.length === 0}
                className="w-full py-4 rounded-2xl font-bold text-sm text-white mt-2 disabled:opacity-40"
                style={{ background: 'linear-gradient(135deg, #7c3aed, #06b6d4)' }}>
                Continue → Choose Device
              </button>
            </div>
          </motion.div>
        )}

        {/* ── STEP 3: DEVICE + VPN (multi-select, max 2) ── */}
        {step === 'device' && (
          <motion.div key="device" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }}>
            <StepHeader title="Your Device & VPN App" sub="Step 3 of 5" onBack={() => setStep('network')} />
            <div className="px-4 space-y-4">
              <p className="text-xs text-gray-400">Select up to <span className="text-cyan-400 font-bold">2 devices</span> and choose a VPN app for each.</p>

              {/* Device selector */}
              <div className="grid grid-cols-3 gap-2">
                {DEVICES.map(d => {
                  const isSelected = selectedDevices.some(sd => sd.val === d.val);
                  const isDisabled = !isSelected && selectedDevices.length >= MAX_DEVICES;
                  return (
                    <button key={d.val} onClick={() => !isDisabled && toggleDevice(d.val)}
                      className={`flex flex-col items-center gap-1.5 p-3 rounded-2xl border transition-all ${isSelected ? 'border-violet-500/60 bg-violet-500/10' : isDisabled ? 'border-gray-700/30 bg-gray-800/20 opacity-40 cursor-not-allowed' : 'border-gray-700/50 bg-gray-800/40'}`}>
                      <d.icon className={`w-6 h-6 ${isSelected ? 'text-violet-400' : 'text-gray-500'}`} />
                      <p className={`text-[11px] font-bold ${isSelected ? 'text-violet-300' : 'text-gray-400'}`}>{d.label}</p>
                      {isSelected && <CheckCircle className="w-3.5 h-3.5 text-violet-400" />}
                    </button>
                  );
                })}
              </div>
              {selectedDevices.length === MAX_DEVICES && (
                <p className="text-[11px] text-amber-400">⚠️ Maximum 2 devices selected. Deselect one to change.</p>
              )}

              {/* Per-device VPN + Device ID */}
              {selectedDevices.map(sd => {
                const deviceCfg = DEVICES.find(d => d.val === sd.val);
                const vpnCfg = deviceCfg?.vpns.find(v => v.val === sd.vpn);
                const needsId = vpnCfg?.needsDeviceId;
                const idType = vpnCfg?.idType;
                const isUploading = uploadingScreenshot[sd.val];

                return (
                  <motion.div key={sd.val} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                    className="bg-gray-900/60 border border-violet-500/20 rounded-2xl p-4 space-y-3">
                    <p className="text-xs font-bold text-violet-300 uppercase tracking-wider">{deviceCfg?.label} Setup</p>

                    {/* VPN app picker */}
                    <div>
                      <p className="text-[11px] text-gray-500 mb-1.5">VPN App</p>
                      <div className="flex gap-2">
                        {deviceCfg?.vpns.map(v => (
                          <button key={v.val} onClick={() => updateDeviceField(sd.val, 'vpn', v.val)}
                            className={`flex-1 py-2.5 px-3 rounded-xl border text-xs font-bold transition-all ${sd.vpn === v.val ? 'border-cyan-500/60 bg-cyan-500/10 text-cyan-300' : 'border-gray-700/40 bg-gray-800/40 text-gray-400'}`}>
                            {v.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Device ID if required */}
                    {needsId && (
                      <div>
                        <div className="flex items-center justify-between mb-1.5">
                          <p className="text-[11px] text-gray-400 font-bold uppercase tracking-wider">
                            {idType === 'netmod' ? 'NetMod Hardware ID' : 'NPV Tunnel Device ID'}
                          </p>
                          <button onClick={() => setInstructionsModal(idType)}
                            className="flex items-center gap-1 text-[10px] text-cyan-400 bg-cyan-500/10 border border-cyan-500/20 px-2 py-1 rounded-lg">
                            <Info className="w-3 h-3" /> How to find it?
                          </button>
                        </div>
                        <input
                          value={sd.deviceId}
                          onChange={e => updateDeviceField(sd.val, 'deviceId', e.target.value)}
                          placeholder={idType === 'netmod' ? 'Paste Hardware ID here...' : 'Paste Device ID here...'}
                          className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-3 py-2.5 text-xs font-mono text-white focus:outline-none focus:border-cyan-500/50 mb-2"
                        />

                        {/* Screenshot upload */}
                        <p className="text-[11px] text-gray-500 mb-1.5">📸 Screenshot showing your Device ID</p>
                        <input
                          ref={el => { if (el) screenshotRefs.current[sd.val] = el; }}
                          type="file" accept="image/*" className="hidden"
                          onChange={e => handleScreenshotUpload(e, sd.val)}
                        />
                        <button onClick={() => screenshotRefs.current[sd.val]?.click()}
                          className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl border text-xs font-semibold transition-all ${sd.screenshotUrl ? 'border-green-500/50 bg-green-500/10 text-green-300' : 'border-gray-600/50 bg-gray-800/40 text-gray-400'}`}>
                          {isUploading ? <Loader className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
                          {isUploading ? 'Uploading...' : sd.screenshotUrl ? `✓ ${sd.screenshotFile}` : 'Upload Device ID Screenshot'}
                        </button>
                      </div>
                    )}
                  </motion.div>
                );
              })}

              <button onClick={() => deviceStepValid && setStep('info')} disabled={!deviceStepValid}
                className="w-full py-4 rounded-2xl font-bold text-sm text-white disabled:opacity-40"
                style={{ background: 'linear-gradient(135deg, #7c3aed, #06b6d4)' }}>
                Continue → Your Details
              </button>
            </div>
          </motion.div>
        )}

        {/* ── STEP 4: INFO ── */}
        {step === 'info' && (
          <motion.div key="info" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }}>
            <StepHeader title="Your Details" sub="Step 4 of 5" onBack={() => setStep('device')} />
            <div className="px-4 space-y-4">
              {/* Name */}
              <div>
                <label className="text-xs font-bold text-gray-300 uppercase tracking-wider mb-2 block">Full Name</label>
                <input value={fullName} onChange={e => setFullName(e.target.value)} placeholder="Your full name"
                  className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-violet-500/60" />
              </div>

              {/* WhatsApp */}
              <div>
                <label className="text-xs font-bold text-gray-300 uppercase tracking-wider mb-2 block">WhatsApp Number</label>
                <input value={whatsapp} onChange={e => setWhatsapp(e.target.value)} placeholder="+27 xxx xxx xxxx"
                  className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-violet-500/60" />
                <p className="text-[11px] text-gray-500 mt-1">Your package will be sent via Masters DeoVex on WhatsApp.</p>
              </div>

              {/* Primary Email — locked */}
              <div>
                <label className="text-xs font-bold text-gray-300 uppercase tracking-wider mb-2 block">Primary Email</label>
                <div className="w-full bg-gray-800/30 border border-gray-700/30 rounded-xl px-4 py-3 flex items-center justify-between">
                  <span className="text-sm text-gray-400 font-mono">{user?.email || 'Loading...'}</span>
                  <span className="text-[10px] text-green-400 bg-green-500/10 border border-green-500/20 px-2 py-0.5 rounded-full">Verified ✓</span>
                </div>
                <p className="text-[11px] text-gray-600 mt-1">Linked to your DeoVex account — cannot be changed.</p>
              </div>

              {/* Nickname — for group chat anonymity */}
              <div>
                <label className="text-xs font-bold text-gray-300 uppercase tracking-wider mb-2 block">
                  Group Chat Nickname <span className="text-red-400">*</span>
                </label>
                <input value={nickname} onChange={e => setNickname(e.target.value)} placeholder="e.g. SpeedKing, DataSaver, TechPro"
                  className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-violet-500/60" />
                <p className="text-[11px] text-gray-500 mt-1">This is shown in the Paid Members Group — stay anonymous, don't use your email or real name.</p>
              </div>

              {/* Second Email — optional */}
              <div>
                <label className="text-xs font-bold text-gray-300 uppercase tracking-wider mb-2 block">
                  Second Email <span className="text-gray-600 font-normal normal-case">(optional)</span>
                </label>
                <input value={secondEmail} onChange={e => setSecondEmail(e.target.value)} placeholder="your.other@email.com"
                  className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-violet-500/60" />
                <p className="text-[11px] text-gray-500 mt-1">We'll also send your package to this email if provided.</p>
              </div>

              <button onClick={() => fullName && whatsapp && nickname && setStep('payment')} disabled={!fullName || !whatsapp || !nickname}
                className="w-full py-4 rounded-2xl font-bold text-sm text-white disabled:opacity-40"
                style={{ background: 'linear-gradient(135deg, #7c3aed, #06b6d4)' }}>
                Continue → Payment
              </button>
            </div>
          </motion.div>
        )}

        {/* ── STEP 5: PAYMENT ── */}
        {step === 'payment' && (
          <motion.div key="payment" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }}>
            <StepHeader title="Payment" sub="Step 5 of 5" onBack={() => setStep('info')} />
            <div className="px-4 space-y-4">

              {/* Summary */}
              <div className="bg-gradient-to-r from-violet-600/15 to-cyan-600/15 border border-violet-500/30 rounded-2xl p-4">
                <p className="text-[10px] text-violet-400 uppercase tracking-wider font-bold mb-2">Order Summary</p>
                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between"><span className="text-gray-400">Plan</span><span className="text-white font-bold">{PLANS.find(p => p.val === plan)?.label}</span></div>
                  <div className="flex justify-between"><span className="text-gray-400">Networks</span><span className="text-white font-bold capitalize">{networks.join(', ')}</span></div>
                  <div className="flex justify-between"><span className="text-gray-400">Devices</span><span className="text-white font-bold capitalize">{selectedDevices.map(d => d.val).join(', ')}</span></div>
                  <div className="flex justify-between border-t border-gray-700/50 pt-1.5 mt-1.5">
                    <span className="text-gray-400">Total</span>
                    <span className="text-green-400 font-black text-base">R{AMOUNT_MAP[plan]}</span>
                  </div>
                </div>
              </div>

              {/* Payment method toggle */}
              <div>
                <p className="text-xs font-bold text-gray-300 uppercase tracking-wider mb-2">💳 Payment Method</p>
                <div className="grid grid-cols-2 gap-2">
                  {[{ val: 'bank_transfer', label: '🏦 Bank Transfer' }, { val: '1voucher', label: '🎟️ 1Voucher' }].map(m => (
                    <button key={m.val} onClick={() => setPaymentMethod(m.val)}
                      className={`py-3 rounded-xl border font-semibold text-xs transition-all ${paymentMethod === m.val ? 'border-cyan-500/60 bg-cyan-500/10 text-cyan-300' : 'border-gray-700/40 bg-gray-800/40 text-gray-400'}`}>
                      {m.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Bank Transfer */}
              {paymentMethod === 'bank_transfer' && (
                <div className="space-y-3">
                  <div className="bg-gray-900/70 border border-green-500/30 rounded-2xl p-4">
                    <p className="text-xs text-green-400 font-bold mb-3">🏦 Capitec Bank Details</p>
                    <div className="space-y-2">
                      {[
                        { label: 'Bank', value: 'Capitec Bank', copy: false },
                        { label: 'Account No.', value: '2453250201', copy: true },
                        { label: 'Reference', value: whatsapp || 'Your WhatsApp Number', copy: false },
                        { label: 'Amount', value: `R${AMOUNT_MAP[plan]}`, copy: false },
                      ].map(row => (
                        <div key={row.label} className="flex items-center justify-between">
                          <span className="text-xs text-gray-500">{row.label}</span>
                          <div className="flex items-center gap-1.5">
                            <span className={`text-xs font-bold ${row.label === 'Amount' ? 'text-green-400' : row.label === 'Account No.' ? 'text-cyan-400 font-mono' : 'text-white'}`}>{row.value}</span>
                            {row.copy && (
                              <button onClick={() => navigator.clipboard.writeText(row.value)} className="p-1 rounded bg-gray-700/60 hover:bg-gray-600/60 transition-all">
                                <Copy className="w-2.5 h-2.5 text-gray-400" />
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-300 uppercase tracking-wider mb-1.5 block">Reference You Used</label>
                    <input value={reference} onChange={e => setReference(e.target.value)} placeholder="Reference you put on the payment"
                      className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-cyan-500/50" />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-300 uppercase tracking-wider mb-1.5 block">Proof of Payment (Screenshot or PDF)</label>
                    <input ref={fileRef} type="file" accept="image/*,.pdf" className="hidden" onChange={e => handleFileUpload(e, 'pop')} />
                    <button onClick={() => fileRef.current?.click()}
                      className={`w-full flex items-center justify-center gap-2 py-3.5 rounded-xl border font-semibold text-sm transition-all ${popUrl ? 'border-green-500/50 bg-green-500/10 text-green-300' : 'border-gray-600/50 bg-gray-800/40 text-gray-400 hover:border-gray-500'}`}>
                      {uploading ? <Loader className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                      {uploading ? 'Uploading...' : popUrl ? `✓ ${popFile}` : 'Upload Screenshot / PDF'}
                    </button>
                  </div>
                </div>
              )}

              {/* 1Voucher */}
              {paymentMethod === '1voucher' && (
                <div className="space-y-3">
                  <div className="bg-gray-900/60 border border-amber-500/20 rounded-2xl p-3">
                    <p className="text-xs text-amber-300 mb-1">💡 Buy a 1Voucher from any shop or online, then submit below.</p>
                    <p className="text-[11px] text-gray-500">You can enter the PIN, upload a photo of the voucher, or both.</p>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-300 uppercase tracking-wider mb-1.5 block">1Voucher PIN (optional)</label>
                    <input value={voucherPin} onChange={e => setVoucherPin(e.target.value)} placeholder="Enter PIN code"
                      className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-4 py-3 text-sm text-white font-mono focus:outline-none focus:border-cyan-500/50" />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-300 uppercase tracking-wider mb-1.5 block">Voucher Photo / Screenshot (optional)</label>
                    <input ref={voucherRef} type="file" accept="image/*" className="hidden" onChange={e => handleFileUpload(e, 'voucher')} />
                    <button onClick={() => voucherRef.current?.click()}
                      className={`w-full flex items-center justify-center gap-2 py-3.5 rounded-xl border font-semibold text-sm transition-all ${voucherUrl ? 'border-green-500/50 bg-green-500/10 text-green-300' : 'border-gray-600/50 bg-gray-800/40 text-gray-400 hover:border-gray-500'}`}>
                      {uploadingVoucher ? <Loader className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                      {uploadingVoucher ? 'Uploading...' : voucherUrl ? `✓ ${voucherFile}` : 'Upload Voucher Photo'}
                    </button>
                  </div>
                </div>
              )}

              {/* Warning banner */}
              <div className="bg-red-500/10 border border-red-500/30 rounded-xl px-3 py-3 flex gap-2.5">
                <span className="text-lg flex-shrink-0">⚠️</span>
                <div>
                  <p className="text-[11px] text-red-300 font-bold">Do NOT share your Paid Version config</p>
                  <p className="text-[10px] text-red-400/80 mt-0.5">Sharing violates our rules. Account + subscription will be permanently banned ❌</p>
                </div>
              </div>

              {/* Verification notice */}
              <div className="bg-amber-500/8 border border-amber-500/20 rounded-xl px-3 py-3 space-y-1.5">
                <p className="text-xs font-bold text-amber-300">⏳ Verification Time: 10 minutes – 6 hours</p>
                <p className="text-[11px] text-gray-400">You'll be notified via:</p>
                <div className="flex flex-wrap gap-2">
                  {['🧑‍💻 Masters DeoVex', '📧 Email', '📱 WhatsApp'].map(m => (
                    <span key={m} className="text-[11px] bg-amber-500/10 border border-amber-500/20 text-amber-200 px-2 py-0.5 rounded-full">{m}</span>
                  ))}
                </div>
                <p className="text-[11px] text-gray-500">Your package will be sent to Masters DeoVex & your registered contacts.</p>
              </div>

              <button onClick={handleSubmit} disabled={submitting}
                className="w-full py-4 rounded-2xl font-bold text-sm text-white disabled:opacity-50"
                style={{ background: 'linear-gradient(135deg, #7c3aed, #06b6d4)', boxShadow: '0 0 20px rgba(124,58,237,0.3)' }}>
                {submitting
                  ? <span className="flex items-center justify-center gap-2"><Loader className="w-4 h-4 animate-spin" /> Submitting...</span>
                  : `🚀 Submit Order — R${AMOUNT_MAP[plan]}`}
              </button>
            </div>
          </motion.div>
        )}

        {/* ── SUBMITTED ── */}
        {step === 'submitted' && (
          <motion.div key="submitted" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}
            className="px-4 py-8">

            <div className="text-center mb-6">
              <div className="w-24 h-24 mx-auto rounded-3xl bg-gradient-to-br from-green-500/30 to-emerald-600/30 border border-green-500/40 flex items-center justify-center mb-4" style={{ boxShadow: '0 0 28px rgba(34,197,94,0.2)' }}>
                <CheckCircle className="w-12 h-12 text-green-400" />
              </div>
              <h2 className="text-2xl font-black text-white mb-1">Order Received! ✅</h2>
              <p className="text-sm text-gray-400">Your subscription is now <span className="text-amber-400 font-bold">Pending Verification</span></p>
            </div>

            {/* What happens next */}
            <div className="bg-gray-900/70 border border-gray-700/50 rounded-2xl p-4 mb-4">
              <p className="text-xs font-bold text-white uppercase tracking-wider mb-3">What Happens Next</p>
              <div className="space-y-3">
                {[
                  { step: '1', text: 'We verify your payment (10 min – 6 hours)', color: 'bg-amber-500/20 text-amber-400' },
                  { step: '2', text: 'Your package is sent to Masters DeoVex', color: 'bg-violet-500/20 text-violet-400' },
                  { step: '3', text: 'You get notified via Masters DeoVex • Email • WhatsApp', color: 'bg-blue-500/20 text-blue-400' },
                  { step: '4', text: "You're added to the Paid Members WhatsApp Group", color: 'bg-green-500/20 text-green-400' },
                  { step: '5', text: 'Import config into your VPN app & enjoy!', color: 'bg-cyan-500/20 text-cyan-400' },
                ].map(item => (
                  <div key={item.step} className="flex items-center gap-3">
                    <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 font-black text-xs ${item.color}`}>{item.step}</div>
                    <p className="text-xs text-gray-300">{item.text}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Speed up */}
            <div className="bg-green-500/10 border border-green-500/30 rounded-2xl p-4 mb-3">
              <p className="text-xs text-green-400 font-bold mb-2">⚡ Speed Up Verification</p>
              <p className="text-xs text-gray-400 mb-3">Send <strong className="text-white">"Paid@DeoVex"</strong> to admin — one tap pre-fills the message:</p>
              <a href="https://wa.me/27692987836?text=Paid%40DeoVex" target="_blank" rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full bg-green-600/40 hover:bg-green-600/60 border border-green-500/40 text-green-300 font-bold py-3 rounded-xl text-sm transition-all">
                <MessageSquare className="w-4 h-4" /> Send "Paid@DeoVex" to Admin →
              </a>
            </div>

            {/* Join Group */}
            <div className="bg-green-500/8 border border-green-500/20 rounded-2xl p-4 mb-5">
              <p className="text-xs text-green-400 font-bold mb-2">👥 Join Paid Members WhatsApp Group</p>
              <a href="https://mspy.qzz.io/letsvpngopaidversion" target="_blank" rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full bg-green-700/30 hover:bg-green-700/50 border border-green-500/30 text-green-300 font-bold py-3 rounded-xl text-sm transition-all">
                <MessageSquare className="w-4 h-4" /> Join Paid Members Group →
              </a>
            </div>

            <div className="flex gap-3">
              <Link to="/PaidVersionDashboard"
                className="flex-1 text-center py-3.5 rounded-2xl font-bold text-sm text-white"
                style={{ background: 'linear-gradient(135deg, #7c3aed, #06b6d4)' }}>
                View My Subscription
              </Link>
              <Link to="/EthicalInternet"
                className="px-4 py-3.5 rounded-2xl font-bold text-sm text-gray-400 border border-gray-700/50 bg-gray-800/40">
                Home
              </Link>
            </div>
          </motion.div>
        )}

      </AnimatePresence>
    </div>
  );
}