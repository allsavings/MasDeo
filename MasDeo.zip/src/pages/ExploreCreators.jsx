import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ArrowLeft, Sparkles } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function ExploreCreators() {
  const [creators, setCreators] = useState([]);
  const [followedCreators, setFollowedCreators] = useState([]);
  const [sections, setSections] = useState([]);
  const [subsections, setSubsections] = useState([]);
  const [cards, setCards] = useState([]);
  const [expandedSections, setExpandedSections] = useState({});
  const [searchAll, setSearchAll] = useState('');
  const [searchFollowed, setSearchFollowed] = useState('');
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      const [allSections, allSubsections, allCards, allFollows, allProfiles] = await Promise.all([
        base44.entities.MainSection.list(),
        base44.entities.Subsection.list(),
        base44.entities.TemplateCard.list(),
        base44.entities.Follow.list(),
        base44.entities.CreatorProfile.list()
      ]);

      // Get followed creators for current user
      const userFollows = allFollows.filter(f => f.user_email === currentUser.email);
      const followedIds = userFollows.map(f => f.creator_id);
      const followed = allProfiles.filter(p => followedIds.includes(p.id));
      setFollowedCreators(followed);

      const creatorEmails = [...new Set(allSections.map(s => s.creator_email))];
      const creatorProfs = await Promise.all(
        creatorEmails.map(email => base44.entities.CreatorProfile.filter({ user_email: email }))
      );

      setSections(allSections);
      setSubsections(allSubsections);
      setCards(allCards);
      setCreators(creatorProfs.flat());
    } catch (error) {
      console.error('Error loading creators:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleSection = (id) => {
    setExpandedSections(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const getSectionsForCreator = (creatorEmail) =>
    sections.filter(s => s.creator_email === creatorEmail).sort((a, b) => (a.order || 0) - (b.order || 0));

  const getSubsectionsForMain = (mainId) =>
    subsections.filter(s => s.main_section_id === mainId).sort((a, b) => (a.order || 0) - (b.order || 0));

  const getCardsForSub = (subId) =>
    cards.filter(c => c.subsection_id === subId).sort((a, b) => (a.order || 0) - (b.order || 0));

  // Filter cards by search term (title, description, icon_url)
  const filterCardsBySearch = (cardList, query) => {
    if (!query.trim()) return cardList;
    const q = query.toLowerCase();
    return cardList.filter(c => 
      c.title?.toLowerCase().includes(q) || 
      c.description?.toLowerCase().includes(q)
    );
  };

  // Get all cards for a creator
  const getAllCardsForCreator = (creatorEmail) => {
    const creatorSections = getSectionsForCreator(creatorEmail);
    return creatorSections.flatMap(sec => 
      getSubsectionsForMain(sec.id).flatMap(sub => getCardsForSub(sub.id))
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 2, repeat: Infinity }} className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#0a0a0f]/95 backdrop-blur-xl border-b border-gray-800/50 px-6 py-4">
        <div className="flex items-center gap-4">
          <Link to={createPageUrl('Home')} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-800 transition-all">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Explore Creators</h1>
              <p className="text-xs text-gray-400">{creators.length} creators</p>
            </div>
          </div>
        </div>
      </div>

      <div className="px-6 py-6 space-y-4">
        {/* Followed Creators Section */}
        {followedCreators.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-br from-purple-900/30 to-pink-900/20 border border-purple-500/40 rounded-2xl p-5"
          >
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                <span className="text-lg">❤️</span>
              </div>
              <h2 className="text-lg font-bold text-white">Creators You Follow</h2>
              <span className="text-xs bg-purple-500/20 text-purple-300 px-2 py-1 rounded-full">{followedCreators.length}</span>
            </div>

            {/* Search for followed creators */}
            <div className="mb-4">
              <input
                type="text"
                placeholder="Search followed creators' content..."
                value={searchFollowed}
                onChange={(e) => setSearchFollowed(e.target.value)}
                className="w-full bg-gray-900/50 border border-gray-700/50 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-purple-500/50"
              />
            </div>

            <div className="space-y-3">
              {followedCreators.map(creator => {
                const creatorCards = getAllCardsForCreator(creator.user_email);
                const filteredCards = filterCardsBySearch(creatorCards, searchFollowed);
                
                return (
                  <motion.div
                    key={creator.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="bg-gray-800/40 border border-purple-500/20 rounded-xl p-3"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
                        {creator.user_email[0].toUpperCase()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-white text-sm truncate">{creator.user_email.split('@')[0]}</p>
                      </div>
                      <span className="text-[10px] bg-purple-500/20 text-purple-300 px-1.5 py-0.5 rounded-full flex-shrink-0">{filteredCards.length} items</span>
                    </div>

                    {/* Show content cards */}
                    {filteredCards.length > 0 && (
                      <div className="space-y-1 mt-2">
                        {filteredCards.slice(0, 3).map(card => (
                          <div key={card.id} className="text-[11px] text-gray-400 bg-gray-900/30 rounded-lg px-2 py-1 truncate">
                            • {card.title}
                          </div>
                        ))}
                        {filteredCards.length > 3 && (
                          <p className="text-[10px] text-gray-600 px-2 py-1">+{filteredCards.length - 3} more</p>
                        )}
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* All Creators Section */}
        <div>
          <div className="flex items-center gap-2 mb-4 mt-6">
            <h2 className="text-lg font-bold text-white">All Creators</h2>
            <span className="text-xs bg-gray-700/50 text-gray-300 px-2 py-1 rounded-full">{creators.length}</span>
          </div>

          {/* Search for all creators */}
          <div className="mb-4">
            <input
              type="text"
              placeholder="Search creators or content..."
              value={searchAll}
              onChange={(e) => setSearchAll(e.target.value)}
              className="w-full bg-gray-900/50 border border-gray-700/50 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-blue-500/50"
            />
          </div>
        </div>

        {creators.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-20"
          >
            <div className="w-16 h-16 bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-2xl mx-auto mb-4 flex items-center justify-center">
              <Sparkles className="w-8 h-8 text-purple-400 opacity-50" />
            </div>
            <p className="text-gray-400 text-sm font-medium">No creator templates yet</p>
          </motion.div>
        ) : (
          creators
            .filter(creator => {
              if (!searchAll.trim()) return true;
              const q = searchAll.toLowerCase();
              const email = creator.user_email.toLowerCase();
              const allCards = getAllCardsForCreator(creator.user_email);
              const hasMatchingContent = allCards.some(c => 
                c.title?.toLowerCase().includes(q) || c.description?.toLowerCase().includes(q)
              );
              return email.includes(q) || hasMatchingContent;
            })
            .map(creator => {
            const creatorSections = getSectionsForCreator(creator.user_email);
            return (
              <motion.div
                key={creator.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-gradient-to-br from-gray-800/40 to-gray-900/40 border border-gray-700/50 rounded-2xl overflow-hidden hover:border-purple-500/50 transition-all"
              >
                {/* Creator Header */}
                <div className="px-5 py-4 border-b border-gray-700/30 bg-gray-900/20">
                  <h2 className="font-semibold text-white text-sm">{creator.username || creator.user_email.split('@')[0]}</h2>
                  <p className="text-xs text-gray-500 mt-1">{creatorSections.length} template{creatorSections.length !== 1 ? 's' : ''}</p>
                </div>

                {/* Creator's Sections */}
                <div className="space-y-2 p-5">
                  {creatorSections.map(section => (
                    <motion.div key={section.id} className="border border-gray-700/30 rounded-xl overflow-hidden bg-gray-900/20 hover:border-gray-600/50 transition-all">
                      <button
                        onClick={() => toggleSection(section.id)}
                        className="w-full px-4 py-4 flex items-center justify-between hover:bg-gray-800/40 transition-colors"
                      >
                        <div className="text-left">
                          <h3 className="font-semibold text-white text-sm">{section.title}</h3>
                          <p className="text-xs text-gray-500 mt-1">
                            {getSubsectionsForMain(section.id).length} categor{getSubsectionsForMain(section.id).length !== 1 ? 'ies' : 'y'}
                          </p>
                        </div>
                        <ChevronDown
                          className={`w-5 h-5 text-gray-500 transition-transform ${expandedSections[section.id] ? 'rotate-180' : ''}`}
                        />
                      </button>

                      {/* Subsections */}
                       <AnimatePresence>
                        {expandedSections[section.id] && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="border-t border-gray-700/20 bg-gray-800/20 px-4 py-4 space-y-4"
                          >
                            {getSubsectionsForMain(section.id).map(sub => (
                              <div key={sub.id}>
                                <h4 className="text-xs font-semibold text-gray-300 mb-3 uppercase tracking-widest">{sub.title}</h4>
                                <div className="space-y-2.5">
                                  {getCardsForSub(sub.id).map(card => (
                                    <motion.div
                                      key={card.id}
                                      initial={{ opacity: 0, x: -10 }}
                                      animate={{ opacity: 1, x: 0 }}
                                      className="bg-gradient-to-br from-gray-800/60 to-gray-900/40 border border-gray-700/40 rounded-xl p-4 hover:border-blue-500/40 transition-all"
                                    >
                                      <div className="flex items-start gap-3">
                                        {card.icon_url && (
                                          <img
                                            src={card.icon_url}
                                            alt={card.title}
                                            className="w-11 h-11 rounded-lg object-cover flex-shrink-0"
                                          />
                                        )}
                                        <div className="flex-1 min-w-0">
                                          <h5 className="font-semibold text-white text-sm">{card.title}</h5>
                                          <p className="text-xs text-gray-400 mt-1 leading-relaxed line-clamp-2">{card.description}</p>
                                          {(card.button1_label || card.button2_label) && (
                                            <div className="flex gap-2 mt-3 flex-wrap">
                                              {card.button1_label && (
                                                <a
                                                  href={card.button1_url || '#'}
                                                  target="_blank"
                                                  rel="noopener noreferrer"
                                                  className="text-xs px-3 py-1.5 bg-blue-500/20 text-blue-300 border border-blue-500/30 rounded-lg hover:bg-blue-500/30 transition-colors font-medium"
                                                >
                                                  {card.button1_label}
                                                </a>
                                              )}
                                              {card.button2_label && (
                                                <a
                                                  href={card.button2_url || '#'}
                                                  target="_blank"
                                                  rel="noopener noreferrer"
                                                  className="text-xs px-3 py-1.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-lg hover:bg-emerald-500/30 transition-colors font-medium"
                                                >
                                                  {card.button2_label}
                                                </a>
                                              )}
                                            </div>
                                          )}
                                        </div>
                                      </div>
                                    </motion.div>
                                  ))}
                                </div>
                              </div>
                            ))}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            );
          })
        )}
      </div>
    </div>
  );
}