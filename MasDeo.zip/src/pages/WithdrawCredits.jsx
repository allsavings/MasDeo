import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Wallet, CheckCircle, AlertCircle } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function WithdrawCredits() {
  const navigate = useNavigate();
  const fromWallet = new URLSearchParams(window.location.search).get('from') === 'Wallet';
  const [profile, setProfile] = useState(null);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  
  const [formData, setFormData] = useState({
    amount: '',
    bank_name: '',
    account_number: '',
    account_holder_name: ''
  });

  const southAfricanBanks = [
    'ABSA Bank',
    'Standard Bank',
    'FNB (First National Bank)',
    'Nedbank',
    'Capitec Bank',
    'African Bank',
    'Bidvest Bank',
    'Discovery Bank',
    'Investec',
    'TymeBank',
    'Bank Zero'
  ];

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      const userData = await base44.auth.me();
      setUser(userData);
      
      const profiles = await base44.entities.UserProfile.filter({ created_by: userData.email });
      if (profiles.length > 0) {
        setProfile(profiles[0]);
      }
    } catch (error) {
      console.log('Error loading user data:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const amount = parseFloat(formData.amount);
      const currentCredits = profile?.credits || 0;

      // Validation
      if (!formData.bank_name) {
        setError('Please select a bank');
        setLoading(false);
        return;
      }

      if (amount < 50) {
        setError('Minimum withdrawal amount is R50');
        setLoading(false);
        return;
      }

      if (amount > currentCredits) {
        setError(`Insufficient credits. You have R${currentCredits} available`);
        setLoading(false);
        return;
      }

      if (!formData.account_number || formData.account_number.length < 8) {
        setError('Please enter a valid account number');
        setLoading(false);
        return;
      }

      if (!formData.account_holder_name) {
        setError('Please enter the account holder name');
        setLoading(false);
        return;
      }

      // Create withdrawal request
      await base44.entities.Withdrawal.create({
        user_email: user.email,
        amount: amount,
        bank_name: formData.bank_name,
        account_number: formData.account_number,
        account_holder_name: formData.account_holder_name,
        status: 'pending'
      });

      // Deduct credits from user profile
      await base44.entities.UserProfile.update(profile.id, {
        credits: currentCredits - amount
      });

      setSuccess(true);
      setTimeout(() => {
        navigate(createPageUrl('Home'));
      }, 2500);

    } catch (err) {
      setError('Failed to process withdrawal. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white flex items-center justify-center p-6">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="text-center"
        >
          <div className="w-20 h-20 mx-auto mb-6 bg-green-500/20 rounded-full flex items-center justify-center">
            <CheckCircle className="w-10 h-10 text-green-400" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Withdrawal Submitted!</h2>
          <p className="text-gray-400 mb-6">
            Your withdrawal request of R{formData.amount} has been submitted.<br />
            Processing typically takes 2-5 business days.
          </p>
          <p className="text-sm text-gray-500">Redirecting to home...</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      {/* Header */}
      <div className="px-6 pt-6 pb-4 sticky top-0 bg-[#0a0a0f]/95 backdrop-blur-xl z-10 border-b border-gray-800/50">
        <div className="flex items-center gap-4 mb-2">
          <Link to={createPageUrl(fromWallet ? 'Wallet' : 'Home')} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-800 transition-all">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-2xl font-bold">Withdraw Credits</h1>
        </div>
        <p className="text-sm text-gray-400 ml-16">Transfer your credits to your bank account</p>
      </div>

      {/* Current Balance */}
      {profile && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mx-6 mt-6 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 rounded-2xl p-6 border border-blue-500/20"
        >
          <p className="text-sm text-gray-400 mb-1">Available Balance</p>
          <div className="flex items-center gap-2">
            <Wallet className="w-6 h-6 text-blue-400" />
            <span className="text-3xl font-bold text-white">R{(profile.credits || 0).toFixed(2)}</span>
          </div>
          <p className="text-xs text-gray-500 mt-2">Minimum withdrawal: R50</p>
        </motion.div>
      )}

      {/* Withdrawal Form */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="mx-6 mt-6"
      >
        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Amount */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Withdrawal Amount (R)
            </label>
            <Input
              type="number"
              min="50"
              step="0.01"
              value={formData.amount}
              onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
              placeholder="Enter amount (min R50)"
              className="bg-gray-800/50 border-gray-700/50 text-white placeholder:text-gray-500"
              required
            />
          </div>

          {/* Bank Name */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Select Bank
            </label>
            <Select
              value={formData.bank_name}
              onValueChange={(value) => setFormData({ ...formData, bank_name: value })}
            >
              <SelectTrigger className="bg-gray-800/50 border-gray-700/50 text-white">
                <SelectValue placeholder="Choose your bank" />
              </SelectTrigger>
              <SelectContent>
                {southAfricanBanks.map((bank) => (
                  <SelectItem key={bank} value={bank}>
                    {bank}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Account Number */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Account Number
            </label>
            <Input
              type="text"
              value={formData.account_number}
              onChange={(e) => setFormData({ ...formData, account_number: e.target.value })}
              placeholder="Enter your account number"
              className="bg-gray-800/50 border-gray-700/50 text-white placeholder:text-gray-500"
              required
            />
          </div>

          {/* Account Holder Name */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Account Holder Name
            </label>
            <Input
              type="text"
              value={formData.account_holder_name}
              onChange={(e) => setFormData({ ...formData, account_holder_name: e.target.value })}
              placeholder="Full name as per bank account"
              className="bg-gray-800/50 border-gray-700/50 text-white placeholder:text-gray-500"
              required
            />
          </div>

          {/* Error Message */}
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 flex items-start gap-3"
            >
              <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-400">{error}</p>
            </motion.div>
          )}

          {/* Submit Button */}
          <Button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:opacity-90 text-white font-semibold py-6 rounded-xl transition-all"
          >
            {loading ? 'Processing...' : 'Submit Withdrawal Request'}
          </Button>
        </form>
      </motion.div>

      {/* Info Box */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="mx-6 mt-6 bg-gray-800/30 rounded-2xl p-5 border border-gray-700/30"
      >
        <h3 className="font-semibold text-white mb-3">Important Information</h3>
        <ul className="text-sm text-gray-400 space-y-2">
          <li className="flex items-start gap-2">
            <span className="text-blue-400 mt-0.5">•</span>
            <span>Minimum withdrawal amount is R50</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-400 mt-0.5">•</span>
            <span>Processing takes 2-5 business days</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-400 mt-0.5">•</span>
            <span>Ensure your bank details are correct before submitting</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-400 mt-0.5">•</span>
            <span>Credits will be deducted immediately upon request</span>
          </li>
        </ul>
      </motion.div>
    </div>
  );
}