import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Users, Video, Copy, CheckCircle, Gift, Play, X, Star } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

const AD_REWARD_AMOUNT = 0.05; // R0.05 per ad
const AD_DURATION_SEC  = 30;   // countdown seconds

function AdSenseAd() {
  const adRef = useRef(null);
  useEffect(() => {
    if (adRef.current && adRef.current.offsetWidth > 0) {
      try {
        (window.adsbygoogle = window.adsbygoogle || []).push({});
      } catch (e) {}
    }
  }, []);
  return (
    <ins
      ref={adRef}
      className="adsbygoogle"
      style={{ display: 'block', width: '100%', minHeight: '250px' }}
      data-ad-client="ca-pub-5501254524499942"
      data-ad-slot="2699610368"
      data-ad-format="auto"
      data-full-width-responsive="true"
    />
  );
}

export default function EarnCredits() {
  const [profile, setProfile] = useState(null);
  const [user, setUser] = useState(null);
  const fromWallet = new URLSearchParams(window.location.search).get('from') === 'Wallet';
  const [referralCode, setReferralCode] = useState('');
  const [copied, setCopied] = useState(false);

  // Ad state
  const [adState, setAdState]       = useState('idle'); // idle | loading | playing | rewarded | error
  const [countdown, setCountdown]   = useState(AD_DURATION_SEC);
  const [adEarned, setAdEarned]     = useState(0);
  const countdownRef                = useRef(null);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      const userData = await base44.auth.me();
      setUser(userData);
      
      const profiles = await base44.entities.UserProfile.filter({ created_by: userData.email });
      if (profiles.length > 0) {
        setProfile(profiles[0]);
        // Generate referral code from user ID
        setReferralCode(profiles[0].id.slice(0, 8).toUpperCase());
      }
    } catch (error) {
      console.log('Error loading user data:', error);
    }
  };

  const copyReferralLink = () => {
    const link = `${window.location.origin}${createPageUrl('AuthScreen')}?ref=${referralCode}`;
    navigator.clipboard.writeText(link);
    setCopied(true);
    toast.success('Referral link copied!');
    setTimeout(() => setCopied(false), 2000);
  };

  const watchAd = async () => {
    if (adState !== 'idle') return;
    setAdState('loading');
    setCountdown(AD_DURATION_SEC);

    // Simulate ad load (in native app: admob.showRewardedAd(ADMOB_AD_UNIT))
    setTimeout(() => {
      setAdState('playing');
      countdownRef.current = setInterval(() => {
        setCountdown(prev => {
          if (prev <= 1) {
            clearInterval(countdownRef.current);
            grantReward();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }, 1500);
  };

  const grantReward = async () => {
    setAdState('rewarded');
    try {
      const newCredits = (profile?.credits || 0) + AD_REWARD_AMOUNT;
      await base44.entities.UserProfile.update(profile.id, { credits: newCredits });
      setProfile(p => ({ ...p, credits: newCredits }));
      setAdEarned(p => p + AD_REWARD_AMOUNT);
    } catch (e) {
      console.log('Credit update error:', e);
    }
  };

  const closeAd = () => {
    clearInterval(countdownRef.current);
    setAdState('idle');
    setCountdown(AD_DURATION_SEC);
  };

  const earnMethods = [
    {
      id: 'referral',
      title: 'Refer Friends',
      description: 'Earn R5 when your friend signs up and becomes premium',
      reward: 'R5 per referral',
      icon: Users,
      color: 'from-purple-500 to-pink-500',
      action: 'share'
    },
    {
      id: 'ads',
      title: 'Watch Ads',
      description: 'Watch short video ads to earn credits',
      reward: 'R0.05 per ad',
      icon: Video,
      color: 'from-blue-500 to-cyan-500',
      action: 'watch'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      {/* Header */}
      <div className="px-6 pt-6 pb-4 sticky top-0 bg-[#0a0a0f]/95 backdrop-blur-xl z-10 border-b border-gray-800/50">
        <div className="flex items-center gap-4 mb-2">
          <Link to={createPageUrl(fromWallet ? 'Wallet' : 'Home')} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-800 transition-all">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-2xl font-bold">Earn Credits</h1>
        </div>
        <p className="text-sm text-gray-400 ml-16">Complete tasks to earn free credits</p>
      </div>

      {/* Current Balance */}
      {profile && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mx-6 mt-6 bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 rounded-2xl p-6 border border-emerald-500/20"
        >
          <p className="text-sm text-gray-400 mb-1">Current Balance</p>
          <div className="flex items-center gap-2">
            <Gift className="w-6 h-6 text-emerald-400" />
            <span className="text-3xl font-bold text-white">R{(profile.credits || 0).toFixed(2)}</span>
          </div>
        </motion.div>
      )}

      {/* Earn Methods */}
      <div className="px-6 pt-6 space-y-4">
        <h2 className="text-sm font-semibold text-gray-400 mb-4">WAYS TO EARN</h2>
        
        {earnMethods.map((method, index) => {
          const Icon = method.icon;
          
          return (
            <motion.div
              key={method.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50"
            >
              <div className="flex items-start gap-4 mb-4">
                <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${method.color} flex items-center justify-center flex-shrink-0`}>
                  <Icon className="w-7 h-7 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-white mb-1">{method.title}</h3>
                  <p className="text-sm text-gray-400 mb-2">{method.description}</p>
                  <div className="inline-block bg-green-500/20 text-green-400 text-xs font-semibold px-3 py-1 rounded-full">
                    {method.reward}
                  </div>
                </div>
              </div>

              {method.action === 'share' && (
                <div className="space-y-3">
                  <div className="bg-gray-900/50 rounded-xl p-4 border border-gray-700/30">
                    <p className="text-xs text-gray-400 mb-2">Your Referral Code</p>
                    <div className="flex items-center gap-2">
                      <code className="flex-1 bg-gray-800/60 text-purple-400 px-3 py-2 rounded-lg font-mono text-sm">
                        {referralCode}
                      </code>
                      <button
                        onClick={copyReferralLink}
                        className="p-2 bg-purple-500/20 hover:bg-purple-500/30 rounded-lg transition-all"
                      >
                        {copied ? (
                          <CheckCircle className="w-5 h-5 text-green-400" />
                        ) : (
                          <Copy className="w-5 h-5 text-purple-400" />
                        )}
                      </button>
                    </div>
                  </div>
                  <p className="text-xs text-gray-500">
                    Share your referral link with friends. You'll earn R5 when they sign up and subscribe to premium.
                  </p>
                </div>
              )}

              {method.action === 'watch' && (
                <div className="space-y-3">
                  {adEarned > 0 && (
                    <div className="flex items-center gap-2 bg-green-500/10 border border-green-500/20 rounded-xl px-4 py-2">
                      <Star className="w-4 h-4 text-green-400" />
                      <p className="text-sm text-green-400 font-semibold">Earned today: R{adEarned.toFixed(2)}</p>
                    </div>
                  )}
                  <button
                    onClick={watchAd}
                    disabled={adState !== 'idle'}
                    className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:opacity-90 disabled:opacity-50 text-white font-semibold py-3 rounded-xl transition-all flex items-center justify-center gap-2"
                  >
                    <Play className="w-4 h-4" />
                    {adState === 'loading' ? 'Loading Ad...' : 'Watch Ad & Earn R0.05'}
                  </button>

                </div>
              )}
            </motion.div>
          );
        })}
      </div>

      {/* Info */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="mx-6 mt-6 bg-gray-800/30 rounded-2xl p-5 border border-gray-700/30"
      >
        <h3 className="font-semibold text-white mb-3">How It Works</h3>
        <ul className="text-sm text-gray-400 space-y-2">
          <li className="flex items-start gap-2">
            <span className="text-purple-400 mt-0.5">•</span>
            <span><strong>Referrals:</strong> Share your unique link and earn R5 when someone subscribes to premium</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-400 mt-0.5">•</span>
            <span><strong>Ads:</strong> Watch short video ads (15-30 seconds) to earn R0.05 instantly</span>
          </li>
        </ul>
        <p className="text-xs text-gray-500 mt-4">
          Credits are added to your account immediately and can be used for premium features.
        </p>
      </motion.div>
      {/* Rewarded Ad Modal */}
      <AnimatePresence>
        {(adState === 'playing' || adState === 'rewarded') && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/95 flex flex-col items-center justify-center px-6"
          >
            {adState === 'playing' && (
              <>
                {/* Real AdSense Ad */}
                <div className="w-full max-w-sm bg-gray-900 rounded-2xl overflow-hidden border border-gray-700/50 mb-6 p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-gray-500">Advertisement</span>
                    <div className="bg-black/70 rounded-full px-3 py-1">
                      <span className="text-white text-xs font-mono">{countdown}s</span>
                    </div>
                  </div>
                  <AdSenseAd />
                </div>

                {/* Progress bar */}
                <div className="w-full max-w-sm bg-gray-800 rounded-full h-1.5 mb-4">
                  <motion.div
                    className="bg-gradient-to-r from-blue-500 to-cyan-500 h-1.5 rounded-full"
                    initial={{ width: '0%' }}
                    animate={{ width: '100%' }}
                    transition={{ duration: AD_DURATION_SEC, ease: 'linear' }}
                  />
                </div>

                <p className="text-gray-400 text-sm">View the ad to earn <span className="text-cyan-400 font-semibold">R0.05</span></p>
                {countdown <= 5 && (
                  <p className="text-yellow-400 text-xs mt-1 animate-pulse">Almost done…</p>
                )}
              </>
            )}

            {adState === 'rewarded' && (
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="flex flex-col items-center text-center"
              >
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center mb-6 shadow-lg shadow-emerald-500/30">
                  <Gift className="w-12 h-12 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">You Earned!</h2>
                <p className="text-4xl font-bold text-emerald-400 mb-2">R0.05</p>
                <p className="text-gray-400 text-sm mb-8">Credited to your wallet instantly</p>
                <div className="flex gap-3 w-full max-w-xs">
                  <button
                    onClick={() => { closeAd(); }}
                    className="flex-1 bg-gray-800 border border-gray-700 text-white font-semibold py-3 rounded-xl"
                  >
                    Done
                  </button>
                  <button
                    onClick={() => { closeAd(); setTimeout(watchAd, 300); }}
                    className="flex-1 bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-semibold py-3 rounded-xl"
                  >
                    Watch Again
                  </button>
                </div>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}