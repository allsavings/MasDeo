import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import {
  Lock, Eye, EyeOff, ArrowRight, Loader,
  AlertCircle, CheckCircle, Mail
} from 'lucide-react';
import { useLocation } from 'react-router-dom';

export default function ResetPassword() {
  const location = useLocation();

  const [token, setToken] = useState('');
  const [tokenType, setTokenType] = useState(null); // 'ours' | 'platform'
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [stage, setStage] = useState('form'); // 'form' | 'check_email' | 'done' | 'invalid' | 'auto_applying'

  useEffect(() => {
    const params = new URLSearchParams(location.search || window.location.search);
    const t =
      params.get('hashed_reset_token') ||
      params.get('token') ||
      params.get('reset_token') ||
      params.get('resetToken');

    if (!t) {
      setStage('invalid');
      return;
    }

    setToken(t);
    setTokenType('platform');

    // Always a platform token here. Check sessionStorage first (user-initiated flow),
    // then fall back to fetching from the admin-set pending vault.
    const stored = sessionStorage.getItem('pending_reset_password');
    if (stored) {
      sessionStorage.removeItem('pending_reset_password');
      setStage('auto_applying');
      // We need the email to fetch from vault — but we have the password already
      applyPlatformReset(t, stored);
    } else {
      // Possibly an admin-set reset — try to get email from URL and fetch pending password
      const emailParam = params.get('email');
      if (emailParam) {
        setStage('auto_applying');
        fetchPendingAndApply(t, emailParam);
      }
      // Otherwise just show the manual form
    }
  }, []);

  const fetchPendingAndApply = async (platformToken, email) => {
    setLoading(true);
    setError('');
    try {
      const vaultRes = await base44.functions.invoke('adminGetPendingPassword', { email });
      const pendingPassword = vaultRes.data?.password;
      if (pendingPassword) {
        await applyPlatformReset(platformToken, pendingPassword);
      } else {
        // No pending password — show manual form
        setStage('form');
      }
    } catch (err) {
      setStage('form');
    } finally {
      setLoading(false);
    }
  };

  const applyPlatformReset = async (platformToken, password) => {
    setLoading(true);
    setError('');
    try {
      await base44.auth.resetPassword({ resetToken: platformToken, newPassword: password });
      setStage('done');
    } catch (err) {
      const raw = err?.response?.data;
      const msg =
        (typeof raw === 'string' ? raw : raw?.error || raw?.message || raw?.detail) ||
        err?.message ||
        '';
      setError(msg || 'Failed to set password. The link may have expired — please request a new reset.');
      setStage('form');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (newPassword !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    if (newPassword.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }

    setLoading(true);
    try {
      if (tokenType === 'platform') {
        // Platform token — apply directly
        await applyPlatformReset(token, newPassword);
      } else {
        // Our backup-code token — validate it, store password, trigger platform email
        const res = await base44.functions.invoke('applyPasswordReset', {
          reset_token: token,
          newPassword
        });

        if (res.data?.success) {
          // Store password so the platform email link auto-applies it
          sessionStorage.setItem('pending_reset_password', newPassword);
          setStage('check_email');
        } else {
          setError(res.data?.error || 'Something went wrong. Please try again.');
        }
      }
    } catch (err) {
      const msg =
        err?.response?.data?.error ||
        err?.response?.data?.message ||
        err?.message ||
        '';
      setError(msg || 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // ── AUTO-APPLYING ──────────────────────────────────────────────────────────
  if (stage === 'auto_applying') {
    return (
      <PageShell>
        <div className="text-center space-y-4">
          <Loader className="w-10 h-10 text-cyan-400 animate-spin mx-auto" />
          <p className="text-white font-semibold text-lg">Applying your new password...</p>
          <p className="text-gray-500 text-sm">Just a moment.</p>
        </div>
      </PageShell>
    );
  }

  // ── INVALID TOKEN ──────────────────────────────────────────────────────────
  if (stage === 'invalid') {
    return (
      <PageShell>
        <div className="text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-red-500/20 flex items-center justify-center mx-auto">
            <AlertCircle className="w-8 h-8 text-red-400" />
          </div>
          <p className="text-white font-semibold text-lg">Invalid Reset Link</p>
          <p className="text-gray-400 text-sm">This link is invalid or missing a token. Please request a new password reset.</p>
          <a href="/auth" className="inline-block mt-2 text-cyan-400 text-sm hover:underline">← Back to Sign In</a>
        </div>
      </PageShell>
    );
  }

  // ── CHECK EMAIL ────────────────────────────────────────────────────────────
  if (stage === 'check_email') {
    return (
      <PageShell>
        <div className="text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-blue-500/20 flex items-center justify-center mx-auto">
            <Mail className="w-8 h-8 text-blue-400" />
          </div>
          <p className="text-white font-semibold text-lg">One last step!</p>
          <p className="text-gray-400 text-sm leading-relaxed">
            Check your email and click the <strong className="text-white">Reset Password</strong> link.<br />
            Your new password will be applied automatically — no need to type it again.
          </p>
          <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4 text-left text-xs text-blue-300 leading-relaxed">
            <p>📧 Open the email we just sent you and tap the reset button.</p>
            <p className="mt-2 text-blue-400/70">The link expires in 30 minutes.</p>
          </div>
          <a href="/auth" className="inline-block mt-2 text-gray-500 text-xs hover:text-gray-300 transition-colors">← Back to Sign In</a>
        </div>
      </PageShell>
    );
  }

  // ── SUCCESS ────────────────────────────────────────────────────────────────
  if (stage === 'done') {
    return (
      <PageShell>
        <div className="text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center mx-auto">
            <CheckCircle className="w-8 h-8 text-green-400" />
          </div>
          <p className="text-green-300 font-semibold text-lg">Password Updated!</p>
          <p className="text-gray-400 text-sm">Your password has been changed successfully.</p>
          <a
            href="/auth"
            className="inline-block mt-4 py-3 px-8 rounded-2xl font-bold text-white text-sm"
            style={{ background: 'linear-gradient(135deg, #7c3aed, #06b6d4)' }}
          >
            Sign In Now
          </a>
        </div>
      </PageShell>
    );
  }

  // ── PASSWORD FORM ──────────────────────────────────────────────────────────
  return (
    <PageShell>
      <div className="text-center mb-8">
        <h1 className="text-2xl font-black text-white mb-2">Set New Password</h1>
        <p className="text-sm text-gray-400">
          {tokenType === 'platform'
            ? 'Enter your new password below.'
            : 'Enter the password you want to use. You\'ll receive one final email to confirm.'}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <PasswordField
          value={newPassword}
          onChange={setNewPassword}
          placeholder="New Password"
          show={showNew}
          onToggle={() => setShowNew(!showNew)}
          disabled={loading}
        />
        <PasswordField
          value={confirmPassword}
          onChange={setConfirmPassword}
          placeholder="Confirm Password"
          show={showConfirm}
          onToggle={() => setShowConfirm(!showConfirm)}
          disabled={loading}
        />

        {error && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-xl px-3.5 py-3 text-xs text-red-300"
          >
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            {error}
          </motion.div>
        )}

        <button
          type="submit"
          disabled={loading || !newPassword || !confirmPassword}
          className="w-full py-4 rounded-2xl font-black text-base text-white disabled:opacity-50 transition-all flex items-center justify-center gap-2"
          style={{
            background: 'linear-gradient(135deg, #7c3aed, #06b6d4)',
            boxShadow: '0 0 24px rgba(124,58,237,0.3)'
          }}
        >
          {loading ? (
            <><Loader className="w-4 h-4 animate-spin" /> Saving...</>
          ) : (
            <>{tokenType === 'platform' ? 'Set New Password' : 'Confirm & Send Email'} <ArrowRight className="w-4 h-4" /></>
          )}
        </button>
      </form>

      <div className="text-center mt-4">
        <a href="/auth" className="text-xs text-gray-600 hover:text-gray-400 transition-colors">← Back to Sign In</a>
      </div>
    </PageShell>
  );
}

// ── Shared shell ───────────────────────────────────────────────────────────────
function PageShell({ children }) {
  return (
    <div className="min-h-screen bg-[#0a0a0f] flex flex-col items-center justify-center px-6 py-10 relative overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-gradient-to-br from-violet-600/20 to-cyan-600/10 rounded-full blur-3xl pointer-events-none" />
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-sm"
      >
        <div className="text-center mb-8">
          <img
            src="https://media.base44.com/images/public/69f87739a9356aa0dffa0a0a/a4f90e43b_FinalMastersDeoVex.png?v=2"
            alt="Masters|DeoVex"
            className="w-20 h-20 mx-auto"
          />
        </div>
        {children}
      </motion.div>
    </div>
  );
}

// ── Password input field ───────────────────────────────────────────────────────
function PasswordField({ value, onChange, placeholder, show, onToggle, disabled }) {
  return (
    <div className="relative bg-gray-800/60 border border-gray-700/50 rounded-xl focus-within:border-violet-500/50 transition-colors">
      <span className="absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none">
        <Lock className="w-4 h-4 text-gray-600" />
      </span>
      <input
        type={show ? 'text' : 'password'}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        disabled={disabled}
        className="w-full bg-transparent pl-11 pr-11 py-3.5 text-sm text-white placeholder-gray-600 focus:outline-none disabled:opacity-50"
      />
      <button
        type="button"
        onClick={onToggle}
        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-600 hover:text-gray-400 transition-colors"
      >
        {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
      </button>
    </div>
  );
}