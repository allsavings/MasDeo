import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Globe, BookOpen, DollarSign, Check, X, ArrowLeft, Sparkles, Eye, Download, Star, FileText, User, Edit2, Shield, Award } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import NovaToggle from '@/components/ui/NovaToggle';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

export default function CreatorDashboard() {
  const [user, setUser] = useState(null);
  const [creatorSettings, setCreatorSettings] = useState(null);
  const [creatorProfile, setCreatorProfile] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [activeSubs, setActiveSubs] = useState([]);
  const [contentOverview, setContentOverview] = useState({});
  const [analyticsData, setAnalyticsData] = useState({ totalViews: 0, totalDownloads: 0, averageRating: 0 });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editingBio, setEditingBio] = useState(false);
  const [bioText, setBioText] = useState('');
  const [selectedCreatorType, setSelectedCreatorType] = useState('');
  const [followerCount, setFollowerCount] = useState(0);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const userData = await base44.auth.me();
      setUser(userData);

      const [subs, settings, creatorProfileData, userProfileData, vpnFiles, vpsServers, courses, resources, followers] = await Promise.all([
        base44.entities.Subscription.filter({ user_email: userData.email, status: 'active' }),
        base44.entities.CreatorSettings.filter({ created_by: userData.email }),
        base44.entities.CreatorProfile.filter({ user_email: userData.email }),
        base44.entities.UserProfile.filter({ created_by: userData.email }),
        base44.entities.CreatorVpnFile.filter({ creator_email: userData.email }),
        base44.entities.CreatorVpsServer.filter({ creator_email: userData.email }),
        base44.entities.CreatorCourse.filter({ creator_email: userData.email }),
        base44.entities.CreatorResource.filter({ creator_email: userData.email }),
        base44.entities.Follow.filter({ creator_email: userData.email })
      ]);

      setActiveSubs(subs);
      setUserProfile(userProfileData[0] || null);

      // Auto-create CreatorProfile if user has subscription but no profile
      let profile = creatorProfileData[0] || null;
      if (subs.length > 0 && !profile) {
        const plans = subs.map(s => s.plan);
        let creatorType = 'earn_online';
        if (plans.includes('all_in_one')) {
          creatorType = 'earn_online';
        } else if (plans.includes('earn_online')) {
          creatorType = 'earn_online';
        } else if (plans.includes('learn_skills')) {
          creatorType = 'learn_digital_skills';
        } else if (plans.includes('ethical_internet')) {
          creatorType = 'ethical_free_internet';
        }
        
        profile = await base44.entities.CreatorProfile.create({
          user_email: userData.email,
          creator_type: creatorType,
          verified: false,
          bio: '',
          trust_score: 0,
          banned: false
        });
        toast.success('Creator profile created!');
      }
      
      setCreatorProfile(profile);
      setBioText(profile?.bio || '');
      setSelectedCreatorType(profile?.creator_type || 'earn_online');

      let currentSettings = settings.length > 0 ? settings[0] : null;
      if (!currentSettings) {
        currentSettings = await base44.entities.CreatorSettings.create({
          user_email: userData.email,
          is_public: false,
          platforms: [],
          all_platforms: false
        });
      }
      setCreatorSettings(currentSettings);

      // Content Overview
      const allContentItems = [...vpnFiles, ...vpsServers, ...courses, ...resources];
      setContentOverview({
        vpnFiles: vpnFiles.filter(f => f.is_public).length,
        vpsServers: vpsServers.filter(s => s.is_public).length,
        courses: courses.filter(c => c.is_published).length,
        resources: resources.filter(r => r.is_published).length,
        total: vpnFiles.filter(f => f.is_public).length + vpsServers.filter(s => s.is_public).length + courses.filter(c => c.is_published).length + resources.filter(r => r.is_published).length
      });

      // Analytics
      let totalViews = 0;
      let totalDownloads = 0;
      if (allContentItems.length > 0) {
        const contentIds = allContentItems.map(item => item.id);
        const [views, downloads] = await Promise.all([
          base44.entities.ContentView.filter({}),
          base44.entities.ContentDownload.filter({})
        ]);
        totalViews = views.filter(v => contentIds.includes(v.content_id)).length;
        totalDownloads = downloads.filter(d => contentIds.includes(d.content_id)).length;
      }
      
      const avgRating = profile?.average_rating || 0;
      setAnalyticsData({ totalViews, totalDownloads, averageRating: avgRating });

      // Set follower count
      setFollowerCount(followers.length);

    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load creator settings');
    } finally {
      setLoading(false);
    }
  };

  const hasSubscription = (platform) => {
    const plans = activeSubs.map(s => s.plan);
    if (plans.includes('all_in_one')) return true;
    
    if (platform === 'ethical') return plans.includes('ethical_internet');
    if (platform === 'learn') return plans.includes('learn_skills');
    if (platform === 'earn') return plans.includes('earn_online');
    return false;
  };

  const hasAllSubscriptions = () => {
    const plans = activeSubs.map(s => s.plan);
    if (plans.includes('all_in_one')) return true;
    return plans.includes('ethical_internet') && plans.includes('learn_skills') && plans.includes('earn_online');
  };

  const togglePublic = async () => {
    if (!creatorSettings) return;
    setSaving(true);
    try {
      const newPublicStatus = !creatorSettings.is_public;
      await base44.entities.CreatorSettings.update(creatorSettings.id, {
        is_public: newPublicStatus
      });
      setCreatorSettings({ ...creatorSettings, is_public: newPublicStatus });
      toast.success(newPublicStatus ? 'You are now public!' : 'You are now private');
    } catch (error) {
      console.error('Error toggling public status:', error);
      toast.error('Failed to update status');
    } finally {
      setSaving(false);
    }
  };

  const togglePlatform = async (platform) => {
    if (!creatorSettings) return;

    if (!hasSubscription(platform)) {
      toast.error(`You need a subscription to ${platform === 'ethical' ? 'Ethical Internet' : platform === 'learn' ? 'Learn Skills' : 'Earn Online'}`);
      return;
    }

    setSaving(true);
    try {
      const currentPlatforms = creatorSettings.platforms || [];
      let newPlatforms;

      if (currentPlatforms.includes(platform)) {
        newPlatforms = currentPlatforms.filter(p => p !== platform);
      } else {
        newPlatforms = [...currentPlatforms, platform];
      }

      await base44.entities.CreatorSettings.update(creatorSettings.id, {
        platforms: newPlatforms,
        all_platforms: false
      });
      
      setCreatorSettings({ ...creatorSettings, platforms: newPlatforms, all_platforms: false });
      toast.success('Platform settings updated');
    } catch (error) {
      console.error('Error updating platform:', error);
      toast.error('Failed to update platform');
    } finally {
      setSaving(false);
    }
  };

  const toggleAllPlatforms = async () => {
    if (!creatorSettings) return;

    if (!hasAllSubscriptions()) {
      toast.error('You need subscriptions to all platforms (Ethical, Learn, Earn)');
      return;
    }

    setSaving(true);
    try {
      const newAllStatus = !creatorSettings.all_platforms;
      const newPlatforms = newAllStatus ? ['ethical', 'learn', 'earn'] : [];

      await base44.entities.CreatorSettings.update(creatorSettings.id, {
        all_platforms: newAllStatus,
        platforms: newPlatforms
      });
      
      setCreatorSettings({ ...creatorSettings, all_platforms: newAllStatus, platforms: newPlatforms });
      toast.success(newAllStatus ? 'Now public on all platforms!' : 'Removed from all platforms');
    } catch (error) {
      console.error('Error updating all platforms:', error);
      toast.error('Failed to update platforms');
    } finally {
      setSaving(false);
    }
  };

  const saveBio = async () => {
    if (!creatorProfile) return;
    setSaving(true);
    try {
      await base44.entities.CreatorProfile.update(creatorProfile.id, { bio: bioText });
      setCreatorProfile({ ...creatorProfile, bio: bioText });
      setEditingBio(false);
      toast.success('Bio updated successfully');
    } catch (error) {
      console.error('Error updating bio:', error);
      toast.error('Failed to update bio');
    } finally {
      setSaving(false);
    }
  };

  const saveCreatorType = async (type) => {
    if (!creatorProfile) return;
    setSaving(true);
    try {
      await base44.entities.CreatorProfile.update(creatorProfile.id, { creator_type: type });
      setCreatorProfile({ ...creatorProfile, creator_type: type });
      setSelectedCreatorType(type);
      toast.success('Creator type updated');
    } catch (error) {
      console.error('Error updating creator type:', error);
      toast.error('Failed to update creator type');
    } finally {
      setSaving(false);
    }
  };

  const requestVerification = async () => {
    if (!creatorProfile) return;
    if (creatorProfile.verification_requested) {
      toast.info('Verification already requested');
      return;
    }
    setSaving(true);
    try {
      await base44.entities.CreatorProfile.update(creatorProfile.id, { verification_requested: true });
      setCreatorProfile({ ...creatorProfile, verification_requested: true });
      toast.success('Verification request submitted! Admin will review your profile.');
    } catch (error) {
      console.error('Error requesting verification:', error);
      toast.error('Failed to submit verification request');
    } finally {
      setSaving(false);
    }
  };

  const creatorTypeOptions = [
    { value: 'ethical_free_internet', label: 'Ethical Free Internet', icon: Globe, color: 'text-blue-400' },
    { value: 'learn_digital_skills', label: 'Learn Digital Skills', icon: BookOpen, color: 'text-purple-400' },
    { value: 'earn_online', label: 'Earn Online', icon: DollarSign, color: 'text-emerald-400' }
  ];

  const platforms = [
    {
      id: 'ethical',
      name: 'Ethical Internet',
      icon: Globe,
      color: 'from-blue-500 to-cyan-400',
      bgColor: 'bg-blue-500/10',
      borderColor: 'border-blue-500/30'
    },
    {
      id: 'learn',
      name: 'Learn Skills',
      icon: BookOpen,
      color: 'from-purple-500 to-blue-500',
      bgColor: 'bg-purple-500/10',
      borderColor: 'border-purple-500/30'
    },
    {
      id: 'earn',
      name: 'Earn Online',
      icon: DollarSign,
      color: 'from-emerald-500 to-cyan-400',
      bgColor: 'bg-emerald-500/10',
      borderColor: 'border-emerald-500/30'
    }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white pb-20">
      {/* Header */}
      <div className="px-4 pt-6 pb-4 border-b border-gray-800/50">
        <div className="flex items-center gap-3 mb-4">
          <Link to={createPageUrl('Home')} className="text-gray-400 hover:text-white transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-xl font-bold">Creator Dashboard</h1>
        </div>
        <p className="text-sm text-gray-400">Manage your creator visibility and platform presence</p>
      </div>

      <div className="px-4 py-6 space-y-6">
        {/* Creator Profile Section */}
        <div>
          <h3 className="text-sm font-semibold text-gray-300 mb-3">Creator Profile</h3>
          
          {/* Profile Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-br from-gray-800/60 to-gray-900/60 rounded-2xl p-5 border border-gray-700/50 mb-3"
          >
            <div className="flex items-start gap-4 mb-4">
              {userProfile?.profile_picture_url ? (
                <img 
                  src={userProfile.profile_picture_url}
                  alt="Profile"
                  className="w-16 h-16 rounded-full object-cover border-2 border-blue-500/30"
                />
              ) : (
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center">
                  <User className="w-8 h-8 text-white" />
                </div>
              )}
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h2 className="font-bold text-white">{userProfile?.nickname || 'Creator'}</h2>
                  {creatorProfile?.verified && (
                    <div className="flex items-center gap-1 bg-blue-500/20 px-2 py-0.5 rounded-full">
                      <Shield className="w-3 h-3 text-blue-400" />
                      <span className="text-xs text-blue-400 font-medium">Verified</span>
                      {followerCount > 0 && (
                        <>
                          <span className="text-blue-400/50 mx-0.5">•</span>
                          <span className="text-xs text-blue-400 font-semibold">{followerCount}</span>
                        </>
                      )}
                    </div>
                  )}
                </div>
                <p className="text-sm text-gray-400">{userProfile?.handle || '@creator'}</p>
                <div className="flex items-center gap-2 mt-2">
                  <Award className="w-4 h-4 text-amber-400" />
                  <span className="text-xs text-gray-400">Trust Score: <span className="text-amber-400 font-semibold">{creatorProfile?.trust_score || 0}</span></span>
                </div>
                </div>
              <Link to={createPageUrl('Settings')}>
                <Button variant="outline" size="sm" className="gap-2">
                  <Edit2 className="w-3 h-3" />
                  Edit Profile
                </Button>
              </Link>
            </div>

            {/* Bio Section */}
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-medium text-gray-300">Bio</label>
                {!editingBio && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setEditingBio(true)}
                    className="h-7 text-xs"
                  >
                    <Edit2 className="w-3 h-3 mr-1" />
                    Edit
                  </Button>
                )}
              </div>
              {editingBio ? (
                <div className="space-y-2">
                  <Textarea
                    value={bioText}
                    onChange={(e) => setBioText(e.target.value)}
                    placeholder="Tell people about yourself and what you create..."
                    className="bg-gray-900/50 border-gray-700/50 text-white min-h-24"
                    maxLength={300}
                  />
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500">{bioText.length}/300</span>
                    <div className="flex gap-2">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => {
                          setBioText(creatorProfile?.bio || '');
                          setEditingBio(false);
                        }}
                      >
                        Cancel
                      </Button>
                      <Button 
                        size="sm" 
                        onClick={saveBio}
                        disabled={saving}
                      >
                        {saving ? 'Saving...' : 'Save'}
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-gray-400 bg-gray-900/30 rounded-lg p-3 min-h-20">
                  {creatorProfile?.bio || 'No bio yet. Click edit to add one.'}
                </p>
              )}
            </div>

            {/* Creator Type */}
            <div>
              <label className="text-sm font-medium text-gray-300 mb-2 block">Primary Creator Type</label>
              <Select value={selectedCreatorType} onValueChange={saveCreatorType} disabled={saving}>
                <SelectTrigger className="bg-gray-900/50 border-gray-700/50 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {creatorTypeOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      <div className="flex items-center gap-2">
                        <option.icon className={`w-4 h-4 ${option.color}`} />
                        <span>{option.label}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </motion.div>

          {/* Verification Status */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 }}
            className={`rounded-2xl p-4 border ${
              creatorProfile?.verified 
                ? 'bg-green-500/10 border-green-500/30' 
                : creatorProfile?.verification_requested
                ? 'bg-yellow-500/10 border-yellow-500/30'
                : 'bg-blue-500/10 border-blue-500/30'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <h4 className="font-semibold text-sm mb-1">
                  {creatorProfile?.verified 
                    ? '✓ Verified Creator' 
                    : creatorProfile?.verification_requested
                    ? 'Verification Pending'
                    : 'Get Verified'}
                </h4>
                <p className="text-xs text-gray-400">
                  {creatorProfile?.verified 
                    ? 'Your profile is verified and trusted by the community' 
                    : creatorProfile?.verification_requested
                    ? 'Admin is reviewing your verification request'
                    : 'Request verification to build trust and appear in Browse Creators'}
                </p>
              </div>
              {!creatorProfile?.verified && !creatorProfile?.verification_requested && (
                <Button 
                  size="sm" 
                  onClick={requestVerification}
                  disabled={saving}
                  className="bg-blue-500 hover:bg-blue-600"
                >
                  Request
                </Button>
              )}
            </div>
          </motion.div>
        </div>

        {/* Content Overview Section */}
        <div>
          <h3 className="text-sm font-semibold text-gray-300 mb-3">Content Overview</h3>
          <div className="grid grid-cols-2 gap-3">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-blue-500/10 rounded-xl p-4 border border-blue-500/30"
            >
              <div className="flex items-center gap-2 mb-2">
                <Globe className="w-4 h-4 text-blue-400" />
                <span className="text-xs text-gray-400">Ethical Internet</span>
              </div>
              <div className="text-2xl font-bold text-white">{(contentOverview.vpnFiles || 0) + (contentOverview.vpsServers || 0)}</div>
              <div className="text-xs text-gray-500">Files & Servers</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 }}
              className="bg-purple-500/10 rounded-xl p-4 border border-purple-500/30"
            >
              <div className="flex items-center gap-2 mb-2">
                <BookOpen className="w-4 h-4 text-purple-400" />
                <span className="text-xs text-gray-400">Learn Skills</span>
              </div>
              <div className="text-2xl font-bold text-white">{contentOverview.courses || 0}</div>
              <div className="text-xs text-gray-500">Courses</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-emerald-500/10 rounded-xl p-4 border border-emerald-500/30"
            >
              <div className="flex items-center gap-2 mb-2">
                <DollarSign className="w-4 h-4 text-emerald-400" />
                <span className="text-xs text-gray-400">Earn Online</span>
              </div>
              <div className="text-2xl font-bold text-white">{contentOverview.resources || 0}</div>
              <div className="text-xs text-gray-500">Resources</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              className="bg-amber-500/10 rounded-xl p-4 border border-amber-500/30"
            >
              <div className="flex items-center gap-2 mb-2">
                <FileText className="w-4 h-4 text-amber-400" />
                <span className="text-xs text-gray-400">Total Content</span>
              </div>
              <div className="text-2xl font-bold text-white">{contentOverview.total || 0}</div>
              <div className="text-xs text-gray-500">Published Items</div>
            </motion.div>
          </div>
        </div>

        {/* Basic Analytics Section */}
        <div>
          <h3 className="text-sm font-semibold text-gray-300 mb-3">Basic Analytics</h3>
          <div className="grid grid-cols-3 gap-3">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-gray-800/40 rounded-xl p-4 border border-gray-700/50"
            >
              <Eye className="w-5 h-5 text-cyan-400 mb-2" />
              <div className="text-xl font-bold text-white">{analyticsData.totalViews}</div>
              <div className="text-xs text-gray-500">Views</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.25 }}
              className="bg-gray-800/40 rounded-xl p-4 border border-gray-700/50"
            >
              <Download className="w-5 h-5 text-blue-400 mb-2" />
              <div className="text-xl font-bold text-white">{analyticsData.totalDownloads}</div>
              <div className="text-xs text-gray-500">Downloads</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-gray-800/40 rounded-xl p-4 border border-gray-700/50"
            >
              <Star className="w-5 h-5 text-amber-400 mb-2" />
              <div className="text-xl font-bold text-white">{analyticsData.averageRating.toFixed(1)}</div>
              <div className="text-xs text-gray-500">Avg Rating</div>
            </motion.div>
          </div>
        </div>

        {/* Platform Management Section */}
        <div>
          <h3 className="text-sm font-semibold text-gray-300 mb-3">Platform Management</h3>
          
          {/* Public Status Toggle */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35 }}
            className="bg-gray-800/40 rounded-xl p-5 border border-gray-700/50 mb-3"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${creatorSettings?.is_public ? 'bg-gradient-to-br from-purple-500 to-pink-500' : 'bg-gray-700/50'}`}>
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h2 className="font-semibold text-sm">Creator Status</h2>
                  <p className="text-xs text-gray-400">
                    {creatorSettings?.is_public ? 'Your profile is public' : 'Your profile is private'}
                  </p>
                </div>
              </div>
              <NovaToggle
                isActive={!!creatorSettings?.is_public}
                onToggle={!saving ? togglePublic : undefined}
                activeColorClass="from-purple-500 to-fuchsia-500"
              />
            </div>
            <p className="text-xs text-gray-500 leading-relaxed">
              Toggle this to make your creator profile visible to others on your selected platforms
            </p>
          </motion.div>

          {/* All Platforms Toggle */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className={`bg-gradient-to-br from-amber-500/10 to-orange-500/10 rounded-xl p-5 border ${
              hasAllSubscriptions() ? 'border-amber-500/30' : 'border-gray-700/30'
            }`}
          >
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="font-semibold text-sm mb-1">All Platforms</h2>
              <p className="text-xs text-gray-400">
                {hasAllSubscriptions() 
                  ? 'Go public on Ethical, Learn & Earn' 
                  : 'Requires all platform subscriptions'}
              </p>
            </div>
            <NovaToggle
              isActive={!!creatorSettings?.all_platforms}
              onToggle={(!saving && hasAllSubscriptions()) ? toggleAllPlatforms : undefined}
              activeColorClass="from-amber-400 to-orange-500"
            />
          </div>
          {!hasAllSubscriptions() && (
            <div className="flex items-start gap-2 mt-2 p-2 bg-red-500/10 rounded-lg border border-red-500/20">
              <X className="w-3.5 h-3.5 text-red-400 mt-0.5 flex-shrink-0" />
              <p className="text-xs text-red-400">Subscribe to all platforms to enable this option</p>
            </div>
          )}
        </motion.div>

          {/* Individual Platforms */}
          <div className="space-y-3">
            {platforms.map((platform, index) => {
              const isActive = creatorSettings?.platforms?.includes(platform.id) || creatorSettings?.all_platforms;
              const hasSub = hasSubscription(platform.id);

              return (
                <motion.div
                  key={platform.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.45 + index * 0.05 }}
                  className={`${platform.bgColor} rounded-xl p-4 border ${platform.borderColor} ${
                    !hasSub ? 'opacity-60' : ''
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1">
                      <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${platform.color} flex items-center justify-center`}>
                        <platform.icon className="w-5 h-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-sm">{platform.name}</h3>
                        <div className="flex items-center gap-2 mt-1">
                          {hasSub ? (
                            <div className="flex items-center gap-1">
                              <Check className="w-3 h-3 text-green-400" />
                              <span className="text-xs text-green-400">Subscribed</span>
                            </div>
                          ) : (
                            <div className="flex items-center gap-1">
                              <X className="w-3 h-3 text-red-400" />
                              <span className="text-xs text-red-400">No subscription</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    <NovaToggle
                      isActive={isActive}
                      onToggle={(!saving && hasSub && !creatorSettings?.all_platforms) ? () => togglePlatform(platform.id) : undefined}
                      activeColorClass={platform.color}
                    />
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Info Box */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="bg-blue-500/10 rounded-xl p-4 border border-blue-500/20 mt-3"
          >
            <p className="text-xs text-blue-300 leading-relaxed">
              💡 Your creator profile will only be visible on platforms where you have an active subscription and have toggled public visibility.
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}