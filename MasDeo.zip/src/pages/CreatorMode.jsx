import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { ArrowLeft, Server, FileText, Globe, Plus, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';

export default function CreatorMode() {
  const [user, setUser] = useState(null);
  const [subscription, setSubscription] = useState(null);
  const [activeTab, setActiveTab] = useState('vps');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const userData = await base44.auth.me();
    setUser(userData);
    
    const subs = await base44.entities.Subscription.filter({ 
      user_email: userData.email,
      status: 'active'
    });
    
    if (subs.length > 0) {
      setSubscription(subs[0]);
    }
  };

  if (!subscription) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white flex items-center justify-center p-6">
        <div className="text-center">
          <Shield className="w-16 h-16 text-amber-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-2">No Active Subscription</h2>
          <p className="text-gray-400 mb-6">You need an active premium subscription to access Creator Mode</p>
          <Link to={createPageUrl("Subscribe")}>
            <Button className="bg-blue-600">Subscribe Now</Button>
          </Link>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'vps', label: 'VPS Servers', icon: Server, page: 'CreatorVps' },
    { id: 'files', label: 'VPN Files', icon: FileText, page: 'CreatorFiles' },
    { id: 'websites', label: 'Websites', icon: Globe, page: 'CreatorWebsites' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center gap-4 mb-6">
          <Link to={createPageUrl("MySubscription")} className="p-2 bg-gray-800/50 rounded-xl">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div className="flex-1">
            <h1 className="text-xl font-bold">Creator Mode</h1>
            <p className="text-sm text-gray-400">{subscription.plan.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}</p>
          </div>
        </div>

        <div className="space-y-4">
          {tabs.map((tab, index) => (
            <motion.div
              key={tab.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Link to={createPageUrl(tab.page)}>
                <div className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50 hover:border-blue-500/50 transition-all cursor-pointer">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center">
                        <tab.icon className="w-6 h-6 text-blue-400" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-white">{tab.label}</h3>
                        <p className="text-sm text-gray-400">Manage your {tab.label.toLowerCase()}</p>
                      </div>
                    </div>
                    <Plus className="w-5 h-5 text-gray-600" />
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}