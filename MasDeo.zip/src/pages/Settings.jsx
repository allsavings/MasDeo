import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, User, Bell, Moon, Globe, Shield, ChevronRight, Camera, Crown, Lock, Sparkles, WifiOff, Trash2, KeyRound } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import NovaToggle from "@/components/ui/NovaToggle";
import { useTheme } from '@/hooks/useTheme';
import DeleteAccountDialog from '@/components/DeleteAccountDialog';

export default function Settings() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [notifications, setNotifications] = useState(true);
  const [isDark, setDark] = useTheme();
  const [offlineMode, setOfflineMode] = useState(() => localStorage.getItem('offline_mode') === 'true');
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [editedNickname, setEditedNickname] = useState('');
  const [editedHandle, setEditedHandle] = useState('');
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [creatorProfile, setCreatorProfile] = useState(null);
  const [showCreatorModal, setShowCreatorModal] = useState(false);
  const [selectedCreatorType, setSelectedCreatorType] = useState(null);
  // Password recovery handled via OTP flow at /auth


  useEffect(() => {
    loadUserAndProfile();
  }, []);

  const loadUserAndProfile = async () => {
    try {
      const userData = await base44.auth.me();
      setUser(userData);
      
      const profiles = await base44.entities.UserProfile.filter({ created_by: userData.email });
      if (profiles.length > 0) {
        setProfile(profiles[0]);
        setEditedNickname(profiles[0].nickname || 'Tk Master');
        setEditedHandle(profiles[0].handle || '@MastersDeoVex');
      }

      const creatorProfiles = await base44.entities.CreatorProfile.filter({ user_email: userData.email });
      if (creatorProfiles.length > 0) {
        setCreatorProfile(creatorProfiles[0]);
      }
    } catch (error) {
      console.log('User not logged in');
    }
  };

  const handleSaveProfile = async () => {
    if (!profile) return;
    
    const updates = { nickname: editedNickname };
    
    // Premium users can also update handle
    if (profile.membership_type === 'premium') {
      updates.handle = editedHandle;
    }
    
    await base44.entities.UserProfile.update(profile.id, updates);
    await loadUserAndProfile();
    setEditMode(false);
  };

  const handleProfilePictureUpload = async (e) => {
    if (profile?.membership_type !== 'premium') {
      alert('Profile picture upload is only available for premium members!');
      return;
    }
    
    const file = e.target.files?.[0];
    if (!file) return;
    
    setUploading(true);
    setUploadError('');
    try {
      const { uploadFile } = await import('@/components/vpsAPI');
      const result = await uploadFile(file);
      await base44.entities.UserProfile.update(profile.id, {
        profile_picture_url: result.url
      });
      await loadUserAndProfile();
    } catch (error) {
      setUploadError(error.message || 'Upload failed. Please try again.');
      console.error('Upload failed:', error);
    }
    setUploading(false);
  };

  const selectPremiumType = async (type) => {
    if (profile?.membership_type !== 'premium') {
      alert('Upgrade to Premium first!');
      return;
    }

    await base44.entities.UserProfile.update(profile.id, {
      premium_type: type
    });

    // Create creator profile if doesn't exist
    if (!creatorProfile) {
      await base44.entities.CreatorProfile.create({
        user_email: user.email,
        creator_type: type,
        verified: false,
        verification_requested: false,
        trust_score: 0,
        strikes: 0,
        banned: false
      });
    } else {
      await base44.entities.CreatorProfile.update(creatorProfile.id, {
        creator_type: type
      });
    }

    await loadUserAndProfile();
    setShowCreatorModal(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      {/* Header */}
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center gap-4 mb-6">
          <Link to={createPageUrl("Profile")} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-xl font-bold">Settings</h1>
        </div>
      </div>

      {/* Profile Section */}
      <div className="px-6 mb-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gray-800/40 rounded-2xl p-6 border border-gray-700/50"
        >
          <div className="flex items-start gap-4 mb-4">
            <div className="relative">
              <input
                type="file"
                id="profile-upload"
                className="hidden"
                accept="image/*"
                onChange={handleProfilePictureUpload}
                disabled={profile?.membership_type !== 'premium'}
              />
              {profile?.profile_picture_url && profile?.membership_type === 'premium' ? (
                <img 
                  src={profile.profile_picture_url}
                  alt="Profile"
                  className="w-16 h-16 rounded-full object-cover"
                />
              ) : (
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6997a28cb8ba4da96dc79bb8/9821b9501_FinalMastersDeoVex.png" 
                  alt="Default Profile"
                  className="w-16 h-16"
                />
              )}
              <label 
                htmlFor="profile-upload" 
                className={`absolute -bottom-1 -right-1 w-7 h-7 ${profile?.membership_type === 'premium' ? 'bg-blue-500 cursor-pointer' : 'bg-gray-600 cursor-not-allowed'} rounded-full flex items-center justify-center border-2 border-gray-900`}
              >
                {uploading ? (
                  <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : profile?.membership_type === 'premium' ? (
                  <Camera className="w-3 h-3 text-white" />
                ) : (
                  <Lock className="w-3 h-3 text-gray-400" />
                )}
              </label>
            </div>
            {uploadError && (
              <div className="mt-2 text-xs text-red-400 bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2">
                {uploadError}
              </div>
            )}
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-semibold text-white text-lg">{profile?.nickname || 'Tk Master'}</h3>
                {profile?.membership_type === 'premium' && (
                  <Crown className="w-4 h-4 text-amber-400" />
                )}
              </div>
              <p className="text-sm text-gray-400 mb-1">{profile?.handle || '@MastersDeoVex'}</p>
              <p className="text-xs text-gray-500">{user?.email}</p>
            </div>
          </div>

          {!editMode ? (
            <Button 
              onClick={() => setEditMode(true)}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              Edit Profile
            </Button>
          ) : (
            <div className="space-y-3">
              <div>
                <Label className="text-gray-400 text-xs mb-1 block">Nickname</Label>
                <Input
                  value={editedNickname}
                  onChange={(e) => setEditedNickname(e.target.value)}
                  placeholder="Your nickname"
                  className="bg-gray-700/50 border-gray-600"
                />
              </div>
              
              <div>
                <Label className="text-gray-400 text-xs mb-1 block flex items-center gap-2">
                  Handle 
                  {profile?.membership_type !== 'premium' && (
                    <span className="text-amber-400 flex items-center gap-1 text-[10px]">
                      <Lock className="w-3 h-3" /> Premium Only
                    </span>
                  )}
                </Label>
                <Input
                  value={editedHandle}
                  onChange={(e) => setEditedHandle(e.target.value)}
                  placeholder="@YourHandle"
                  disabled={profile?.membership_type !== 'premium'}
                  className="bg-gray-700/50 border-gray-600 disabled:opacity-50"
                />
              </div>

              <div className="flex gap-2">
                <Button 
                  onClick={handleSaveProfile}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                >
                  Save
                </Button>
                <Button 
                  onClick={() => {
                    setEditMode(false);
                    setEditedNickname(profile?.nickname || 'Tk Master');
                    setEditedHandle(profile?.handle || '@MastersDeoVex');
                  }}
                  variant="outline"
                  className="flex-1"
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </motion.div>
      </div>

      {/* Settings Sections */}
      <div className="px-6 space-y-6">
        {/* Preferences */}
        <div>
          <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider mb-3">Preferences</h3>
          <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 overflow-hidden">
            <div className="p-4 flex items-center justify-between border-b border-gray-700/50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center">
                  <Bell className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <h4 className="font-medium text-white">Notifications</h4>
                  <p className="text-xs text-gray-500">Receive updates and alerts</p>
                </div>
              </div>
              <NovaToggle isActive={notifications} onToggle={() => setNotifications(v => !v)} activeColorClass="from-blue-500 to-cyan-400" size="sm" />
            </div>
            <div className="p-4 flex items-center justify-between border-b border-gray-700/50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center">
                  <Moon className="w-5 h-5 text-purple-400" />
                </div>
                <div>
                  <h4 className="font-medium text-white">Dark Mode</h4>
                  <p className="text-xs text-gray-500">Follows system by default</p>
                </div>
              </div>
              <NovaToggle isActive={isDark} onToggle={() => setDark(v => !v)} activeColorClass="from-purple-500 to-indigo-500" size="sm" />
            </div>
            <div className="p-4 flex items-center justify-between border-b border-gray-700/50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-green-500/20 flex items-center justify-center">
                  <Globe className="w-5 h-5 text-green-400" />
                </div>
                <div>
                  <h4 className="font-medium text-white">Language</h4>
                  <p className="text-xs text-gray-500">English</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-600" />
            </div>
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${offlineMode ? 'bg-orange-500/20' : 'bg-gray-600/20'}`}>
                  <WifiOff className={`w-5 h-5 ${offlineMode ? 'text-orange-400' : 'text-gray-400'}`} />
                </div>
                <div>
                  <h4 className="font-medium text-white">Offline Mode</h4>
                  <p className="text-xs text-gray-500">
                    {offlineMode ? '✅ App ready for offline use' : 'Skip sync — use cached data only'}
                  </p>
                </div>
              </div>
              <NovaToggle
                isActive={offlineMode}
                onToggle={() => {
                  const next = !offlineMode;
                  setOfflineMode(next);
                  if (next) localStorage.setItem('offline_mode', 'true');
                  else localStorage.removeItem('offline_mode');
                }}
                activeColorClass="from-orange-500 to-amber-400"
                size="sm"
              />
            </div>
          </div>
        </div>

        {/* Creator Mode */}
        <div>
          <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider mb-3">Creator Features</h3>
          {creatorProfile ? (
            <Link to={createPageUrl("CreatorDashboard")}>
              <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-2xl p-5 border border-purple-500/30 hover:border-purple-500/50 transition-all cursor-pointer">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center">
                      <Sparkles className="w-5 h-5 text-purple-400" />
                    </div>
                    <div>
                      <h4 className="font-medium text-white">Creator Dashboard</h4>
                      <p className="text-xs text-gray-400">Manage your creator profile</p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-600" />
                </div>
              </div>
            </Link>
          ) : (
            <div className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50">
              <div className="flex items-start gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-purple-400" />
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-white mb-1">Premium Type</h4>
                  <p className="text-xs text-gray-400 mb-3">
                    Current: {!profile?.premium_type || profile?.premium_type === 'none' ? 'None' : 
                      profile.premium_type.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
                  </p>
                  {profile?.membership_type !== 'premium' && (
                    <div className="flex items-center gap-2 text-amber-400 text-xs mb-3">
                      <Lock className="w-3 h-3" />
                      <span>Premium membership required</span>
                    </div>
                  )}
                </div>
              </div>
              <Button 
                onClick={() => setShowCreatorModal(true)}
                disabled={profile?.membership_type !== 'premium'}
                className="w-full bg-purple-600 hover:bg-purple-700 disabled:opacity-50"
              >
                {profile?.membership_type === 'premium' ? 'Select Premium Type' : 'Upgrade to Premium'}
              </Button>
            </div>
          )}
        </div>

        {/* Security */}
        <div>
          <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider mb-3">Security</h3>
          <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 overflow-hidden mb-3">

            {/* Forgot Password Row — links to OTP recovery flow */}
            <Link to="/auth" className="block">
              <div className="w-full p-4 flex items-center justify-between hover:bg-gray-700/20 transition-colors border-b border-gray-700/50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-violet-500/20 flex items-center justify-center">
                    <KeyRound className="w-5 h-5 text-violet-400" />
                  </div>
                  <div className="text-left">
                    <h4 className="font-medium text-white">Forgot Password</h4>
                    <p className="text-xs text-gray-500">Recover your password via email code</p>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-600" />
              </div>
            </Link>

            {localStorage.getItem('app_pin') ? (
              <div
                onClick={() => {
                  if (confirm('Remove PIN lock? You will no longer need to enter PIN on app launch.')) {
                    localStorage.removeItem('app_pin');
                    alert('PIN removed successfully');
                  }
                }}
                className="p-4 flex items-center justify-between cursor-pointer hover:bg-gray-700/20 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center">
                    <Lock className="w-5 h-5 text-red-400" />
                  </div>
                  <div>
                    <h4 className="font-medium text-white">Remove PIN</h4>
                    <p className="text-xs text-gray-500">Disable PIN lock</p>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-600" />
              </div>
            ) : (
              <Link to={createPageUrl("SetupPin")}>
                <div className="p-4 flex items-center justify-between cursor-pointer hover:bg-gray-700/20 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center">
                      <Lock className="w-5 h-5 text-amber-400" />
                    </div>
                    <div>
                      <h4 className="font-medium text-white">Setup PIN</h4>
                      <p className="text-xs text-gray-500">Quick unlock with PIN</p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-600" />
                </div>
              </Link>
            )}
          </div>
        </div>

        {/* Account Actions */}
        <div>
          <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider mb-3">Account</h3>
          <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 overflow-hidden">
            <div
              onClick={() => { window.location.href = createPageUrl('LogoutConfirm'); }}
              className="p-4 flex items-center justify-between cursor-pointer hover:bg-red-500/10 transition-colors border-b border-gray-700/50"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center">
                  <Shield className="w-5 h-5 text-red-400" />
                </div>
                <div>
                  <h4 className="font-medium text-red-400">Logout</h4>
                  <p className="text-xs text-gray-500">Sign out of your account</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-600" />
            </div>

            {/* Delete Account */}
            <div
              onClick={() => setShowDeleteDialog(true)}
              role="button"
              aria-label="Delete account permanently"
              className="p-4 flex items-center justify-between cursor-pointer hover:bg-red-900/20 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-red-900/40 flex items-center justify-center">
                  <Trash2 className="w-5 h-5 text-red-500" />
                </div>
                <div>
                  <h4 className="font-medium text-red-500">Delete Account</h4>
                  <p className="text-xs text-gray-500">Permanently remove all your data</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-600" />
            </div>
          </div>
        </div>

        {/* Version */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-center pt-6"
        >
          <p className="text-gray-600 text-sm">Masters DeoVex v1.0.0</p>
          <p className="text-gray-700 text-xs mt-1">{profile?.membership_type === 'premium' ? 'Premium Version' : 'Free Version'}</p>
        </motion.div>
      </div>

      {/* Delete Account Dialog */}
      <DeleteAccountDialog
        open={showDeleteDialog}
        onClose={() => setShowDeleteDialog(false)}
        userEmail={user?.email}
      />

      {/* Creator Type Selection Modal */}
      {showCreatorModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-gray-900 rounded-2xl p-6 max-w-md w-full border border-gray-700"
          >
            <h3 className="text-xl font-bold text-white mb-2">Choose Your Creator Type</h3>
            <p className="text-sm text-gray-400 mb-6">Select the area you want to create content in:</p>
            
            <div className="space-y-3 mb-6">
              <button
                onClick={() => selectPremiumType('ethical_free_internet')}
                className="w-full bg-blue-500/20 border border-blue-500/30 rounded-xl p-4 text-left hover:bg-blue-500/30 transition-colors"
              >
                <h4 className="font-semibold text-white mb-1">Ethical Free Internet</h4>
                <p className="text-xs text-gray-400">VPNs, privacy tools, network security</p>
              </button>
              
              <button
                onClick={() => selectPremiumType('learn_digital_skills')}
                className="w-full bg-purple-500/20 border border-purple-500/30 rounded-xl p-4 text-left hover:bg-purple-500/30 transition-colors"
              >
                <h4 className="font-semibold text-white mb-1">Learn Digital Skills</h4>
                <p className="text-xs text-gray-400">Tutorials, courses, skill development</p>
              </button>
              
              <button
                onClick={() => selectPremiumType('earn_online')}
                className="w-full bg-green-500/20 border border-green-500/30 rounded-xl p-4 text-left hover:bg-green-500/30 transition-colors"
              >
                <h4 className="font-semibold text-white mb-1">Earn Online</h4>
                <p className="text-xs text-gray-400">Trading systems, earning opportunities</p>
              </button>

              <button
                onClick={() => selectPremiumType('all_in_one')}
                className="w-full bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/30 rounded-xl p-4 text-left hover:bg-amber-500/30 transition-colors"
              >
                <h4 className="font-semibold text-white mb-1 flex items-center gap-2">
                  All-in-One
                  <span className="text-xs bg-amber-500/30 px-2 py-0.5 rounded-full">Premium+</span>
                </h4>
                <p className="text-xs text-gray-400">Access all creator features</p>
              </button>
            </div>

            <Button 
              onClick={() => setShowCreatorModal(false)}
              variant="outline"
              className="w-full"
            >
              Cancel
            </Button>
          </motion.div>
        </div>
      )}
    </div>
  );
}