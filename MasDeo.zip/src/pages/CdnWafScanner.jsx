import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft, Shield, Square, Download, Upload, Trash2,
  Loader, CheckCircle, Copy, Check, Code, Terminal,
  ChevronDown, ChevronUp
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

// ─── Shared host storage key (syncs with ZeroRatedScan) ───────────────────────
const SHARED_HOSTS_KEY = 'shared_target_hosts';

// ─── CONFIG ──────────────────────────────────────────────────────────────────
const DEFAULT_HOST = 'fx.tkmaster.qzz.io';
const DEFAULT_TOKEN = '123000';
const HARDCODED_PLUGIN = { id: 'M@☆', name: 'CDNWAF_Scanner [M@☆]' };

// ─── COPY BUTTON ─────────────────────────────────────────────────────────────
function CopyBtn({ text }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      onClick={() => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
      className="flex items-center gap-1 text-xs text-gray-400 hover:text-white px-2 py-1 rounded-lg hover:bg-gray-700/50 transition-all"
    >
      {copied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
      {copied ? 'Copied!' : 'Copy'}
    </button>
  );
}

// ─── CODE BLOCK ──────────────────────────────────────────────────────────────
function CodeBlock({ title, icon: Icon, code }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className="bg-gray-900/80 rounded-2xl border border-gray-700/50 overflow-hidden mb-4">
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-gray-700/50 bg-gray-800/50">
        <div className="flex items-center gap-2">
          <Icon className="w-4 h-4 text-purple-400" />
          <span className="text-xs font-medium text-gray-300">{title}</span>
        </div>
        <div className="flex items-center gap-1">
          <CopyBtn text={code} />
          <button onClick={() => setExpanded(!expanded)} className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-gray-700/50 transition-all">
            {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>
      <pre className={`text-xs text-gray-300 p-4 overflow-x-auto leading-relaxed whitespace-pre-wrap ${expanded ? '' : 'max-h-48 overflow-y-hidden'}`}>{code}</pre>
      {!expanded && (
        <button onClick={() => setExpanded(true)} className="w-full text-center text-xs text-gray-500 hover:text-gray-300 py-2 bg-gray-900/60 border-t border-gray-700/30 transition-all">
          Show more ↓
        </button>
      )}
    </div>
  );
}

// ─── RESULT CARD ─────────────────────────────────────────────────────────────
// Header-like lines: HTTP response header patterns
const isHeaderLine = (line) => /^\s+[\w\-]+:\s/.test(line) || /^\s*(Server|CF-|X-|Content-|Cache-|Set-Cookie|Location|Date|ETag|Last-Modified|Via|Alt-Svc|Vary|Age|Strict-Transport|Access-Control)/i.test(line.trim());

function ResultCard({ r, index, showHeaders, showIp }) {
  let lines = r.text ? r.text.split('\n') : [];

  // Filter IP/Org lines if IP lookup is off
  if (!showIp) {
    lines = lines.filter(line => !line.startsWith('IP') && !line.startsWith('Org'));
  }

  // Filter header lines if full headers is off
  if (!showHeaders) {
    lines = lines.filter(line => !isHeaderLine(line));
  }

  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.12, delay: index * 0.03 }}
      className="rounded-xl border border-purple-500/20 overflow-hidden"
    >
      <div className="flex items-center gap-3 px-4 py-2.5 bg-gray-800/60">
        <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
        <p className="flex-1 text-sm font-mono font-semibold truncate text-white">{r.domain}</p>
      </div>
      <div className="px-4 py-3 bg-gray-900/50 font-mono text-[11px] text-gray-300 whitespace-pre-wrap leading-relaxed">
        {lines.map((line, i) => {
          if (line.startsWith('✅')) return <p key={i} className="text-green-400 font-semibold">{line}</p>;
          if (line.startsWith('❌') || line.includes('Error')) return <p key={i} className="text-red-400">{line}</p>;
          if (line.startsWith('IP') || line.startsWith('Org')) return <p key={i} className="text-cyan-300">{line}</p>;
          if (line.startsWith('Checking:')) return <p key={i} className="text-purple-300 font-bold">{line}</p>;
          if (line.startsWith('---')) return <p key={i} className="text-gray-700">{line}</p>;
          if (isHeaderLine(line)) return <p key={i} className="text-gray-400 ml-3">{line}</p>;
          return <p key={i}>{line}</p>;
        })}
      </div>
    </motion.div>
  );
}

// ─── MAIN PAGE ────────────────────────────────────────────────────────────────
export default function CdnWafScanner() {
  // Sync hosts with ZeroRatedScan via localStorage
  const [hostsText, setHostsText] = useState(() => localStorage.getItem(SHARED_HOSTS_KEY) || '');
  const [scanning, setScanning] = useState(false);
  const [results, setResults] = useState([]);
  const [progress, setProgress] = useState({ done: 0, total: 0 });
  const vpsHost = localStorage.getItem('vps_host') || DEFAULT_HOST;
  const vpsToken = localStorage.getItem('vps_token') || DEFAULT_TOKEN;
  const [enableIpLookup, setEnableIpLookup] = useState(true);
  const [enableFullHeaders, setEnableFullHeaders] = useState(true);
  // Smart Filter
  const [keepPorts, setKeepPorts] = useState(false);
  const [keepPaths, setKeepPaths] = useState(false);
  const [autoClean, setAutoClean] = useState(false);

  const stopRef = useRef(false);
  const fileInputRef = useRef(null);

  // Keep shared hosts in sync
  const updateHosts = (val) => {
    setHostsText(val);
    localStorage.setItem(SHARED_HOSTS_KEY, val);
  };

  // Poll for changes from ZeroRatedScan
  useEffect(() => {
    const interval = setInterval(() => {
      const shared = localStorage.getItem(SHARED_HOSTS_KEY) || '';
      setHostsText(prev => prev !== shared ? shared : prev);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const hosts = hostsText.split('\n').map(h => h.trim()).filter(h => h && !h.startsWith('#'));
  const apiBase = `https://${vpsHost}`;

  const parseFileToHosts = (content, filename) => {
    const ext = filename.split('.').pop().toLowerCase();
    if (ext === 'json') {
      try {
        const parsed = JSON.parse(content);
        const arr = Array.isArray(parsed) ? parsed : Object.values(parsed).flat();
        return arr.map(v => (typeof v === 'string' ? v : (v?.host || v?.domain || v?.url || JSON.stringify(v)))).filter(Boolean).join('\n');
      } catch { return content; }
    }
    if (ext === 'csv') {
      return content.split('\n').map(line => {
        const cols = line.split(',');
        return cols[0].replace(/["']/g, '').trim();
      }).filter(Boolean).join('\n');
    }
    return content;
  };

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    const allHosts = [];
    for (const file of files) {
      const content = await file.text();
      allHosts.push(parseFileToHosts(content, file.name));
    }
    const combined = hostsText ? hostsText + '\n' + allHosts.join('\n') : allHosts.join('\n');
    updateHosts(combined);
    e.target.value = '';
  };

  // Clean & Format logic (same as ZeroRatedScan)
  const cleanAndFormat = () => {
    const lines = hostsText.split('\n').map(l => l.trim()).filter(l => l && !l.startsWith('#'));
    let items = [];
    for (const line of lines) {
      const parts = line.split(/[,\s]+/).map(p => p.trim()).filter(Boolean);
      items.push(...parts);
    }
    items = items.map(item => {
      item = item.replace(/^.*?:\/\//, ''); // always strip protocol
      if (!keepPorts) item = item.replace(/:\d+.*$/, '');
      if (!keepPaths) item = item.replace(/\/.*$/, '');
      item = item.replace(/[?#].*$/, '');
      return item.trim();
    });
    const hostPattern = /^([\w][\w\-]*\.)+[\w\-]+(:\d+)?(\/[\w\-./?%&=]*)?$|^\d{1,3}(\.\d{1,3}){3}(:\d+)?(\/.*)?$/;
    items = items.filter(item => item && hostPattern.test(item));
    items = [...new Set(items)];
    updateHosts(items.join('\n'));
  };

  // Run scan via VPS (always uses HARDCODED_PLUGIN)
  const startScan = async () => {
    if (!hosts.length) return;
    stopRef.current = false;
    setResults([]);
    setProgress({ done: 0, total: hosts.length });
    setScanning(true);

    const BATCH = 3;
    const allResults = [];

    for (let i = 0; i < hosts.length; i += BATCH) {
      if (stopRef.current) break;
      const batch = hosts.slice(i, i + BATCH);

      const batchPromises = batch.map(async (domain) => {
        if (stopRef.current) return null;
        const body = {
          hosts_content: domain,
          domain,
          enable_ip_lookup: enableIpLookup,
          ip_lookup: enableIpLookup,
          full_headers: enableFullHeaders,
          enable_full_headers: enableFullHeaders,
        };
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 180000);
        try {
          const res = await fetch(`${apiBase}/run/${HARDCODED_PLUGIN.id}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${vpsToken}` },
            body: JSON.stringify(body),
            signal: controller.signal,
          });
          clearTimeout(timer);
          const data = JSON.parse(await res.text());
          const text = (data.text || '').trim();
          if (!text) return { domain, text: 'No known CDN/WAF detected ❌', success: false };
          return { domain, text, success: true };
        } catch (e) {
          clearTimeout(timer);
          return { domain, text: `Error ❌ (${e.name === 'AbortError' ? 'timed out' : e.message})`, success: false };
        }
      });

      const batchResults = (await Promise.all(batchPromises)).filter(Boolean);
      allResults.push(...batchResults);
      setResults([...allResults]);
      setProgress({ done: Math.min(i + BATCH, hosts.length), total: hosts.length });
    }

    setScanning(false);
  };

  const stopScan = () => { stopRef.current = true; setScanning(false); };

  const downloadResults = () => {
    const ts = new Date().toISOString().slice(0, 19).replace('T', '_').replace(/:/g, '-');
    const content = results.map(r => {
      let lines = (r.text || '').split('\n');
      if (!enableIpLookup) lines = lines.filter(line => !line.startsWith('IP') && !line.startsWith('Org'));
      if (!enableFullHeaders) lines = lines.filter(line => !isHeaderLine(line));
      return lines.join('\n');
    }).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([content], { type: 'text/plain' }));
    a.download = `CDN&WAF_${ts}.txt`;
    a.click();
  };

  const PLACEHOLDER = `Enter one host per line, or upload a .txt file...

Examples:
  cloudflare.com
  github.com
  https://vercel.com     ← Auto-Clean strips the https://
  site.com:443           ← Turn ON Keep Ports to preserve :443
  api.site.com/v1        ← Turn ON Keep Paths to preserve /v1
  google.com, bing.com   ← Commas & spaces are auto-split
  # This line is a comment and will be ignored

Smart Filter tips:
  ✨ Clean  →  removes duplicates, bad formats & protocols
  Keep Ports ON  →  keeps :port numbers (e.g. site.com:443)
  Keep Paths ON  →  keeps /paths (e.g. site.com/api)
  Auto-Clean ON  →  always strips protocols (http:// / https://)`;

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      {/* Header */}
      <div className="px-4 pt-6 pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link to={createPageUrl("HostScanner")} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors">
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div>
              <h1 className="text-lg font-bold leading-tight">CDN & WAF Scanner</h1>
              <p className="text-xs text-purple-400">Detect CDN & WAF Protection</p>
            </div>
          </div>

        </div>
      </div>



      <div className="px-4 space-y-4">
        {/* Toggles */}
        <div className="space-y-2">
          <div className="bg-gray-800/40 rounded-xl px-4 py-3 border border-gray-700/40 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-white">IP & Org Lookup</p>
              <p className="text-[10px] text-gray-500">Resolve IP & organisation for each host</p>
            </div>
            <button onClick={() => setEnableIpLookup(!enableIpLookup)} disabled={scanning}
              className={`relative w-10 h-5 rounded-full transition-all disabled:opacity-40 ${enableIpLookup ? 'bg-purple-500' : 'bg-gray-600'}`}>
              <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all ${enableIpLookup ? 'left-5' : 'left-0.5'}`} />
            </button>
          </div>
          <div className="bg-gray-800/40 rounded-xl px-4 py-3 border border-gray-700/40 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-white">Full Headers</p>
              <p className="text-[10px] text-gray-500">Show all response headers for each host</p>
            </div>
            <button onClick={() => setEnableFullHeaders(!enableFullHeaders)} disabled={scanning}
              className={`relative w-10 h-5 rounded-full transition-all disabled:opacity-40 ${enableFullHeaders ? 'bg-purple-500' : 'bg-gray-600'}`}>
              <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all ${enableFullHeaders ? 'left-5' : 'left-0.5'}`} />
            </button>
          </div>
        </div>

        {/* Target Hosts Input */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
              Target Hosts <span className="text-purple-400 normal-case font-normal">{hosts.length} hosts</span>
            </h3>
            <div className="flex items-center gap-2">
              <button onClick={cleanAndFormat} disabled={scanning}
                className="flex items-center gap-1 text-xs bg-cyan-600/20 hover:bg-cyan-600/40 text-cyan-300 border border-cyan-500/30 px-2.5 py-1 rounded-lg transition-all disabled:opacity-40">
                ✨ Clean
              </button>
              <button onClick={() => fileInputRef.current?.click()} disabled={scanning}
                className="flex items-center gap-1 text-xs bg-gray-700/60 hover:bg-gray-600/60 text-gray-300 px-2.5 py-1 rounded-lg transition-all disabled:opacity-40">
                <Upload className="w-3 h-3" /> Upload Files
              </button>
              <button onClick={() => updateHosts('')} disabled={scanning}
                className="text-xs bg-gray-700/60 hover:bg-red-900/40 text-gray-400 hover:text-red-400 p-1.5 rounded-lg transition-all disabled:opacity-40">
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          </div>

          {/* Smart Filter Bar */}
          <div className="flex items-center gap-2 bg-gray-800/40 border border-gray-700/40 rounded-xl px-3 py-2 mb-2 flex-wrap">
            <span className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider mr-1">Smart Filter</span>
            {[
              { label: 'Keep Ports', value: keepPorts, set: setKeepPorts },
              { label: 'Keep Paths', value: keepPaths, set: setKeepPaths },
              { label: 'Auto-Clean', value: autoClean, set: setAutoClean },
            ].map(({ label, value, set }) => (
              <button
                key={label}
                onClick={() => set(v => !v)}
                disabled={scanning}
                className={`flex items-center gap-1.5 px-2 py-1 rounded-lg text-[10px] font-semibold transition-all border disabled:opacity-40 ${
                  value
                    ? 'bg-purple-500/15 text-purple-300 border-purple-500/30'
                    : 'bg-gray-700/40 text-gray-500 border-gray-600/30'
                }`}
              >
                <div className={`w-5 h-2.5 rounded-full relative transition-all ${value ? 'bg-purple-500' : 'bg-gray-600'}`}>
                  <div className={`absolute top-0.5 w-1.5 h-1.5 bg-white rounded-full shadow transition-all ${value ? 'left-3' : 'left-0.5'}`} />
                </div>
                {label}
              </button>
            ))}
          </div>

          <input ref={fileInputRef} type="file" accept=".txt,.json,.csv" multiple className="hidden" onChange={handleFileUpload} />
          <textarea value={hostsText} onChange={e => updateHosts(e.target.value)} disabled={scanning} rows={6}
            placeholder={PLACEHOLDER}
            className="w-full bg-gray-900/70 border border-gray-700/50 rounded-xl px-4 py-3 text-sm text-gray-200 font-mono resize-none focus:outline-none focus:border-purple-500/50 disabled:opacity-50" />
          <p className="text-xs text-gray-600 mt-1">One host per line. Lines starting with # are ignored.</p>
        </div>

        {/* Detect Button */}
        <div>
          {!scanning ? (
            <button onClick={startScan} disabled={!hosts.length}
              className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 disabled:opacity-40 text-white font-semibold py-3 rounded-xl transition-all">
              🚀 Detect Infrastructure
            </button>
          ) : (
            <button onClick={stopScan}
              className="w-full flex items-center justify-center gap-2 bg-red-600/80 hover:bg-red-600 text-white font-semibold py-3 rounded-xl transition-all">
              <Square className="w-4 h-4" /> Stop Scan
            </button>
          )}
        </div>

        {/* Progress */}
        <AnimatePresence>
          {scanning && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="bg-gray-800/60 rounded-xl px-4 py-3 border border-gray-700/50">
                <div className="flex items-center gap-2 mb-2">
                  <Loader className="w-4 h-4 text-purple-400 animate-spin" />
                  <span className="text-sm text-purple-300">Detecting... {progress.done}/{progress.total}</span>
                </div>
                <div className="w-full bg-gray-700/50 rounded-full h-1.5">
                  <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-1.5 rounded-full transition-all duration-300"
                    style={{ width: `${progress.total > 0 ? (progress.done / progress.total) * 100 : 0}%` }} />
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>



        {/* Stats + Results */}
        {results.length > 0 && (
          <>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-gray-800/40 rounded-xl p-3 border border-gray-700/40 text-center">
                <p className="text-xl font-bold text-white">{results.length}</p>
                <p className="text-xs text-gray-500">Processed</p>
              </div>
              <div className="bg-green-500/10 rounded-xl p-3 border border-green-500/20 text-center">
                <p className="text-xl font-bold text-green-400">{results.filter(r => r.success).length}</p>
                <p className="text-xs text-gray-500">Detected</p>
              </div>
            </div>
            {!scanning && (
              <button onClick={downloadResults}
                className="w-full flex items-center justify-center gap-2 bg-gray-700/60 hover:bg-gray-600/60 text-gray-200 text-sm font-medium py-2.5 rounded-xl transition-all border border-gray-600/40">
                <Download className="w-4 h-4" /> Download Results (.txt)
              </button>
            )}
            <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Results</h3>
            <div className="space-y-3">
              {results.map((r, i) => <ResultCard key={i} r={r} index={i} showHeaders={enableFullHeaders} showIp={enableIpLookup} />)}
            </div>
          </>
        )}
      </div>
    </div>
  );
}