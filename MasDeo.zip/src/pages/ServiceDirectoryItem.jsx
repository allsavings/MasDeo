import React from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, ExternalLink, CheckCircle, Smartphone, Wifi, Gift, ShieldCheck, Bot, GraduationCap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { serviceSections } from '../components/serviceDirectoryData';

const iconMap = { Smartphone, Wifi, Gift, ShieldCheck, Bot, GraduationCap };

export default function ServiceDirectoryItem() {
  const navigate = useNavigate();
  const params = new URLSearchParams(window.location.search);
  const sectionKey = params.get('section');
  const itemIndex = parseInt(params.get('item') || '0', 10);

  const section = serviceSections[sectionKey];
  if (!section) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] text-white flex items-center justify-center">
        <p className="text-gray-400">Item not found.</p>
      </div>
    );
  }

  const item = section.items[itemIndex];
  const Icon = iconMap[section.iconName];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      {/* Header */}
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center gap-4 mb-2">
          <button
            onClick={() => navigate(-1)}
            className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <p className="text-xs text-gray-500">{section.title}</p>
            <h1 className="text-xl font-bold">{item.name}</h1>
          </div>
        </div>
      </div>

      {/* Hero Card */}
      <div className="px-6 mb-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className={`rounded-2xl p-5 border ${section.borderColor} ${section.bgColor} flex items-center gap-4`}
        >
          <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${section.colorClass} flex items-center justify-center flex-shrink-0`}>
            <Icon className="w-7 h-7 text-white" />
          </div>
          <div>
            <h2 className="font-bold text-white text-lg">{item.name}</h2>
            <p className="text-sm text-gray-400">{section.description}</p>
          </div>
        </motion.div>
      </div>

      {/* Facts */}
      <div className="px-6 space-y-3 mb-6">
        <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Key Facts</h3>
        {item.facts.map((fact, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, x: -16 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.07 }}
            className={`flex items-start gap-3 p-4 rounded-xl border ${section.borderColor} bg-gray-800/30`}
          >
            <CheckCircle className={`w-4 h-4 flex-shrink-0 mt-0.5 text-green-400`} />
            <p className="text-sm text-gray-200 leading-relaxed">{fact}</p>
          </motion.div>
        ))}
      </div>

      {/* Visit Button */}
      {item.link && (
        <div className="px-6">
          <motion.a
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            href={item.link}
            target="_blank"
            rel="noopener noreferrer"
            className={`flex items-center justify-center gap-2 w-full py-4 rounded-2xl bg-gradient-to-r ${section.colorClass} text-white font-semibold text-sm hover:opacity-90 transition-opacity`}
          >
            <ExternalLink className="w-4 h-4" />
            Visit {item.name}
          </motion.a>
        </div>
      )}
    </div>
  );
}