import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { LogOut, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { useNavigate } from 'react-router-dom';

export default function LogoutConfirm() {
  const navigate = useNavigate();
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    base44.auth.isAuthenticated().then(authed => {
      setIsAuthenticated(authed);
      if (!authed) {
        base44.auth.redirectToLogin(createPageUrl('Home'));
      }
    });
  }, []);

  const handleLogout = async () => {
    localStorage.removeItem('app_pin');
    localStorage.removeItem('pending_signup');
    localStorage.removeItem('creator_mode_active');
    localStorage.clear();
    sessionStorage.clear();
    await base44.auth.logout();
    // Redirect to custom auth page instead of default /login
    window.location.href = '/auth';
  };

  const handleCancel = () => {
    navigate(createPageUrl('Home'));
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] flex items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md"
      >
        <div className="bg-gray-800/40 rounded-3xl p-8 border border-gray-700/50 text-center">
          <div className="w-20 h-20 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <LogOut className="w-10 h-10 text-red-400" />
          </div>
          
          <h1 className="text-2xl font-bold text-white mb-3">Logout Confirmation</h1>
          <p className="text-gray-400 text-sm mb-8">
            Are you sure you want to logout from your account?
          </p>

          <div className="space-y-3">
            <button
              onClick={handleLogout}
              className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-4 rounded-2xl transition-all active:scale-[0.98]"
            >
              Yes, Logout
            </button>
            
            <button
              onClick={handleCancel}
              className="w-full bg-gray-700/50 hover:bg-gray-700 text-white font-semibold py-4 rounded-2xl transition-all active:scale-[0.98] flex items-center justify-center gap-2"
            >
              <X className="w-4 h-4" />
              Cancel
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}