import React from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, ChevronRight, Smartphone, Wifi, Gift, ShieldCheck, Bot, GraduationCap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { serviceSections } from '../components/serviceDirectoryData';

const iconMap = { Smartphone, Wifi, Gift, ShieldCheck, Bot, GraduationCap };

export default function ServiceDirectory() {
  const navigate = useNavigate();
  const params = new URLSearchParams(window.location.search);
  const sectionKey = params.get('section');
  const section = serviceSections[sectionKey];

  if (!section) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] text-white flex items-center justify-center">
        <p className="text-gray-400">Section not found.</p>
      </div>
    );
  }

  const Icon = iconMap[section.iconName];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      {/* Header */}
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center gap-4 mb-4">
          <button
            onClick={() => navigate(-1)}
            className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-bold">{section.title}</h1>
        </div>
      </div>

      {/* Hero */}
      <div className="px-6 mb-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className={`rounded-2xl p-5 border ${section.borderColor} ${section.bgColor}`}
          >
          <div className="flex items-center gap-3">
          <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${section.colorClass} flex items-center justify-center flex-shrink-0`}>
              <Icon className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-white">{section.title}</h2>
              <p className="text-sm text-gray-400">{section.description}</p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Items */}
      <div className="px-6 space-y-3">
        {section.items.map((item, idx) => (
          <motion.button
            key={idx}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.06 }}
            onClick={() => navigate(createPageUrl('ServiceDirectoryItem') + `?section=${sectionKey}&item=${idx}`)}
            className={`w-full flex items-center gap-3 p-4 rounded-2xl border ${section.borderColor} bg-gray-800/40 hover:bg-gray-800/60 transition-colors`}
          >
            <span className={`text-xs font-bold w-8 h-8 rounded-full bg-gradient-to-br ${section.colorClass} flex items-center justify-center flex-shrink-0 text-white`}>
              {idx + 1}
            </span>
            <span className="flex-1 text-left font-semibold text-white">{item.name}</span>
            <ChevronRight className="w-4 h-4 text-gray-400 flex-shrink-0" />
          </motion.button>
        ))}
      </div>
    </div>
  );
}