import React, { useState, useRef, useEffect } from 'react';
import GodCommandCard from '../components/sni/GodCommandCard';
import SceneDirector from '../components/sni/SceneDirector';
import ScriptsTab from '../components/sni/ScriptsTab';
import TermuxGuideTab from '../components/sni/TermuxGuideTab';
import PullToRefresh from '../components/PullToRefresh';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft, Wifi, Play, Square, Download, Upload,
  CheckCircle, XCircle, AlertCircle, Loader, Trash2,
  Terminal, Copy, Check, Code, Zap, ChevronDown
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

// ─── CARRIER DATA ─────────────────────────────────────────────────────────────
const CARRIER_PROBES = {
  vodacom:    ["enrichment.vodacom.co.za","www.vodacom.co.za","connectu.vodacom.co.za"],
  mtn:        ["nofunds.mtn.co.za","mtn.co.za"],
  telkom:     ["oob.telkom.co.za","telkom.co.za"],
  cellc:      ["nofunds.cellc.mobi","cellc.co.za"],
  rain:       ["device.rain.co.za","portal.rain.co.za","buy.rain.co.za","static.rain.co.za"],
  knect:      ["knectmobile.co.za"],
  melon:      ["melonmobile.co.za"],
  capitec:    ["capitecconnect.co.za"],
  afrihost:   ["mobile.afrihost.com"],
  mweb:       ["mobile.mweb.co.za"],
  mvno:       ["mvno.co.za"],
  coolmobile: ["coolmobile.co.za"],
  boxing:     ["boxingmobile.co.za"],
  cbs:        ["cbsmobile.co.za"],
  yo:         ["yomobile.co.za"],
};

const CAPTIVE_PATTERNS = {
  vodacom: ["connectu.vodacom.co.za"],
  mtn:     ["nofunds.mtn.co.za"],
  telkom:  ["oob.telkom.co.za"],
  cellc:   ["nofunds.cellc.mobi"],
  rain:    ["rain.co.za","cloud.rain","10.64.","portal.rain","device.rain"],
  knect:   ["knectmobile"],
  melon:   ["melonmobile"],
  capitec: ["capitecconnect"],
  afrihost:["afrihost"],
  mweb:    ["mweb"],
};

const CARRIER_LABELS = {
  vodacom:"Vodacom",mtn:"MTN",telkom:"Telkom",cellc:"Cell C",
  knect:"Knect",rain:"Rain",melon:"Melon Mobile",capitec:"Capitec Connect",
  mvno:"MVNO",afrihost:"Afrihost Mobile",coolmobile:"Cool Mobile",
  mweb:"MWEB Mobile",boxing:"Boxing Mobile",cbs:"CBS Mobile",
  yo:"Yo Mobile",unknown:"Unknown"
};

// ─── BROWSER PROBE ENGINE ─────────────────────────────────────────────────────
async function checkBalance(timeoutMs = 6000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    await fetch('https://www.google.com/', { signal: ctrl.signal, mode: 'no-cors', cache: 'no-store' });
    clearTimeout(t); return true;
  } catch { clearTimeout(t); return false; }
}

async function probeHost(host, timeoutMs = 6000, maxRetries = 0) {
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      await fetch(`https://${host}/`, { signal: ctrl.signal, mode: 'no-cors', cache: 'no-store' });
      clearTimeout(t); return { reachable: true };
    } catch (err) {
      clearTimeout(t);
      if (err.name === 'AbortError') { if (attempt < maxRetries) { await new Promise(r => setTimeout(r, 500)); continue; } break; }
    }
    const ctrl2 = new AbortController();
    const t2 = setTimeout(() => ctrl2.abort(), timeoutMs);
    try {
      await fetch(`http://${host}/`, { signal: ctrl2.signal, mode: 'no-cors', cache: 'no-store' });
      clearTimeout(t2); return { reachable: true };
    } catch { clearTimeout(t2); if (attempt < maxRetries) { await new Promise(r => setTimeout(r, 500)); continue; } }
    break;
  }
  return { reachable: false };
}

async function browserSniper(host, timeoutMs = 6000) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (v) => { if (!done) { done = true; resolve(v); } };
    const timer = setTimeout(() => finish(false), timeoutMs);
    try {
      const ws = new WebSocket(`wss://${host}/`);
      ws.onopen = () => { clearTimeout(timer); ws.close(); finish(true); };
      ws.onclose = (e) => { clearTimeout(timer); finish(e.code !== 1006 && e.code !== 0); };
      ws.onerror = () => {};
    } catch { clearTimeout(timer); finish(false); }
  });
}

// ─── TERMUX POPUP COMPONENTS ──────────────────────────────────────────────────
function TermuxNotDetectedPopup({ onClose }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-end justify-center px-4 pb-8 bg-black/70 backdrop-blur-sm"
      onClick={onClose}>
      <motion.div initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 60, opacity: 0 }}
        transition={{ type: 'spring', stiffness: 300, damping: 28 }}
        className="w-full max-w-sm bg-[#13131f] border border-green-500/30 rounded-3xl p-6 shadow-2xl"
        onClick={e => e.stopPropagation()}>
        <div className="flex justify-center mb-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-green-500/30 to-emerald-600/30 border border-green-500/40 flex items-center justify-center">
            <Terminal className="w-8 h-8 text-green-400" />
          </div>
        </div>
        <h2 className="text-lg font-bold text-white text-center mb-1">Termux Not Detected</h2>
        <p className="text-sm text-gray-400 text-center mb-5">Install Termux for <span className="text-green-400 font-semibold">100% accuracy</span> scanning.</p>
        <div className="bg-green-500/10 border border-green-500/20 rounded-2xl px-4 py-3 mb-5 space-y-1.5">
          {[['⚡','150 concurrent connections vs browser\'s 10'],['🔬','True HTTP/HTTPS dual-probe — no CORS limits'],['📁','Saves results directly to phone storage']].map((f,i) => (
            <div key={i} className="flex items-center gap-2 text-xs text-gray-300"><span>{f[0]}</span><span>{f[1]}</span></div>
          ))}
        </div>
        <a href="https://f-droid.org/en/packages/com.termux/" target="_blank" rel="noopener noreferrer"
          className="flex items-center justify-center gap-2 w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white font-semibold py-3 rounded-2xl transition-all mb-3">
          <Terminal className="w-4 h-4" /> Install Termux from F-Droid
        </a>
        <button onClick={onClose} className="w-full text-gray-500 hover:text-gray-300 text-sm font-medium py-2 transition-all">
          Continue with browser scan instead
        </button>
      </motion.div>
    </motion.div>
  );
}

function TermuxLaunchedPopup({ onClose }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-end justify-center px-4 pb-8 bg-black/70 backdrop-blur-sm"
      onClick={onClose}>
      <motion.div initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 60, opacity: 0 }}
        transition={{ type: 'spring', stiffness: 300, damping: 28 }}
        className="w-full max-w-sm bg-[#13131f] border border-cyan-500/30 rounded-3xl p-6 shadow-2xl"
        onClick={e => e.stopPropagation()}>
        <div className="flex justify-center mb-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500/30 to-blue-600/30 border border-cyan-500/40 flex items-center justify-center">
            <Zap className="w-8 h-8 text-cyan-400" />
          </div>
        </div>
        <h2 className="text-lg font-bold text-white text-center mb-1">Hosts Copied & Termux Launching</h2>
        <p className="text-sm text-gray-400 text-center mb-5">Switch to Termux and paste when prompted.</p>
        <div className="bg-gray-900/60 border border-gray-700/50 rounded-2xl px-4 py-3 mb-5">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">In Termux, run:</p>
          <code className="text-xs text-green-300 font-mono block">python3 M@☆_zero_rated_scan.py</code>
        </div>
        <button onClick={onClose}
          className="flex items-center justify-center gap-2 w-full bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-semibold py-3 rounded-2xl transition-all">
          <Check className="w-4 h-4" /> Got it!
        </button>
      </motion.div>
    </motion.div>
  );
}

// ─── MAIN PAGE ─────────────────────────────────────────────────────────────────
export default function ZeroRatedScan() {
  const [tab, setTab] = useState('scan');
  const SHARED_HOSTS_KEY = 'shared_target_hosts';
  const [hostsText, setHostsText] = useState(() => localStorage.getItem(SHARED_HOSTS_KEY) || '');
  const [scanning, setScanning] = useState(false);

  // Persist hosts to localStorage on change
  useEffect(() => {
    localStorage.setItem(SHARED_HOSTS_KEY, hostsText);
  }, [hostsText]);
  const [results, setResults] = useState([]);
  const [carrier, setCarrier] = useState(null);
  const [stage, setStage] = useState('idle');
  const [progress, setProgress] = useState(0);
  const [total, setTotal] = useState(0);
  const [balanceError, setBalanceError] = useState(false);
  const [keepPorts, setKeepPorts] = useState(false);
  const [keepPaths, setKeepPaths] = useState(false);
  const [showTermuxNotFound, setShowTermuxNotFound] = useState(false);
  const [showTermuxLaunched, setShowTermuxLaunched] = useState(false);
  const [scanMode, setScanMode] = useState('1');
  const [scanTimeout, setScanTimeout] = useState(5);
  const [scanRetries, setScanRetries] = useState(0);
  const [scanThreads, setScanThreads] = useState(100);
  const [scanBatchSize, setScanBatchSize] = useState(50);
  const [scanRecovery, setScanRecovery] = useState(1);
  const [systemMsg, setSystemMsg] = useState('');
  const [currentScene, setCurrentScene] = useState('idle');
  const [sceneError, setSceneError] = useState('');
  const [telemetry, setTelemetry] = useState('');
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [termuxId, setTermuxId] = useState(null);
  const [engineStatus, setEngineStatus] = useState('offline');
  const [isHostsOpen, setIsHostsOpen] = useState(false);
  const [liveStats, setLiveStats] = useState({ batch_prog: '0', batch_size: '0', scanned: '0', total: '0', zero: '0', bugs: '0', elapsed: '00s', eta: '00s', pshd: '0' });
  const [sysInfo, setSysInfo] = useState({ user: 'UNKNOWN', hw_id: 'UNKNOWN', license: 'UNKNOWN' });
  const [rawLogs, setRawLogs] = useState([]);
  const stopRef = useRef(false);
  const fileInputRef = useRef(null);
  const wsRef = useRef(null);

  // ── WebSocket Bridge ──────────────────────────────────────────────────────
  const connectToEngine = () => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) return;
    setEngineStatus('connecting');
    try {
      const ws = new WebSocket('ws://127.0.0.1:8765');
      ws.onopen = () => setEngineStatus('connected');
      ws.onclose = () => {
        setEngineStatus('offline'); wsRef.current = null;
        setCurrentScene('idle'); setIsSynthesizing(false);
      };
      ws.onerror = () => { setEngineStatus('offline'); setIsSynthesizing(false); };
      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.type === 'sys_info') {
            if (msg.termux_id) setTermuxId(msg.termux_id);
            if (msg.key && msg.val !== undefined) {
              setSysInfo(prev => ({ ...prev, [msg.key]: msg.val }));
            } else {
              setSysInfo({
                user: msg.user || 'UNKNOWN',
                hw_id: msg.hw_id || 'UNKNOWN',
                license: msg.license || 'UNKNOWN'
              });
            }
            return;
          }
          if (msg.type === 'raw_feed') {
            setRawLogs(prev => [...prev, msg.text || '']);
            return;
          }
          if (msg.type === 'scene') {
            setCurrentScene(msg.name);
            setSceneError(msg.error || '');
            setIsSynthesizing(false);
            return;
          }
          if (msg.type === 'telemetry') {
            const txt = msg.text || '';
            setTelemetry(txt);
            if (txt.includes('COMPLETED')) {
              if (navigator.vibrate) navigator.vibrate([1000, 500, 1000]);
              if (window.Notification && Notification.permission === 'granted') {
                new Notification('M@☆ SYSTEM', { body: 'Scan Complete. Master Tier results generated.' });
              }
            }
            return;
          }
          if (msg.type === 'live_time') {
            setLiveStats(prev => ({ ...prev, elapsed: msg.elapsed || prev.elapsed, eta: msg.eta || prev.eta, pshd: msg.pshd || prev.pshd }));
            return;
          }
          if (msg.type === 'live_counts') {
            setLiveStats(prev => ({ ...prev, batch_prog: msg.batch_prog || prev.batch_prog, batch_size: msg.batch_size || prev.batch_size, scanned: msg.scanned || prev.scanned, total: msg.total || prev.total, zero: msg.zero || prev.zero, bugs: msg.bugs || prev.bugs }));
            return;
          }
          if (msg.type === 'scan_result') {
            const rawStatus = (msg.status || '').toUpperCase();
            let status = 'blocked';
            if (rawStatus.includes('ZERO') || rawStatus.includes('FREE')) status = 'zero-rated';
            else if (rawStatus.includes('HIDDEN') || rawStatus.includes('BUG')) status = 'hidden-bug';
            else if (rawStatus.includes('BILL')) status = 'billed';
            const host = msg.host || msg.details || '';
            setResults(prev => [...prev, { host, status, details: msg.details }]);
            setProgress(prev => prev + 1);
            return;
          }
          if (msg.type === 'system_msg') {
            setSystemMsg(msg.text || '');
            if ((msg.text || '').includes('COMPLETED') || (msg.text || '').includes('DONE')) {
              setScanning(false); setStage('done');
            }
            return;
          }
          if (msg.action === 'scan_complete') {
            setScanning(false); setStage('done'); setCurrentScene('idle');
          }
        } catch {}
      };
      wsRef.current = ws;
    } catch { setEngineStatus('offline'); }
  };

  useEffect(() => {
    connectToEngine();
    return () => { wsRef.current?.close(); };
  }, []);

  const hosts = hostsText.split('\n').map(h => h.trim()).filter(h => h && !h.startsWith('#'));

  const updateHosts = (val) => { setHostsText(val); localStorage.setItem(SHARED_HOSTS_KEY, val); };

  const cleanAndFormat = () => {
    const lines = hostsText.split('\n').map(l => l.trim()).filter(l => l && !l.startsWith('#'));
    let items = [];
    for (const line of lines) { items.push(...line.split(/[,\s]+/).map(p => p.trim()).filter(Boolean)); }
    items = items.map(item => {
      item = item.replace(/^.*?:\/\//, '');
      if (!keepPorts) item = item.replace(/:\d+.*$/, '');
      if (!keepPaths) item = item.replace(/\/.*$/, '');
      return item.replace(/[?#].*$/, '').trim();
    });
    const hostPattern = /^([\w][\w\-]*\.)+[\w\-]+(:\d+)?(\/[\w\-./?%&=]*)?$|^\d{1,3}(\.\d{1,3}){3}(:\d+)?(\/.*)?$/;
    items = [...new Set(items.filter(item => item && hostPattern.test(item)))];
    updateHosts(items.join('\n'));
  };

  const parseFileToHosts = (content, filename) => {
    const ext = filename.split('.').pop().toLowerCase();
    if (ext === 'json') {
      try {
        const parsed = JSON.parse(content);
        const arr = Array.isArray(parsed) ? parsed : Object.values(parsed).flat();
        return arr.map(v => (typeof v === 'string' ? v : (v?.host || v?.domain || v?.url || ''))).filter(Boolean).join('\n');
      } catch { return content; }
    }
    if (ext === 'csv') {
      return content.split('\n').map(line => line.split(',')[0].replace(/["']/g, '').trim()).filter(Boolean).join('\n');
    }
    return content;
  };

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    const allHosts = [];
    for (const file of files) { allHosts.push(parseFileToHosts(await file.text(), file.name)); }
    updateHosts(hostsText ? hostsText + '\n' + allHosts.join('\n') : allHosts.join('\n'));
    e.target.value = '';
  };

  const startScan = async () => {
    if (!hosts.length) return;
    if (engineStatus === 'connected' && wsRef.current?.readyState === WebSocket.OPEN) {
      setResults([]); setProgress(0); setTotal(hosts.length);
      setSystemMsg(''); setScanning(true); setStage('scanning');
      wsRef.current.send(JSON.stringify({
        action: 'start_scan', hosts,
        mode: Number(scanMode), threads: scanThreads,
        timeout: scanTimeout, batch: scanBatchSize,
        retries: scanRetries, recovery: scanRecovery,
      }));
      return;
    }
    stopRef.current = false; setResults([]); setCarrier(null);
    setProgress(0); setTotal(hosts.length); setBalanceError(false); setScanning(true);
    const tMs = scanTimeout * 1000;
    const retries = scanRetries;
    const batch = Math.max(1, Math.min(scanBatchSize, 200));

    if (scanMode === '1' || scanMode === '3') {
      setStage('checking');
      const hasData = await checkBalance(tMs);
      if (stopRef.current) { setScanning(false); setStage('idle'); return; }
      if (hasData) { setBalanceError(true); setStage('done'); setScanning(false); return; }
    }
    setStage('detecting');
    let det = 'unknown';
    if (!stopRef.current) {
      outer: for (const [name, pHosts] of Object.entries(CARRIER_PROBES)) {
        for (const h of pHosts) {
          if (stopRef.current) break outer;
          const p = await probeHost(h, tMs, 0);
          if (p.reachable) { det = name; break outer; }
        }
      }
    }
    setCarrier(det);
    if (stopRef.current) { setScanning(false); setStage('idle'); return; }
    setStage('scanning');
    for (let i = 0; i < hosts.length; i += batch) {
      if (stopRef.current) break;
      const slice = hosts.slice(i, i + batch);
      const batchRes = await Promise.all(slice.map(async (host) => {
        const p = await probeHost(host, tMs, retries);
        let status = p.reachable ? 'zero-rated' : 'blocked';
        if (status === 'blocked') { const sniped = await browserSniper(host, tMs); if (sniped) status = 'hidden-bug'; }
        return { host, status };
      }));
      setResults(prev => [...prev, ...batchRes]);
      setProgress(Math.min(i + batch, hosts.length));
    }
    setStage('done'); setScanning(false);
  };

  const stopScan = () => { stopRef.current = true; setScanning(false); setStage('done'); };

  const launchTermuxMode = async () => {
    if (!hosts.length) return;
    try { await navigator.clipboard.writeText(hosts.join('\n')); } catch {}
    window.location.href = 'termux://open?command=python3%20M%40%E2%98%86_zero_rated_scan.py';
    await new Promise(r => setTimeout(r, 1500));
    if (document.hidden || !document.hasFocus()) { setShowTermuxLaunched(true); }
    else { setShowTermuxNotFound(true); }
  };

  const downloadResults = (type = 'all') => {
    const ts = new Date().toISOString().slice(0,19).replace('T','_').replace(/:/g,'-');
    const cn = CARRIER_LABELS[carrier] || 'unknown';
    const filtered = type === 'zero' ? results.filter(r => r.status === 'zero-rated' || r.status === 'hidden-bug') : results;
    const labelMap = { 'zero-rated': '✅', 'hidden-bug': '🔥', 'billed': '🚫', 'blocked': '❌' };
    const lines = [
      `# @MastersTechSolutions M@☆ Zero-Rated Scanner V11.3`,
      `# Carrier: ${cn}  |  Date: ${new Date().toLocaleString()}`,
      `# Total: ${results.length}  |  Zero-rated: ${zeroRated.length}  |  Bugs: ${hiddenBugs.length}  |  Blocked: ${blocked.length}`,
      '', ...filtered.map(r => `${labelMap[r.status] || '?'} ${r.host}`)
    ];
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([lines.join('\n')], { type: 'text/plain' }));
    a.download = `zero_rated_${type}_${cn}_${ts}.txt`; a.click();
  };

  const zeroRated = results.filter(r => r.status === 'zero-rated');
  const hiddenBugs = results.filter(r => r.status === 'hidden-bug');
  const billed = results.filter(r => r.status === 'billed');
  const blocked = results.filter(r => r.status === 'blocked');
  const stageLabel = {
    idle:'', checking:'Verifying SIM balance...', detecting:'Detecting carrier...',
    scanning: systemMsg || `Scanning... ${progress}/${total}`,
    done: systemMsg || 'Scan complete ✓'
  };

  const tabs = [
    { id: 'scan', label: 'Scanner', icon: Wifi },
    { id: 'scripts', label: 'Scripts', icon: Code },
    { id: 'termux', label: 'Termux Guide', icon: Terminal },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      <AnimatePresence>
        {showTermuxNotFound && <TermuxNotDetectedPopup onClose={() => setShowTermuxNotFound(false)} />}
        {showTermuxLaunched && <TermuxLaunchedPopup onClose={() => setShowTermuxLaunched(false)} />}
      </AnimatePresence>

      {/* Header */}
      <div className="px-4 pt-6 pb-3">
        <div className="flex items-center gap-3">
          <Link to={createPageUrl("HostScanner")} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-lg font-bold leading-tight">Datafree Website Scanner</h1>
            <p className="text-xs text-cyan-400">Identify zero-rated & data-free sites on your network</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="px-4 mb-4">
        <div className="flex gap-2 bg-gray-800/50 rounded-xl p-1 border border-gray-700/40">
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all ${
                tab === t.id ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white' : 'text-gray-500 hover:text-gray-300'
              }`}>
              <t.icon className="w-3.5 h-3.5" />
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* ── TAB: SCANNER ── */}
      {tab === 'scan' && (
        <div className="px-4">

          {/* ══ SOVEREIGN ENGINE PANEL ══ */}
          <div className="mb-4">

            {/* Glowing MASTERS Logo */}
            <div className="text-center mb-3 pt-1">
              <h2
                className="text-2xl font-black tracking-[0.25em] text-cyan-400 uppercase select-none"
                style={{ fontFamily: 'monospace', filter: 'drop-shadow(0 0 10px rgba(6,182,212,0.8))' }}
              >
                M@☆ MASTERS
              </h2>
              <p className="text-[10px] text-cyan-500/60 tracking-[0.4em] uppercase font-mono mt-0.5">DeoVex Sovereign Engine</p>
            </div>

            {/* TK Master Authorization Banner */}
            <AnimatePresence>
              {termuxId && (
                <motion.div
                  initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                  className="rounded-2xl px-4 py-3 mb-3 border border-blue-500/40 backdrop-blur-md"
                  style={{ background: 'rgba(15,20,40,0.85)', boxShadow: '0 0 24px rgba(59,130,246,0.15), inset 0 1px 0 rgba(255,255,255,0.05)' }}
                >
                  <p className="text-[9px] font-black text-blue-400/80 uppercase tracking-[0.35em] mb-1">TK Master Authorization</p>
                  <div className="flex items-center justify-between gap-3 flex-wrap">
                    <p className="text-xs font-mono text-white">
                      Termux ID: <span className="text-cyan-300 font-bold">{termuxId}</span>
                    </p>
                    <a
                      href="https://mspy.qzz.io/tkmasterinfo"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[11px] text-blue-400 underline underline-offset-2 hover:text-blue-300 transition-colors font-semibold"
                      style={{ filter: 'drop-shadow(0 0 6px rgba(96,165,250,0.6))' }}
                    >
                      Get Verification Key
                    </a>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Engine Status Card */}
            <div className={`rounded-2xl p-4 border backdrop-blur-sm ${
              engineStatus === 'connected' ? 'bg-green-500/8 border-green-500/30' : 'bg-gray-900/60 border-gray-700/40'
            }`}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                      engineStatus === 'connected' ? 'bg-green-500/20' : engineStatus === 'connecting' ? 'bg-amber-500/20' : 'bg-gray-700/50'
                    }`}>
                      <Terminal className={`w-4 h-4 ${engineStatus === 'connected' ? 'text-green-400' : engineStatus === 'connecting' ? 'text-amber-400' : 'text-gray-500'}`} />
                    </div>
                    {engineStatus === 'connected' && <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-green-400 rounded-full animate-pulse" />}
                    {engineStatus === 'connecting' && <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-amber-400 rounded-full animate-pulse" />}
                  </div>
                  <div>
                    <p className={`text-xs font-bold ${engineStatus === 'connected' ? 'text-green-300' : engineStatus === 'connecting' ? 'text-amber-300' : 'text-gray-400'}`}>
                      {engineStatus === 'connected' ? '🟢 Termux Engine Online' : engineStatus === 'connecting' ? '🟡 Connecting...' : '🔴 Engine Offline'}
                    </p>
                    <p className="text-[10px] text-gray-600 font-mono">ws://127.0.0.1:8765</p>
                  </div>
                </div>
                {engineStatus !== 'connected' && (
                  <button onClick={connectToEngine}
                    className="text-[10px] font-bold bg-gray-700/60 hover:bg-gray-600/60 text-gray-300 border border-gray-600/40 px-2.5 py-1.5 rounded-lg transition-all">
                    Retry
                  </button>
                )}
              </div>

              {/* Install command — offline only */}
              {engineStatus !== 'connected' && (
                <div className="bg-gray-950/80 border border-gray-700/40 rounded-xl overflow-hidden mb-3">
                  <div className="flex items-center justify-between px-3 py-1.5 border-b border-gray-800/60 bg-gray-900/50">
                    <span className="text-[9px] text-gray-600 font-mono">bash — Termux</span>
                    <button onClick={() => navigator.clipboard.writeText('curl -sL https://mspy.qzz.io/deovexbridge | bash')}
                      className="text-[9px] text-gray-500 hover:text-gray-300 px-2 py-0.5 rounded transition-all">Copy</button>
                  </div>
                  <p className="px-3 py-2 text-[11px] text-green-300 font-mono break-all">
                    curl -sL https://mspy.qzz.io/deovexbridge | bash
                  </p>
                </div>
              )}

              {/* Initialize — offline only */}
              {engineStatus !== 'connected' && (
                <a href="intent://com.termux#Intent;scheme=termux;package=com.termux;end"
                  className="flex items-center justify-center gap-2 w-full bg-gradient-to-r from-green-700/60 to-emerald-700/60 hover:from-green-600/70 hover:to-emerald-600/70 border border-green-500/30 text-green-300 font-bold py-2.5 rounded-xl transition-all text-xs">
                  <Terminal className="w-4 h-4" /> Initialize Termux@DeoVex
                </a>
              )}

              {/* Launch Matrix — connected only, anti-collision */}
              {engineStatus === 'connected' && (
                <motion.button
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  disabled={isSynthesizing}
                  onClick={() => {
                    if (isSynthesizing) return;
                    setIsSynthesizing(true);
                    setResults([]); setCurrentScene('idle'); setTelemetry(''); setSceneError('');
                    if (wsRef.current?.readyState === WebSocket.OPEN) {
                      wsRef.current.send(JSON.stringify({ action: 'launch_engine' }));
                    }
                  }}
                  className="w-full py-3 rounded-xl font-bold text-sm text-white transition-all disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  style={{
                    background: isSynthesizing
                      ? 'linear-gradient(135deg, #374151, #4b5563)'
                      : 'linear-gradient(135deg, #06b6d4, #3b82f6, #8b5cf6)',
                    boxShadow: isSynthesizing ? 'none' : '0 0 20px rgba(6,182,212,0.25)',
                  }}
                >
                  {isSynthesizing
                    ? <><Loader className="w-4 h-4 animate-spin" /> SYNTHESIZING...</>
                    : '🚀 Launch Matrix'
                  }
                </motion.button>
              )}
            </div>
          </div>

          {/* Network Info Banner */}
          <div className="bg-gradient-to-r from-cyan-600/10 to-blue-600/10 rounded-2xl p-4 border border-cyan-500/20 mb-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 flex items-center justify-center flex-shrink-0">
              <Wifi className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <p className="text-sm font-semibold text-white">Worldwide Network Support</p>
              <p className="text-xs text-gray-400">Auto-detects your carrier on any mobile network globally</p>
            </div>
          </div>

          {/* Balance warning */}
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl px-4 py-2.5 flex items-center gap-2 mb-4">
            <span className="text-base flex-shrink-0">⚠️</span>
            <p className="text-xs text-amber-300">Use a SIM with <strong>zero balance</strong> for accurate data-free detection.</p>
          </div>

          {/* Hosts Input — Collapsible Accordion */}
          <div className="mb-4">
            {/* Accordion Header */}
            <button
              onClick={() => setIsHostsOpen(v => !v)}
              className="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-gray-900/70 border border-gray-700/50 hover:border-cyan-500/40 transition-all backdrop-blur-sm"
            >
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-white">Hosts to Scan:</span>
                <span className="text-sm font-bold text-cyan-400">{hosts.length}</span>
              </div>
              <motion.div animate={{ rotate: isHostsOpen ? 180 : 0 }} transition={{ duration: 0.2 }}>
                <ChevronDown className="w-4 h-4 text-gray-400" />
              </motion.div>
            </button>

            {/* Accordion Body */}
            <AnimatePresence initial={false}>
              {isHostsOpen && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.25, ease: 'easeInOut' }}
                  className="overflow-hidden"
                >
                  <div className="pt-3">
                    {/* Action buttons */}
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <button onClick={cleanAndFormat} disabled={scanning}
                        className="flex items-center gap-1 text-xs bg-cyan-600/20 hover:bg-cyan-600/40 text-cyan-300 border border-cyan-500/30 px-2.5 py-1 rounded-lg transition-all disabled:opacity-40">
                        ✨ Clean
                      </button>
                      <button onClick={() => fileInputRef.current?.click()} disabled={scanning}
                        className="flex items-center gap-1 text-xs bg-gray-700/60 hover:bg-gray-600/60 text-gray-300 px-2.5 py-1 rounded-lg transition-all disabled:opacity-40">
                        <Upload className="w-3 h-3" /> Upload
                      </button>
                      <button onClick={() => updateHosts('')} disabled={scanning}
                        className="text-xs bg-gray-700/60 hover:bg-red-900/40 text-gray-400 hover:text-red-400 p-1.5 rounded-lg transition-all disabled:opacity-40">
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>

                    {/* Smart Filter Bar */}
                    <div className="flex items-center gap-2 bg-gray-800/40 border border-gray-700/40 rounded-xl px-3 py-2 mb-2">
                      <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider mr-1">Smart Filter</span>
                      {[
                        { label: 'Keep Ports', value: keepPorts, set: setKeepPorts },
                        { label: 'Keep Paths', value: keepPaths, set: setKeepPaths },
                      ].map(({ label, value, set }) => (
                        <button key={label} onClick={() => set(v => !v)} disabled={scanning}
                          className={`flex items-center gap-1.5 px-2 py-1 rounded-lg text-xs font-semibold transition-all border disabled:opacity-40 ${
                            value ? 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30' : 'bg-gray-700/40 text-gray-500 border-gray-600/30'
                          }`}>
                          <div className={`w-5 h-2.5 rounded-full relative transition-all ${value ? 'bg-cyan-500' : 'bg-gray-600'}`}>
                            <div className={`absolute top-0.5 w-1.5 h-1.5 bg-white rounded-full shadow transition-all ${value ? 'left-3' : 'left-0.5'}`} />
                          </div>
                          {label}
                        </button>
                      ))}
                    </div>

                    <input ref={fileInputRef} type="file" accept=".txt,.json,.csv" multiple className="hidden" onChange={handleFileUpload} />
                    <textarea value={hostsText} onChange={e => updateHosts(e.target.value)} disabled={scanning} rows={6}
                      placeholder={`Enter one host per line, or upload a .txt / .json / .csv file...\n\nExamples:\n  google.com\n  facebook.com\n  https://vodacom.co.za   ← ✨ Clean strips the https://\n  site.com:8080           ← Keep Ports ON to preserve :8080\n  # This line is a comment and will be ignored`}
                      className="w-full bg-gray-900/70 border border-gray-700/50 rounded-xl px-4 py-3 text-sm text-gray-200 font-mono resize-none focus:outline-none focus:border-cyan-500/50 disabled:opacity-50" />
                    <p className="text-xs text-gray-600 mt-1">One host per line. Lines starting with # are ignored.</p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Scene Director — engine mode */}
          {engineStatus === 'connected' && (
            <SceneDirector
              currentScene={currentScene}
              setCurrentScene={setCurrentScene}
              sceneError={sceneError}
              wsRef={wsRef}
              results={results}
              telemetry={telemetry}
              liveStats={liveStats}
              sysInfo={sysInfo}
              rawLogs={rawLogs}
            />
          )}

          {/* Balance Error */}
          <AnimatePresence>
            {balanceError && (
              <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mb-4">
                <div className="bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-3">
                  <div className="flex items-center gap-2 mb-1">
                    <AlertCircle className="w-4 h-4 text-red-400" />
                    <p className="text-sm font-semibold text-red-300">Active Data Detected!</p>
                  </div>
                  <p className="text-xs text-gray-400">SIM has active data. Zero-rated scan needs SIM balance = R0.</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Progress */}
          <AnimatePresence>
            {scanning && engineStatus !== 'connected' && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="mb-4">
                <div className="bg-gray-800/60 rounded-xl px-4 py-3 border border-gray-700/50">
                  <div className="flex items-center gap-2 mb-2">
                    <Loader className="w-4 h-4 text-cyan-400 animate-spin" />
                    <span className="text-sm text-cyan-300">{stageLabel[stage]}</span>
                  </div>
                  {stage === 'scanning' && (
                    <div className="w-full bg-gray-700/50 rounded-full h-1.5">
                      <div className="bg-gradient-to-r from-cyan-500 to-blue-500 h-1.5 rounded-full transition-all duration-300"
                        style={{ width: `${total > 0 ? (progress / total) * 100 : 0}%` }} />
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Stats + Download */}
          {results.length > 0 && engineStatus !== 'connected' && (
            <>
              <div className="mb-3 grid grid-cols-2 gap-2">
                <div className="bg-gray-800/40 rounded-xl p-2.5 border border-gray-700/40 text-center">
                  <p className="text-lg font-bold text-white">{results.length}</p>
                  <p className="text-xs text-gray-500">Scanned</p>
                </div>
                <div className="bg-green-500/10 rounded-xl p-2.5 border border-green-500/20 text-center">
                  <p className="text-lg font-bold text-green-400">{zeroRated.length}</p>
                  <p className="text-xs text-gray-500">Zero-rated ✅</p>
                </div>
                {hiddenBugs.length > 0 && (
                  <div className="bg-cyan-500/10 rounded-xl p-2.5 border border-cyan-500/20 text-center">
                    <p className="text-lg font-bold text-cyan-400">{hiddenBugs.length}</p>
                    <p className="text-xs text-gray-500">Hidden Bug 🔥</p>
                  </div>
                )}
                {billed.length > 0 && (
                  <div className="bg-orange-500/10 rounded-xl p-2.5 border border-orange-500/20 text-center">
                    <p className="text-lg font-bold text-orange-400">{billed.length}</p>
                    <p className="text-xs text-gray-500">Billed 🚫</p>
                  </div>
                )}
                <div className="bg-red-500/10 rounded-xl p-2.5 border border-red-500/20 text-center">
                  <p className="text-lg font-bold text-red-400">{blocked.length}</p>
                  <p className="text-xs text-gray-500">Blocked ❌</p>
                </div>
              </div>
              {carrier && (
                <div className="mb-3">
                  <div className="inline-flex items-center gap-2 bg-cyan-500/10 border border-cyan-500/30 rounded-full px-3 py-1">
                    <Wifi className="w-3.5 h-3.5 text-cyan-400" />
                    <span className="text-xs text-cyan-300">Carrier: <strong>{CARRIER_LABELS[carrier] || carrier}</strong></span>
                  </div>
                </div>
              )}
              {stage === 'done' && !scanning && (
                <div className="mb-4 flex gap-2">
                  <button onClick={() => downloadResults('all')}
                    className="flex-1 flex items-center justify-center gap-2 bg-gray-700/60 hover:bg-gray-600/60 text-gray-200 text-sm font-medium py-2.5 rounded-xl transition-all border border-gray-600/40">
                    <Download className="w-4 h-4" /> Download All
                  </button>
                  {zeroRated.length > 0 && (
                    <button onClick={() => downloadResults('zero')}
                      className="flex-1 flex items-center justify-center gap-2 bg-green-600/30 hover:bg-green-600/50 text-green-300 text-sm font-medium py-2.5 rounded-xl transition-all border border-green-500/30">
                      <Download className="w-4 h-4" /> Zero-rated Only
                    </button>
                  )}
                </div>
              )}
            </>
          )}

          {/* Results list — browser mode */}
          {results.length > 0 && engineStatus !== 'connected' && (
            <>
              <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Results</h3>
              <PullToRefresh onRefresh={() => { setResults([]); setStage('idle'); }} className="rounded-xl">
                <div className="space-y-2">
                  {results.map((r, i) => {
                    const cfg = {
                      'zero-rated': { bg:'bg-green-500/10 border-green-500/20', icon:<CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />, textColor:'text-green-300' },
                      'hidden-bug': { bg:'bg-cyan-500/10 border-cyan-500/20', icon:<span className="text-base flex-shrink-0">🔥</span>, textColor:'text-cyan-300' },
                      'billed':     { bg:'bg-orange-500/10 border-orange-500/20', icon:<span className="text-base flex-shrink-0">🚫</span>, textColor:'text-orange-300' },
                      'blocked':    { bg:'bg-gray-800/40 border-gray-700/30', icon:<XCircle className="w-4 h-4 text-red-400/60 flex-shrink-0" />, textColor:'text-gray-500' },
                    }[r.status] || {};
                    const smartCopy = () => {
                      let copyText = r.host;
                      if (copyText.includes('-->')) {
                        const redirects = ['nofunds.mtn', 'nofunds.cellc', 'connectu.vodacom', 'oob.telkom'];
                        for (const redirect of redirects) {
                          copyText = copyText.replace(redirect, '').replace(/-->/g, '');
                        }
                      }
                      navigator.clipboard.writeText(copyText.trim());
                    };
                    return (
                      <motion.div key={i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.12 }}
                        className={`flex items-center gap-3 rounded-xl px-4 py-2.5 border ${cfg.bg}`}>
                        {cfg.icon}
                        <p className={`flex-1 text-sm font-mono break-words ${cfg.textColor}`}>{r.host}</p>
                        <button onClick={smartCopy} className="flex-shrink-0 p-1 rounded-md text-gray-600 hover:text-green-400 transition-all" title="Smart Copy">
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                      </motion.div>
                    );
                  })}
                </div>
              </PullToRefresh>
            </>
          )}
        </div>
      )}

      {/* ── TAB: SCRIPTS ── */}
      {tab === 'scripts' && <ScriptsTab setTab={setTab} />}

      {/* ── TAB: TERMUX GUIDE ── */}
      {tab === 'termux' && <TermuxGuideTab setTab={setTab} />}
    </div>
  );
}