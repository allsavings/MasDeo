import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { ArrowLeft, Plus, Server, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function CreatorVps() {
  const [user, setUser] = useState(null);
  const [servers, setServers] = useState([]);
  const [showAdd, setShowAdd] = useState(false);
  const [formData, setFormData] = useState({
    server_name: '',
    ip_address: '',
    location: '',
    os: '',
    max_users: 10
  });
  const [scriptForm, setScriptForm] = useState({
    script_type: '',
    port: '',
    username: '',
    password: '',
    ssl_domain: '',
    notes: ''
  });
  const [selectedServer, setSelectedServer] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const userData = await base44.auth.me();
    setUser(userData);
    const myServers = await base44.entities.VpsServer.filter({ creator_email: userData.email });
    setServers(myServers);
  };

  const handleCreateServer = async () => {
    await base44.entities.VpsServer.create({
      creator_email: user.email,
      ...formData,
      installed_scripts: []
    });
    await loadData();
    setShowAdd(false);
    setFormData({ server_name: '', ip_address: '', location: '', os: '', max_users: 10 });
  };

  const handleAddScript = async () => {
    if (!selectedServer) return;
    
    const updatedScripts = [...(selectedServer.installed_scripts || []), scriptForm];
    await base44.entities.VpsServer.update(selectedServer.id, {
      installed_scripts: updatedScripts
    });
    
    await loadData();
    setScriptForm({ script_type: '', port: '', username: '', password: '', ssl_domain: '', notes: '' });
    setSelectedServer(null);
  };

  const handleDeleteServer = async (serverId) => {
    if (confirm('Delete this server? This action cannot be undone.')) {
      await base44.entities.VpsServer.delete(serverId);
      await loadData();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("CreatorMode")} className="p-2 bg-gray-800/50 rounded-xl">
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <h1 className="text-xl font-bold">VPS Servers</h1>
          </div>
          <Button onClick={() => setShowAdd(!showAdd)} className="bg-blue-600">
            <Plus className="w-4 h-4 mr-2" />
            Add
          </Button>
        </div>

        {showAdd && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50 mb-6"
          >
            <h3 className="font-semibold mb-4">Add VPS Server</h3>
            <div className="space-y-3">
              <Input
                placeholder="Server Name"
                value={formData.server_name}
                onChange={(e) => setFormData({...formData, server_name: e.target.value})}
                className="bg-gray-700/50 border-gray-600"
              />
              <Input
                placeholder="IP Address"
                value={formData.ip_address}
                onChange={(e) => setFormData({...formData, ip_address: e.target.value})}
                className="bg-gray-700/50 border-gray-600"
              />
              <Input
                placeholder="Location (e.g., USA, UK)"
                value={formData.location}
                onChange={(e) => setFormData({...formData, location: e.target.value})}
                className="bg-gray-700/50 border-gray-600"
              />
              <Input
                placeholder="Operating System"
                value={formData.os}
                onChange={(e) => setFormData({...formData, os: e.target.value})}
                className="bg-gray-700/50 border-gray-600"
              />
              <Input
                type="number"
                placeholder="Max Users"
                value={formData.max_users}
                onChange={(e) => setFormData({...formData, max_users: parseInt(e.target.value)})}
                className="bg-gray-700/50 border-gray-600"
              />
              <Button onClick={handleCreateServer} className="w-full bg-blue-600">
                Create Server
              </Button>
            </div>
          </motion.div>
        )}

        <div className="space-y-4">
          {servers.map((server) => (
            <motion.div
              key={server.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h4 className="font-semibold text-white mb-1">{server.server_name}</h4>
                  <p className="text-sm text-gray-400 mb-2">IP: {server.ip_address}</p>
                  <div className="flex gap-2 text-xs text-gray-500">
                    <span>{server.location}</span>
                    <span>•</span>
                    <span>{server.os}</span>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleDeleteServer(server.id)}
                  className="text-red-400 hover:text-red-300"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>

              {server.installed_scripts && server.installed_scripts.length > 0 && (
                <div className="mt-3 space-y-2">
                  <p className="text-xs text-gray-400 font-semibold">Installed Scripts:</p>
                  {server.installed_scripts.map((script, idx) => (
                    <div key={idx} className="bg-gray-900/50 rounded-lg p-3 text-xs">
                      <p className="text-white font-semibold mb-1">{script.script_type}</p>
                      <div className="grid grid-cols-2 gap-1 text-gray-400">
                        <p>Port: {script.port}</p>
                        <p>User: {script.username}</p>
                        {script.ssl_domain && <p className="col-span-2">Domain: {script.ssl_domain}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <Button
                onClick={() => setSelectedServer(server)}
                className="w-full mt-3 bg-purple-600"
                size="sm"
              >
                Add Script
              </Button>
            </motion.div>
          ))}
        </div>

        {selectedServer && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-6">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-gray-900 rounded-2xl p-6 max-w-md w-full border border-gray-700 max-h-[90vh] overflow-y-auto"
            >
              <h3 className="text-xl font-bold mb-4">Add Script to {selectedServer.server_name}</h3>
              <div className="space-y-3">
                <Select value={scriptForm.script_type} onValueChange={(value) => setScriptForm({...scriptForm, script_type: value})}>
                  <SelectTrigger className="bg-gray-800 border-gray-700">
                    <SelectValue placeholder="Script Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="SSL">SSL</SelectItem>
                    <SelectItem value="SSH">SSH</SelectItem>
                    <SelectItem value="OpenVPN">OpenVPN</SelectItem>
                    <SelectItem value="V2Ray">V2Ray</SelectItem>
                    <SelectItem value="3X-UI">3X-UI</SelectItem>
                    <SelectItem value="UDP">UDP</SelectItem>
                    <SelectItem value="WireGuard">WireGuard</SelectItem>
                    <SelectItem value="XRay">XRay</SelectItem>
                  </SelectContent>
                </Select>
                <Input
                  placeholder="Port"
                  value={scriptForm.port}
                  onChange={(e) => setScriptForm({...scriptForm, port: e.target.value})}
                  className="bg-gray-800 border-gray-700"
                />
                <Input
                  placeholder="Username"
                  value={scriptForm.username}
                  onChange={(e) => setScriptForm({...scriptForm, username: e.target.value})}
                  className="bg-gray-800 border-gray-700"
                />
                <Input
                  placeholder="Password"
                  type="password"
                  value={scriptForm.password}
                  onChange={(e) => setScriptForm({...scriptForm, password: e.target.value})}
                  className="bg-gray-800 border-gray-700"
                />
                <Input
                  placeholder="SSL Domain (optional)"
                  value={scriptForm.ssl_domain}
                  onChange={(e) => setScriptForm({...scriptForm, ssl_domain: e.target.value})}
                  className="bg-gray-800 border-gray-700"
                />
                <Textarea
                  placeholder="Notes (optional)"
                  value={scriptForm.notes}
                  onChange={(e) => setScriptForm({...scriptForm, notes: e.target.value})}
                  className="bg-gray-800 border-gray-700"
                />
                <div className="flex gap-2">
                  <Button onClick={handleAddScript} className="flex-1 bg-blue-600">
                    Add Script
                  </Button>
                  <Button onClick={() => setSelectedServer(null)} variant="outline" className="flex-1">
                    Cancel
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
}