import React from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, BarChart3, Bot, Radio, Info, TrendingUp, Zap, Activity } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function Forex() {
  const tools = [
    {
      title: "Trading Bots",
      description: "Automated trading systems that execute trades 24/7",
      icon: Bot,
      color: "from-blue-500 to-cyan-500",
      features: ["Automated execution", "24/7 trading", "Risk management"]
    },
    {
      title: "Robot Systems",
      description: "Advanced algorithmic trading robots with AI",
      icon: Zap,
      color: "from-purple-500 to-pink-500",
      features: ["AI-powered", "High frequency", "Back-testing"]
    },
    {
      title: "Trading Signals",
      description: "Real-time buy/sell signals from expert traders",
      icon: Radio,
      color: "from-green-500 to-emerald-500",
      features: ["Real-time alerts", "Expert analysis", "Multiple pairs"]
    },
    {
      title: "Market Analysis",
      description: "Technical and fundamental analysis tools",
      icon: Activity,
      color: "from-amber-500 to-orange-500",
      features: ["Charts & indicators", "News feed", "Price alerts"]
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      {/* Header */}
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center gap-4 mb-6">
          <Link to={createPageUrl("EarnOnline")} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-xl font-bold">Forex Trading</h1>
        </div>

        {/* Hero */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-green-600/30 to-emerald-600/30 rounded-2xl p-6 border border-green-500/30 mb-6"
        >
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-lg">Currency Trading</h2>
              <p className="text-sm text-gray-400">Learn & automate</p>
            </div>
          </div>
          <p className="text-sm text-gray-300">Trade the forex market with automated bots, expert signals, and advanced trading systems.</p>
        </motion.div>

        {/* Warning */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-4 mb-6"
        >
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-semibold text-amber-400 mb-1">Risk Warning</h4>
              <p className="text-xs text-gray-400">Forex trading involves substantial risk. Only invest money you can afford to lose. Always use proper risk management.</p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Trading Tools */}
      <div className="px-6 space-y-4">
        <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider">Trading Tools & Systems</h3>
        
        {tools.map((tool, index) => (
          <motion.div
            key={tool.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 + index * 0.1 }}
          >
            <div className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50 hover:border-green-500/50 transition-all cursor-pointer group">
              <div className="flex items-start gap-4 mb-3">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${tool.color} flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                  <tool.icon className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-white mb-1">{tool.title}</h4>
                  <p className="text-sm text-gray-400 mb-3">{tool.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {tool.features.map((feature, idx) => (
                      <span key={idx} className="text-xs bg-gray-700/50 text-gray-300 px-2 py-1 rounded-full">
                        {feature}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        ))}

        {/* Learning Resources */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mt-6"
        >
          <div className="bg-gradient-to-r from-blue-500/20 to-cyan-500/20 rounded-2xl p-5 border border-blue-500/30">
            <h4 className="font-semibold text-white mb-2 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-400" />
              Start Learning Forex
            </h4>
            <p className="text-sm text-gray-400 mb-4">Master the basics before using automated systems. Learn technical analysis, risk management, and trading strategies.</p>
            <Link 
              to={createPageUrl("LearnSkills")}
              className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-500 to-cyan-500 text-white px-6 py-3 rounded-xl font-medium hover:opacity-90 transition-opacity text-sm"
            >
              Learn Forex Trading
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}