import React from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Star, Crown, Zap, Check, Lock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function Premium() {
  const features = [
    "Access all premium courses",
    "Exclusive earning strategies",
    "1-on-1 mentorship sessions",
    "Private community access",
    "Certificate of completion",
    "Priority support"
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      {/* Header */}
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center gap-4 mb-6">
          <Link to={createPageUrl("Home")} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-xl font-bold">Premium Content</h1>
        </div>
      </div>

      {/* Premium Card */}
      <div className="px-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-gradient-to-br from-amber-500/20 via-orange-500/20 to-amber-600/20 rounded-3xl p-6 border border-amber-500/30 mb-6 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-amber-400/20 to-transparent rounded-full blur-3xl" />
          
          <div className="relative">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center">
                <Crown className="w-7 h-7 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-xl text-white">Go Premium</h2>
                <p className="text-sm text-amber-200/70">Unlock everything</p>
              </div>
            </div>

            <div className="space-y-3 mb-6">
              {features.map((feature, index) => (
                <motion.div
                  key={feature}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 + index * 0.1 }}
                  className="flex items-center gap-3"
                >
                  <div className="w-5 h-5 rounded-full bg-amber-500/30 flex items-center justify-center">
                    <Check className="w-3 h-3 text-amber-400" />
                  </div>
                  <span className="text-sm text-gray-200">{feature}</span>
                </motion.div>
              ))}
            </div>

            <div className="text-center mb-4">
              <div className="text-3xl font-bold text-white mb-1">
                $9.99<span className="text-lg font-normal text-gray-400">/month</span>
              </div>
              <p className="text-sm text-amber-200/70">Cancel anytime</p>
            </div>

            <button className="w-full bg-gradient-to-r from-amber-400 to-orange-500 text-white py-4 rounded-2xl font-semibold text-lg hover:opacity-90 transition-opacity flex items-center justify-center gap-2">
              <Zap className="w-5 h-5" />
              Upgrade Now
            </button>
          </div>
        </motion.div>

        {/* Locked Content Preview */}
        <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider mb-4">Premium Courses</h3>
        
        {['Advanced Trading Strategies', 'Passive Income Masterclass', 'AI for Business'].map((course, index) => (
          <motion.div
            key={course}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 + index * 0.1 }}
            className="mb-4"
          >
            <div className="bg-gray-800/30 rounded-2xl p-5 border border-gray-700/30 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-transparent to-gray-900/80" />
              <div className="relative flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gray-700/50 flex items-center justify-center">
                    <Lock className="w-5 h-5 text-gray-500" />
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-400">{course}</h4>
                    <p className="text-xs text-gray-600">Premium only</p>
                  </div>
                </div>
                <Star className="w-5 h-5 text-amber-500/50" />
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}