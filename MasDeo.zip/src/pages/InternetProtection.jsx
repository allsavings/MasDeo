import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft, Shield, Lock, AlertTriangle, Wifi,
  Eye, EyeOff, CheckCircle, XCircle, Zap, Radio,
  ShieldAlert, ShieldCheck, Fingerprint, KeyRound,
  Bug, PhoneCall, Globe, Smartphone
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

// ─── PRIVACY SECTION ────────────────────────────────────────────────
const privacyTips = [
  {
    tag: 'REALITY',
    tagColor: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
    title: 'They Are Watching',
    body: 'Every app, every site, every tap is recorded. Your location, habits, what you buy, who you talk to — all sold to advertisers or stolen by hackers. Protecting your privacy is not about hiding — it\'s about owning your own data.',
  },
  {
    tag: 'HABIT',
    tagColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
    title: 'Safe Browsing Rules',
    body: 'Only use HTTPS sites (check for the padlock). Clear cookies weekly. Never click random links. Use incognito for anything sensitive. Log out of accounts you\'re not actively using.',
  },
  {
    tag: 'TOOL',
    tagColor: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
    title: 'Block the Trackers',
    body: 'Install uBlock Origin on your browser — it blocks ads and trackers silently. Switch to Brave Browser or Firefox. Use DuckDuckGo, not Google Search. Turn off personalised ads in Google account settings.',
  },
  {
    tag: 'MOBILE',
    tagColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
    title: 'Your Phone Knows Too Much',
    body: 'Check every app\'s permissions. Does your torch app need your contacts? Revoke location from apps that don\'t need it. Turn off Bluetooth and WiFi when you\'re not using them. Use Signal for sensitive conversations.',
  },
];

// ─── SECURITY SECTION ────────────────────────────────────────────────
const securityProtocols = [
  {
    step: '01',
    title: 'Password Protocol',
    status: 'CRITICAL',
    statusColor: 'text-red-400 bg-red-500/15 border-red-500/30',
    body: 'Minimum 12 characters. Mix letters, numbers, and symbols. NEVER reuse the same password on two sites. Use Bitwarden or Google Password Manager — they generate and store strong passwords so you don\'t have to remember them.',
  },
  {
    step: '02',
    title: 'Two-Factor (2FA)',
    status: 'ESSENTIAL',
    statusColor: 'text-amber-400 bg-amber-500/15 border-amber-500/30',
    body: 'Even if someone steals your password — without your phone, they can\'t log in. Enable 2FA on email, banking, WhatsApp, and social media. Use an authenticator app (Google Authenticator or Authy) — not SMS codes.',
  },
  {
    step: '03',
    title: 'Device Lockdown',
    status: 'STANDARD',
    statusColor: 'text-green-400 bg-green-500/15 border-green-500/30',
    body: 'PIN, pattern or biometric lock — always on. Keep your OS and apps updated (updates fix security holes). Don\'t install APKs from random Telegram channels or unknown sites. Run Avast or Bitdefender scan once a month.',
  },
  {
    step: '04',
    title: 'Email Safety',
    status: 'STANDARD',
    statusColor: 'text-green-400 bg-green-500/15 border-green-500/30',
    body: 'Never open attachments from strangers. Scammers use emails like "support@fnb-secure.net" — check the actual domain carefully. Rule: If an email asks for your password or OTP, it\'s a scam. Always go to the site directly.',
  },
];

// ─── SCAM SECTION ────────────────────────────────────────────────────
const scamAlerts = [
  {
    level: '🔴 HIGH ALERT',
    levelColor: 'text-red-400',
    title: 'Fake Earning Platforms',
    redFlags: ['Promises R5,000/day for no work', 'Requires upfront payment to join', 'Pushes you to recruit others', 'No real company address or registration'],
    masterNote: 'Real platforms pay small, consistent amounts. If it sounds too good to be true — it is. Search the name + "scam" before joining anything.',
  },
  {
    level: '🔴 HIGH ALERT',
    levelColor: 'text-red-400',
    title: 'Phishing Links',
    redFlags: ['"standard-bank-login.com" is NOT Standard Bank', 'Slight spelling changes in URLs', 'Email links that lead to login pages', 'Fake verification text messages'],
    masterNote: 'Hover over links before clicking. If the URL looks even slightly wrong — don\'t touch it. Type the site address manually.',
  },
  {
    level: '🟡 WATCH OUT',
    levelColor: 'text-amber-400',
    title: 'Fake VPN Apps',
    redFlags: ['No real privacy policy', 'Unknown developer name', 'Too many perfect 5-star reviews', 'Asks for unnecessary permissions'],
    masterNote: 'A VPN that collects your data is worse than no VPN. Only use VPNs we recommend on this platform — they\'ve been tested.',
  },
  {
    level: '🟡 WATCH OUT',
    levelColor: 'text-amber-400',
    title: 'WhatsApp & SMS Scams (SA)',
    redFlags: ['"You\'ve won R10,000 — click here"', 'Job offers that need upfront fees', 'Fake SASSA/UIF notifications', '"Your bank account is suspended"'],
    masterNote: 'Your bank will NEVER ask for your PIN or OTP on WhatsApp. Report scams to SAPS Cybercrime or your bank\'s fraud line immediately.',
  },
];

// ─── WIFI SECTION ────────────────────────────────────────────────────
const wifiRules = [
  { icon: Radio, color: 'text-rose-400', rule: 'Open WiFi = Open Door', detail: 'Mall WiFi, restaurant hotspots, and transport hubs are completely unencrypted. Anyone on the same network can see your traffic. Hackers set up fake spots named "FreeShopWifi" — you connect, they see everything.' },
  { icon: ShieldCheck, color: 'text-emerald-400', rule: 'VPN First, Always', detail: 'Before connecting to any public or unknown WiFi — activate your VPN first. It encrypts all your traffic so even if intercepted, it\'s unreadable. Lets VPN Go is your default on this platform.' },
  { icon: Smartphone, color: 'text-blue-400', rule: 'Turn Off Auto-Connect', detail: 'Your phone should not auto-join networks you\'ve used before. Disable this setting. Forget old networks you no longer need. If possible, keep WiFi off and use mobile data for sensitive tasks.' },
  { icon: Globe, color: 'text-purple-400', rule: 'Campus & Zero-Rated WiFi', detail: 'University WiFi and zero-rated portals are generally safer than random hotspots — but still use a VPN. On shared campus computers, always sign out and clear the browser cache before leaving.' },
];


// ─── COMPONENTS ──────────────────────────────────────────────────────

function PrivacyStation({ expanded, onToggle }) {
  const [openTip, setOpenTip] = useState(null);
  return (
    <div className="rounded-2xl border border-blue-500/30 overflow-hidden">
      <button onClick={onToggle} className="w-full flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-blue-900/30 to-indigo-900/20">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-500 flex items-center justify-center flex-shrink-0">
          <Eye className="w-4 h-4 text-white" />
        </div>
        <div className="flex-1 text-left">
          <p className="font-bold text-white text-sm">Privacy Basics</p>
          <p className="text-[11px] text-gray-400">Your data belongs to you</p>
        </div>
        <div className={`w-6 h-6 rounded-full flex items-center justify-center border transition-all ${expanded ? 'bg-blue-500/30 border-blue-400/50' : 'bg-gray-800 border-gray-700'}`}>
          <span className="text-white text-[10px] font-bold">{expanded ? '−' : '+'}</span>
        </div>
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }} className="bg-gray-900/40">
            <div className="p-4 space-y-2">
              {privacyTips.map((tip, i) => (
                <div key={i} className="rounded-xl border border-gray-700/50 overflow-hidden">
                  <button onClick={() => setOpenTip(openTip === i ? null : i)} className="w-full flex items-center gap-3 px-4 py-3 text-left bg-gray-800/40 hover:bg-gray-800/70 transition-colors">
                    <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full border flex-shrink-0 ${tip.tagColor}`}>{tip.tag}</span>
                    <span className="flex-1 font-semibold text-sm text-white">{tip.title}</span>
                    <span className="text-gray-500 text-xs">{openTip === i ? '▲' : '▼'}</span>
                  </button>
                  <AnimatePresence>
                    {openTip === i && (
                      <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="overflow-hidden">
                        <p className="px-4 py-3 text-sm text-gray-300 leading-relaxed border-t border-gray-700/40">{tip.body}</p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function SecurityStation({ expanded, onToggle }) {
  const [openProto, setOpenProto] = useState(null);
  return (
    <div className="rounded-2xl border border-green-500/30 overflow-hidden">
      <button onClick={onToggle} className="w-full flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-green-900/30 to-emerald-900/20">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center flex-shrink-0">
          <KeyRound className="w-4 h-4 text-white" />
        </div>
        <div className="flex-1 text-left">
          <p className="font-bold text-white text-sm">Security Protocols</p>
          <p className="text-[11px] text-gray-400">Lock down your accounts and devices</p>
        </div>
        <div className={`w-6 h-6 rounded-full flex items-center justify-center border transition-all ${expanded ? 'bg-green-500/30 border-green-400/50' : 'bg-gray-800 border-gray-700'}`}>
          <span className="text-white text-[10px] font-bold">{expanded ? '−' : '+'}</span>
        </div>
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }} className="bg-gray-900/40">
            <div className="p-4 space-y-2">
              {securityProtocols.map((proto, i) => (
                <div key={i} className="rounded-xl border border-gray-700/50 overflow-hidden">
                  <button onClick={() => setOpenProto(openProto === i ? null : i)} className="w-full flex items-center gap-3 px-4 py-3 text-left bg-gray-800/40 hover:bg-gray-800/70 transition-colors">
                    <span className="text-[11px] font-bold text-gray-500 font-mono flex-shrink-0">{proto.step}</span>
                    <span className="flex-1 font-semibold text-sm text-white">{proto.title}</span>
                    <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full border ${proto.statusColor} flex-shrink-0`}>{proto.status}</span>
                  </button>
                  <AnimatePresence>
                    {openProto === i && (
                      <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="overflow-hidden">
                        <p className="px-4 py-3 text-sm text-gray-300 leading-relaxed border-t border-gray-700/40">{proto.body}</p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ScamStation({ expanded, onToggle }) {
  const [openAlert, setOpenAlert] = useState(null);
  return (
    <div className="rounded-2xl border border-amber-500/30 overflow-hidden">
      <button onClick={onToggle} className="w-full flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-amber-900/30 to-orange-900/20">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center flex-shrink-0">
          <ShieldAlert className="w-4 h-4 text-white" />
        </div>
        <div className="flex-1 text-left">
          <p className="font-bold text-white text-sm">Scam Awareness</p>
          <p className="text-[11px] text-gray-400">Know the traps before you fall in</p>
        </div>
        <div className={`w-6 h-6 rounded-full flex items-center justify-center border transition-all ${expanded ? 'bg-amber-500/30 border-amber-400/50' : 'bg-gray-800 border-gray-700'}`}>
          <span className="text-white text-[10px] font-bold">{expanded ? '−' : '+'}</span>
        </div>
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }} className="bg-gray-900/40">
            <div className="p-4 space-y-3">
              {scamAlerts.map((alert, i) => (
                <div key={i} className="rounded-xl border border-gray-700/50 overflow-hidden">
                  <button onClick={() => setOpenAlert(openAlert === i ? null : i)} className="w-full flex items-start gap-3 px-4 py-3 text-left bg-gray-800/40 hover:bg-gray-800/70 transition-colors">
                    <div className="flex-1">
                      <span className={`text-[10px] font-bold ${alert.levelColor}`}>{alert.level}</span>
                      <p className="font-semibold text-sm text-white mt-0.5">{alert.title}</p>
                    </div>
                    <span className="text-gray-500 text-xs mt-1">{openAlert === i ? '▲' : '▼'}</span>
                  </button>
                  <AnimatePresence>
                    {openAlert === i && (
                      <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="overflow-hidden">
                        <div className="px-4 py-3 border-t border-gray-700/40 space-y-3">
                          <div>
                            <p className="text-[10px] font-bold text-red-400 uppercase tracking-wider mb-2">🚩 Red Flags</p>
                            <div className="space-y-1.5">
                              {alert.redFlags.map((flag, j) => (
                                <div key={j} className="flex items-start gap-2">
                                  <XCircle className="w-3.5 h-3.5 text-red-400 flex-shrink-0 mt-0.5" />
                                  <span className="text-xs text-gray-300">{flag}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                          <div className="bg-amber-500/10 border border-amber-500/25 rounded-xl p-3">
                            <p className="text-[10px] font-bold text-amber-400 mb-1">💬 Master's Note</p>
                            <p className="text-xs text-gray-300 leading-relaxed">{alert.masterNote}</p>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function WiFiStation({ expanded, onToggle }) {
  const [openRule, setOpenRule] = useState(null);
  return (
    <div className="rounded-2xl border border-purple-500/30 overflow-hidden">
      <button onClick={onToggle} className="w-full flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-purple-900/30 to-violet-900/20">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center flex-shrink-0">
          <Wifi className="w-4 h-4 text-white" />
        </div>
        <div className="flex-1 text-left">
          <p className="font-bold text-white text-sm">Public WiFi Safety</p>
          <p className="text-[11px] text-gray-400">Open networks are a battlefield</p>
        </div>
        <div className={`w-6 h-6 rounded-full flex items-center justify-center border transition-all ${expanded ? 'bg-purple-500/30 border-purple-400/50' : 'bg-gray-800 border-gray-700'}`}>
          <span className="text-white text-[10px] font-bold">{expanded ? '−' : '+'}</span>
        </div>
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }} className="bg-gray-900/40">
            <div className="p-4 space-y-2">
              {wifiRules.map((item, i) => {
                const Icon = item.icon;
                return (
                  <div key={i} className="rounded-xl border border-gray-700/50 overflow-hidden">
                    <button onClick={() => setOpenRule(openRule === i ? null : i)} className="w-full flex items-center gap-3 px-4 py-3 text-left bg-gray-800/40 hover:bg-gray-800/70 transition-colors">
                      <Icon className={`w-4 h-4 ${item.color} flex-shrink-0`} />
                      <span className="flex-1 font-semibold text-sm text-white">{item.rule}</span>
                      <span className="text-gray-500 text-xs">{openRule === i ? '▲' : '▼'}</span>
                    </button>
                    <AnimatePresence>
                      {openRule === i && (
                        <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="overflow-hidden">
                          <p className="px-4 py-3 text-sm text-gray-300 leading-relaxed border-t border-gray-700/40">{item.detail}</p>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}


// ─── MAIN PAGE ────────────────────────────────────────────────────────
export default function InternetProtection() {
  const navigate = useNavigate();
  const [openStation, setOpenStation] = useState(null);

  const toggle = (id) => setOpenStation(openStation === id ? null : id);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">

      {/* Header */}
      <div className="px-6 pt-6 pb-4 flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-xl font-bold leading-tight">Internet Protection</h1>
          <p className="text-[11px] text-gray-500">Your safety is our priority</p>
        </div>
      </div>

      {/* Hero */}
      <div className="px-6 mb-6">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative rounded-2xl overflow-hidden border border-red-500/40 bg-gradient-to-br from-red-950/60 via-[#0f0f1a] to-rose-950/30 p-5"
        >
          {/* Top bar strip */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-500 via-rose-500 to-orange-500" />

          <div className="flex items-start gap-4 mb-4">
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-red-500 to-rose-600 flex items-center justify-center flex-shrink-0 shadow-lg shadow-red-900/40">
              <Shield className="w-7 h-7 text-white" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[9px] font-bold tracking-[0.15em] text-red-400 uppercase">Masters DeoVex</span>
                <span className="w-1 h-1 rounded-full bg-red-400" />
                <span className="text-[9px] font-bold tracking-widest text-gray-500 uppercase">Protection Manual</span>

              </div>
              <h2 className="font-extrabold text-white text-lg leading-tight">Protect Yourself First</h2>
              <p className="text-xs text-gray-400 mt-0.5">No tool, no VPN, no platform works if you don't know how to protect yourself.</p>
            </div>
          </div>

          <p className="text-sm text-gray-300 leading-relaxed mb-4">
            This is not a generic safety checklist. This is what I actually use and teach. 
            Before you touch any VPN or tool on this platform, go through all 4 stations below. 
            Knowledge is the strongest shield you have.
          </p>

          {/* Station overview row */}
          <div className="grid grid-cols-4 gap-2">
            {[
              { emoji: '🔏', color: 'from-blue-500 to-indigo-500' },
              { emoji: '🔒', color: 'from-green-500 to-emerald-500' },
              { emoji: '⚠️', color: 'from-amber-500 to-orange-500' },
              { emoji: '📶', color: 'from-purple-500 to-violet-600' },
            ].map((s, i) => (
              <div key={i} className="flex items-center justify-center">
                <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${s.color} flex items-center justify-center shadow-md`}>
                  <span className="text-base">{s.emoji}</span>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Quick Rules Row */}
      <div className="px-6 mb-6">
        <p className="text-[10px] font-bold tracking-widest text-gray-500 uppercase mb-3">Non-Negotiable Rules</p>
        <div className="space-y-2">
          {[
            { icon: CheckCircle, color: 'text-emerald-400', text: 'VPN on before any unknown WiFi — always' },
            { icon: CheckCircle, color: 'text-emerald-400', text: '2FA enabled on all important accounts' },
            { icon: CheckCircle, color: 'text-emerald-400', text: 'Never pay upfront to "earn" online' },
            { icon: CheckCircle, color: 'text-emerald-400', text: 'Check the URL before entering any password' },
          ].map((rule, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 + i * 0.07 }}
              className="flex items-center gap-3 bg-gray-800/30 border border-gray-700/40 rounded-xl px-4 py-2.5"
            >
              <rule.icon className={`w-4 h-4 ${rule.color} flex-shrink-0`} />
              <span className="text-sm text-gray-200">{rule.text}</span>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Stations */}
      <div className="px-6 space-y-4">
        <p className="text-[10px] font-bold tracking-widest text-gray-500 uppercase">4 Protection Stations</p>

        <PrivacyStation expanded={openStation === 'privacy'} onToggle={() => toggle('privacy')} />
        <SecurityStation expanded={openStation === 'security'} onToggle={() => toggle('security')} />
        <ScamStation expanded={openStation === 'scams'} onToggle={() => toggle('scams')} />
        <WiFiStation expanded={openStation === 'wifi'} onToggle={() => toggle('wifi')} />
      </div>

      {/* Footer stamp */}
      <div className="px-6 mt-8">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="flex items-center gap-4 bg-gray-800/30 border border-gray-700/40 rounded-2xl p-4"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-500/30 to-rose-600/30 border border-red-500/30 flex items-center justify-center flex-shrink-0">
            <Fingerprint className="w-5 h-5 text-red-400" />
          </div>
          <div>
            <p className="text-xs font-bold text-white">Masters DeoVex · Digital Freedom Starts Here</p>
            <p className="text-[11px] text-gray-500 mt-0.5">Share this with everyone who uses the internet.</p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}