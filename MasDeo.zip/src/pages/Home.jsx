import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Globe, BookOpen, DollarSign, Star, User, Zap, ZapOff, Search, Heart, Eye, EyeOff, Wallet, Users } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import PinLock from '../components/PinLock';
import NotificationBell from '../components/NotificationBell';
import { saveCache, loadCache } from '../components/offlineCache';
import SpinningCreatorRing from '../components/SpinningCreatorRing';
import SpinningExploreRing from '../components/SpinningExploreRing';
import LockedSectionOverlay from '../components/LockedSectionOverlay';
import { useWIPLock } from '@/lib/WIPLockContext';

export default function Home() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState(() => loadCache('profile'));
  const [user, setUser] = useState(() => loadCache('user'));
  const [isLocked, setIsLocked] = useState(false);
  const [activeSubs, setActiveSubs] = useState(() => loadCache('activeSubs') || []);
  const [isCreatorMode, setIsCreatorMode] = useState(() => localStorage.getItem('creator_mode_active') === 'true');
  const [showCredit, setShowCredit] = useState(() => localStorage.getItem('show_credit') === 'true');
  const [showWalletMenu, setShowWalletMenu] = useState(false);
  const walletBtnRef = useRef(null);
  const [walletDropdownStyle, setWalletDropdownStyle] = useState({});
  const [followerCount, setFollowerCount] = useState(() => loadCache('followerCount') || 0);
  const [exploreCreatorsMode, setExploreCreatorsMode] = useState(() => localStorage.getItem('explore_creators_mode') === 'true');
  const { isRouteLocked } = useWIPLock();

  useEffect(() => {
    const savedPin = localStorage.getItem('app_pin');
    if (savedPin) {
      setIsLocked(true);
    } else {
      loadProfile();
    }
  }, []);

  useEffect(() => {
    if (!isLocked) {
      loadProfile();
    }
  }, [isLocked]);

  const loadProfile = async () => {
    if (!navigator.onLine) {
      // Offline: silently use cached data already loaded as initial state
      return;
    }
    try {
      const userData = await base44.auth.me();
      setUser(userData);
      saveCache('user', userData);

      const [profiles, subs, creatorProfiles] = await Promise.all([
        base44.entities.UserProfile.filter({ created_by: userData.email }),
        base44.entities.Subscription.filter({ user_email: userData.email, status: 'active' }),
        base44.entities.CreatorProfile.filter({ user_email: userData.email })
      ]);
      setActiveSubs(subs);
      saveCache('activeSubs', subs);

      // Get follower count if user is a creator
      if (creatorProfiles.length > 0) {
        const followers = await base44.entities.Follow.filter({ creator_email: userData.email });
        setFollowerCount(followers.length);
        saveCache('followerCount', followers.length);
      }
      if (profiles.length > 0) {
        const hasSub = subs.length > 0;
        const membershipType = hasSub ? 'premium' : 'free';
        const updatedProfile = { ...profiles[0], membership_type: membershipType };
        setProfile(updatedProfile);
        saveCache('profile', updatedProfile);
        base44.entities.UserProfile.update(profiles[0].id, { last_seen: new Date().toISOString(), membership_type: membershipType });
      } else {
        // Check if signup data was stored from the AuthScreen
        const pendingRaw = localStorage.getItem('pending_signup');
        const pending = pendingRaw ? JSON.parse(pendingRaw) : {};
        localStorage.removeItem('pending_signup');
        const newProfile = await base44.entities.UserProfile.create({
          nickname: pending.nickname || userData.full_name || "Tk Master",
          username: pending.username || '',
          phone: pending.phone || '',
          handle: pending.username ? `@${pending.username}` : "@MastersDeoVex",
          membership_type: "free",
          last_seen: new Date().toISOString()
        });
        setProfile(newProfile);
        saveCache('profile', newProfile);
      }
    } catch (error) {
      console.log('User not logged in or error loading profile');
      // If fetch failed mid-session (data ran out), cached state is already showing
    }
  };

  // Compute subscription label
  const getVersionLabel = () => {
    const plans = activeSubs.map(s => s.plan);
    if (plans.includes('all_in_one')) return { label: 'All-In-One Premium', gradient: 'from-amber-400 to-orange-400' };
    const hasEthical = plans.includes('ethical_internet');
    const hasLearn = plans.includes('learn_skills');
    const hasEarn = plans.includes('earn_online');
    if (hasEthical && hasLearn && hasEarn) return { label: 'All-In-One Premium', gradient: 'from-amber-400 to-orange-400' };
    if (hasEthical && hasLearn) return { label: 'Ethical & Learn Premium', gradient: 'from-blue-400 to-purple-400' };
    if (hasEthical && hasEarn) return { label: 'Ethical & Earn Premium', gradient: 'from-blue-400 to-emerald-400' };
    if (hasLearn && hasEarn) return { label: 'Learn & Earn Premium', gradient: 'from-purple-400 to-emerald-400' };
    if (hasEthical) return { label: 'Ethical Premium', gradient: 'from-blue-400 to-cyan-400' };
    if (hasLearn) return { label: 'Learn Premium', gradient: 'from-purple-400 to-blue-400' };
    if (hasEarn) return { label: 'Earn Premium', gradient: 'from-emerald-400 to-cyan-400' };
    return { label: 'FREE VERSION', gradient: 'from-blue-400 to-cyan-400', isFree: true };
  };

  const isCreatorEligible = activeSubs.length > 0;

  const toggleCreatorMode = () => {
    if (!isCreatorEligible) return;
    const next = !isCreatorMode;
    setIsCreatorMode(next);
    localStorage.setItem('creator_mode_active', next ? 'true' : 'false');
  };

  const toggleCreditVisibility = () => {
    const next = !showCredit;
    setShowCredit(next);
    localStorage.setItem('show_credit', next ? 'true' : 'false');
  };

  const toggleExploreCreators = () => {
    const next = !exploreCreatorsMode;
    setExploreCreatorsMode(next);
    localStorage.setItem('explore_creators_mode', next ? 'true' : 'false');
  };

  const categories = [
    {
      title: "Ethical Free Internet",
      description: "Access resources ethically",
      icon: Globe,
      color: "from-blue-500 to-cyan-400",
      page: "EthicalInternet"
    },
    {
      title: "Learn Digital Skills",
      description: "Master new technologies",
      icon: BookOpen,
      color: "from-purple-500 to-blue-500",
      page: "LearnSkills"
    },
    {
      title: "Earn Online",
      description: "Monetize your skills",
      icon: DollarSign,
      color: "from-emerald-500 to-cyan-400",
      page: "EarnOnline"
    },
    {
      title: "Premium Subscription",
      description: "Unlock exclusive features",
      icon: Star,
      color: "from-amber-500 to-orange-500",
      page: "MySubscription"
    }
  ];

  if (isLocked) {
    return <PinLock onUnlock={() => setIsLocked(false)} />;
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white overflow-x-hidden">
      {/* Big Logo Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="px-4 pt-6 pb-4"
      >
        <img 
          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/699aa662b79dd361c7b3904b/7f8e2ae2c_186683c9-e11a-4e07-a3bc-e80e42b08b3e_20260219_212443_00001.png" 
          alt="Masters DeoVex"
          className="w-full h-auto max-w-md mx-auto"
        />
      </motion.div>

      {/* User Profile Section */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="px-4 pb-4 text-center"
      >
        {/* Profile Picture */}
        <button
          onClick={() => navigate(createPageUrl("Settings"))}
          onContextMenu={(e) => e.preventDefault()}
          className="inline-block mb-2"
          style={{ userSelect: 'none', WebkitUserSelect: 'none', WebkitTouchCallout: 'none', background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}
        >
          <div className="relative">
            {profile?.profile_picture_url && activeSubs.length > 0 ? (
              <img 
                src={profile.profile_picture_url}
                alt="Profile"
                className="w-16 h-16 rounded-full object-cover border-2 border-blue-500/30 mx-auto"
              />
            ) : (
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6997a28cb8ba4da96dc79bb8/9821b9501_FinalMastersDeoVex.png" 
                alt="Default Profile"
                className="w-16 h-16 mx-auto"
              />
            )}
            {activeSubs.length > 0 && (
              <div className="absolute -bottom-1 -right-1 flex items-center gap-1">
                <span className="w-5 h-5 bg-gradient-to-r from-amber-500 to-orange-500 rounded-full flex items-center justify-center border-2 border-gray-900">
                  <Star className="w-2.5 h-2.5 text-white" />
                </span>
                {followerCount > 0 && (
                  <span className="text-[10px] font-bold text-amber-400 bg-gray-900/80 px-1.5 py-0.5 rounded-full border border-amber-500/30">
                    {followerCount}
                  </span>
                )}
              </div>
            )}
          </div>
        </button>
        
        {/* User Info */}
        <h2 className="text-base font-bold text-white mb-0.5">
          {profile?.nickname || 'Masters'}
        </h2>
        <p className="text-gray-400 text-xs mb-2">{profile?.handle || '@MastersTechSolutions'}</p>

        {/* Credit Display - Toggleable for All Users */}
        <motion.div
          initial={{ opacity: 0, y: 5 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="inline-block"
        >
          <button 
            ref={walletBtnRef}
            onClick={() => {
              const next = !showWalletMenu;
              if (next && walletBtnRef.current) {
                const rect = walletBtnRef.current.getBoundingClientRect();
                const scrollTop = window.scrollY || document.documentElement.scrollTop;
                setWalletDropdownStyle({
                  position: 'absolute',
                  top: rect.bottom + scrollTop + 8,
                  left: '25%',
                  right: '25%',
                  width: 'auto',
                });
              }
              setShowWalletMenu(next);
            }}
            className="group flex items-center gap-2 bg-gradient-to-r from-gray-800/60 to-gray-800/40 hover:from-gray-800/80 hover:to-gray-800/60 border border-gray-700/40 hover:border-gray-600/60 rounded-xl px-3 py-1.5 transition-all"
          >
            <Wallet className="w-3.5 h-3.5 text-gray-500 group-hover:text-gray-400 transition-colors" />
            {showCredit ? (
              <>
                <span className="text-xs text-gray-400">Credit</span>
                <span className="text-xs font-semibold text-blue-400">R{(profile?.credits || 0).toFixed(2)}</span>
                <EyeOff className="w-3 h-3 text-gray-600 group-hover:text-gray-500 transition-colors ml-0.5" />
              </>
            ) : (
              <>
                <span className="text-xs text-gray-500">••••</span>
                <Eye className="w-3 h-3 text-gray-600 group-hover:text-gray-500 transition-colors" />
              </>
            )}
          </button>

          {/* Wallet Menu Dropdown */}
          {showWalletMenu && (
            <div>
              <div className="fixed inset-0 z-40" onClick={() => setShowWalletMenu(false)} />
              <motion.div
                initial={{ opacity: 0, y: -10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -10, scale: 0.95 }}
                className="bg-gray-900/98 backdrop-blur-2xl border border-gray-700/60 rounded-2xl shadow-[0_8px_32px_rgba(0,0,0,0.7)] overflow-hidden z-50"
                style={walletDropdownStyle}
              >
                <div className="px-3 py-2 border-b border-gray-800/60 flex items-center gap-2">
                  <Wallet className="w-3.5 h-3.5 text-blue-400" />
                  <span className="text-xs font-semibold text-white">Wallet</span>
                  {showCredit && <span className="ml-auto text-xs font-bold text-blue-400">R{(profile?.credits || 0).toFixed(2)}</span>}
                </div>
                <div className="p-2 space-y-1">
                  <button
                    onClick={toggleCreditVisibility}
                    className="w-full text-left px-3 py-2 rounded-lg hover:bg-gray-800/60 transition-all flex items-center gap-2"
                  >
                    {showCredit ? <EyeOff className="w-3.5 h-3.5 text-gray-400" /> : <Eye className="w-3.5 h-3.5 text-gray-400" />}
                    <span className="text-xs text-gray-300">{showCredit ? 'Hide Balance' : 'Show Balance'}</span>
                  </button>
                  <button onClick={() => { setShowWalletMenu(false); navigate(createPageUrl('EarnCredits')); }} onContextMenu={(e) => e.preventDefault()} style={{ userSelect: 'none', WebkitTouchCallout: 'none' }} className="w-full text-left px-3 py-2 rounded-lg hover:bg-emerald-500/10 transition-all flex items-center gap-2 border border-emerald-500/20">
                    <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-xs text-emerald-400 font-medium">Earn Free</span>
                  </button>
                  <button onClick={() => { setShowWalletMenu(false); navigate(createPageUrl('BuyCredits')); }} onContextMenu={(e) => e.preventDefault()} style={{ userSelect: 'none', WebkitTouchCallout: 'none' }} className="w-full text-left px-3 py-2 rounded-lg hover:bg-blue-500/10 transition-all flex items-center gap-2 border border-blue-500/20">
                    <Wallet className="w-3.5 h-3.5 text-blue-400" />
                    <span className="text-xs text-blue-400 font-medium">Buy Credits</span>
                  </button>
                  <button onClick={() => { setShowWalletMenu(false); navigate(createPageUrl('WithdrawCredits')); }} onContextMenu={(e) => e.preventDefault()} style={{ userSelect: 'none', WebkitTouchCallout: 'none' }} className="w-full text-left px-3 py-2 rounded-lg hover:bg-purple-500/10 transition-all flex items-center gap-2 border border-purple-500/20">
                    <DollarSign className="w-3.5 h-3.5 text-purple-400" />
                    <span className="text-xs text-purple-400 font-medium">Withdraw</span>
                  </button>
                  <button onClick={() => { setShowWalletMenu(false); navigate(createPageUrl('Wallet')); }} onContextMenu={(e) => e.preventDefault()} style={{ userSelect: 'none', WebkitTouchCallout: 'none' }} className="w-full text-left px-3 py-2 rounded-lg hover:bg-amber-500/10 transition-all flex items-center gap-2 border border-amber-500/20">
                    <Wallet className="w-3.5 h-3.5 text-amber-400" />
                    <span className="text-xs text-amber-400 font-medium">My Wallet</span>
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </motion.div>
      </motion.div>

      {/* Plan Badge */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2 }}
        className="mx-4 mb-4"
      >
        {(() => {
          const version = getVersionLabel();
          return (
            <div className={`rounded-xl p-3.5 border flex items-center justify-between gap-2 ${version.isFree ? 'bg-gray-800/50 border-gray-700/50' : 'bg-gray-900/60 border-amber-500/30'}`}>
              <div className="text-left">
                <span className={`text-[10px] font-semibold tracking-wider ${version.isFree ? 'text-gray-500' : 'text-amber-500/80'}`}>
                  {version.isFree ? 'PLAN' : 'PLAN'}
                </span>
                <p className={`text-sm font-bold bg-gradient-to-r ${version.gradient} bg-clip-text text-transparent leading-tight`}>
                  {version.label}
                </p>
              </div>

            </div>
          );
        })()}
      </motion.div>





      <div className="px-4 pb-28">
        <div className="grid grid-cols-2 gap-3 mb-0">
          {categories.slice(0, 2).map((category, index) => {
            const isLocked = isRouteLocked(`/${category.page}`);
            return (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + index * 0.1 }}
            >
              <LockedSectionOverlay isLocked={isLocked} sectionName={category.title} path={`/${category.page}`}>
                <button
                  onClick={() => navigate(createPageUrl(category.page))}
                  onContextMenu={(e) => e.preventDefault()}
                  className={`w-full bg-gray-800/40 rounded-2xl p-4 border-2 transition-all duration-300 h-28 flex flex-col justify-between group ${index === 1 ? 'border-cyan-500/40' : 'border-blue-500/40'} cursor-pointer hover:border-opacity-80 active:scale-95`}
                  style={{ userSelect: 'none', WebkitUserSelect: 'none', WebkitTouchCallout: 'none' }}
                >
                  <div className="relative w-9 h-9">
                    <div className={`w-9 h-9 rounded-lg bg-gradient-to-br ${category.color} flex items-center justify-center group-hover:scale-110 transition-transform ${exploreCreatorsMode ? 'ring-2 ring-cyan-400/60 ring-offset-1 ring-offset-gray-900' : ''}`}>
                      <category.icon className="w-4 h-4 text-white" />
                    </div>
                    {exploreCreatorsMode && <SpinningExploreRing />}
                    {isCreatorMode && <SpinningCreatorRing />}
                  </div>
                  <div>
                    <h3 className="font-semibold text-xs text-white mb-0.5 leading-tight">{category.title}</h3>
                    <p className="text-[10px] text-gray-500 leading-tight">{category.description}</p>
                  </div>
                </button>
              </LockedSectionOverlay>
            </motion.div>
            );
          })}
        </div>

        {/* Icon row: 4-column grid — equal columns, all perfectly centered on same axis */}
        <div className="grid grid-cols-4 place-items-center w-full max-w-sm mx-auto my-2 px-2">

          {/* Col 1: Explore Creators toggle */}
          <div className="relative flex items-center justify-center w-10 h-10">
            <button
              onClick={toggleExploreCreators}
              className={`relative flex items-center justify-center w-10 h-10 rounded-full transition-all hover:scale-110 ${
                exploreCreatorsMode
                  ? 'bg-gradient-to-br from-cyan-500/60 to-blue-600/60 border border-cyan-500/30'
                  : 'bg-gray-800/60 border border-gray-700/50 hover:border-gray-600'
              }`}
            >
              <Users className={`w-4 h-4 ${exploreCreatorsMode ? 'text-cyan-300' : 'text-gray-500'}`} />
              {exploreCreatorsMode && (
                <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-cyan-500 border border-[#0a0a0f] rounded-full text-[7px] text-white flex items-center justify-center font-bold">
                  ✓
                </span>
              )}
            </button>
          </div>

          {/* Col 2: Notification Bell — center-left */}
          <div className="flex items-center justify-center w-10 h-10">
            <NotificationBell />
          </div>

          {/* Col 3: Creator Dashboard — center-right, mathematically between Bell and Creator Mode */}
          <div className="flex items-center justify-center w-10 h-10">
            {isCreatorEligible ? (
              <button onClick={() => navigate(createPageUrl("CreatorDashboard"))} onContextMenu={(e) => e.preventDefault()} className="relative flex items-center justify-center rounded-full transition-all hover:scale-110 bg-gray-800/60 border border-gray-700/50 hover:border-gray-600" style={{width:'2.5rem',height:'2.5rem',minWidth:'2.5rem',minHeight:'2.5rem',maxWidth:'2.5rem',maxHeight:'2.5rem', userSelect:'none', WebkitTouchCallout:'none'}}>
                <User className="w-4 h-4 text-gray-500" />
                {isCreatorMode && <SpinningCreatorRing />}
              </button>
            ) : (
              <div className="w-10 h-10" />
            )}
          </div>

          {/* Col 4: Creator Mode toggle */}
          <div className="flex items-center justify-center w-10 h-10">
            {isCreatorEligible ? (
              <div className="relative">
                <button
                  onClick={toggleCreatorMode}
                  className={`relative flex items-center justify-center w-10 h-10 rounded-full transition-all hover:scale-110 ${
                    isCreatorMode
                      ? 'bg-gradient-to-br from-purple-500/60 to-fuchsia-600/60 border border-purple-500/30'
                      : 'bg-gray-800/60 border border-gray-700/50 hover:border-gray-600'
                  }`}
                >
                  <Zap className={`w-4 h-4 ${isCreatorMode ? 'text-purple-300' : 'text-gray-500'}`} />
                  {isCreatorMode && (
                    <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-purple-500 border border-[#0a0a0f] rounded-full text-[7px] text-white flex items-center justify-center font-bold">
                      ✓
                    </span>
                  )}
                </button>
                {isCreatorMode && <SpinningCreatorRing />}
              </div>
            ) : (
              <div className="w-10 h-10" />
            )}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-3">
          {categories.slice(2, 4).map((category, index) => {
            const isTargetCard = index === 0; // only "Earn Online"
            const isLocked = isRouteLocked(`/${category.page}`);
            return (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + index * 0.1 }}
            >
              <LockedSectionOverlay isLocked={isLocked} sectionName={category.title} path={`/${category.page}`}>
                <button
                  onClick={() => navigate(createPageUrl(category.page))}
                  onContextMenu={(e) => e.preventDefault()}
                  className={`w-full bg-gray-800/40 rounded-2xl p-4 border-2 transition-all duration-300 h-28 flex flex-col justify-between group ${isTargetCard ? 'border-emerald-500/40' : 'border-amber-500/40'} cursor-pointer hover:border-opacity-80 active:scale-95`}
                  style={{ userSelect: 'none', WebkitUserSelect: 'none', WebkitTouchCallout: 'none' }}
                >
                  <div className="relative w-9 h-9">
                    <div className={`w-9 h-9 rounded-lg bg-gradient-to-br ${category.color} flex items-center justify-center group-hover:scale-110 transition-transform ${isTargetCard && exploreCreatorsMode ? 'ring-2 ring-cyan-400/60 ring-offset-1 ring-offset-gray-900' : ''}`}>
                      <category.icon className="w-4 h-4 text-white" />
                    </div>
                    {isTargetCard && exploreCreatorsMode && <SpinningExploreRing />}
                    {isCreatorMode && <SpinningCreatorRing />}
                  </div>
                  <div>
                    <h3 className="font-semibold text-xs text-white mb-0.5 leading-tight">{category.title}</h3>
                    <p className="text-[10px] text-gray-500 leading-tight">{category.description}</p>
                  </div>
                </button>
              </LockedSectionOverlay>
            </motion.div>
            );
          })}
        </div>



        {/* Featured Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="mb-3"
        >
          <div className="bg-gradient-to-r from-blue-600/20 to-cyan-600/20 rounded-xl p-4 border border-blue-500/30">
            <h3 className="font-semibold text-white text-sm mb-1">Start Your Journey</h3>
            <p className="text-xs text-gray-400 mb-3 leading-relaxed">Learn ethical digital skills and earn online with our comprehensive guides.</p>
            <button
              onClick={() => navigate(createPageUrl("LearnSkills"))}
              onContextMenu={(e) => e.preventDefault()}
              className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-500 to-cyan-500 text-white px-3 py-2 rounded-lg text-xs font-medium hover:opacity-90 transition-opacity active:scale-95"
              style={{ userSelect: 'none', WebkitUserSelect: 'none', WebkitTouchCallout: 'none' }}
            >
              Get Started
              <BookOpen className="w-3.5 h-3.5" />
            </button>
          </div>
        </motion.div>


      </div>
    </div>
  );
}