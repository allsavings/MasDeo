import React, { useState, useEffect } from 'react';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Users, Crown, ShieldCheck, ShieldX, CheckCircle, XCircle,
  Clock, Eye, Ban, ArrowLeft, RefreshCw, Search, ChevronDown,
  ChevronUp, FileImage, CircleDot, Zap, AlertTriangle, LogOut, Server,
  Code, Copy, Check, Download, Archive, Banknote, Coins, TrendingUp, Database, Bell,
  MessageSquare, Play, AlertCircle, Loader, Lock, Sparkles, Edit
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useRealtimeConfig } from '@/hooks/useRealtimeConfig';
import NovaToggle from '@/components/ui/NovaToggle';
import WithdrawalsTab from '../components/admin/WithdrawalsTab';
import CreditsTab from '../components/admin/CreditsTab';
import ImportExportTab from '../components/admin/ImportExportTab';
import SystemMirrorTab from '../components/admin/SystemMirrorTab';
import NotifyTab from '../components/admin/NotifyTab';
import AnalyticsTab from '../components/admin/AnalyticsTab';
import ContentModTab from '../components/admin/ContentModTab';
import CreatorMgmtTab from '../components/admin/CreatorMgmtTab';
import RenewalsTab from '../components/admin/RenewalsTab';
import SupportTab from '../components/admin/SupportTab';
import VideosTab from '../components/admin/VideosTab';
import VpsFilesTab from '../components/admin/VpsFilesTab';
import RecoveryRequestsTab from '../components/admin/RecoveryRequestsTab';
import PasswordVaultTab from '../components/admin/PasswordVaultTab';
import VpsManagementTab from '../components/admin/VpsManagementTab';
import AdControlTab from '../components/admin/AdControlTab';
import AIAssistantTab from '../components/admin/AIAssistantTab';
import ContentLiveEditor from '../components/admin/ContentLiveEditor';
import WIPPathManagerTab from '../components/admin/WIPPathManagerTab';
import WhatsNewTab from '../components/admin/WhatsNewTab';

// ── ADMIN AUTH CONSTANTS ──────────────────────────────────────────────────────
const ADMIN_EMAIL = '772mastersunlimited@gmail.com';
const STATIC_CODE = '0000ADMIN';
const SECOND_CODE = 'MASTER2025';
const SESSION_EXPIRY_HOURS = 24;

function AdminLogin({ onAuthenticated }) {
  const [stage, setStage] = useState('email');
  const [email, setEmail] = useState('');
  const [staticCode, setStaticCode] = useState('');
  const [secondCode, setSecondCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const generateSecureToken = () =>
    Array.from(crypto.getRandomValues(new Uint8Array(32)))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');

  const handleEmailSubmit = (e) => {
    e.preventDefault();
    setError('');
    if (email !== ADMIN_EMAIL) { setError('Invalid admin email. Access denied.'); return; }
    setStage('staticCode');
  };

  const handleStaticCodeSubmit = (e) => {
    e.preventDefault();
    setError('');
    if (staticCode !== STATIC_CODE) { setError('Invalid verification code. Access denied.'); return; }
    setStage('secondCode');
  };

  const handleSecondCodeSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (secondCode !== SECOND_CODE) { setError('Invalid second verification code. Access denied.'); return; }
    setLoading(true);
    const sessionToken = generateSecureToken();
    const sessionExpiresAt = new Date(Date.now() + SESSION_EXPIRY_HOURS * 60 * 60000);
    const session = await base44.entities.AdminSession.create({
      admin_email: ADMIN_EMAIL, otp_code: 'N/A', otp_attempts: 0, otp_used: true,
      otp_expires_at: sessionExpiresAt.toISOString(),
      session_token: sessionToken, session_expires_at: sessionExpiresAt.toISOString(), is_active: true
    });
    localStorage.setItem('adminSessionId', session.id);
    localStorage.setItem('adminSessionToken', sessionToken);
    setLoading(false);
    onAuthenticated(session.id);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0f] via-purple-900/20 to-[#0a0a0f] flex items-center justify-center p-6">
      <div className="w-full max-w-md bg-gray-800/40 backdrop-blur border border-gray-700/50 rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
            <span className="text-lg">🔐</span>
          </div>
          <div>
            <h2 className="text-white font-bold text-base">Admin Access</h2>
            <p className="text-xs text-gray-400">Masters | DeoVex</p>
          </div>
        </div>

        {stage === 'email' && (
          <form onSubmit={handleEmailSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-white mb-2">Admin Email</label>
              <Input type="email" placeholder="Enter admin email" value={email}
                onChange={e => setEmail(e.target.value)} disabled={loading}
                className="bg-gray-700/60 border-gray-600 text-white" autoFocus />
            </div>
            {error && <div className="flex gap-2 p-3 bg-red-500/10 border border-red-500/50 rounded-xl text-red-400 text-xs"><AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />{error}</div>}
            <Button type="submit" disabled={loading} className="w-full bg-purple-600 hover:bg-purple-700">Continue</Button>
          </form>
        )}

        {stage === 'staticCode' && (
          <form onSubmit={handleStaticCodeSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-white mb-2">Verification Code</label>
              <p className="text-xs text-gray-400 mb-3">Enter the first verification code</p>
              <Input type="text" placeholder="Enter code" value={staticCode}
                onChange={e => setStaticCode(e.target.value.toUpperCase())} disabled={loading}
                className="bg-gray-700/60 border-gray-600 text-white" autoFocus />
            </div>
            {error && <div className="flex gap-2 p-3 bg-red-500/10 border border-red-500/50 rounded-xl text-red-400 text-xs"><AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />{error}</div>}
            <Button type="submit" disabled={loading} className="w-full bg-purple-600 hover:bg-purple-700">Verify</Button>
            <Button type="button" variant="outline" onClick={() => { setStage('email'); setStaticCode(''); setError(''); }} className="w-full">Back</Button>
          </form>
        )}

        {stage === 'secondCode' && (
          <form onSubmit={handleSecondCodeSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-white mb-2">Second Verification Code</label>
              <p className="text-xs text-gray-400 mb-3">Enter the second verification code</p>
              <Input type="text" placeholder="Enter code" value={secondCode}
                onChange={e => setSecondCode(e.target.value.toUpperCase())} disabled={loading}
                className="bg-gray-700/60 border-gray-600 text-white" autoFocus />
            </div>
            {error && <div className="flex gap-2 p-3 bg-red-500/10 border border-red-500/50 rounded-xl text-red-400 text-xs"><AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />{error}</div>}
            <Button type="submit" disabled={loading} className="w-full bg-purple-600 hover:bg-purple-700">
              {loading ? <><Loader className="w-4 h-4 mr-2 animate-spin" />Logging in...</> : 'Verify & Login'}
            </Button>
            <Button type="button" variant="outline" onClick={() => { setStage('staticCode'); setSecondCode(''); setError(''); }} className="w-full">Back</Button>
          </form>
        )}
      </div>
    </div>
  );
}

// ── SOURCE FILES DATA ─────────────────────────────────────────────────────────
const BACKUP_FILES = [
  { name: 'Layout.js', category: 'Core', code: `import React, { useEffect, useState } from 'react';\nimport { Link, useLocation } from 'react-router-dom';\nimport { createPageUrl } from '@/utils';\nimport { Home, Globe, BookOpen, DollarSign, Grid2X2 } from 'lucide-react';\nimport { motion } from 'framer-motion';\nimport { base44 } from '@/api/base44Client';\n\n// Auth guard + bottom nav layout. Hides nav on Profile/Settings/HelpSupport/AuthScreen.\n// navItems: Home, Ethical, Learn, Earn, More(Profile)` },
  { name: 'entities/UserProfile.json', category: 'Entities', code: `{ "name":"UserProfile","properties":{ "nickname":{"type":"string","default":"Tk Master"},"handle":{"type":"string","default":"@MastersDeoVex"},"username":{"type":"string"},"phone":{"type":"string"},"profile_picture_url":{"type":"string"},"membership_type":{"type":"string","enum":["free","premium"],"default":"free"},"premium_type":{"type":"string","enum":["none","ethical_free_internet","learn_digital_skills","earn_online","all_in_one"],"default":"none"},"credits":{"type":"number","default":0},"is_banned":{"type":"boolean","default":false},"ban_reason":{"type":"string"},"last_seen":{"type":"string"} },"required":["nickname"] }` },
  { name: 'entities/Subscription.json', category: 'Entities', code: `{ "name":"Subscription","properties":{ "user_email":{"type":"string"},"user_name":{"type":"string"},"plan":{"type":"string","enum":["ethical_internet","learn_skills","earn_online","all_in_one"]},"status":{"type":"string","enum":["pending","active","rejected","cancelled"],"default":"pending"},"payment_proof_url":{"type":"string"},"amount_paid":{"type":"number"},"start_date":{"type":"string","format":"date"},"end_date":{"type":"string","format":"date"},"approved_by":{"type":"string"},"approved_date":{"type":"string","format":"date"},"creator_mode_enabled":{"type":"boolean","default":false},"creator_verified":{"type":"boolean","default":false},"creator_public":{"type":"boolean","default":false},"notes":{"type":"string"} },"required":["user_email","plan"] }` },
  { name: 'entities/CreatorProfile.json', category: 'Entities', code: `{ "name":"CreatorProfile","properties":{ "user_email":{"type":"string"},"creator_type":{"type":"string","enum":["ethical_free_internet","learn_digital_skills","earn_online"]},"verified":{"type":"boolean","default":false},"verification_requested":{"type":"boolean","default":false},"trust_score":{"type":"number","default":0},"strikes":{"type":"number","default":0},"banned":{"type":"boolean","default":false},"bio":{"type":"string"},"total_ratings":{"type":"number","default":0},"average_rating":{"type":"number","default":0} },"required":["user_email","creator_type"] }` },
  { name: 'entities/CreatorSettings.json', category: 'Entities', code: `{ "name":"CreatorSettings","properties":{ "user_email":{"type":"string"},"is_public":{"type":"boolean","default":false},"platforms":{"type":"array","items":{"type":"string","enum":["ethical","learn","earn"]}},"all_platforms":{"type":"boolean","default":false} },"required":["user_email"] }` },
  { name: 'entities/Follow.json', category: 'Entities', code: `{ "name":"Follow","properties":{ "user_email":{"type":"string"},"creator_id":{"type":"string"},"creator_email":{"type":"string"} },"required":["user_email","creator_id","creator_email"] }` },
  { name: 'entities/Withdrawal.json', category: 'Entities', code: `{ "name":"Withdrawal","properties":{ "user_email":{"type":"string"},"amount":{"type":"number"},"bank_name":{"type":"string"},"account_number":{"type":"string"},"account_holder_name":{"type":"string"},"status":{"type":"string","enum":["pending","processing","completed","rejected"],"default":"pending"},"notes":{"type":"string"} },"required":["user_email","amount","bank_name","account_number","account_holder_name"] }` },
  { name: 'entities/AdminSession.json', category: 'Entities', code: `{ "name":"AdminSession","properties":{ "session_token":{"type":"string"},"session_expires_at":{"type":"string","format":"date-time"},"is_active":{"type":"boolean","default":true},"admin_email":{"type":"string"} } }` },
  { name: 'pages/Home.jsx', category: 'Pages', code: `// Main dashboard. PIN lock, loads UserProfile+Subscriptions+CreatorProfile.\n// Wallet menu (credits), plan badge (combo detection), Creator Mode toggle,\n// Explore Creators toggle, Creator Dashboard link, category cards` },
  { name: 'pages/Admin.jsx', category: 'Pages', code: `// AdminGuard-protected. 6 tabs: Subscriptions|Users|Credits|Withdrawals|Settings|Backup.\n// Subs: approve/reject/cancel, grant creator, verify, set public, ban/unban.\n// Users: online status (last_seen<5min), ban/unban, join date, plan badges.\n// Credits: add/deduct/set credits per user.\n// Withdrawals: review/approve/reject/complete withdrawal requests.\n// Settings: VPS host+token for CDN/WAF scanner.\n// Backup: code backup section with download.\n// ADMIN_EMAIL=772mastersunlimited@gmail.com` },
];

const APK_STRUCTURE = {
  stats: [
    { label: "APK Size (est.)", value: "~4.2 MB", sub: "Production build", color: "text-amber-400", bg: "bg-amber-500/10", border: "border-amber-500/20" },
    { label: "Total Files", value: "87 files", sub: "JS/JSX + JSON + config", color: "text-cyan-400", bg: "bg-cyan-500/10", border: "border-cyan-500/20" },
  ],
  tech: ["React 18", "Vite", "Tailwind CSS", "shadcn/ui", "framer-motion", "lucide-react", "react-router-dom", "Base44 SDK"],
};

function CopyBtn({ text, label = 'Copy' }) {
  const [copied, setCopied] = useState(false);
  const copy = () => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); };
  return (
    <button onClick={copy} className="flex items-center gap-1 text-[11px] text-gray-400 hover:text-white px-2 py-1 rounded-lg hover:bg-gray-700/50 transition-all flex-shrink-0">
      {copied ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
      {copied ? 'Copied!' : label}
    </button>
  );
}

const PLAN_LABELS = { ethical_internet: 'Ethical', learn_skills: 'Learn', earn_online: 'Earn', all_in_one: 'All In One' };
const PLAN_COLORS = { ethical_internet: 'from-blue-500 to-cyan-500', learn_skills: 'from-purple-500 to-blue-500', earn_online: 'from-emerald-500 to-cyan-500', all_in_one: 'from-amber-500 to-orange-500' };

const TABS = [
  { id: 'subscriptions', label: 'Subs', icon: Crown },
  { id: 'vpnpaid', label: 'VPN Paid', icon: Zap },
  { id: 'users', label: 'Users', icon: Users },
  { id: 'analytics', label: 'Analytics', icon: TrendingUp },
  { id: 'videos', label: 'Videos', icon: Play },
  { id: 'credits', label: 'Credits', icon: Coins },
  { id: 'withdrawals', label: 'Withdrawals', icon: Banknote },
  { id: 'renewals', label: 'Renewals', icon: Clock },
  { id: 'content', label: 'Content', icon: Archive },
  { id: 'creators', label: 'Creators', icon: ShieldCheck },
  { id: 'recovery', label: 'Recovery', icon: ShieldX },
  { id: 'vault', label: 'Vault', icon: Lock },
  { id: 'support', label: 'Support', icon: CircleDot },
  { id: 'vpsfiles', label: 'VPS Files', icon: Database },
  { id: 'ads', label: 'Ads', icon: Zap },
  { id: 'settings', label: 'Settings', icon: Server },
  { id: 'notify', label: 'Notify', icon: Bell },
  { id: 'vps_mgmt', label: 'VPS Mgmt', icon: Server },
  { id: 'sync', label: 'Sync', icon: Database },
  { id: 'wip', label: 'WIP Lock', icon: Lock },
  { id: 'whatsnew', label: "What's New", icon: Sparkles },
  { id: 'editor', label: 'Editor', icon: Edit },
  { id: 'ai', label: 'AI', icon: Sparkles },
  { id: 'backup', label: 'Backup', icon: Code },
  { id: 'devnotes', label: 'Dev Notes', icon: AlertTriangle },
];

function AdminDashboard({ sessionId: initialSessionId }) {
  const [user, setUser] = useState(null);
  const [tab, setTab] = useState('subscriptions');
  const [backupCategory, setBackupCategory] = useState('All');
  const [expandedFile, setExpandedFile] = useState(null);
  const [vpsHost, setVpsHost] = useState(() => localStorage.getItem('vps_host') || 'fx.tkmaster.qzz.io');
  const [vpsToken, setVpsToken] = useState(() => localStorage.getItem('vps_token') || '123000');
  const [vpsSaved, setVpsSaved] = useState(false);
  const [subscriptions, setSubscriptions] = useState([]);
  const [profiles, setProfiles] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [withdrawals, setWithdrawals] = useState([]);
  const [vpnNodes, setVpnNodes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [expandedSub, setExpandedSub] = useState(null);
  const [noteText, setNoteText] = useState({});
  const [banReason, setBanReason] = useState({});
  const { config: realtimeConfig, updateConfig } = useRealtimeConfig();
  const [adRunCount, setAdRunCount] = useState(() => parseInt(localStorage.getItem('ad_run_count') || '2'));
  const [adRestCount, setAdRestCount] = useState(() => parseInt(localStorage.getItem('ad_rest_count') || '2'));

  useEffect(() => { loadData(); }, []);

  const loadData = async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const userData = await base44.auth.me();
      setUser(userData);
      const [subs, profs, users, wds, nodes] = await Promise.all([
        base44.entities.Subscription.list('-created_date', 200),
        base44.entities.UserProfile.list('-created_date', 200),
        base44.entities.User.list('-created_date', 200),
        base44.entities.Withdrawal.list('-created_date', 200),
        base44.entities.ISPNode.list('-created_date', 500),
      ]);
      setSubscriptions(subs);
      setProfiles(profs);
      setAllUsers(users);
      setWithdrawals(wds);
      setVpnNodes(nodes);
    } catch (e) { console.error(e); }
    if (!silent) setLoading(false);
  };

  const updateSub = async (id, data) => { await base44.entities.Subscription.update(id, data); loadData(true); };

  const banUser = async (email, reason) => {
    const prof = profiles.find(p => p.created_by === email);
    if (prof) { await base44.entities.UserProfile.update(prof.id, { is_banned: true, ban_reason: reason || 'Banned by admin' }); loadData(true); }
  };
  const unbanUser = async (email) => {
    const prof = profiles.find(p => p.created_by === email);
    if (prof) { await base44.entities.UserProfile.update(prof.id, { is_banned: false, ban_reason: '' }); loadData(true); }
  };

  const handleLogout = async () => {
    const storedId = localStorage.getItem('adminSessionId');
    if (storedId) await base44.entities.AdminSession.update(storedId, { is_active: false });
    localStorage.removeItem('adminSessionId');
    localStorage.removeItem('adminSessionToken');
    window.location.reload();
  };

  if (loading) return (
    <div className="min-h-screen bg-[#0a0a0f] text-white flex items-center justify-center">
      <div className="flex items-center gap-3 text-gray-400">
        <RefreshCw className="w-5 h-5 animate-spin" /> Loading admin panel...
      </div>
    </div>
  );

  const pendingSubs = subscriptions.filter(s => s.status === 'pending');
  const activeSubs = subscriptions.filter(s => s.status === 'active');
  const bannedProfiles = profiles.filter(p => p.is_banned);
  const pendingWithdrawals = withdrawals.filter(w => w.status === 'pending');
  const vpnPendingCount = vpnNodes.filter(n => ['pending_payment','pending_approval'].includes(n.status)).length;

  const filteredSubs = subscriptions.filter(s => {
    const matchSearch = search === '' || s.user_email?.toLowerCase().includes(search.toLowerCase()) || s.user_name?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === 'all' || s.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const filteredUsers = allUsers.filter(u =>
    search === '' || u.email?.toLowerCase().includes(search.toLowerCase()) || u.full_name?.toLowerCase().includes(search.toLowerCase())
  );

  const getUserProfile = (email) => profiles.find(p => p.created_by === email);
  const getUserSubs = (email) => subscriptions.filter(s => s.user_email === email && s.status === 'active');
  const isOnline = (email) => {
    const prof = getUserProfile(email);
    if (!prof?.last_seen) return false;
    return (Date.now() - new Date(prof.last_seen).getTime()) < 5 * 60 * 1000;
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#07070e] to-[#0f0f1a] text-white pb-10">
      {/* Header */}
      <div className="bg-gray-900/90 border-b border-gray-800/60 px-4 pt-5 pb-3 sticky top-0 z-10 backdrop-blur-xl">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Link to={createPageUrl("Home")} className="p-2 bg-gray-800/60 rounded-xl hover:bg-gray-700/60 transition-colors">
              <ArrowLeft className="w-4 h-4 text-gray-400" />
            </Link>
            <div>
              <h1 className="text-base font-bold flex items-center gap-2">
                <Crown className="w-4 h-4 text-amber-400" />
                <span className="bg-gradient-to-r from-amber-400 to-orange-400 bg-clip-text text-transparent">Masters Admin</span>
              </h1>
              <p className="text-[10px] text-gray-500">{user?.email}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={loadData} className="p-2 bg-gray-800/60 rounded-xl hover:bg-gray-700/60 transition-colors">
              <RefreshCw className="w-4 h-4 text-gray-400" />
            </button>
            <button onClick={handleLogout} className="p-2 bg-red-500/15 hover:bg-red-500/30 rounded-xl transition-colors">
              <LogOut className="w-4 h-4 text-red-400" />
            </button>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-5 gap-1.5 mb-4">
          {[
            { label: 'Users', value: allUsers.length, color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/20' },
            { label: 'Active', value: activeSubs.length, color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/20' },
            { label: 'Pending', value: pendingSubs.length, color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20' },
            { label: 'Withdraw', value: pendingWithdrawals.length, color: 'text-cyan-400', bg: 'bg-cyan-500/10', border: 'border-cyan-500/20' },
            { label: 'Banned', value: bannedProfiles.length, color: 'text-red-400', bg: 'bg-red-500/10', border: 'border-red-500/20' },
          ].map(s => (
            <div key={s.label} className={`${s.bg} border ${s.border} rounded-xl p-2 text-center`}>
              <p className={`text-sm font-bold ${s.color}`}>{s.value}</p>
              <p className="text-[9px] text-gray-500 leading-tight">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Tabs - scrollable */}
        <div className="flex gap-1 overflow-x-auto pb-0.5 scrollbar-hide scroll-container">
          {TABS.map(t => {
            const hasBadge = (t.id === 'subscriptions' && pendingSubs.length > 0) || (t.id === 'withdrawals' && pendingWithdrawals.length > 0) || (t.id === 'support') || (t.id === 'vpnpaid' && vpnPendingCount > 0);
            return (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`relative flex-shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                  tab === t.id
                    ? 'bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-400 border border-amber-500/30'
                    : 'text-gray-500 hover:text-gray-300 hover:bg-gray-800/40'
                }`}>
                <t.icon className="w-3.5 h-3.5" />
                {t.label}
                {hasBadge && <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-red-500 rounded-full" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Search + Filter */}
      {(tab === 'subscriptions' || tab === 'users') && (
        <div className="px-4 py-3 flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by email or name..."
              className="bg-gray-800/40 border-gray-700 text-white text-sm pl-9" />
          </div>
          {tab === 'subscriptions' && (
            <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}
              className="bg-gray-800/40 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm">
              <option value="all">All</option>
              <option value="pending">Pending</option>
              <option value="active">Active</option>
              <option value="rejected">Rejected</option>
              <option value="cancelled">Cancelled</option>
            </select>
          )}
        </div>
      )}

      {/* SUBSCRIPTIONS TAB */}
      {tab === 'subscriptions' && (
        <div className="px-4 space-y-3">
          {filteredSubs.length === 0 && <p className="text-center text-gray-600 text-sm py-10">No subscriptions found.</p>}
          {filteredSubs.map(sub => {
            const isExpanded = expandedSub === sub.id;
            const userBanned = getUserProfile(sub.user_email)?.is_banned;
            const statusColors = {
              pending: 'text-amber-400 bg-amber-500/20 border-amber-500/30',
              active: 'text-green-400 bg-green-500/20 border-green-500/30',
              rejected: 'text-red-400 bg-red-500/20 border-red-500/30',
              cancelled: 'text-gray-400 bg-gray-500/20 border-gray-700/30'
            };
            return (
              <motion.div key={sub.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                className="bg-gray-800/40 rounded-2xl border border-gray-700/50 overflow-hidden">
                <div className={`h-1 bg-gradient-to-r ${PLAN_COLORS[sub.plan] || 'from-gray-500 to-gray-600'}`} />
                <div className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-white text-sm">{sub.user_name || sub.user_email}</p>
                        {userBanned && <span className="text-xs bg-red-500/20 text-red-400 px-1.5 py-0.5 rounded-full border border-red-500/30">BANNED</span>}
                      </div>
                      <p className="text-xs text-gray-500">{sub.user_email}</p>
                      <div className="flex items-center gap-2 mt-1.5">
                        <span className={`text-xs px-2 py-0.5 rounded-full border ${statusColors[sub.status]}`}>{sub.status}</span>
                        <span className="text-xs text-gray-500">{PLAN_LABELS[sub.plan]} • R{sub.amount_paid}/mo</span>
                      </div>
                    </div>
                    <button onClick={() => setExpandedSub(isExpanded ? null : sub.id)} className="p-1.5 rounded-lg bg-gray-700/50">
                      {isExpanded ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
                    </button>
                  </div>

                  <div className="flex gap-2 flex-wrap">
                    {sub.status === 'pending' && (
                      <>
                        <button onClick={() => updateSub(sub.id, { status: 'active', approved_by: user.email, approved_date: new Date().toISOString().split('T')[0] })}
                          className="flex items-center gap-1 text-xs bg-green-500/20 text-green-400 border border-green-500/30 px-3 py-1.5 rounded-xl hover:bg-green-500/30 transition-colors">
                          <CheckCircle className="w-3 h-3" /> Approve
                        </button>
                        <button onClick={() => updateSub(sub.id, { status: 'rejected' })}
                          className="flex items-center gap-1 text-xs bg-red-500/20 text-red-400 border border-red-500/30 px-3 py-1.5 rounded-xl hover:bg-red-500/30 transition-colors">
                          <XCircle className="w-3 h-3" /> Reject
                        </button>
                      </>
                    )}
                    {sub.status === 'active' && !sub.creator_mode_enabled && (
                      <button onClick={() => updateSub(sub.id, { creator_mode_enabled: true })}
                        className="flex items-center gap-1 text-xs bg-purple-500/20 text-purple-400 border border-purple-500/30 px-3 py-1.5 rounded-xl hover:bg-purple-500/30 transition-colors">
                        <Zap className="w-3 h-3" /> Grant Creator
                      </button>
                    )}
                    {sub.status === 'active' && sub.creator_mode_enabled && !sub.creator_verified && (
                      <button onClick={() => updateSub(sub.id, { creator_verified: true })}
                        className="flex items-center gap-1 text-xs bg-blue-500/20 text-blue-400 border border-blue-500/30 px-3 py-1.5 rounded-xl hover:bg-blue-500/30 transition-colors">
                        <ShieldCheck className="w-3 h-3" /> Verify Creator
                      </button>
                    )}
                    {sub.status === 'active' && sub.creator_mode_enabled && (
                      <button onClick={() => updateSub(sub.id, { creator_public: !sub.creator_public })}
                        className={`flex items-center gap-1 text-xs border px-3 py-1.5 rounded-xl transition-colors ${sub.creator_public ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30' : 'bg-gray-700/50 text-gray-400 border-gray-700/50'}`}>
                        <Eye className="w-3 h-3" /> {sub.creator_public ? 'Public ✓' : 'Set Public'}
                      </button>
                    )}
                    {sub.status === 'active' && (
                      <button onClick={() => updateSub(sub.id, { status: 'cancelled' })}
                        className="flex items-center gap-1 text-xs bg-gray-700/50 text-gray-400 border border-gray-700/50 px-3 py-1.5 rounded-xl hover:bg-gray-700 transition-colors">
                        <XCircle className="w-3 h-3" /> Cancel
                      </button>
                    )}
                  </div>

                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="mt-3 space-y-3">
                        <div className="bg-gray-900/50 rounded-xl p-3 text-xs space-y-1 text-gray-400">
                          <p>Submitted: {new Date(sub.created_date).toLocaleString()}</p>
                          {sub.approved_date && <p>Approved: {sub.approved_date}</p>}
                          {sub.approved_by && <p>By: {sub.approved_by}</p>}
                          {sub.creator_mode_enabled && <p className="text-purple-400">⚡ Creator Mode {sub.creator_verified ? '• Verified ✓' : ''}</p>}
                          {sub.creator_public && <p className="text-cyan-400">🌐 Public Profile</p>}
                        </div>
                        {sub.payment_proof_url && (
                          <a href={sub.payment_proof_url} target="_blank" rel="noopener noreferrer"
                            className="flex items-center gap-2 text-xs text-blue-400 bg-blue-500/10 border border-blue-500/20 rounded-xl px-3 py-2 hover:bg-blue-500/20 transition-colors">
                            <FileImage className="w-4 h-4" /> View Payment Proof
                          </a>
                        )}
                        <div className="flex gap-2">
                          <Input value={noteText[sub.id] ?? sub.notes ?? ''} onChange={e => setNoteText(n => ({ ...n, [sub.id]: e.target.value }))}
                            placeholder="Admin note..." className="bg-gray-900/50 border-gray-700 text-white text-xs flex-1" />
                          <button onClick={() => updateSub(sub.id, { notes: noteText[sub.id] })}
                            className="px-3 py-1.5 bg-blue-600/50 hover:bg-blue-600 rounded-lg text-xs text-white transition-colors">Save</button>
                        </div>
                        {!userBanned ? (
                          <div className="flex gap-2">
                            <Input value={banReason[sub.user_email] ?? ''} onChange={e => setBanReason(r => ({ ...r, [sub.user_email]: e.target.value }))}
                              placeholder="Ban reason..." className="bg-gray-900/50 border-gray-700 text-white text-xs flex-1" />
                            <button onClick={() => banUser(sub.user_email, banReason[sub.user_email])}
                              className="flex items-center gap-1 px-3 py-1.5 bg-red-600/50 hover:bg-red-600 rounded-lg text-xs text-white transition-colors">
                              <Ban className="w-3 h-3" /> Ban
                            </button>
                          </div>
                        ) : (
                          <button onClick={() => unbanUser(sub.user_email)}
                            className="w-full flex items-center justify-center gap-2 py-2 bg-green-500/20 text-green-400 border border-green-500/30 rounded-xl text-xs hover:bg-green-500/30 transition-colors">
                            <ShieldCheck className="w-3 h-3" /> Unban User
                          </button>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* VPN PAID TAB */}
      {tab === 'vpnpaid' && (
        <div className="px-4 py-3 space-y-3">
          {/* Stats row */}
          <div className="grid grid-cols-4 gap-2 mb-2">
            {[
              { label: 'Total', val: vpnNodes.length, color: 'text-violet-400' },
              { label: 'Active', val: vpnNodes.filter(n => n.status === 'active').length, color: 'text-green-400' },
              { label: 'Pending', val: vpnPendingCount, color: 'text-amber-400' },
              { label: 'Revenue', val: `R${vpnNodes.filter(n => n.status === 'active').reduce((s, n) => s + (n.amount_paid || 0), 0)}`, color: 'text-cyan-400' },
            ].map(s => (
              <div key={s.label} className="bg-gray-900/60 border border-gray-700/40 rounded-xl p-2.5 text-center">
                <p className={`text-base font-black ${s.color}`}>{s.val}</p>
                <p className="text-[9px] text-gray-500">{s.label}</p>
              </div>
            ))}
          </div>

          {/* Quick link to full admin */}
          <Link to="/ISPNodeAdmin"
            className="flex items-center justify-between w-full bg-gradient-to-r from-violet-600/20 to-cyan-600/20 border border-violet-500/40 rounded-2xl px-4 py-3 hover:border-violet-400/70 transition-all">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-500 to-cyan-500 flex items-center justify-center">
                <Zap className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-sm font-bold text-white">Open Full VPN Paid Admin</p>
                <p className="text-xs text-violet-300">Approve orders · Set VLESS · Send notifications</p>
              </div>
            </div>
            <ChevronDown className="w-4 h-4 text-gray-500 -rotate-90" />
          </Link>

          {/* All paid users list */}
          {vpnNodes.length === 0 ? (
            <div className="text-center py-10 text-gray-600 text-sm">No VPN paid users yet.</div>
          ) : (
            vpnNodes.map(node => {
              const statusColors = {
                pending_payment:  'text-yellow-400 bg-yellow-500/10 border-yellow-500/30',
                pending_approval: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
                deploying:        'text-blue-400 bg-blue-500/10 border-blue-500/30',
                active:           'text-green-400 bg-green-500/10 border-green-500/30',
                expired:          'text-red-400 bg-red-500/10 border-red-500/30',
                rejected:         'text-red-400 bg-red-500/10 border-red-500/30',
              };
              const statusLabels = {
                pending_payment: 'Pending Payment', pending_approval: 'Awaiting Approval',
                deploying: 'Deploying', active: 'Active', expired: 'Expired', rejected: 'Rejected',
              };
              return (
                <motion.div key={node.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                  className="bg-gray-800/40 border border-gray-700/50 rounded-2xl p-3">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-white truncate">{node.user_name}</p>
                      <p className="text-xs text-gray-500 font-mono truncate">{node.user_email}</p>
                      {node.whatsapp && <p className="text-xs text-green-400">📱 {node.whatsapp}</p>}
                    </div>
                    <span className={`text-xs font-bold px-2 py-0.5 rounded-full border ml-2 flex-shrink-0 ${statusColors[node.status] || 'text-gray-400 bg-gray-700/30 border-gray-600/30'}`}>
                      {statusLabels[node.status] || node.status}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap text-[10px]">
                    <span className="bg-gray-700/60 border border-gray-600/40 text-gray-300 px-2 py-0.5 rounded-full capitalize">{node.node_type}-Access</span>
                    <span className="bg-cyan-500/15 border border-cyan-500/25 text-cyan-300 px-2 py-0.5 rounded-full">{node.plan === '30days' ? 'R50 / 30d' : 'R30 / 14d'}</span>
                    {node.expiry_date && <span className="bg-gray-700/60 border border-gray-600/40 text-gray-400 px-2 py-0.5 rounded-full">Expires: {node.expiry_date}</span>}
                    <span className="bg-gray-700/60 border border-gray-600/40 text-gray-400 px-2 py-0.5 rounded-full capitalize">{node.payment_method?.replace('_',' ')}</span>
                  </div>
                  {node.vless_string && (
                    <p className="text-[10px] text-green-400 font-mono truncate mt-1.5">✅ Config: {node.vless_string.slice(0, 50)}...</p>
                  )}
                  {node.admin_notes && (
                    <p className="text-[10px] text-gray-500 mt-1">📝 {node.admin_notes}</p>
                  )}
                  {/* Created date */}
                  <p className="text-[10px] text-gray-600 mt-1">Submitted: {node.created_date ? new Date(node.created_date).toLocaleDateString('en-ZA') : '—'}</p>
                </motion.div>
              );
            })
          )}
        </div>
      )}

      {/* ANALYTICS TAB */}
      {tab === 'analytics' && (
        <div className="py-3">
          <AnalyticsTab allUsers={allUsers} subscriptions={subscriptions} profiles={profiles} />
        </div>
      )}

      {/* VIDEOS TAB */}
      {tab === 'videos' && (
        <div className="py-3">
          <VideosTab />
        </div>
      )}

      {/* RENEWALS TAB */}
      {tab === 'renewals' && (
        <div className="py-3">
          <RenewalsTab subscriptions={subscriptions} />
        </div>
      )}

      {/* CONTENT MODERATION TAB */}
      {tab === 'content' && (
        <div className="py-3">
          <ContentModTab />
        </div>
      )}

      {/* CREATORS TAB */}
      {tab === 'creators' && (
        <div className="py-3">
          <CreatorMgmtTab />
        </div>
      )}

      {/* RECOVERY REQUESTS TAB */}
      {tab === 'recovery' && (
        <div className="py-3">
          <RecoveryRequestsTab />
        </div>
      )}

      {/* PASSWORD VAULT TAB */}
      {tab === 'vault' && (
        <div className="py-3">
          <PasswordVaultTab />
        </div>
      )}

      {/* SUPPORT TAB */}
      {tab === 'support' && (
        <div className="py-3">
          <SupportTab />
        </div>
      )}

      {/* CREDITS TAB */}
      {tab === 'credits' && (
        <div className="py-3">
          <CreditsTab profiles={profiles} allUsers={allUsers} onRefresh={() => loadData(true)} />
        </div>
      )}

      {/* WITHDRAWALS TAB */}
      {tab === 'withdrawals' && (
        <div className="py-3">
          <WithdrawalsTab withdrawals={withdrawals} onRefresh={() => loadData(true)} />
        </div>
      )}

      {/* VPS FILES TAB */}
      {tab === 'vpsfiles' && (
        <div className="py-3">
          <VpsFilesTab />
        </div>
      )}

      {/* ADS CONTROL TAB */}
      {tab === 'ads' && (
        <div className="px-4 py-4">
          <AdControlTab />
        </div>
      )}

      {/* SETTINGS TAB */}
      {tab === 'settings' && (
        <div className="px-4 py-4 space-y-4">

          {/* VPN Node Admin Shortcut */}
          <Link to="/ISPNodeAdmin">
            <div className="bg-gradient-to-r from-violet-600/20 to-cyan-600/20 rounded-2xl p-4 border border-violet-500/40 hover:border-violet-400/70 transition-all group flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500 to-cyan-500 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                <Server className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <p className="font-bold text-white">Lets VPN Go — Paid Admin</p>
                <p className="text-xs text-violet-300">Manage paid subscriptions, approve orders, send notifications</p>
              </div>
              <span className="text-xs text-gray-500">Open ↗</span>
            </div>
          </Link>



            {/* VPS Scanner Settings */}
            <div className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                <Server className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-white">VPS Scanner Settings</h3>
                <p className="text-xs text-gray-400">Used by CDN & WAF Scanner engine</p>
              </div>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-gray-400 mb-1 block">Server Address</label>
                <Input value={vpsHost} onChange={e => setVpsHost(e.target.value)} className="bg-gray-900/60 border-gray-700 text-white font-mono text-sm" />
              </div>
              <div>
                <label className="text-xs text-gray-400 mb-1 block">Bearer Token</label>
                <Input value={vpsToken} onChange={e => setVpsToken(e.target.value)} type="password" className="bg-gray-900/60 border-gray-700 text-white font-mono text-sm" />
              </div>
              <button onClick={() => { localStorage.setItem('vps_host', vpsHost); localStorage.setItem('vps_token', vpsToken); setVpsSaved(true); setTimeout(() => setVpsSaved(false), 2000); }}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-semibold text-sm py-2.5 rounded-xl transition-all">
                {vpsSaved ? '✓ Saved!' : 'Save Settings'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* USERS TAB */}
      {tab === 'users' && (
        <div className="px-4 space-y-3">
          {filteredUsers.length === 0 && <p className="text-center text-gray-600 text-sm py-10">No users found.</p>}
          <div className="max-h-[600px] overflow-y-auto scroll-container">
          {filteredUsers.map((u, i) => {
            const prof = getUserProfile(u.email);
            const userSubs = getUserSubs(u.email);
            const online = isOnline(u.email);
            const banned = prof?.is_banned;
            return (
              <motion.div key={u.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}
                className="bg-gray-800/40 rounded-2xl p-4 border border-gray-700/50">
                <div className="flex items-start gap-3">
                  <div className="relative flex-shrink-0">
                    {prof?.profile_picture_url ? (
                      <img src={prof.profile_picture_url} alt="" className="w-11 h-11 rounded-full object-cover" />
                    ) : (
                      <div className="w-11 h-11 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm">
                        {(u.full_name || u.email || '?')[0].toUpperCase()}
                      </div>
                    )}
                    <div className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-gray-900 ${online ? 'bg-green-400' : 'bg-gray-600'}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="font-semibold text-white text-sm truncate">{u.full_name || 'No name'}</p>
                      <span className={`text-xs px-1.5 py-0.5 rounded-full ${online ? 'bg-green-500/20 text-green-400' : 'bg-gray-700/50 text-gray-500'}`}>
                        {online ? '● Online' : '○ Offline'}
                      </span>
                      {banned && <span className="text-xs bg-red-500/20 text-red-400 px-1.5 py-0.5 rounded-full">BANNED</span>}
                      {u.role === 'admin' && <span className="text-xs bg-amber-500/20 text-amber-400 px-1.5 py-0.5 rounded-full">Admin</span>}
                    </div>
                    <p className="text-xs text-gray-500 truncate">{u.email}</p>
                    {userSubs.length > 0 && (
                      <div className="flex gap-1 mt-1.5 flex-wrap">
                        {userSubs.map(s => (
                          <span key={s.id} className={`text-[10px] bg-gradient-to-r ${PLAN_COLORS[s.plan]} text-white px-2 py-0.5 rounded-full`}>{PLAN_LABELS[s.plan]}</span>
                        ))}
                      </div>
                    )}
                    {prof?.last_seen && <p className="text-[10px] text-gray-600 mt-1">Last seen: {new Date(prof.last_seen).toLocaleString()}</p>}
                    {banned && prof?.ban_reason && (
                      <p className="text-xs text-red-400 mt-1 flex items-center gap-1"><AlertTriangle className="w-3 h-3" /> {prof.ban_reason}</p>
                    )}
                    <div className="flex gap-2 mt-2 flex-wrap">
                      {!banned ? (
                        <div className="flex gap-2">
                          <Input value={banReason[u.email] ?? ''} onChange={e => setBanReason(r => ({ ...r, [u.email]: e.target.value }))}
                            placeholder="Ban reason..." className="bg-gray-900/50 border-gray-700 text-white text-xs h-7 w-36" />
                          <button onClick={() => banUser(u.email, banReason[u.email])}
                            className="flex items-center gap-1 px-2 py-1 bg-red-600/40 hover:bg-red-600/70 rounded-lg text-xs text-red-300 transition-colors">
                            <Ban className="w-3 h-3" /> Ban
                          </button>
                        </div>
                      ) : (
                        <button onClick={() => unbanUser(u.email)}
                          className="flex items-center gap-1 px-3 py-1 bg-green-500/20 text-green-400 border border-green-500/30 rounded-lg text-xs hover:bg-green-500/30 transition-colors">
                          <ShieldCheck className="w-3 h-3" /> Unban
                        </button>
                      )}
                      <p className="text-xs text-gray-600 self-center">Joined {new Date(u.created_date).toLocaleDateString()}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
          </div>
          </div>
          )}

          {/* VPS MANAGEMENT TAB */}
          {tab === 'vps_mgmt' && (
        <div className="py-3">
          <VpsManagementTab />
        </div>
      )}

      {/* NOTIFY TAB */}
      {tab === 'notify' && (
        <div className="py-3">
          <NotifyTab allUsers={allUsers} />
        </div>
      )}

      {/* WIP PATH MANAGER TAB */}
      {tab === 'wip' && (
        <div className="px-4 py-4">
          <WIPPathManagerTab />
        </div>
      )}

      {/* AI ASSISTANT TAB */}
      {tab === 'ai' && (
        <div className="px-4 py-4">
          <AIAssistantTab />
        </div>
      )}

      {/* WHAT'S NEW TAB */}
      {tab === 'whatsnew' && (
        <div className="py-3">
          <WhatsNewTab />
        </div>
      )}

      {/* LIVE CONTENT EDITOR TAB */}
      {tab === 'editor' && (
        <div className="px-4 py-4">
          <ContentLiveEditor />
        </div>
      )}

      {/* SYNC TAB */}
      {tab === 'sync' && (
        <div className="py-3">
          <SystemMirrorTab />
        </div>
      )}

      {/* DEV NOTES TAB */}
      {tab === 'devnotes' && (
        <div className="px-4 py-4 space-y-4">

          {/* ── CARD 0: AI GUARDRAIL SYSTEM ─────────────────────────────── */}
          <div className="bg-gradient-to-br from-green-900/30 to-emerald-900/20 rounded-2xl border border-green-500/30 p-4 space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-base">🤖</span>
              <h3 className="text-green-300 font-bold text-sm">AI Guardrail System</h3>
              <span className="ml-auto text-[9px] font-bold bg-green-500/20 text-green-400 border border-green-500/30 px-2 py-0.5 rounded-full">ACTIVE</span>
            </div>
            <p className="text-[11px] text-gray-400 leading-relaxed">Every AI edit must follow this sequence before making any change:</p>
            <div className="space-y-1.5">
              {[
                'Load Admin Panel → Dev Notes section first.',
                'Read AI Editing Protocol, Layout Anchors, and Protected UI Components.',
                'Identify the component related to the issue.',
                'Apply the stored layout rules exactly.',
              ].map((step, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="text-[10px] font-bold text-green-400 bg-green-500/10 border border-green-500/20 rounded-full w-4 h-4 flex items-center justify-center flex-shrink-0 mt-0.5">{i + 1}</span>
                  <p className="text-[11px] text-gray-300">{step}</p>
                </div>
              ))}
            </div>
            <div className="bg-gray-900/60 border border-gray-700/50 rounded-xl p-3 space-y-1.5">
              <p className="text-[10px] text-green-300 font-semibold uppercase tracking-wider">Guardrails</p>
              {[
                'Modify ONLY the target component.',
                'Do NOT refactor unrelated components.',
                'Do NOT change the layout anchor system.',
                'Do NOT redesign protected components.',
                'Preserve existing behavior unless explicitly required to change it.',
              ].map((rule, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="text-green-400 text-[10px] flex-shrink-0 mt-0.5">•</span>
                  <p className="text-[11px] text-gray-300">{rule}</p>
                </div>
              ))}
            </div>
            <div className="bg-green-900/20 border border-green-500/20 rounded-xl p-3">
              <p className="text-[10px] text-green-300 font-semibold mb-1">⚡ Implementation Rule</p>
              <p className="text-[11px] text-gray-400">Fix the reported issue with the <strong className="text-white">smallest possible change</strong>.</p>
            </div>
            <div className="bg-gray-900/60 border border-amber-500/20 rounded-xl p-3 space-y-1.5">
              <p className="text-[10px] text-amber-400 font-semibold">✅ Verification Step — After every edit confirm:</p>
              {[
                'Notification Bell Dropdown',
                'Wallet Dropdown',
                'Plan Version Row',
                'Top Navigation Layout',
              ].map((comp, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="text-amber-400 text-[10px]">→</span>
                  <p className="text-[11px] text-gray-300">{comp} still works exactly the same</p>
                </div>
              ))}
              <p className="text-[11px] text-red-400 mt-1 font-medium">If any would be affected — stop and ask before applying changes.</p>
            </div>
          </div>

          {/* ── CARD 1: AI EDITING PROTOCOL ─────────────────────────────── */}
          <div className="bg-gradient-to-br from-blue-900/30 to-purple-900/20 rounded-2xl border border-blue-500/30 p-4 space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-base">🧠</span>
              <h3 className="text-blue-300 font-bold text-sm">AI Editing Protocol</h3>
              <span className="ml-auto text-[9px] font-bold bg-blue-500/20 text-blue-400 border border-blue-500/30 px-2 py-0.5 rounded-full">LOAD FIRST</span>
            </div>
            <p className="text-[11px] text-gray-400 leading-relaxed">Before modifying any UI component, follow this process:</p>
            <div className="space-y-1.5">
              {[
                'Check Dev Notes — UI Fix Reference.',
                'Identify if a rule already exists for the component.',
                'Follow the stored positioning and layout rules exactly.',
                'Modify only the target component.',
                'Do not refactor or redesign unrelated components.',
                'Preserve working behavior unless explicitly instructed.',
              ].map((step, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="text-[10px] font-bold text-blue-400 bg-blue-500/10 border border-blue-500/20 rounded-full w-4 h-4 flex items-center justify-center flex-shrink-0 mt-0.5">{i + 1}</span>
                  <p className="text-[11px] text-gray-300">{step}</p>
                </div>
              ))}
            </div>
            <div className="bg-blue-900/20 border border-blue-500/20 rounded-xl p-3">
              <p className="text-[10px] text-blue-300 font-semibold mb-1">Default Rule</p>
              <p className="text-[11px] text-gray-400">Fix the issue without changing the overall layout system.</p>
            </div>
            <div className="bg-gray-900/60 border border-gray-700/50 rounded-xl p-3">
              <p className="text-[10px] text-amber-400 font-semibold mb-1">⚡ Pro Prompt Prefix</p>
              <p className="text-[11px] text-gray-300 font-mono italic">"Follow Dev Notes UI Fix Reference before applying changes. [describe issue]"</p>
            </div>
          </div>

          {/* ── CARD 2: LAYOUT ANCHORS ───────────────────────────────────── */}
          <div className="bg-gradient-to-br from-cyan-900/20 to-teal-900/10 rounded-2xl border border-cyan-500/30 p-4 space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-base">📐</span>
              <h3 className="text-cyan-300 font-bold text-sm">Layout Anchors</h3>
              <span className="ml-auto text-[9px] font-bold bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 px-2 py-0.5 rounded-full">ALIGNMENT SYSTEM</span>
            </div>
            <p className="text-[11px] text-gray-400 leading-relaxed">These elements define the horizontal alignment system for the app.</p>
            <div className="bg-gray-900/60 border border-gray-700/50 rounded-xl p-3 space-y-1">
              <p className="text-[10px] text-cyan-300 font-semibold">Plan Version Row</p>
              <p className="text-[11px] text-gray-400">Reference spacing: <code className="text-cyan-400">mx-4 (1rem each side)</code></p>
            </div>
            <div className="space-y-2">
              <p className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider">Rules</p>
              {[
                'Full-width dropdowns must align with this row',
                'Modals and popups should respect the same container spacing',
                'Notification dropdown uses full-width alignment',
                'Wallet dropdown uses centered 50% width alignment',
              ].map((rule, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="text-cyan-400 text-[10px] flex-shrink-0 mt-0.5">•</span>
                  <p className="text-[11px] text-gray-300">{rule}</p>
                </div>
              ))}
            </div>
            <div className="bg-gray-800 rounded-lg p-3 font-mono text-[11px] space-y-1">
              <p className="text-green-400">{'// ✅ Required Implementation — Notification Bell'}</p>
              <p className="text-gray-300">{'left: "1rem"   right: "1rem"   width: "auto"'}</p>
              <p className="text-green-400 mt-2">{'// ✅ Required Implementation — Wallet Dropdown'}</p>
              <p className="text-gray-300">{'left: "25%"   right: "25%"'}</p>
              <p className="text-red-400 mt-2">{'// ❌ Forbidden Methods'}</p>
              <p className="text-gray-500">{'left: "50%"  transform: "translateX(-50%)"'}</p>
              <p className="text-gray-500">{'position: "fixed"  // causes scroll issues'}</p>
            </div>
          </div>

          {/* ── CARD 3: PROTECTED COMPONENTS ────────────────────────────── */}
          <div className="bg-gradient-to-br from-red-900/20 to-orange-900/10 rounded-2xl border border-red-500/30 p-4 space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-base">🛡</span>
              <h3 className="text-red-300 font-bold text-sm">Protected UI Components</h3>
              <span className="ml-auto text-[9px] font-bold bg-red-500/20 text-red-400 border border-red-500/30 px-2 py-0.5 rounded-full">GUARDRAIL</span>
            </div>
            <p className="text-[11px] text-gray-400 leading-relaxed">The following components should not be redesigned unless explicitly instructed.</p>
            <div className="space-y-2">
              {[
                { name: 'Notification Bell Dropdown', file: 'components/NotificationBell.jsx' },
                { name: 'Wallet Dropdown', file: 'pages/Home.jsx' },
                { name: 'Plan Version Row', file: 'pages/Home.jsx' },
                { name: 'Top Navigation Layout', file: 'Layout.js' },
              ].map((comp, i) => (
                <div key={i} className="flex items-center justify-between bg-gray-900/60 border border-gray-700/50 rounded-xl px-3 py-2">
                  <div>
                    <p className="text-[11px] text-white font-semibold">{comp.name}</p>
                    <p className="text-[10px] text-gray-500 font-mono">{comp.file}</p>
                  </div>
                  <span className="text-[9px] font-bold bg-red-500/20 text-red-400 border border-red-500/30 px-2 py-0.5 rounded-full flex-shrink-0 ml-2">PROTECTED</span>
                </div>
              ))}
            </div>
            <div className="space-y-1.5">
              <p className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider">Rules</p>
              {[
                'Only fix the reported issue',
                'Do not change component structure',
                'Do not change alignment system',
                'Do not rewrite styling logic unless necessary',
              ].map((rule, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="text-red-400 text-[10px] flex-shrink-0 mt-0.5">•</span>
                  <p className="text-[11px] text-gray-300">{rule}</p>
                </div>
              ))}
            </div>
          </div>

          {/* ── CARD 4: COMPONENT REGISTRY ──────────────────────────────── */}
          <div className="bg-gradient-to-br from-violet-900/20 to-purple-900/10 rounded-2xl border border-violet-500/30 p-4 space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-base">⚙️</span>
              <h3 className="text-violet-300 font-bold text-sm">Component Registry</h3>
              <span className="ml-auto text-[9px] font-bold bg-violet-500/20 text-violet-400 border border-violet-500/30 px-2 py-0.5 rounded-full">REFERENCE</span>
            </div>
            <p className="text-[11px] text-gray-400 leading-relaxed">Main UI components and their purpose in the layout system.</p>
            <div className="space-y-2">
              {[
                {
                  name: 'NotificationBell.jsx',
                  purpose: 'Controls notification dropdown',
                  details: 'Uses full-width alignment, anchored to Plan Version Row spacing',
                  color: 'border-blue-500/30 bg-blue-900/10'
                },
                {
                  name: 'WalletDropdown.jsx',
                  purpose: 'Wallet actions dropdown',
                  details: 'Uses centered 50% width layout (25% left, 25% right)',
                  color: 'border-emerald-500/30 bg-emerald-900/10'
                },
                {
                  name: 'PlanVersionRow.jsx',
                  purpose: 'Layout anchor for horizontal spacing',
                  details: 'Defines mx-4 alignment reference, no dropdowns should exceed this width',
                  color: 'border-cyan-500/30 bg-cyan-900/10'
                },
                {
                  name: 'TopNavigation.jsx',
                  purpose: 'Contains bell icon and wallet access',
                  details: 'Must not control dropdown width, only button placement',
                  color: 'border-amber-500/30 bg-amber-900/10'
                },
              ].map((comp, i) => (
                <div key={i} className={`rounded-xl p-3 border ${comp.color}`}>
                  <div className="flex items-start gap-2 mb-1.5">
                    <span className="text-violet-400 font-mono text-[10px] font-semibold flex-1">{comp.name}</span>
                    <span className="text-[9px] bg-violet-500/20 text-violet-300 border border-violet-500/30 px-1.5 py-0.5 rounded-full flex-shrink-0">COMPONENT</span>
                  </div>
                  <p className="text-[11px] text-white font-medium mb-0.5">{comp.purpose}</p>
                  <p className="text-[10px] text-gray-400">{comp.details}</p>
                </div>
              ))}
            </div>
          </div>

          {/* ── CARD 5: COMPONENT LOCK SYSTEM ──────────────────────────── */}
          <div className="bg-gradient-to-br from-red-900/30 to-orange-900/20 rounded-2xl border border-red-500/30 p-4 space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-base">🔒</span>
              <h3 className="text-red-300 font-bold text-sm">Component Lock System</h3>
              <span className="ml-auto text-[9px] font-bold bg-red-500/20 text-red-400 border border-red-500/30 px-2 py-0.5 rounded-full">ACTIVE RESTRICTIONS</span>
            </div>
            <p className="text-[11px] text-gray-400 leading-relaxed">Certain UI components are locked to prevent accidental modification during AI edits.</p>
            
            <div className="bg-gray-900/60 border border-gray-700/50 rounded-xl p-3 space-y-1.5">
              <p className="text-[10px] text-red-300 font-semibold uppercase tracking-wider">🔐 Locked Components</p>
              {[
                'Notification Bell Dropdown',
                'Wallet Dropdown',
                'Plan Version Row',
                'Top Navigation Layout',
                'Bottom Navigation Tabs',
                'Page Container Layout',
                'Navigation System',
                'Layout Anchor Spacing (mx-4 system)',
              ].map((comp, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="text-red-400 text-[10px] flex-shrink-0">🔒</span>
                  <p className="text-[11px] text-gray-300">{comp}</p>
                </div>
              ))}
            </div>

            <div className="bg-gray-900/60 border border-gray-700/50 rounded-xl p-3 space-y-1.5">
              <p className="text-[10px] text-red-300 font-semibold uppercase tracking-wider">⛔ AI Editing Restrictions</p>
              {[
                'Do NOT modify locked components unless explicitly unlocked.',
                'If a change would affect a locked component, STOP and ask first.',
                'Layout spacing, alignment, and structure must remain unchanged.',
              ].map((rule, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="text-red-400 text-[10px] flex-shrink-0 mt-0.5">•</span>
                  <p className="text-[11px] text-gray-300">{rule}</p>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="bg-green-900/20 border border-green-500/20 rounded-xl p-3">
                <p className="text-[10px] text-green-300 font-semibold mb-1.5">✅ Allowed Actions</p>
                {[
                  'Small bug fixes',
                  'Style tweaks',
                  'Logic fixes (structure safe)',
                ].map((action, i) => (
                  <div key={i} className="flex items-start gap-2 mb-1">
                    <span className="text-green-400 text-[9px] flex-shrink-0">→</span>
                    <p className="text-[10px] text-gray-300">{action}</p>
                  </div>
                ))}
              </div>
              <div className="bg-red-900/20 border border-red-500/20 rounded-xl p-3">
                <p className="text-[10px] text-red-300 font-semibold mb-1.5">❌ Forbidden Actions</p>
                {[
                  'Refactoring layouts',
                  'Changing alignment',
                  'Rewriting dropdowns',
                  'Modifying nav',
                ].map((action, i) => (
                  <div key={i} className="flex items-start gap-2 mb-1">
                    <span className="text-red-400 text-[9px] flex-shrink-0">✕</span>
                    <p className="text-[10px] text-gray-300">{action}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gray-800 rounded-lg p-3 font-mono text-[11px] space-y-1">
              <p className="text-amber-400">{'// ⚡ To UNLOCK a component, use:'}</p>
              <p className="text-gray-300">{'Unlock Component: [component name]'}</p>
              <p className="text-amber-400 mt-2">{'// Example:'}</p>
              <p className="text-gray-300">{'Unlock Component: Notification Bell Dropdown'}</p>
              <p className="text-gray-500 text-[10px] mt-1">{'Only then can the AI modify that specific component.'}</p>
            </div>

            <div className="bg-amber-900/20 border border-amber-500/20 rounded-xl p-3">
              <p className="text-[10px] text-amber-300 font-semibold mb-1">🧠 Default Rule</p>
              <p className="text-[11px] text-gray-400">If unsure whether a change affects a locked component, <strong className="text-white">do not apply the change</strong>.</p>
            </div>
          </div>

          {/* ── CARD 6: UI BEHAVIOR MEMORY ─────────────────────────────── */}
          <div className="bg-gradient-to-br from-indigo-900/30 to-blue-900/20 rounded-2xl border border-indigo-500/30 p-4 space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-base">🧠</span>
              <h3 className="text-indigo-300 font-bold text-sm">UI Behavior Memory</h3>
              <span className="ml-auto text-[9px] font-bold bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 px-2 py-0.5 rounded-full">DESIGN DNA</span>
            </div>
            <p className="text-[11px] text-gray-400 leading-relaxed">Expected behavior and structure of core UI components. Future edits must preserve these behaviors.</p>
            
            <div className="bg-gray-900/60 border border-gray-700/50 rounded-xl p-3 space-y-1.5">
              <p className="text-[10px] text-indigo-300 font-semibold uppercase tracking-wider">Global UI Behavior Rules</p>
              {[
                'App uses consistent container spacing based on mx-4 (1rem each side).',
                'Full-width dropdowns align with Plan Version Row edges.',
                'Navigation components remain visually fixed and stable.',
                'Dropdown menus scroll with page unless explicitly overlay-designed.',
                'All UI elements respect main page container width.',
              ].map((rule, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="text-indigo-400 text-[10px] flex-shrink-0 mt-0.5">•</span>
                  <p className="text-[11px] text-gray-300">{rule}</p>
                </div>
              ))}
            </div>

            <div className="space-y-2">
              <p className="text-[10px] text-indigo-300 font-semibold uppercase tracking-wider">Component Behavior Memory</p>
              
              {[
                {
                  name: '🔔 Notification Bell Dropdown',
                  behaviors: [
                    'Full-width dropdown',
                    'Aligns with Plan Version Row edges',
                    'Scrolls with page',
                    'Uses left: 1rem and right: 1rem positioning',
                    'Does not center relative to bell icon',
                  ]
                },
                {
                  name: '💰 Wallet Dropdown',
                  behaviors: [
                    'Centered dropdown',
                    'Approximately 50% page width',
                    'Opens relative to wallet icon',
                    'Uses balanced left/right spacing',
                  ]
                },
                {
                  name: '📐 Plan Version Row',
                  behaviors: [
                    'Defines horizontal alignment system',
                    'Uses mx-4 spacing',
                    'Acts as layout anchor',
                  ]
                },
                {
                  name: '🔝 Top Navigation',
                  behaviors: [
                    'Fixed structural component',
                    'Contains notification bell and wallet access',
                    'Must remain visually stable',
                  ]
                },
                {
                  name: '🔢 Bottom Navigation Tabs',
                  behaviors: [
                    'Persistent navigation',
                    'Always visible',
                    'Does not change size or alignment',
                  ]
                },
              ].map((comp, i) => (
                <div key={i} className="bg-gray-900/50 border border-gray-700/40 rounded-lg p-3">
                  <p className="text-[11px] text-white font-semibold mb-2">{comp.name}</p>
                  <div className="space-y-1">
                    {comp.behaviors.map((behavior, j) => (
                      <div key={j} className="flex items-start gap-2">
                        <span className="text-indigo-400 text-[9px] flex-shrink-0 mt-0.5">→</span>
                        <p className="text-[10px] text-gray-300">{behavior}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-indigo-900/20 border border-indigo-500/20 rounded-xl p-3">
              <p className="text-[10px] text-indigo-300 font-semibold mb-1">📋 Page Section Rule</p>
              <p className="text-[11px] text-gray-400">All page sections (Home, Ethical, Learn, Earn) must follow the same card spacing, border radius, and container width for visual consistency.</p>
            </div>

            <div className="bg-gray-800 rounded-lg p-3 font-mono text-[11px] space-y-1">
              <p className="text-blue-400">{'// 🧠 Load memory before editing:'}</p>
              <p className="text-gray-300">{'Load Dev Notes and UI Behavior Memory before applying changes.'}</p>
              <p className="text-blue-400 mt-2">{'// Follow:'}</p>
              <p className="text-gray-300">{'1. Component Lock System'}</p>
              <p className="text-gray-300">{'2. Layout Anchors'}</p>
              <p className="text-gray-300">{'3. UI Behavior Memory'}</p>
            </div>
          </div>

          {/* ── CARD 7: SELF-HEALING UI SYSTEM ────────────────────────── */}
          <div className="bg-gradient-to-br from-emerald-900/30 to-teal-900/20 rounded-2xl border border-emerald-500/30 p-4 space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-base">🏥</span>
              <h3 className="text-emerald-300 font-bold text-sm">Self-Healing UI System</h3>
              <span className="ml-auto text-[9px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full">AUTO-REPAIR</span>
            </div>
            <p className="text-[11px] text-gray-400 leading-relaxed">Automatically detect layout violations and repair them using Dev Notes rules before changes are finalized.</p>

            <div className="bg-gray-900/60 border border-gray-700/50 rounded-xl p-3 space-y-1.5">
              <p className="text-[10px] text-emerald-300 font-semibold uppercase tracking-wider">Primary Layout Anchors</p>
              {[
                'Top Navigation Bar',
                'Page Content Container',
                'Section Spacing System',
                'Card Component Grid',
              ].map((anchor, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="text-emerald-400 text-[10px] flex-shrink-0">📍</span>
                  <p className="text-[11px] text-gray-300">{anchor}</p>
                </div>
              ))}
            </div>

            <div className="bg-gray-900/60 border border-gray-700/50 rounded-xl p-3 space-y-1.5">
              <p className="text-[10px] text-emerald-300 font-semibold uppercase tracking-wider">Spacing Rules</p>
              {[
                'Section padding must remain consistent across pages.',
                'Card components must maintain identical spacing.',
                'Navigation components must stay aligned with header.',
              ].map((rule, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="text-emerald-400 text-[10px] flex-shrink-0 mt-0.5">•</span>
                  <p className="text-[11px] text-gray-300">{rule}</p>
                </div>
              ))}
            </div>

            <div className="bg-emerald-900/20 border border-emerald-500/20 rounded-xl p-3">
              <p className="text-[10px] text-emerald-300 font-semibold mb-2">🔍 Layout Integrity Check</p>
              <p className="text-[11px] text-gray-400 mb-2">Before finalizing any UI modification, detect violations:</p>
              {[
                'Broken spacing between sections',
                'Misaligned cards or components',
                'Header or navigation misplacement',
                'Grid inconsistencies',
                'Component padding differences',
              ].map((check, i) => (
                <div key={i} className="flex items-start gap-2 mb-1">
                  <span className="text-emerald-400 text-[9px] flex-shrink-0 mt-0.5">✓</span>
                  <p className="text-[10px] text-gray-300">{check}</p>
                </div>
              ))}
            </div>

            <div className="bg-teal-900/20 border border-teal-500/20 rounded-xl p-3">
              <p className="text-[10px] text-teal-300 font-semibold mb-2">⚙️ Automatic Repair Protocol</p>
              {[
                { step: '1', action: 'Compare layout against Dev Notes Layout Rules' },
                { step: '2', action: 'Automatically restore spacing and alignment' },
                { step: '3', action: 'Rebuild affected section using layout anchors' },
                { step: '4', action: 'Preserve visual design system' },
              ].map((item, i) => (
                <div key={i} className="flex items-start gap-2 mb-1">
                  <span className="text-teal-400 font-bold text-[10px] flex-shrink-0 w-4">{item.step}.</span>
                  <p className="text-[10px] text-gray-300">{item.action}</p>
                </div>
              ))}
            </div>

            <div className="bg-red-900/20 border border-red-500/20 rounded-xl p-3 space-y-1.5">
              <p className="text-[10px] text-red-300 font-semibold uppercase tracking-wider">🛡️ UI Integrity Guarantee</p>
              <p className="text-[11px] text-gray-400 mb-1.5">These components must NEVER break:</p>
              {[
                'Top Navigation Layout',
                'Notification Bell Dropdown',
                'Wallet Dropdown',
                'Plan Version Row',
                'Card Component Grid',
              ].map((comp, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="text-red-400 text-[10px] flex-shrink-0">🔒</span>
                  <p className="text-[11px] text-gray-300">{comp}</p>
                </div>
              ))}
              <p className="text-[11px] text-red-400 font-medium mt-2">If a modification risks breaking these, STOP and request confirmation.</p>
            </div>

            <div className="bg-gray-800 rounded-lg p-3 font-mono text-[11px] space-y-1">
              <p className="text-emerald-400">{'// 🧠 Trigger self-healing:'}</p>
              <p className="text-gray-300">{'Activate Self-Healing UI System'}</p>
              <p className="text-emerald-400 mt-2">{'// Run integrity check before finalizing:'}</p>
              <p className="text-gray-300">{'Layout Integrity Check → Auto Repair → Save'}</p>
            </div>
          </div>

          {/* ── CARD 8: TOOL CARD GRID RULES ───────────────────────────── */}
          <div className="bg-gradient-to-br from-orange-900/30 to-amber-900/20 rounded-2xl border border-orange-500/30 p-4 space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-base">📊</span>
              <h3 className="text-orange-300 font-bold text-sm">Tool Card Grid Rules</h3>
              <span className="ml-auto text-[9px] font-bold bg-orange-500/20 text-orange-400 border border-orange-500/30 px-2 py-0.5 rounded-full">LAYOUT PROTECTED</span>
            </div>
            <p className="text-[11px] text-gray-400 leading-relaxed">Masters DeoVex tools must maintain consistent grid structure and spacing.</p>

            <div className="bg-gray-900/60 border border-gray-700/50 rounded-xl p-3 space-y-1.5">
              <p className="text-[10px] text-orange-300 font-semibold uppercase tracking-wider">Grid Structure Rules</p>
              {[
                'All tools must use the same card size.',
                'Cards must stay inside the tool grid container.',
                'Spacing between cards must remain consistent.',
                'Tool cards must not shift navigation or page anchors.',
                'Card borders and shadows must match across all tool sections.',
              ].map((rule, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="text-orange-400 text-[10px] flex-shrink-0 mt-0.5">•</span>
                  <p className="text-[11px] text-gray-300">{rule}</p>
                </div>
              ))}
            </div>

            <div className="bg-amber-900/20 border border-amber-500/20 rounded-xl p-3">
              <p className="text-[10px] text-amber-300 font-semibold mb-1">⚠️ Protected Tool Sections</p>
              <p className="text-[11px] text-gray-400">Tool card layouts in these sections are locked:
                <span className="text-orange-400 font-medium"> Host & SNI Finder, Ethical Internet, Creator Pages, Wallet System</span>
              </p>
            </div>
          </div>

          {/* ── CARD 9: UI FIX REFERENCE (original, with updated labels) ── */}
          <div className="bg-amber-500/5 rounded-2xl border border-amber-500/30 p-4 space-y-4">
            <div className="flex items-center gap-2">
              <span className="text-base">📌</span>
              <h3 className="text-amber-400 font-bold text-sm">Dev Notes — UI Fix Reference</h3>
            </div>

            {/* FIX 1 */}
            <div className="bg-gray-900/60 border border-gray-700/50 rounded-xl p-4 space-y-2">
              <p className="text-white font-semibold text-xs">🔔 Notification Bell Dropdown — Alignment Fix</p>
              <p className="text-gray-500 text-[11px]">File: <code className="text-cyan-400">components/NotificationBell.jsx</code></p>
              <p className="text-[11px] text-gray-400 leading-relaxed">
                The dropdown must align with the same left/right edges as the <strong className="text-white">Plan Version row</strong> (<code className="text-cyan-400">mx-4 = 1rem</code> each side).
              </p>
              <div className="bg-gray-800 rounded-lg p-3 font-mono text-[11px] text-green-400 space-y-1">
                <p>{'// ✅ Required Implementation'}</p>
                <p>{'position: "absolute"'}</p>
                <p>{'top: rect.bottom + window.scrollY + 8'}</p>
                <p>{'left: "1rem"'}</p>
                <p>{'right: "1rem"'}</p>
                <p>{'width: "auto"'}</p>
              </div>
              <div className="bg-gray-800 rounded-lg p-3 font-mono text-[11px] text-red-400 space-y-1">
                <p>{'// ❌ Forbidden Methods'}</p>
                <p>{'left: "50%"'}</p>
                <p>{'transform: "translateX(-50%)"'}</p>
                <p>{'position: "fixed"  // causes scroll issues'}</p>
              </div>
              <p className="text-[11px] text-amber-400/80 italic">
                🛠 Debug tip: Add border to Plan Version row and dropdown — edges should align perfectly.
              </p>
            </div>

            {/* FIX 2 */}
            <div className="bg-gray-900/60 border border-gray-700/50 rounded-xl p-4 space-y-2">
              <p className="text-white font-semibold text-xs">💰 Wallet Dropdown — Size & Alignment</p>
              <p className="text-gray-500 text-[11px]">File: <code className="text-cyan-400">pages/Home.jsx</code></p>
              <p className="text-[11px] text-gray-400 leading-relaxed">
                Wallet dropdown is 50% width and centered (25% from each side), while notification bell is full width (1rem each side).
              </p>
              <div className="bg-gray-800 rounded-lg p-3 font-mono text-[11px] space-y-1">
                <p className="text-green-400">{'// ✅ Required Implementation — Wallet (50% centered)'}</p>
                <p className="text-gray-300">{'left: "25%"'}</p>
                <p className="text-gray-300">{'right: "25%"'}</p>
                <p className="text-green-400 mt-1">{'// ✅ Required Implementation — Bell (full width)'}</p>
                <p className="text-gray-300">{'left: "1rem"'}</p>
                <p className="text-gray-300">{'right: "1rem"'}</p>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* BACKUP TAB */}
      {tab === 'backup' && (
        <div className="px-4 py-4 space-y-4">
          <div className="bg-gradient-to-r from-cyan-600/20 to-blue-600/20 rounded-2xl p-4 border border-cyan-500/30">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center">
                  <Code className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white">Code Backup</h3>
                  <p className="text-xs text-gray-400">Masters DeoVex • React + Base44</p>
                </div>
              </div>
              <button onClick={() => {
                const allCode = BACKUP_FILES.map(f => `${'='.repeat(60)}\n// FILE: ${f.name}  [${f.category}]\n${'='.repeat(60)}\n\n${f.code}\n`).join('\n');
                const blob = new Blob([allCode], { type: 'text/plain' });
                const a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = `MastersDeoVex_backup_${new Date().toISOString().slice(0, 10)}.txt`;
                a.click();
              }}
                className="flex items-center gap-1.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold px-3 py-2 rounded-xl transition-all">
                <Download className="w-3.5 h-3.5" /> Download
              </button>
            </div>
            <div className="flex flex-wrap gap-1">
              {APK_STRUCTURE.tech.map(t => (
                <span key={t} className="text-[10px] bg-gray-800/60 border border-gray-700/50 text-gray-400 px-2 py-0.5 rounded-full">{t}</span>
              ))}
            </div>
          </div>

          <div className="flex gap-1.5 overflow-x-auto pb-1 scroll-container">
            {['All', 'Core', 'Entities', 'Pages', 'Components', 'Config'].map(cat => (
              <button key={cat} onClick={() => setBackupCategory(cat)}
                className={`flex-shrink-0 px-2.5 py-1 rounded-full text-[11px] font-semibold transition-all border ${
                  backupCategory === cat ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40' : 'bg-gray-800/40 text-gray-500 border-gray-700/40'}`}>
                {cat}
              </button>
            ))}
          </div>

          <div className="space-y-2 max-h-[600px] overflow-y-auto scroll-container">
           {(backupCategory === 'All' ? BACKUP_FILES : BACKUP_FILES.filter(f => f.category === backupCategory)).map(file => {
              const isOpen = expandedFile === file.name;
              const catColor = { Core: 'text-blue-300 bg-blue-500/10 border-blue-500/30', Entities: 'text-amber-300 bg-amber-500/10 border-amber-500/30', Pages: 'text-purple-300 bg-purple-500/10 border-purple-500/30', Components: 'text-green-300 bg-green-500/10 border-green-500/30', Config: 'text-gray-300 bg-gray-500/10 border-gray-700/30' }[file.category];
              return (
                <div key={file.name} className="bg-gray-800/50 rounded-xl border border-gray-700/50 overflow-hidden">
                  <div className="flex items-center gap-2 px-3 py-2.5 bg-gray-800/60">
                    <Code className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0" />
                    <span className="text-[11px] font-mono text-white truncate flex-1">{file.name}</span>
                    <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full border flex-shrink-0 ${catColor}`}>{file.category}</span>
                    <CopyBtn text={file.code} />
                    <button onClick={() => setExpandedFile(isOpen ? null : file.name)} className="text-gray-500 hover:text-white p-0.5 rounded transition-all flex-shrink-0">
                      {isOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                  {isOpen && (
                    <pre className="text-[11px] text-gray-300 p-3 overflow-x-auto leading-relaxed whitespace-pre-wrap font-mono bg-gray-900/60 max-h-64 overflow-y-auto scroll-container">
                      {file.code}
                    </pre>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

export default function Admin() {
  const [sessionId, setSessionId] = useState(() => localStorage.getItem('adminSessionId'));
  const [verified, setVerified] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    const verifySession = async () => {
      const storedId = localStorage.getItem('adminSessionId');
      if (!storedId) { setChecking(false); return; }
      const sessions = await base44.entities.AdminSession.filter({ id: storedId, is_active: true });
      if (sessions.length === 0) { localStorage.removeItem('adminSessionId'); setChecking(false); return; }
      const session = sessions[0];
      if (new Date(session.session_expires_at) < new Date()) {
        await base44.entities.AdminSession.update(session.id, { is_active: false });
        localStorage.removeItem('adminSessionId');
        setChecking(false);
        return;
      }
      setSessionId(session.id);
      setVerified(true);
      setChecking(false);
    };
    verifySession();
  }, []);

  if (checking) return (
    <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
      <div className="flex items-center gap-3 text-gray-400">
        <RefreshCw className="w-5 h-5 animate-spin" /> Verifying session...
      </div>
    </div>
  );

  if (!verified) return (
    <AdminLogin onAuthenticated={(id) => { setSessionId(id); setVerified(true); }} />
  );

  return <AdminDashboard sessionId={sessionId} />;
}