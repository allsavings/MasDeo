import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { User, HelpCircle, Settings, LogOut, X, ChevronRight, Crown, Shield } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

function TripleTapAdmin() {
  const [taps, setTaps] = useState(0);
  const timerRef = useRef(null);
  const navigate = useNavigate();

  const handleTap = () => {
    const next = taps + 1;
    setTaps(next);
    clearTimeout(timerRef.current);
    if (next >= 3) {
      setTaps(0);
      navigate(createPageUrl('Admin'));
    } else {
      timerRef.current = setTimeout(() => setTaps(0), 1000);
    }
  };

  return (
    <button onClick={handleTap} className="text-base select-none">💙</button>
  );
}

export default function Profile() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [activeSubs, setActiveSubs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const userData = await base44.auth.me();
      setUser(userData);
      setLoading(false); // Show UI immediately with user data
      
      // Load subscriptions & profile in background
      const [subs, profiles] = await Promise.all([
        base44.entities.Subscription.filter({ user_email: userData.email, status: 'active' }),
        base44.entities.UserProfile.filter({ created_by: userData.email })
      ]);
      setActiveSubs(subs);
      if (profiles.length > 0) setProfile(profiles[0]);
    } catch (error) {
      console.log('User not logged in');
      setLoading(false);
    }
  };

  const getMembershipLabel = () => {
    const plans = activeSubs.map(s => s.plan);
    if (plans.includes('all_in_one')) return { label: 'All-In-One Premium', color: 'from-amber-500/20 to-orange-500/20', border: 'border-amber-500/30', text: 'text-amber-400' };
    if (plans.includes('ethical_internet') && plans.includes('learn_skills') && plans.includes('earn_online')) return { label: 'All-In-One Premium', color: 'from-amber-500/20 to-orange-500/20', border: 'border-amber-500/30', text: 'text-amber-400' };
    if (plans.length > 0) return { label: 'Premium Member', color: 'from-amber-500/20 to-orange-500/20', border: 'border-amber-500/30', text: 'text-amber-400' };
    return { label: 'Free Member', color: 'from-gray-700/30 to-gray-600/30', border: 'border-gray-600/30', text: 'text-gray-400' };
  };

  const handleLogout = () => {
    window.location.href = createPageUrl('LogoutConfirm');
  };

  const menuItems = [
    {
      icon: User,
      label: "My Profile",
      page: "Settings",
      description: "View and edit your profile"
    },
    {
      icon: Shield,
      label: "Browse Creators",
      page: "ExploreCreators",
      description: "Discover verified creators"
    },
    {
      icon: HelpCircle,
      label: "Help & Support",
      page: "HelpSupport",
      description: "Get help and contact us"
    },
    {
      icon: Settings,
      label: "Settings",
      page: "Settings",
      description: "App preferences"
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white">
      {/* Header */}
      <div className="flex items-center justify-between px-6 pt-6 pb-4">
        <div className="w-10" />
        <Link to={createPageUrl("Home")} className="p-2 hover:bg-white/10 rounded-full transition-colors">
          <X className="w-6 h-6" />
        </Link>
      </div>

      {/* Logo & Welcome */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="px-6 pb-8 text-center"
      >
        <div className="inline-block mb-6">
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/699aa662b79dd361c7b3904b/a540039c6_186683c9-e11a-4e07-a3bc-e80e42b08b3e_20260219_212443_00001.png"
            alt="Masters DeoVex"
            className="w-80 h-auto"
          />
        </div>

        <h2 className="text-2xl font-bold text-white mb-2">
          WelCome
        </h2>
        <p className="text-gray-400">Manage your account and settings</p>

        {/* Membership Badge */}
        {(() => {
          const membership = getMembershipLabel();
          return (
            <div className={`mt-4 inline-flex items-center gap-2 bg-gradient-to-r ${membership.color} px-4 py-2 rounded-full border ${membership.border}`}>
              <Crown className={`w-4 h-4 ${membership.text}`} />
              <span className={`text-sm ${membership.text} font-medium`}>{membership.label}</span>
            </div>
          );
        })()}
      </motion.div>

      {/* Divider */}
      <div className="h-px bg-gradient-to-r from-transparent via-gray-700 to-transparent mx-6" />

      {/* Menu Items */}
      <div className="px-6 py-6 space-y-4 pb-40">
        {menuItems.map((item, index) => (
          <motion.div
            key={item.label}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 + index * 0.1 }}
          >
            <Link to={createPageUrl(item.page)}>
              <div className="bg-gray-900/50 rounded-2xl p-5 border border-gray-800 hover:border-gray-700 transition-all group">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-gray-800/80 flex items-center justify-center group-hover:bg-gray-700/80 transition-colors">
                      <item.icon className="w-5 h-5 text-gray-300" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-white">{item.label}</h3>
                      <p className="text-sm text-gray-500">{item.description}</p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-600 group-hover:text-gray-400 transition-colors" />
                </div>
              </div>
            </Link>
          </motion.div>
        ))}

        {/* Sign Out Button */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
        >
          <button
            onClick={handleLogout}
            className="w-full bg-gradient-to-r from-red-500/20 to-red-600/20 rounded-2xl p-5 border border-red-500/30 hover:border-red-500/50 transition-all group"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-red-500/20 flex items-center justify-center">
                <LogOut className="w-5 h-5 text-red-400" />
              </div>
              <span className="font-semibold text-red-400">Sign Out</span>
            </div>
          </button>
        </motion.div>

        {/* Security Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-8"
        >
          <div className="flex flex-col items-center gap-3">
            <div className="flex items-center justify-center gap-2 text-gray-500 text-xs">
              <Shield className="w-4 h-4" />
              <span>Your data is securely protected</span>
            </div>
            <TripleTapAdmin />
          </div>
        </motion.div>
      </div>
    </div>
  );
}