import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Lock, Check } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';

export default function SetupPin() {
  const [step, setStep] = useState(1);
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleNumberClick = (num) => {
    const currentPin = step === 1 ? pin : confirmPin;
    
    if (currentPin.length < 4) {
      const newPin = currentPin + num;
      
      if (step === 1) {
        setPin(newPin);
        if (newPin.length === 4) {
          setTimeout(() => setStep(2), 300);
        }
      } else {
        setConfirmPin(newPin);
        if (newPin.length === 4) {
          if (newPin === pin) {
            localStorage.setItem('app_pin', newPin);
            navigate(createPageUrl('Settings'));
          } else {
            setError('PINs do not match');
            setTimeout(() => {
              setConfirmPin('');
              setPin('');
              setStep(1);
              setError('');
            }, 1500);
          }
        }
      }
    }
  };

  const handleDelete = () => {
    if (step === 1) {
      setPin(pin.slice(0, -1));
    } else {
      setConfirmPin(confirmPin.slice(0, -1));
    }
  };

  const currentPin = step === 1 ? pin : confirmPin;

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white">
      <div className="px-6 pt-6 pb-4">
        <Link to={createPageUrl("Settings")} className="inline-block p-2 bg-gray-800/50 rounded-xl mb-6">
          <ArrowLeft className="w-5 h-5" />
        </Link>
      </div>

      <div className="px-6 flex flex-col items-center justify-center min-h-[70vh]">
        <motion.div
          key={step}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-center w-full"
        >
          <div className="w-20 h-20 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Lock className="w-10 h-10 text-blue-400" />
          </div>
          
          <h2 className="text-2xl font-bold text-white mb-2">
            {step === 1 ? 'Create PIN' : 'Confirm PIN'}
          </h2>
          <p className="text-gray-400 mb-8">
            {step === 1 ? 'Enter a 4-digit PIN' : 'Re-enter your PIN'}
          </p>

          <div className="flex gap-3 justify-center mb-4">
            {[0, 1, 2, 3].map((i) => (
              <div
                key={i}
                className={`w-4 h-4 rounded-full transition-all ${
                  currentPin.length > i ? 'bg-blue-500 scale-110' : 'bg-gray-700'
                }`}
              />
            ))}
          </div>

          {error && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-red-400 text-sm mb-4"
            >
              {error}
            </motion.p>
          )}

          <div className="grid grid-cols-3 gap-4 max-w-xs mx-auto mt-8">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, '', 0, 'delete'].map((num) => (
              <button
                key={num}
                onClick={() => num === 'delete' ? handleDelete() : num !== '' && handleNumberClick(num.toString())}
                disabled={num === ''}
                className={`w-20 h-20 rounded-2xl text-2xl font-bold transition-all ${
                  num === 'delete'
                    ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
                    : num === ''
                    ? 'invisible'
                    : 'bg-gray-800/50 text-white hover:bg-gray-700/50 active:scale-95'
                }`}
              >
                {num === 'delete' ? '⌫' : num}
              </button>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}