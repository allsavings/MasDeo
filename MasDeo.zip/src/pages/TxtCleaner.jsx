import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Upload, Trash2, Copy, Check, Download, FileText, AlertCircle, Sparkles, Filter, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const OUTPUT_MODES = [
  { id: 'host', label: 'Host Only',  desc: 'subdomain / domain' },
  { id: 'ip',   label: 'IP Only',    desc: 'IP address(es)' },
  { id: 'both', label: 'Both',       desc: 'host then IP' },
];

// Regex patterns — HOST_REGEX now captures optional :port and /path
const IP_REGEX   = /\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b/g;
const HOST_REGEX = /\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+(?:com|net|org|io|co|za|info|biz|me|app|dev|tech|xyz|online|site|web|cloud|edu|gov|mil|int|uk|us|de|fr|au|cn|ru|br|in|jp|kr|ng|gh|ke|tz|ug|rw|zm|zw|bw|na|mw|ls|sz|mu|mg|sc|cv|sn|ci|cm|cd|ao|mz|nl|ca|ie|se|be|ga|ml|tk|kz|ir|rs|cc|pw|icu|wtf|win|store|media|boutique|cool|studio|blog|design|network|rocks|live|link|supply|work|space|bike|fans|jewelry|rip|wiki|moe|world|financial|fyi|email|glass|university|best|land|fun|fit|gg|sh|fm|im|ac|ai|to|tv|am|gd|lv|lt|ly|by|ge|az|kg|tj|md|ee|mt|cy|is|al|ba|mk|pl|cz|at|ch|fi|no|dk|es|pt|gr|tr|eg|dz|ma|hu|ro|sk|si|hr|bg|ar|ua|club|bio|page|vegas|srl|industries|codes|systems|game|menu|monster|news|pet|guide|chat|art|pro|eco|works)[a-zA-Z0-9\-]*(?::\d{1,5})?(?:\/[a-zA-Z0-9\/\-\._%~]*)?/gi;

function extractFromText(text, opts = {}) {
  const { keepPorts = false, keepPaths = false } = opts;
  const ips = [...new Set((text.match(IP_REGEX) || []).map(s => s.trim()))];

  const raw = (text.match(HOST_REGEX) || []).map(s => {
    let h = s.trim().toLowerCase();
    if (!keepPaths) h = h.replace(/\/.*$/, '');
    if (!keepPorts) h = h.replace(/:\d{1,5}$/, '');
    return h;
  }).filter(h => h && !/^\d+\.\d+\.\d+\.\d+$/.test(h));

  // Remove duplicates, then remove any entry that is a suffix of a longer entry
  // e.g. remove "laestrellapack.com" when "laestrellapack.com.ar" also exists
  const unique = [...new Set(raw)];
  const hosts = unique.filter(h => !unique.some(other => other !== h && other.endsWith('.' + h)));

  return { hosts, ips };
}

function buildOutput(hosts, ips, mode) {
  let lines = [];
  if (mode === 'host') lines = hosts;
  else if (mode === 'ip') lines = ips;
  else { lines = [...hosts, ...ips]; }
  return [...new Set(lines.filter(Boolean))].join('\n');
}

function CopyBtn({ text }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      onClick={() => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
      className="flex items-center gap-1 text-xs text-gray-400 hover:text-white px-2 py-1 rounded-lg hover:bg-gray-700/50 transition-all"
    >
      {copied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
      {copied ? 'Copied!' : 'Copy'}
    </button>
  );
}

export default function TxtCleaner() {
  const [input, setInput]         = useState('');
  const [mode, setMode]           = useState('host');
  const [output, setOutput]       = useState('');
  const [stats, setStats]         = useState(null);
  const [fileCount, setFileCount] = useState(0);
  const [downloading, setDownloading] = useState(false);
  const [showRename, setShowRename] = useState(false);
  const [downloadName, setDownloadName] = useState('');
  const [keepPorts, setKeepPorts] = useState(false);
  const [keepPaths, setKeepPaths] = useState(false);
  const [autoClean, setAutoClean] = useState(true);
  const fileInputRef = useRef(null);

  const process = (raw, selectedMode, overrides = {}) => {
    const m = selectedMode || mode;
    const opts = {
      keepPorts: overrides.keepPorts !== undefined ? overrides.keepPorts : keepPorts,
      keepPaths: overrides.keepPaths !== undefined ? overrides.keepPaths : keepPaths,
    };
    const { hosts, ips } = extractFromText(raw, opts);
    const out = buildOutput(hosts, ips, m);
    setOutput(out);
    setStats({
      hosts: hosts.length,
      ips: ips.length,
      lines: out ? out.split('\n').filter(Boolean).length : 0,
    });
  };

  const handleInput = (val) => {
    setInput(val);
    setFileCount(0);
    if (val.trim()) { if (autoClean) process(val); }
    else { setOutput(''); setStats(null); }
  };

  const handleMode = (m) => {
    setMode(m);
    if (input.trim()) process(input, m);
  };

  const handleKeepPorts = () => {
    const next = !keepPorts;
    setKeepPorts(next);
    if (input.trim()) process(input, undefined, { keepPorts: next });
  };

  const handleKeepPaths = () => {
    const next = !keepPaths;
    setKeepPaths(next);
    if (input.trim()) process(input, undefined, { keepPaths: next });
  };

  const manualClean = () => {
    if (input.trim()) process(input);
  };

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    const texts = await Promise.all(files.map(f => f.text()));
    const combined = texts.join('\n');
    setInput(combined);
    setFileCount(files.length);
    process(combined); // always clean on file upload regardless of autoClean
    e.target.value = '';
  };

  const defaultFilename = () => `txt_cleaned_${mode}_${new Date().toISOString().slice(0,10)}`;

  const triggerDownload = (name) => {
    const filename = (name || '').trim() ? (name.trim().endsWith('.txt') ? name.trim() : name.trim() + '.txt') : defaultFilename() + '.txt';
    setDownloading(true);
    const blob = new Blob([output], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setShowRename(false);
    setTimeout(() => setDownloading(false), 1500);
  };

  const downloadOutput = () => {
    if (!output) return;
    setDownloadName(defaultFilename());
    setShowRename(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      {/* Header */}
      <div className="px-4 pt-6 pb-3">
        <div className="flex items-center gap-3">
          <Link to={createPageUrl("HostScanner")} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-lg font-bold leading-tight">TXT Cleaner</h1>
            <p className="text-xs text-cyan-400">Smart Filter — Extract hosts & IPs from plain text</p>
          </div>
        </div>
      </div>

      <div className="px-4 space-y-4">
        {/* Info Banner */}
        <div className="bg-gradient-to-r from-cyan-600/10 to-blue-600/10 rounded-2xl p-4 border border-cyan-500/20 flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-500/30 to-blue-500/30 border border-cyan-500/30 flex items-center justify-center flex-shrink-0 mt-0.5">
            <Filter className="w-4 h-4 text-cyan-400" />
          </div>
          <div>
            <p className="text-xs font-semibold text-cyan-300 mb-0.5">Smart Filter — Plain Text / Mixed Content</p>
            <p className="text-xs text-gray-400">
              Paste any raw text, logs, or scan output. Automatically detects{' '}
              <span className="text-cyan-300 font-mono">domains</span>,{' '}
              <span className="text-cyan-300 font-mono">subdomains</span>, and{' '}
              <span className="text-cyan-300 font-mono">IP addresses</span> from unstructured content.
            </p>
          </div>
        </div>

        {/* Smart Toggles */}
        <div className="grid grid-cols-3 gap-2">
          <button onClick={handleKeepPorts}
            className={`rounded-xl px-2 py-2.5 border text-center transition-all ${keepPorts ? 'bg-amber-500/15 border-amber-500/40 text-amber-300' : 'bg-gray-800/40 border-gray-700/40 text-gray-500 hover:text-gray-300'}`}>
            <p className="text-xs font-semibold leading-tight">Keep Ports</p>
            <p className="text-[10px] font-mono opacity-60">{keepPorts ? 'ON' : 'OFF'} · :8080</p>
          </button>
          <button onClick={handleKeepPaths}
            className={`rounded-xl px-2 py-2.5 border text-center transition-all ${keepPaths ? 'bg-purple-500/15 border-purple-500/40 text-purple-300' : 'bg-gray-800/40 border-gray-700/40 text-gray-500 hover:text-gray-300'}`}>
            <p className="text-xs font-semibold leading-tight">Keep Paths</p>
            <p className="text-[10px] font-mono opacity-60">{keepPaths ? 'ON' : 'OFF'} · /path</p>
          </button>
          <button onClick={() => setAutoClean(v => !v)}
            className={`rounded-xl px-2 py-2.5 border text-center transition-all ${autoClean ? 'bg-cyan-500/15 border-cyan-500/40 text-cyan-300' : 'bg-gray-800/40 border-gray-700/40 text-gray-500 hover:text-gray-300'}`}>
            <p className="text-xs font-semibold leading-tight">Auto-Clean</p>
            <p className="text-[10px] font-mono opacity-60">{autoClean ? 'ON' : 'OFF'} · on type</p>
          </button>
        </div>

        {/* Output Mode Selector */}
        <div>
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Output Mode</p>
          <div className="grid grid-cols-3 gap-2">
            {OUTPUT_MODES.map(m => (
              <button
                key={m.id}
                onClick={() => handleMode(m.id)}
                className={`rounded-xl px-3 py-2.5 border text-center transition-all ${
                  mode === m.id
                    ? 'bg-cyan-500/15 border-cyan-500/40 text-cyan-300'
                    : 'bg-gray-800/40 border-gray-700/40 text-gray-500 hover:text-gray-300'
                }`}
              >
                <p className="text-xs font-semibold">{m.label}</p>
                <p className="text-[10px] opacity-70">{m.desc}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Input */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Input</p>
            <div className="flex items-center gap-2">
              <button onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-1 text-xs bg-gray-700/60 hover:bg-gray-600/60 text-gray-300 px-2.5 py-1 rounded-lg transition-all">
                <Upload className="w-3 h-3" /> Upload file
              </button>
              <button onClick={() => { setInput(''); setOutput(''); setStats(null); setFileCount(0); }}
                className="text-xs bg-gray-700/60 hover:bg-red-900/40 text-gray-400 hover:text-red-400 p-1.5 rounded-lg transition-all">
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          </div>
          <input ref={fileInputRef} type="file" accept=".txt,.log,.csv,.text" multiple className="hidden" onChange={handleFileUpload} />
          {!autoClean && (
            <button onClick={manualClean}
              className="w-full mb-2 py-2 rounded-xl bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 text-cyan-300 text-xs font-semibold flex items-center justify-center gap-2 hover:from-cyan-500/30 hover:to-blue-500/30 transition-all">
              <Zap className="w-3.5 h-3.5" /> Clean Now
            </button>
          )}
          <textarea
            value={input}
            onChange={e => handleInput(e.target.value)}
            rows={8}
            placeholder={`Paste any raw text, logs, scan results here:\n\nExample:\nFound host: mail.example.com [192.168.1.1]\nTarget: sub.domain.co.za\n203.0.113.45 - open\ncdn.test.io resolved to 10.0.0.1`}
            className="w-full bg-gray-900/70 border border-gray-700/50 rounded-xl px-4 py-3 text-xs text-gray-200 font-mono resize-none focus:outline-none focus:border-cyan-500/50"
          />
        </div>

        {/* Parse Info Badge */}
        <AnimatePresence>
          {stats && (
            <motion.div initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              className="flex items-center justify-between">
              <span className="text-[11px] text-gray-500 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-cyan-400" />
                {fileCount > 1 ? `📄 ${fileCount} files merged` : '📄 Smart Filter applied'}
              </span>
              <div className="flex items-center gap-3 text-[10px]">
                <span className="text-blue-400">{stats.hosts} hosts</span>
                <span className="text-green-400">{stats.ips} IPs</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Stats */}
        <AnimatePresence>
          {stats && (
            <motion.div initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              className="grid grid-cols-3 gap-2">
              <div className="bg-blue-500/10 rounded-xl p-3 border border-blue-500/20 text-center">
                <p className="text-lg font-bold text-blue-400">{stats.hosts}</p>
                <p className="text-[10px] text-gray-500">Hosts</p>
              </div>
              <div className="bg-cyan-500/10 rounded-xl p-3 border border-cyan-500/20 text-center">
                <p className="text-lg font-bold text-cyan-400">{stats.lines}</p>
                <p className="text-[10px] text-gray-500">Output Lines</p>
              </div>
              <div className="bg-green-500/10 rounded-xl p-3 border border-green-500/20 text-center">
                <p className="text-lg font-bold text-green-400">{stats.ips}</p>
                <p className="text-[10px] text-gray-500">IPs Found</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Output */}
        <AnimatePresence>
          {output && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                  Clean Output — <span className="text-cyan-300 normal-case">{OUTPUT_MODES.find(m2 => m2.id === mode)?.label}</span>
                </p>
                <div className="flex items-center gap-2">
                  <CopyBtn text={output} />
                  <button
                    onClick={downloadOutput}
                    disabled={downloading}
                    className={`flex items-center gap-1.5 text-xs border px-3 py-1.5 rounded-lg transition-all font-medium ${
                      downloading
                        ? 'bg-green-600/20 border-green-500/40 text-green-300'
                        : 'bg-cyan-600/20 hover:bg-cyan-600/40 text-cyan-300 border-cyan-500/30 hover:border-cyan-500/60'
                    }`}
                  >
                    {downloading ? <><Check className="w-3 h-3" /> Saved!</> : <><Download className="w-3 h-3" /> Download .txt</>}
                  </button>
                </div>
              </div>
              <textarea
                readOnly
                value={output}
                rows={10}
                className="w-full bg-gray-900/80 border border-cyan-500/20 rounded-xl px-4 py-3 text-xs text-cyan-200 font-mono resize-none focus:outline-none"
              />
              <motion.button
                whileTap={{ scale: 0.97 }}
                onClick={downloadOutput}
                disabled={downloading}
                className={`mt-3 w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all border ${
                  downloading
                    ? 'bg-green-500/20 border-green-500/40 text-green-300'
                    : 'bg-gradient-to-r from-cyan-500/20 to-blue-500/20 hover:from-cyan-500/30 hover:to-blue-500/30 border-cyan-500/30 text-cyan-300'
                }`}
              >
                {downloading
                  ? <><Check className="w-4 h-4" /> File Downloaded!</>
                  : <><Download className="w-4 h-4" /> Download Clean Output ({stats?.lines} lines)</>
                }
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Rename & Download Modal */}
      <AnimatePresence>
        {showRename && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
              onClick={() => setShowRename(false)}
            />
            <motion.div
              initial={{ opacity: 0, y: 40, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 40, scale: 0.96 }}
              className="fixed bottom-0 left-0 right-0 z-50 bg-gray-900 border-t border-gray-700/60 rounded-t-3xl p-5"
            >
              <div className="w-10 h-1 bg-gray-700 rounded-full mx-auto mb-5" />
              <h3 className="text-base font-bold text-white mb-1 flex items-center gap-2">
                <Download className="w-4 h-4 text-cyan-400" /> Save File
              </h3>
              <p className="text-xs text-gray-400 mb-4">Rename your file or keep the default name.</p>
              <div className="flex items-center bg-gray-800/70 border border-gray-700/50 rounded-xl overflow-hidden mb-4">
                <input
                  type="text"
                  value={downloadName}
                  onChange={e => setDownloadName(e.target.value)}
                  placeholder="filename"
                  className="flex-1 bg-transparent px-4 py-3 text-sm text-white outline-none placeholder-gray-600"
                  autoFocus
                />
                <span className="text-xs text-gray-500 font-mono">.txt</span>
                <button
                  onClick={() => triggerDownload(downloadName)}
                  className="mx-2 px-3 py-1.5 bg-cyan-500/30 hover:bg-cyan-500/50 border border-cyan-500/40 text-cyan-300 text-xs font-semibold rounded-lg transition-all"
                >
                  Save
                </button>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <button onClick={() => setShowRename(false)}
                  className="py-3 rounded-xl border border-gray-700/50 text-sm text-gray-400 hover:text-white hover:border-gray-600 transition-all">
                  Cancel
                </button>
                <button onClick={() => triggerDownload(downloadName)}
                  className="py-3 rounded-xl bg-gradient-to-r from-cyan-500/30 to-blue-500/30 border border-cyan-500/40 text-cyan-300 font-semibold text-sm hover:from-cyan-500/50 hover:to-blue-500/50 transition-all flex items-center justify-center gap-2">
                  <Download className="w-4 h-4" /> Download
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}