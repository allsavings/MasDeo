import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { ArrowLeft, Check, Upload, Sparkles, Globe, BookOpen, DollarSign, CalendarDays, RefreshCw, AlertCircle, Gift, User } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { format, addMonths, parseISO, isAfter } from 'date-fns';

export default function Subscribe() {
  const [user, setUser] = useState(null);
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [paymentProofUrl, setPaymentProofUrl] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [existingSubs, setExistingSubs] = useState([]);
  // Free trial state
  const [trialNickname, setTrialNickname] = useState('');
  const [trialSubmitting, setTrialSubmitting] = useState(false);
  const [trialSubmitted, setTrialSubmitted] = useState(false);
  const [trialError, setTrialError] = useState('');

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const userData = await base44.auth.me();
      setUser(userData);
      const subs = await base44.entities.Subscription.filter({ user_email: userData.email });
      setExistingSubs(subs);
    } catch (error) {
      console.log('User not authenticated');
    }
    setLoading(false);
  };

  const plans = [
    {
      id: 'ethical_internet',
      name: 'Ethical Free Internet',
      price: 50,
      icon: Globe,
      color: 'from-blue-500 to-cyan-400',
      borderHover: 'hover:border-blue-500/60',
      features: ['VPN Tools & Configs', 'SSH/SSL/OpenVPN Scripts', 'Privacy Tools', 'Server Access']
    },
    {
      id: 'learn_skills',
      name: 'Learn Digital Skills',
      price: 50,
      icon: BookOpen,
      color: 'from-purple-500 to-blue-500',
      borderHover: 'hover:border-purple-500/60',
      features: ['Premium Courses', 'Graphic Design', 'Content Writing', 'Video Tutorials']
    },
    {
      id: 'earn_online',
      name: 'Earn Online',
      price: 200,
      icon: DollarSign,
      color: 'from-emerald-500 to-cyan-400',
      borderHover: 'hover:border-emerald-500/60',
      features: ['Trading Signals', 'AI Business Tools', 'Passive Income', 'Expert Mentorship']
    },
    {
      id: 'all_in_one',
      name: 'All In One',
      price: 300,
      icon: Sparkles,
      color: 'from-amber-500 to-orange-500',
      borderHover: 'hover:border-amber-500/60',
      features: ['Everything Above', 'Full Creator Mode', 'Priority Support', 'Exclusive Tools']
    }
  ];

  // Get existing active/pending sub for a plan
  const getExistingSubForPlan = (planId) => {
    return existingSubs
      .filter(s => s.plan === planId && (s.status === 'active' || s.status === 'pending'))
      .sort((a, b) => {
        if (a.end_date && b.end_date) return isAfter(parseISO(a.end_date), parseISO(b.end_date)) ? -1 : 1;
        return 0;
      })[0] || null;
  };

  // Check if there's already a pending submission for this plan (block double submit)
  const hasPendingForPlan = (planId) => {
    return existingSubs.some(s => s.plan === planId && s.status === 'pending');
  };

  // Compute what the new start/end date would be if subscribing again
  const computeNewDates = (planId) => {
    const existing = getExistingSubForPlan(planId);
    let startDate = new Date();
    if (existing && existing.end_date) {
      const endDate = parseISO(existing.end_date);
      if (isAfter(endDate, new Date())) {
        startDate = endDate; // continues from end of existing
      }
    }
    const endDate = addMonths(startDate, 1);
    return { startDate, endDate };
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setUploadError('');
    try {
      const { uploadFile } = await import('@/components/vpsAPI');
      const result = await uploadFile(file);
      setPaymentProofUrl(result.url);
    } catch (error) {
      setUploadError(error.message || 'Upload failed. Please try again.');
    }
    setUploading(false);
  };

  const handleTrialSubmit = async () => {
    if (!trialNickname.trim()) { setTrialError('Please enter a nickname to continue.'); return; }
    setTrialError('');
    setTrialSubmitting(true);
    // Check if already has a trial or active ethical_internet sub
    const existing = existingSubs.find(s => s.plan === 'ethical_internet' && ['active','pending'].includes(s.status));
    if (existing) { setTrialError('You already have an active or pending Ethical Free Internet subscription.'); setTrialSubmitting(false); return; }

    const startDate = new Date();
    const endDate = addMonths(startDate, 0); // 14 days trial
    endDate.setDate(endDate.getDate() + 14);

    await base44.entities.Subscription.create({
      user_email: user.email,
      user_name: user.full_name,
      plan: 'ethical_internet',
      amount_paid: 0,
      status: 'pending',
      notes: `FREE TRIAL (14 days) | Nickname: ${trialNickname.trim()}`,
      start_date: format(startDate, 'yyyy-MM-dd'),
      end_date: format(endDate, 'yyyy-MM-dd'),
    });

    setTrialSubmitting(false);
    setTrialSubmitted(true);
  };

  const handleSubmit = async () => {
    if (!selectedPlan || !paymentProofUrl || !user) return;
    const { startDate, endDate } = computeNewDates(selectedPlan.id);

    await base44.entities.Subscription.create({
      user_email: user.email,
      user_name: user.full_name,
      plan: selectedPlan.id,
      amount_paid: selectedPlan.price,
      payment_proof_url: paymentProofUrl,
      status: 'pending',
      start_date: format(startDate, 'yyyy-MM-dd'),
      end_date: format(endDate, 'yyyy-MM-dd'),
    });

    setSubmitted(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white flex items-center justify-center">
        <div className="text-gray-400">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white flex items-center justify-center p-6">
        <div className="text-center">
          <h2 className="text-xl font-bold mb-2">Please Login</h2>
          <p className="text-gray-400 mb-6">You need to be logged in to subscribe</p>
          <Link to={createPageUrl("Home")}><Button className="bg-blue-600">Go Home</Button></Link>
        </div>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white flex items-center justify-center p-6">
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center">
          <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <Check className="w-10 h-10 text-green-400" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Subscription Submitted!</h2>
          <p className="text-gray-400 mb-6">Your payment is being reviewed. You'll be activated once confirmed.</p>
          <Link to={createPageUrl("MySubscription")}>
            <Button className="bg-blue-600">View My Subscriptions</Button>
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center gap-4 mb-6">
          <Link to={createPageUrl("Home")} className="p-2 bg-gray-800/50 rounded-xl">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-xl font-bold">Subscribe to Premium</h1>
            <p className="text-xs text-gray-500">Tied to your account: {user.email}</p>
          </div>
        </div>

        {!selectedPlan ? (
          <div className="space-y-4">

            {/* ── Free Trial Banner ─────────────────────────────────────── */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
              className="bg-gradient-to-br from-violet-600/20 to-cyan-600/20 border border-violet-500/40 rounded-2xl p-5">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-violet-500 to-cyan-500 flex items-center justify-center flex-shrink-0">
                  <Gift className="w-5 h-5 text-white" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-white">14-Day Free Trial</h3>
                    <span className="text-[10px] bg-green-500/20 border border-green-500/40 text-green-300 px-2 py-0.5 rounded-full font-bold">FREE</span>
                  </div>
                  <p className="text-xs text-violet-300">Ethical Free Internet · Creator Mode</p>
                </div>
              </div>
              <p className="text-xs text-gray-400 mb-3 leading-relaxed">Try Creator Mode for 14 days at no cost. Experience VPN tools, privacy configs, and community features. After trial, continue at <span className="text-white font-bold">R50/month</span>.</p>

              {trialSubmitted ? (
                <div className="flex items-center gap-2 bg-green-500/15 border border-green-500/30 rounded-xl px-4 py-3">
                  <Check className="w-4 h-4 text-green-400" />
                  <p className="text-sm text-green-300 font-bold">Trial request submitted! You'll be approved within 24 hours.</p>
                </div>
              ) : existingSubs.some(s => s.plan === 'ethical_internet' && ['active','pending'].includes(s.status)) ? (
                <div className="flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 rounded-xl px-4 py-3">
                  <AlertCircle className="w-4 h-4 text-amber-400" />
                  <p className="text-xs text-amber-300">You already have an Ethical Free Internet subscription.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                    <input
                      value={trialNickname}
                      onChange={e => { setTrialNickname(e.target.value); setTrialError(''); }}
                      placeholder="Your nickname (shown in community)"
                      className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl pl-9 pr-4 py-2.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-violet-500/60"
                    />
                  </div>
                  {trialError && <p className="text-xs text-red-400">{trialError}</p>}
                  <button onClick={handleTrialSubmit} disabled={trialSubmitting || !trialNickname.trim()}
                    className="w-full py-3 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-violet-600 to-cyan-600 disabled:opacity-40 flex items-center justify-center gap-2">
                    {trialSubmitting ? 'Submitting...' : '🎁 Request Free Trial — No Payment Needed'}
                  </button>
                </div>
              )}
            </motion.div>

            <div className="flex items-center gap-3 my-1">
              <div className="flex-1 h-px bg-gray-700/50" />
              <p className="text-xs text-gray-600 font-bold uppercase tracking-wider">Or subscribe to a plan</p>
              <div className="flex-1 h-px bg-gray-700/50" />
            </div>

            {plans.map((plan, index) => {
              const existing = getExistingSubForPlan(plan.id);
              const { startDate, endDate } = computeNewDates(plan.id);
              const isRenewal = existing && existing.end_date && isAfter(parseISO(existing.end_date), new Date());

              return (
                <motion.div
                  key={plan.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  onClick={() => !hasPendingForPlan(plan.id) && setSelectedPlan(plan)}
                  className={`bg-gray-800/40 rounded-2xl p-5 border transition-all ${
                    hasPendingForPlan(plan.id) ? 'cursor-not-allowed opacity-70 border-yellow-500/30' :
                    isRenewal ? 'cursor-pointer border-amber-500/40 ' + plan.borderHover : 'cursor-pointer border-gray-700/50 ' + plan.borderHover
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${plan.color} flex items-center justify-center`}>
                        <plan.icon className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-bold text-white">{plan.name}</h3>
                        <p className="text-2xl font-bold text-cyan-400">R{plan.price}<span className="text-sm text-gray-500">/month</span></p>
                      </div>
                    </div>
                    {isRenewal && (
                      <span className="flex items-center gap-1 bg-amber-500/20 text-amber-400 text-xs px-2 py-1 rounded-full border border-amber-500/30">
                        <RefreshCw className="w-3 h-3" />
                        Renew
                      </span>
                    )}
                    {hasPendingForPlan(plan.id) && (
                      <span className="flex items-center gap-1 bg-yellow-500/20 text-yellow-400 text-xs px-2 py-1 rounded-full border border-yellow-500/30">
                        <AlertCircle className="w-3 h-3" />
                        Pending Review
                      </span>
                    )}
                  </div>

                  {/* Date preview */}
                  <div className="flex items-center gap-2 mb-3 bg-gray-900/50 rounded-xl px-3 py-2">
                    <CalendarDays className="w-4 h-4 text-gray-400 flex-shrink-0" />
                    <div className="text-xs text-gray-400">
                      {isRenewal ? (
                        <span className="text-amber-300">Continues from {format(parseISO(existing.end_date), 'dd MMM yyyy')} → {format(endDate, 'dd MMM yyyy')}</span>
                      ) : (
                        <span>{format(startDate, 'dd MMM yyyy')} → {format(endDate, 'dd MMM yyyy')}</span>
                      )}
                    </div>
                  </div>

                  {hasPendingForPlan(plan.id) && (
                    <div className="mb-3 flex items-center gap-2 bg-yellow-500/10 border border-yellow-500/30 rounded-xl px-3 py-2 text-xs text-yellow-300">
                      <AlertCircle className="w-4 h-4 flex-shrink-0" />
                      You already submitted a payment for this plan. Please wait for admin approval before submitting again.
                    </div>
                  )}

                  <ul className="space-y-1.5">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-center gap-2 text-sm text-gray-400">
                        <Check className="w-4 h-4 text-green-400 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </motion.div>
              );
            })}
          </div>
        ) : (
          <div className="space-y-5">
            {/* Selected Plan Summary */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
              className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">Selected Plan</h3>
                <Button variant="outline" size="sm" onClick={() => setSelectedPlan(null)}>Change</Button>
              </div>
              <div className="flex items-center gap-3 mb-3">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${selectedPlan.color} flex items-center justify-center`}>
                  <selectedPlan.icon className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="font-semibold text-white">{selectedPlan.name}</h4>
                  <p className="text-xl font-bold text-cyan-400">R{selectedPlan.price}/month</p>
                </div>
              </div>
              {/* Date range */}
              {(() => {
                const { startDate, endDate } = computeNewDates(selectedPlan.id);
                const existing = getExistingSubForPlan(selectedPlan.id);
                const isRenewal = existing && existing.end_date && isAfter(parseISO(existing.end_date), new Date());
                return (
                  <div className={`flex items-center gap-2 rounded-xl px-3 py-2 text-sm ${isRenewal ? 'bg-amber-500/10 border border-amber-500/30' : 'bg-blue-500/10 border border-blue-500/20'}`}>
                    <CalendarDays className={`w-4 h-4 ${isRenewal ? 'text-amber-400' : 'text-blue-400'}`} />
                    <span className={isRenewal ? 'text-amber-300' : 'text-blue-300'}>
                      {isRenewal
                        ? `Renewal: ${format(parseISO(existing.end_date), 'dd MMM yyyy')} → ${format(endDate, 'dd MMM yyyy')}`
                        : `From: ${format(startDate, 'dd MMM yyyy')} → ${format(endDate, 'dd MMM yyyy')}`
                      }
                    </span>
                  </div>
                );
              })()}
              {/* Account binding notice */}
              <div className="mt-3 flex items-center gap-2 text-xs text-gray-500 bg-gray-900/40 rounded-xl px-3 py-2">
                <AlertCircle className="w-3 h-3 text-gray-500" />
                This subscription is linked to <span className="text-gray-300 font-mono ml-1">{user.email}</span>
              </div>
            </motion.div>

            {/* Payment Instructions */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
              className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50">
              <h3 className="font-semibold mb-4">Payment Instructions</h3>
              <div className="space-y-3 text-sm">
                <div className="bg-gray-900/50 rounded-xl p-4 space-y-1">
                  <p className="text-gray-400 mb-2 font-medium">Bank Details:</p>
                  <p className="text-white font-semibold">FNB</p>
                  <p className="text-gray-300">Account: <span className="font-mono text-white">63182436524</span></p>
                  <p className="text-gray-300">Branch: <span className="font-mono text-white">250655</span></p>
                  <p className="text-gray-300">Account Holder: <span className="font-semibold text-white">Masters DeoVex</span></p>
                  <p className="text-amber-400 mt-2">Reference: {user?.email}</p>
                </div>
                <div className="bg-blue-500/10 rounded-xl p-3 border border-blue-500/30">
                  <p className="text-blue-300 text-xs">💡 Make payment above, then upload your proof of payment (screenshot or PDF).</p>
                </div>
              </div>
            </motion.div>

            {/* Upload Proof */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
              className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50">
              <h3 className="font-semibold mb-4">Upload Payment Proof</h3>
              <div className="space-y-4">
                <input type="file" accept="image/*,application/pdf" onChange={handleFileUpload} disabled={uploading} className="hidden" id="payment-proof" />
                <label htmlFor="payment-proof"
                  className="flex items-center justify-center gap-2 bg-gray-700/50 border border-gray-600 rounded-xl p-4 cursor-pointer hover:bg-gray-700/70 transition-colors">
                  <Upload className="w-5 h-5" />
                  {uploading ? 'Uploading...' : paymentProofUrl ? '✓ Change File' : 'Select File'}
                </label>
                {uploadError && (
                  <div className="flex items-start gap-2 bg-red-500/10 border border-red-500/30 rounded-xl px-3 py-2">
                    <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                    <p className="text-xs text-red-400">{uploadError}</p>
                  </div>
                )}
                {paymentProofUrl && (
                  <p className="text-sm text-green-400 flex items-center gap-2">
                    <Check className="w-4 h-4" /> Payment proof uploaded
                  </p>
                )}
                <Button onClick={handleSubmit} disabled={!paymentProofUrl || uploading} className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 font-semibold">
                  Submit Subscription Request
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
}