import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Wallet, Zap, Crown, Gift } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';

export default function BuyCredits() {
  const [profile, setProfile] = useState(null);
  const [selectedPackage, setSelectedPackage] = useState(null);
  const fromWallet = new URLSearchParams(window.location.search).get('from') === 'Wallet';

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    try {
      const user = await base44.auth.me();
      const profiles = await base44.entities.UserProfile.filter({ created_by: user.email });
      if (profiles.length > 0) {
        setProfile(profiles[0]);
      }
    } catch (error) {
      console.log('Error loading profile:', error);
    }
  };

  const packages = [
    {
      id: 'starter',
      amount: 50,
      credits: 50,
      bonus: 0,
      icon: Wallet,
      color: 'from-blue-500 to-cyan-400',
      popular: false
    },
    {
      id: 'popular',
      amount: 100,
      credits: 100,
      bonus: 20,
      icon: Zap,
      color: 'from-purple-500 to-pink-500',
      popular: true
    },
    {
      id: 'premium',
      amount: 200,
      credits: 200,
      bonus: 50,
      icon: Crown,
      color: 'from-amber-500 to-orange-500',
      popular: false
    },
    {
      id: 'mega',
      amount: 500,
      credits: 500,
      bonus: 150,
      icon: Gift,
      color: 'from-emerald-500 to-cyan-500',
      popular: false
    }
  ];

  const handlePurchase = (pkg) => {
    setSelectedPackage(pkg);
    // Payment integration will be added here
    alert(`Payment integration coming soon!\nPackage: R${pkg.amount}\nCredits: ${pkg.credits + pkg.bonus}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      {/* Header */}
      <div className="px-6 pt-6 pb-4 sticky top-0 bg-[#0a0a0f]/95 backdrop-blur-xl z-10 border-b border-gray-800/50">
        <div className="flex items-center gap-4 mb-2">
          <Link to={createPageUrl(fromWallet ? 'Wallet' : 'Home')} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-800 transition-all">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-2xl font-bold">Buy Credits</h1>
        </div>
        <p className="text-sm text-gray-400 ml-16">Choose a credit package</p>
      </div>

      {/* Current Balance */}
      {profile && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mx-6 mt-6 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-2xl p-6 border border-blue-500/20"
        >
          <p className="text-sm text-gray-400 mb-1">Current Balance</p>
          <div className="flex items-center gap-2">
            <Wallet className="w-6 h-6 text-blue-400" />
            <span className="text-3xl font-bold text-white">R{(profile.credits || 0).toFixed(2)}</span>
          </div>
        </motion.div>
      )}

      {/* Packages */}
      <div className="px-6 pt-6 space-y-4">
        <h2 className="text-sm font-semibold text-gray-400 mb-4">CREDIT PACKAGES</h2>
        
        {packages.map((pkg, index) => {
          const Icon = pkg.icon;
          const totalCredits = pkg.credits + pkg.bonus;
          
          return (
            <motion.div
              key={pkg.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <button
                onClick={() => handlePurchase(pkg)}
                className={`w-full relative bg-gray-800/40 hover:bg-gray-800/60 rounded-2xl p-5 border transition-all ${
                  pkg.popular ? 'border-purple-500/50' : 'border-gray-700/50'
                }`}
              >
                {pkg.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <span className="bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-bold px-3 py-1 rounded-full">
                      MOST POPULAR
                    </span>
                  </div>
                )}
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${pkg.color} flex items-center justify-center`}>
                      <Icon className="w-7 h-7 text-white" />
                    </div>
                    <div className="text-left">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xl font-bold text-white">{pkg.credits}</span>
                        {pkg.bonus > 0 && (
                          <span className="text-sm font-semibold text-green-400">+{pkg.bonus} bonus</span>
                        )}
                      </div>
                      <p className="text-sm text-gray-400">
                        Total: {totalCredits} credits
                      </p>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-2xl font-bold text-white">R{pkg.amount}</div>
                    {pkg.bonus > 0 && (
                      <div className="text-xs text-green-400">{Math.round((pkg.bonus / pkg.credits) * 100)}% extra</div>
                    )}
                  </div>
                </div>
              </button>
            </motion.div>
          );
        })}
      </div>

      {/* Info Section */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="mx-6 mt-6 bg-gray-800/30 rounded-2xl p-5 border border-gray-700/30"
      >
        <h3 className="font-semibold text-white mb-3">Payment Methods</h3>
        <p className="text-sm text-gray-400 mb-2">
          We accept all major South African payment methods including:
        </p>
        <ul className="text-sm text-gray-400 space-y-1 ml-4">
          <li>• Credit/Debit Cards</li>
          <li>• EFT</li>
          <li>• Instant EFT</li>
          <li>• SnapScan</li>
        </ul>
        <p className="text-xs text-gray-500 mt-3">
          Payment integration coming soon. All transactions are secure and encrypted.
        </p>
      </motion.div>
    </div>
  );
}