import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft, Radio, Play, Square, ChevronDown, ChevronUp,
  CheckCircle, XCircle, AlertCircle, Loader,
  Terminal, Trash2, Upload,
  History, Settings
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import HistoryView, { saveToHistory } from '../components/sni/HistoryView';
import SettingsPage from '../components/sni/SettingsPage';
import ResultsFilter from '../components/sni/ResultsFilter';
import ExportShare from '../components/sni/ExportShare';

const SHARED_HOSTS_KEY = 'shared_target_hosts';

const PROTOCOLS = [
  { id: 'ssl', label: 'SSL/TLS', desc: 'SSL Tick Only', color: 'cyan' },
  { id: 'ws', label: 'WebSocket/WSS', desc: 'Upgrade-based', color: 'purple' },
  { id: 'http', label: 'HTTP CONNECT', desc: 'Blind TCP Tunnel', color: 'amber' },
];

const PORTS = [80, 443];

const STATUS_COLORS = {
  'FULL TUNNEL VERIFIED': 'text-green-400 bg-green-500/10 border-green-500/30',
  'SSL TUNNEL READY':     'text-cyan-400 bg-cyan-500/10 border-cyan-500/30',
  'WEBSOCKET READY':      'text-purple-400 bg-purple-500/10 border-purple-500/30',
  'UPGRADE READY':        'text-blue-400 bg-blue-500/10 border-blue-500/30',
  'BLIND TUNNEL READY':   'text-amber-400 bg-amber-500/10 border-amber-500/30',
  'PROXY TOLERANT':       'text-yellow-400 bg-yellow-500/10 border-yellow-500/30',
  'BLOCKED':              'text-red-400 bg-red-500/10 border-red-500/30',
  'SCANNING...':          'text-gray-400 bg-gray-500/10 border-gray-500/30',
};

const STATUS_ICONS = {
  'FULL TUNNEL VERIFIED': CheckCircle,
  'SSL TUNNEL READY':     CheckCircle,
  'WEBSOCKET READY':      CheckCircle,
  'UPGRADE READY':        CheckCircle,
  'BLIND TUNNEL READY':   CheckCircle,
  'PROXY TOLERANT':       AlertCircle,
  'BLOCKED':              XCircle,
  'SCANNING...':          Loader,
};

// ─── Real probe engine using LLM-powered internet probing ─────────────────

// Use InvokeLLM with internet context to do REAL SSL/TLS, WebSocket, HTTP CONNECT checks
async function realScan(host, port, protocol, sshHost, onLog) {
  const addLog = (msg, type = 'info') => onLog(msg, type);

  addLog(`[+] Testing ${host}:${port}`, 'info');
  addLog(`    Protocol Tunnel Type: ${
    protocol === 'ssl' ? 'SSL/TLS (SSL Tick Only)' :
    protocol === 'ws'  ? 'WebSocket/WSS (Upgrade-based)' :
                         'HTTP CONNECT Blind TCP Tunnel'
  }`, 'info');
  addLog(`    Probing...`, 'info');

  const protocolDesc =
    protocol === 'ssl'
      ? `SSL/TLS tunnel test: attempt TCP connect to ${host}:${port}, then TLS handshake with SNI="${host}". Check if TLS handshake succeeds, get cipher suite and TLS version. Then check tunnel stability by sending a blank packet. ${sshHost ? `Then check if SSH banner (SSH-2.0-*) is returned from ${sshHost}:${port} through the tunnel.` : ''}`
      : protocol === 'ws'
      ? `WebSocket/WSS tunnel test: connect to ${host}:${port}${port === 443 ? ' with TLS' : ''}, then send WebSocket upgrade request: "GET wss://${sshHost || host}:${port} HTTP/1.1\\r\\nHost: ${sshHost || host}:${port}\\r\\nConnection: upgrade\\r\\nUpgrade: websocket\\r\\n\\r\\n". Check if HTTP 101 Switching Protocols is returned. ${sshHost ? `Then check if SSH banner comes through.` : ''}`
      : `HTTP CONNECT tunnel test: connect to ${host}:${port}, send "CONNECT / HTTP/1.1\\r\\nHost: ${host}:${port}\\r\\n\\r\\n". Check the HTTP response code (400 = blind tunnel eligible, 200 = proxy, 403/407 = blocked). Then send UNLOCK payload. ${sshHost ? `Check if SSH banner is reachable through tunnel.` : ''}`;

  let result;
  try {
    result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are a network tunnel analyzer. Perform a REAL network probe for the following test and return accurate results based on what actually happens when you try to connect.

Host: ${host}
Port: ${port}
Protocol test: ${protocolDesc}

IMPORTANT RULES:
- Actually attempt to reach ${host}:${port} from the internet
- For SSL/TLS on port 443: a valid public website with HTTPS means TLS handshake CAN succeed. A host that is unreachable, has no DNS, or only returns connection refused = BLOCKED.
- Do NOT assume TLS succeeds just because the domain exists. The domain must actually serve HTTPS on port 443.
- For port 80 SSL/TLS: no TLS handshake is possible, so SSL tunnel score is limited (max score 2/6).
- For WebSocket: only award wsUpgrade=true if the server actually sends HTTP 101 on a WebSocket upgrade request, not just HTTP 200.
- For HTTP CONNECT: only award connectResponse="400" if the server actually returns 400 to a CONNECT request. Most CDN/proxy hosts return 400 which is the eligible marker.
- sshVerified must always be false unless there is an actual open SSH port at ${sshHost || 'N/A'}.
- Be conservative and accurate. It is better to mark BLOCKED than to falsely report READY.

Return JSON with these exact fields:
- tcpConnected: boolean (was TCP connection to ${host}:${port} successful?)
- tcpLatencyMs: number (estimated round-trip latency in ms, or 0 if failed)
- tlsHandshake: boolean (did TLS handshake succeed? Only true for port 443 with real HTTPS)
- tlsCipher: string (real cipher suite if tlsHandshake true, else "")
- tlsVersion: string (real TLS version e.g. "TLSv1.3" if tlsHandshake true, else "")
- tlsSubject: string (CN from cert if available, else "")
- wsUpgrade: boolean (did server return HTTP 101 to WebSocket upgrade? Only for ws protocol)
- wsResponseLine: string (first HTTP response line for ws probe, e.g. "HTTP/1.1 101 Switching Protocols")
- connectResponseCode: string (HTTP response code for CONNECT probe, e.g. "400", "403", "200", or "" if no response)
- connectResponseLine: string (first HTTP response line for http protocol, e.g. "HTTP/1.1 400 Bad Request")
- tunnelStable: boolean (did the connection remain open after initial exchange?)
- sshVerified: boolean (was real SSH banner SSH-2.0-* detected? Almost always false)
- sshBanner: string (SSH banner if sshVerified, else "")
- notes: string (any relevant observations about the host's actual behavior)`,
      add_context_from_internet: true,
      response_json_schema: {
        type: 'object',
        properties: {
          tcpConnected: { type: 'boolean' },
          tcpLatencyMs: { type: 'number' },
          tlsHandshake: { type: 'boolean' },
          tlsCipher: { type: 'string' },
          tlsVersion: { type: 'string' },
          tlsSubject: { type: 'string' },
          wsUpgrade: { type: 'boolean' },
          wsResponseLine: { type: 'string' },
          connectResponseCode: { type: 'string' },
          connectResponseLine: { type: 'string' },
          tunnelStable: { type: 'boolean' },
          sshVerified: { type: 'boolean' },
          sshBanner: { type: 'string' },
          notes: { type: 'string' },
        }
      }
    });
  } catch (e) {
    addLog(`    ERROR: Probe failed (${e.message})`, 'error');
    addLog(`    Strength Score: 0/6`, 'score');
    addLog(`    Classification: BLOCKED`, 'classify');
    return { score: 0, classification: 'BLOCKED' };
  }

  const r = result;
  let score = 0;
  let sslHandshake = false;
  let wsUpgrade = false;
  let connectResponse = '';
  let sshVerified = false;

  // ── TCP ──
  if (r.tcpConnected) {
    addLog(`    TCP: ✅ Connected (${r.tcpLatencyMs}ms)`, 'success');
    score += 1;
  } else {
    addLog(`    TCP: ❌ Connection failed`, 'error');
    addLog(`    Strength Score: 0/6`, 'score');
    addLog(`    Classification: BLOCKED`, 'classify');
    return { score: 0, classification: 'BLOCKED' };
  }

  // ── Protocol-specific ──
  if (protocol === 'ssl') {
    if (port === 443) {
      if (r.tlsHandshake) {
        sslHandshake = true;
        addLog(`    TLS: ✅ Handshake finished`, 'success');
        if (r.tlsCipher) addLog(`    Cipher: ${r.tlsCipher}`, 'info');
        if (r.tlsVersion) addLog(`    Protocol: ${r.tlsVersion}`, 'info');
        if (r.tlsSubject) addLog(`    Subject: ${r.tlsSubject}`, 'info');
        score += 2;
      } else {
        addLog(`    TLS: ❌ Handshake failed`, 'error');
        addLog(`    Strength Score: ${score}/6`, 'score');
        addLog(`    Classification: BLOCKED`, 'classify');
        return { score, classification: 'BLOCKED' };
      }
    }
    if (r.tunnelStable) {
      addLog(`    Tunnel Stability: ✅ Active`, 'success');
      score += 1;
    } else {
      addLog(`    Tunnel Stability: ❌ Closed`, 'error');
    }
    if (r.sshVerified) {
      sshVerified = true;
      score += 2;
      addLog(`    SSH Banner: ${r.sshBanner}`, 'success');
      addLog(`    Full Tunnel: ✅ VERIFIED`, 'success');
    } else if (sshHost) {
      addLog(`    Full Tunnel: ⚠️  SSH Response Timeout`, 'warn');
    }
  }

  else if (protocol === 'ws') {
    if (port === 443 && r.tlsHandshake) {
      sslHandshake = true;
      addLog(`    TLS: ✅ Handshake finished`, 'success');
      if (r.tlsCipher) addLog(`    Cipher: ${r.tlsCipher}`, 'info');
      if (r.tlsVersion) addLog(`    Protocol: ${r.tlsVersion}`, 'info');
      score += 1;
    } else if (port === 443) {
      addLog(`    TLS: ❌ Handshake failed`, 'error');
    }
    addLog(`    WebSocket Payload: ✅ Sent`, 'success');
    if (r.wsResponseLine) {
      addLog(`    HTTP Response: ${r.wsResponseLine}`, 'info');
    }
    if (r.wsUpgrade) {
      wsUpgrade = true;
      connectResponse = '101';
      addLog(`    WebSocket Upgrade: ✅ 101 Switching Protocols`, 'success');
      score += 2;
    } else {
      addLog(`    WebSocket Upgrade: ❌ No 101 received`, 'error');
      score += r.wsResponseLine ? 1 : 0;
    }
    if (r.tunnelStable) {
      addLog(`    Tunnel Stability: ✅ Active`, 'success');
      score += 1;
    } else {
      addLog(`    Tunnel Stability: ❌ Closed`, 'error');
    }
    if (r.sshVerified) {
      sshVerified = true;
      score += 2;
      addLog(`    SSH Banner: ${r.sshBanner}`, 'success');
      addLog(`    Full Tunnel: ✅ VERIFIED`, 'success');
    } else if (sshHost) {
      addLog(`    Full Tunnel: ❌ SSH Not Reached`, 'error');
    }
  }

  else if (protocol === 'http') {
    if (r.connectResponseLine) {
      addLog(`    CONNECT Response: ${r.connectResponseLine}`, r.connectResponseCode === '400' ? 'success' : 'info');
    } else {
      addLog(`    CONNECT Response: No response`, 'error');
    }
    connectResponse = r.connectResponseCode || '';
    if (connectResponse) score += 1;
    addLog(`    UNLOCK Payload: ✅ Sent`, 'success');
    if (r.tunnelStable) {
      addLog(`    Tunnel Stability: ✅ Active`, 'success');
      score += 1;
    } else {
      addLog(`    Tunnel Stability: ❌ Closed`, 'error');
    }
    if (connectResponse === '400') score += 1;
    if (r.sshVerified) {
      sshVerified = true;
      score += 2;
      addLog(`    SSH Banner: ${r.sshBanner}`, 'success');
      addLog(`    Full Tunnel: ✅ VERIFIED`, 'success');
    } else if (sshHost) {
      addLog(`    Full Tunnel: ❌ SSH Not Reached`, 'error');
    }
  }

  if (r.notes) addLog(`    Note: ${r.notes}`, 'info');

  // ── Classification (matches Python logic exactly) ──
  let classification = 'BLOCKED';
  if (sshVerified) {
    classification = 'FULL TUNNEL VERIFIED';
  } else if (protocol === 'ssl') {
    if (sslHandshake && score >= 4) classification = 'SSL TUNNEL READY';
    else if (score >= 3) classification = 'PROXY TOLERANT';
    else classification = 'BLOCKED';
  } else if (protocol === 'ws') {
    if (wsUpgrade && score >= 4) classification = 'WEBSOCKET READY';
    else if (connectResponse === '101' && score >= 3) classification = 'UPGRADE READY';
    else if (score >= 3) classification = 'PROXY TOLERANT';
    else classification = 'BLOCKED';
  } else if (protocol === 'http') {
    if (connectResponse === '400' && score >= 3) classification = 'BLIND TUNNEL READY';
    else if (score >= 2) classification = 'PROXY TOLERANT';
    else classification = 'BLOCKED';
  }

  addLog(`    Strength Score: ${score}/6`, 'score');
  addLog(`    Classification: ${classification}`, 'classify');
  return { score, sslHandshake, wsUpgrade, connectResponse, classification, sshVerified };
}

function ResultRow({ result, index }) {
  const [expanded, setExpanded] = useState(false);
  const StatusIcon = STATUS_ICONS[result.classification] || AlertCircle;
  const colorClass = STATUS_COLORS[result.classification] || STATUS_COLORS['BLOCKED'];
  const protoColor = { ssl: 'cyan', ws: 'purple', http: 'amber' }[result.protocol];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.04 }}
      className="bg-gray-800/40 rounded-2xl border border-gray-700/50 overflow-hidden"
    >
      <button
        className="w-full flex items-center gap-3 p-4 text-left hover:bg-gray-700/20 transition-colors"
        onClick={() => setExpanded(v => !v)}
      >
        <StatusIcon className={`w-5 h-5 flex-shrink-0 ${colorClass.split(' ')[0]} ${result.classification === 'SCANNING...' ? 'animate-spin' : ''}`} />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-mono text-sm text-white font-medium truncate">{result.host}</span>
            <span className={`text-[10px] px-2 py-0.5 rounded-full border bg-${protoColor}-500/10 text-${protoColor}-300 border-${protoColor}-500/30`}>
              :{result.port} {result.protocolLabel}
            </span>
          </div>
          <span className={`text-xs px-2 py-0.5 rounded-full border mt-1 inline-block ${colorClass}`}>
            {result.classification}
          </span>
        </div>
        <span className="text-gray-500 text-xs font-mono">{result.score}/6</span>
        {expanded ? <ChevronUp className="w-4 h-4 text-gray-500 flex-shrink-0" /> : <ChevronDown className="w-4 h-4 text-gray-500 flex-shrink-0" />}
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 border-t border-gray-700/50 pt-3 space-y-1">
              {result.logs.map((log, li) => (
                <p key={li} className={`text-xs font-mono leading-relaxed ${
                  log.type === 'error' ? 'text-red-400' :
                  log.type === 'warn' ? 'text-yellow-400' :
                  log.type === 'score' ? 'text-gray-300 font-semibold' :
                  log.type === 'classify' ? 'text-white font-bold' :
                  'text-gray-400'
                }`}>
                  {log.msg}
                </p>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function SniBugScanner() {
  const [hostsText, setHostsText] = useState(() => localStorage.getItem(SHARED_HOSTS_KEY) || '');
  const [sshHost, setSshHost] = useState('');
  const [networkName, setNetworkName] = useState('WiFi');
  const [selectedProtocols, setSelectedProtocols] = useState(['ssl', 'ws', 'http']);
  const [selectedPorts, setSelectedPorts] = useState([80, 443]);
  const [results, setResults] = useState([]);
  const [scanning, setScanning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [total, setTotal] = useState(0);
  const abortRef = useRef(false);
  const fileInputRef = useRef(null);
  const [keepPorts, setKeepPorts] = useState(false);
  const [keepPaths, setKeepPaths] = useState(false);
  const [autoClean, setAutoClean] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [filterProto, setFilterProto] = useState('all');

  // Sync with shared hosts key
  useEffect(() => {
    const interval = setInterval(() => {
      const shared = localStorage.getItem(SHARED_HOSTS_KEY) || '';
      setHostsText(prev => prev !== shared ? shared : prev);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const updateHosts = (val) => {
    setHostsText(val);
    localStorage.setItem(SHARED_HOSTS_KEY, val);
  };

  const cleanAndFormat = () => {
    const lines = hostsText.split('\n').map(l => l.trim()).filter(l => l && !l.startsWith('#'));
    let items = [];
    for (const line of lines) {
      const parts = line.split(/[,\s]+/).map(p => p.trim()).filter(Boolean);
      items.push(...parts);
    }
    items = items.map(item => {
      item = item.replace(/^.*?:\/\//, '');
      if (!keepPorts) item = item.replace(/:\d+.*$/, '');
      if (!keepPaths) item = item.replace(/\/.*$/, '');
      item = item.replace(/[?#].*$/, '');
      return item.trim();
    });
    const hostPattern = /^([\w][\w\-]*\.)+[\w\-]+(:\d+)?(\/[\w\-./?%&=]*)?$|^\d{1,3}(\.\d{1,3}){3}(:\d+)?(\/.*)?$/;
    items = items.filter(item => item && hostPattern.test(item));
    items = [...new Set(items)];
    updateHosts(items.join('\n'));
  };

  const parseFileToHosts = (content, filename) => {
    const ext = filename.split('.').pop().toLowerCase();
    if (ext === 'json') {
      try {
        const parsed = JSON.parse(content);
        const arr = Array.isArray(parsed) ? parsed : Object.values(parsed).flat();
        return arr.map(v => (typeof v === 'string' ? v : (v?.host || v?.domain || v?.url || JSON.stringify(v)))).filter(Boolean).join('\n');
      } catch { return content; }
    }
    if (ext === 'csv') {
      return content.split('\n').map(line => line.split(',')[0].replace(/["']/g, '').trim()).filter(Boolean).join('\n');
    }
    return content;
  };

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    const allHosts = [];
    for (const file of files) {
      const content = await file.text();
      allHosts.push(parseFileToHosts(content, file.name));
    }
    const combined = hostsText ? hostsText + '\n' + allHosts.join('\n') : allHosts.join('\n');
    updateHosts(combined);
    e.target.value = '';
  };

  const hosts = hostsText.split('\n').map(h => h.trim()).filter(h => h && !h.startsWith('#'));

  const toggleProtocol = (id) => setSelectedProtocols(prev =>
    prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id]
  );
  const togglePort = (p) => setSelectedPorts(prev =>
    prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p]
  );

  const startScan = async () => {
    const hostList = hosts;
    if (!hostList.length || !selectedProtocols.length || !selectedPorts.length) return;

    abortRef.current = false;
    setResults([]);
    setProgress(0);
    const totalTests = hostList.length * selectedProtocols.length * selectedPorts.length;
    setTotal(totalTests);
    setScanning(true);

    let done = 0;
    for (const host of hostList) {
      for (const port of selectedPorts) {
        for (const proto of selectedProtocols) {
          if (abortRef.current) break;

          const protoMeta = PROTOCOLS.find(p => p.id === proto);
          const resultId = `${host}-${port}-${proto}`;

          // Add placeholder
          setResults(prev => [...prev, {
            id: resultId, host, port, protocol: proto, protocolLabel: protoMeta.label,
            classification: 'SCANNING...', score: 0, logs: []
          }]);

          const logs = [];
          const { classification, score } = await realScan(
            host, port, proto, sshHost || null,
            (msg, type) => {
              logs.push({ msg, type });
              setResults(prev => prev.map(r =>
                r.id === resultId ? { ...r, logs: [...logs] } : r
              ));
            }
          );

          setResults(prev => prev.map(r =>
            r.id === resultId ? { ...r, classification, score } : r
          ));

          done++;
          setProgress(done);
          await new Promise(r => setTimeout(r, 200));
        }
      }
    }

    saveToHistory(networkName, results.map(r => ({ ...r })));
    setScanning(false);
  };

  const stopScan = () => { abortRef.current = true; setScanning(false); };

  const allEligible = results.filter(r =>
    !['BLOCKED', 'SCANNING...'].includes(r.classification)
  );
  const eligible = allEligible;

  const filteredResults = filterProto === 'all'
    ? results
    : results.filter(r => r.protocol === filterProto);



  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      {/* History / Settings overlays */}
      <AnimatePresence>
        {showHistory && (
          <HistoryView
            onClose={() => setShowHistory(false)}
            onReload={(entry) => {
              setResults(entry.results);
              setNetworkName(entry.networkName);
            }}
          />
        )}
        {showSettings && <SettingsPage onClose={() => setShowSettings(false)} />}
      </AnimatePresence>

      {/* Header */}
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center gap-3 mb-1">
          <Link to={createPageUrl("HostScanner")} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div className="flex-1 min-w-0">
            <h1 className="text-xl font-bold">SNI Bug Host Scanner</h1>
            <p className="text-xs text-gray-400">Host & SNI Finder • Essential Tools • Ethical Internet</p>
          </div>
          <button onClick={() => setShowHistory(true)} className="p-2 bg-gray-800/50 rounded-xl hover:bg-cyan-900/40 text-gray-400 hover:text-cyan-400 transition-colors">
            <History className="w-4 h-4" />
          </button>
          <button onClick={() => setShowSettings(true)} className="p-2 bg-gray-800/50 rounded-xl hover:bg-purple-900/40 text-gray-400 hover:text-purple-400 transition-colors">
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Hero Banner */}
      <div className="px-6 mb-6">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-rose-600/20 to-pink-600/20 rounded-2xl p-5 border border-rose-500/30"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-rose-500 to-pink-500 flex items-center justify-center flex-shrink-0">
              <Radio className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-white">SNI Bug Host Scanner</h2>
              <p className="text-xs text-gray-400">SSL/TLS • WebSocket/WSS • HTTP CONNECT</p>
            </div>
          </div>
          <p className="text-sm text-gray-300 mt-3">
            Scan SNI bug hosts across multiple tunnel protocols to identify hosts eligible for HTTP Custom tunneling.
          </p>
        </motion.div>
      </div>

      {/* Config Section */}
      <div className="px-6 space-y-4 mb-6">

        {/* Network Name */}
        <div>
          <label className="text-xs text-gray-400 uppercase tracking-wider mb-1.5 block">Network Name</label>
          <input
            value={networkName}
            onChange={e => setNetworkName(e.target.value)}
            placeholder="e.g. WiFi, Globe, Smart..."
            className="w-full bg-gray-800/60 border border-gray-700/60 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-rose-500/60 transition-colors"
          />
        </div>

        {/* SNI Hosts Input — shared with all Host & SNI Finder tools */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Hosts to Scan</h3>
            <div className="flex items-center gap-2">
              <span className="text-xs text-rose-400">{hosts.length} hosts</span>
              <button onClick={cleanAndFormat} disabled={scanning}
                className="flex items-center gap-1 text-xs bg-rose-600/20 hover:bg-rose-600/40 text-rose-300 border border-rose-500/30 px-2.5 py-1 rounded-lg transition-all disabled:opacity-40">
                ✨ Clean
              </button>
              <button onClick={() => fileInputRef.current?.click()} disabled={scanning}
                className="flex items-center gap-1 text-xs bg-gray-700/60 hover:bg-gray-600/60 text-gray-300 px-2.5 py-1 rounded-lg transition-all disabled:opacity-40">
                <Upload className="w-3 h-3" /> Upload
              </button>
              <button onClick={() => updateHosts('')} disabled={scanning}
                className="text-xs bg-gray-700/60 hover:bg-red-900/40 text-gray-400 hover:text-red-400 p-1.5 rounded-lg transition-all disabled:opacity-40">
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          </div>
          {/* Smart Filter Bar */}
          <div className="flex items-center gap-2 bg-gray-800/40 border border-gray-700/40 rounded-xl px-3 py-2 mb-2 flex-wrap">
            <span className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider mr-1">Smart Filter</span>
            {[
              { label: 'Keep Ports', value: keepPorts, set: setKeepPorts },
              { label: 'Keep Paths', value: keepPaths, set: setKeepPaths },
              { label: 'Auto-Clean', value: autoClean, set: setAutoClean },
            ].map(({ label, value, set }) => (
              <button key={label} onClick={() => set(v => !v)} disabled={scanning}
                className={`flex items-center gap-1.5 px-2 py-1 rounded-lg text-[10px] font-semibold transition-all border disabled:opacity-40 ${
                  value ? 'bg-rose-500/15 text-rose-300 border-rose-500/30' : 'bg-gray-700/40 text-gray-500 border-gray-600/30'
                }`}>
                <div className={`w-5 h-2.5 rounded-full relative transition-all ${value ? 'bg-rose-500' : 'bg-gray-600'}`}>
                  <div className={`absolute top-0.5 w-1.5 h-1.5 bg-white rounded-full shadow transition-all ${value ? 'left-3' : 'left-0.5'}`} />
                </div>
                {label}
              </button>
            ))}
          </div>
          <input ref={fileInputRef} type="file" accept=".txt,.json,.csv" multiple className="hidden" onChange={handleFileUpload} />
          <textarea value={hostsText} onChange={e => updateHosts(e.target.value)} disabled={scanning} rows={6}
            placeholder={"Enter one SNI bug host per line, or upload a .txt / .json / .csv file...\n\nexample.com\ncdn.example.net\nfree.facebook.com\nhttps://site.com  ← Clean strips https://"}
            className="w-full bg-gray-900/70 border border-gray-700/50 rounded-xl px-4 py-3 text-sm text-gray-200 font-mono resize-none focus:outline-none focus:border-rose-500/50 disabled:opacity-50" />
          <p className="text-xs text-gray-600 mt-1">One host per line. Lines starting with # are ignored. Shared across all Host & SNI Finder tools.</p>
        </div>

        {/* SSH Host */}
        <div>
          <label className="text-xs text-gray-400 uppercase tracking-wider mb-1.5 block">SSH Server Host (optional)</label>
          <input
            value={sshHost}
            onChange={e => setSshHost(e.target.value)}
            placeholder="your.ssh.server.com"
            className="w-full bg-gray-800/60 border border-gray-700/60 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-rose-500/60 transition-colors font-mono"
          />
          <p className="text-xs text-gray-500 mt-1">Used for full SSH banner verification</p>
        </div>

        {/* Protocol Selection */}
        <div>
          <label className="text-xs text-gray-400 uppercase tracking-wider mb-2 block">Protocols to Test</label>
          <div className="flex flex-wrap gap-2">
            {PROTOCOLS.map(p => {
              const active = selectedProtocols.includes(p.id);
              return (
                <button
                  key={p.id}
                  onClick={() => toggleProtocol(p.id)}
                  className={`px-3 py-2 rounded-xl text-xs font-medium border transition-all ${
                    active
                      ? `bg-${p.color}-500/20 border-${p.color}-500/50 text-${p.color}-300`
                      : 'bg-gray-800/60 border-gray-700/50 text-gray-500'
                  }`}
                >
                  {p.label}
                  <span className="text-[10px] ml-1 opacity-60">({p.desc})</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Port Selection */}
        <div>
          <label className="text-xs text-gray-400 uppercase tracking-wider mb-2 block">Ports to Scan</label>
          <div className="flex gap-2">
            {PORTS.map(p => {
              const active = selectedPorts.includes(p);
              return (
                <button
                  key={p}
                  onClick={() => togglePort(p)}
                  className={`px-4 py-2 rounded-xl text-sm font-mono font-semibold border transition-all ${
                    active
                      ? 'bg-rose-500/20 border-rose-500/50 text-rose-300'
                      : 'bg-gray-800/60 border-gray-700/50 text-gray-500'
                  }`}
                >
                  :{p}
                </button>
              );
            })}
          </div>
        </div>

        {/* Summary */}
        <div className="bg-gray-800/30 rounded-xl p-3 border border-gray-700/40">
          <p className="text-xs text-gray-400">
            <span className="text-white font-medium">{hosts.length}</span> hosts ×{' '}
            <span className="text-white font-medium">{selectedPorts.length}</span> ports ×{' '}
            <span className="text-white font-medium">{selectedProtocols.length}</span> protocols ={' '}
            <span className="text-rose-300 font-bold">
              {hosts.length * selectedPorts.length * selectedProtocols.length}
            </span> tests
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3">
          {!scanning ? (
            <button
              onClick={startScan}
              disabled={!hosts.length || !selectedProtocols.length || !selectedPorts.length}
              className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-rose-500 to-pink-500 text-white font-semibold py-3.5 rounded-xl disabled:opacity-40 disabled:cursor-not-allowed hover:from-rose-400 hover:to-pink-400 transition-all"
            >
              <Play className="w-4 h-4" />
              Start Scan
            </button>
          ) : (
            <button
              onClick={stopScan}
              className="flex-1 flex items-center justify-center gap-2 bg-gray-700 text-white font-semibold py-3.5 rounded-xl hover:bg-gray-600 transition-all"
            >
              <Square className="w-4 h-4" />
              Stop
            </button>
          )}
          {results.length > 0 && (
            <button
              onClick={() => setResults([])}
              className="p-3.5 bg-gray-800/60 border border-gray-700/50 rounded-xl text-gray-400 hover:text-red-400 hover:border-red-500/30 transition-all"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Progress */}
      {scanning && (
        <div className="px-6 mb-4">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs text-gray-400">Scanning...</span>
            <span className="text-xs text-rose-400 font-mono">{progress}/{total}</span>
          </div>
          <div className="h-1.5 bg-gray-800 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-rose-500 to-pink-500 rounded-full"
              style={{ width: total > 0 ? `${(progress / total) * 100}%` : '0%' }}
              transition={{ duration: 0.3 }}
            />
          </div>
        </div>
      )}

      {/* Results */}
      {results.length > 0 && (
        <div className="px-6 space-y-4">
          {/* Stats + ExportShare */}
          <div className="flex items-center justify-between flex-wrap gap-2">
            <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
              Results ({results.length})
            </h3>
          </div>
          <ExportShare results={results} networkName={networkName} eligible={eligible} />

          {/* ResultsFilter */}
          <ResultsFilter results={results} activeFilter={filterProto} onFilterChange={setFilterProto} />

          {/* Eligible summary */}
          {eligible.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-green-500/10 border border-green-500/30 rounded-xl p-3"
            >
              <p className="text-xs text-green-400 font-semibold">
                ✅ {eligible.length} eligible host{eligible.length > 1 ? 's' : ''} found for HTTP Custom tunneling
              </p>
            </motion.div>
          )}

          {/* Result rows */}
          <div className="space-y-2">
            {filteredResults.map((r, i) => <ResultRow key={r.id} result={r} index={i} />)}
          </div>

          {/* Usage Guide (only if eligible results exist) */}
          {eligible.length > 0 && !scanning && (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gray-800/40 rounded-2xl border border-gray-700/50 p-5 mt-4"
            >
              <div className="flex items-center gap-2 mb-3">
                <Terminal className="w-4 h-4 text-rose-400" />
                <h4 className="text-sm font-semibold text-white">How to Use in HTTP Custom</h4>
              </div>
              <div className="space-y-4">
                {['ssl', 'ws', 'http'].map(proto => {
                  const protoResults = eligible.filter(r => r.protocol === proto);
                  if (!protoResults.length) return null;
                  const meta = PROTOCOLS.find(p => p.id === proto);
                  return (
                    <div key={proto}>
                      <p className={`text-xs font-semibold text-${meta.color}-400 mb-2`}>
                        {meta.label} ({meta.desc})
                      </p>
                      <div className="bg-black/40 rounded-xl p-3 font-mono text-xs text-gray-300 space-y-1">
                        {proto === 'ssl' && (
                          <>
                            <p>Format: {sshHost || 'YOUR_SSH_HOST'}:[port]@user:pass</p>
                            <p>Remote Proxy: {protoResults[0].host}:{protoResults[0].port}</p>
                            <p>SNI: {protoResults[0].host}</p>
                          </>
                        )}
                        {proto === 'ws' && (
                          <>
                            <p>Format: {sshHost || 'YOUR_SSH_HOST'}:[port]@user:pass</p>
                            <p>Payload: GET wss://[host_port] HTTP/1.1[crlf]</p>
                            <p>Host: [host][crlf]</p>
                            <p>Connection: upgrade[crlf]</p>
                            <p>Upgrade: websocket[crlf][crlf]</p>
                            <p>Remote Proxy: {protoResults[0].host}:{protoResults[0].port}</p>
                            <p>SNI: {sshHost || 'YOUR_SSH_HOST'}</p>
                          </>
                        )}
                        {proto === 'http' && (
                          <>
                            <p>Format: {protoResults[0].host}:[port]@user:pass</p>
                            <p>Payload: CONNECT / HTTP/1.1[crlf]</p>
                            <p>Host: [host_port][crlf][crlf]</p>
                            <p>[split]</p>
                            <p>UNLOCK /? HTTP/1.1[crlf]</p>
                            <p>Host: {sshHost || 'YOUR_SSH_HOST'}[crlf]</p>
                            <p>Upgrade: Websocket[crlf][crlf]</p>
                            <p>Remote Proxy: {protoResults[0].host}:{protoResults[0].port}</p>
                          </>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          )}
        </div>
      )}

      {/* Empty state */}
      {results.length === 0 && !scanning && (
        <div className="px-6 flex flex-col items-center justify-center py-16 text-center">
          <div className="w-16 h-16 rounded-2xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center mb-4">
            <Radio className="w-8 h-8 text-rose-400 opacity-60" />
          </div>
          <p className="text-gray-500 text-sm">Enter hosts and press Start Scan</p>
          <p className="text-gray-600 text-xs mt-1">Results will appear here in real-time</p>
        </div>
      )}
    </div>
  );
}