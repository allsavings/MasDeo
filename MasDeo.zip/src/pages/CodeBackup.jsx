import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Copy, Check, Code, ChevronDown, ChevronUp, Download } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

// ── All source files as plain text strings ──────────────────────────────────

const FILES = [
  {
    name: 'Layout.js',
    category: 'Core',
    code: `import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Home, Globe, BookOpen, DollarSign, Grid2X2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const currentPath = location.pathname;
  const [isAuthed, setIsAuthed] = useState(null);

  useEffect(() => {
    base44.auth.isAuthenticated().then(authed => {
      setIsAuthed(authed);
      if (!authed && currentPageName !== 'AuthScreen') {
        const wasAuthed = sessionStorage.getItem('was_authenticated');
        if (!wasAuthed) window.location.href = createPageUrl('AuthScreen');
      } else if (authed) {
        sessionStorage.setItem('was_authenticated', 'true');
      }
    });
  }, [currentPageName]);

  if (currentPageName === 'AuthScreen') return <div className="min-h-screen bg-[#0a0a0f]">{children}</div>;
  if (isAuthed === null) return null;
  if (isAuthed === false) return null;

  const navItems = [
    { icon: Home,       label: "Home",    page: "Home",           path: "/" },
    { icon: Globe,      label: "Ethical", page: "EthicalInternet",path: "/EthicalInternet" },
    { icon: BookOpen,   label: "Learn",   page: "LearnSkills",    path: "/LearnSkills" },
    { icon: DollarSign, label: "Earn",    page: "EarnOnline",     path: "/EarnOnline" },
    { icon: Grid2X2,    label: "More",    page: "Profile",        path: "/Profile" },
  ];

  const isActive = (item) => {
    if (item.path === "/" && (currentPath === "/" || currentPath === "/Home")) return true;
    return currentPath.includes(item.page);
  };

  const hideNav = ['Profile','Settings','HelpSupport','AuthScreen'].some(p => currentPath.includes(p));

  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      {children}
      {!hideNav && (
        <motion.div initial={{ y: 100 }} animate={{ y: 0 }}
          className="fixed bottom-0 left-0 right-0 bg-[#0a0a0f]/95 backdrop-blur-xl border-t border-gray-800/50 px-2 pb-2 pt-1 z-50">
          <div className="max-w-lg mx-auto flex items-center justify-around">
            {navItems.map((item) => {
              const active = isActive(item);
              return (
                <Link key={item.label} to={createPageUrl(item.page)} className="flex-1">
                  <div className={\`flex flex-col items-center py-2 px-1 rounded-xl transition-all \${active ? 'bg-blue-500/10' : 'hover:bg-gray-800/50'}\`}>
                    <item.icon className={\`w-5 h-5 mb-1 \${active ? 'text-cyan-400' : 'text-gray-500'}\`} />
                    <span className={\`text-[10px] font-medium \${active ? 'text-cyan-400' : 'text-gray-500'}\`}>{item.label}</span>
                  </div>
                </Link>
              );
            })}
          </div>
        </motion.div>
      )}
    </div>
  );
}`
  },
  {
    name: 'entities/UserProfile.json',
    category: 'Entities',
    code: `{
  "name": "UserProfile",
  "type": "object",
  "properties": {
    "nickname": { "type": "string", "default": "Tk Master" },
    "handle": { "type": "string", "default": "@MastersDeoVex" },
    "username": { "type": "string" },
    "phone": { "type": "string" },
    "profile_picture_url": { "type": "string" },
    "membership_type": { "type": "string", "enum": ["free","premium"], "default": "free" },
    "premium_type": { "type": "string", "enum": ["none","ethical_free_internet","learn_digital_skills","earn_online","all_in_one"], "default": "none" },
    "credits": { "type": "number", "default": 0 },
    "is_banned": { "type": "boolean", "default": false },
    "ban_reason": { "type": "string" },
    "last_seen": { "type": "string" }
  },
  "required": ["nickname"]
}`
  },
  {
    name: 'entities/Subscription.json',
    category: 'Entities',
    code: `{
  "name": "Subscription",
  "type": "object",
  "properties": {
    "user_email": { "type": "string" },
    "user_name": { "type": "string" },
    "plan": { "type": "string", "enum": ["ethical_internet","learn_skills","earn_online","all_in_one"] },
    "status": { "type": "string", "enum": ["pending","active","rejected","cancelled"], "default": "pending" },
    "payment_proof_url": { "type": "string" },
    "amount_paid": { "type": "number" },
    "start_date": { "type": "string", "format": "date" },
    "end_date": { "type": "string", "format": "date" },
    "approved_by": { "type": "string" },
    "approved_date": { "type": "string", "format": "date" },
    "creator_mode_enabled": { "type": "boolean", "default": false },
    "creator_verified": { "type": "boolean", "default": false },
    "creator_public": { "type": "boolean", "default": false },
    "notes": { "type": "string" }
  },
  "required": ["user_email","plan"]
}`
  },
  {
    name: 'entities/CreatorProfile.json',
    category: 'Entities',
    code: `{
  "name": "CreatorProfile",
  "type": "object",
  "properties": {
    "user_email": { "type": "string" },
    "creator_type": { "type": "string", "enum": ["ethical_free_internet","learn_digital_skills","earn_online"] },
    "verified": { "type": "boolean", "default": false },
    "verification_requested": { "type": "boolean", "default": false },
    "trust_score": { "type": "number", "default": 0 },
    "strikes": { "type": "number", "default": 0 },
    "banned": { "type": "boolean", "default": false },
    "bio": { "type": "string" },
    "total_ratings": { "type": "number", "default": 0 },
    "average_rating": { "type": "number", "default": 0 }
  },
  "required": ["user_email","creator_type"]
}`
  },
  {
    name: 'entities/CreatorSettings.json',
    category: 'Entities',
    code: `{
  "name": "CreatorSettings",
  "type": "object",
  "properties": {
    "user_email": { "type": "string" },
    "is_public": { "type": "boolean", "default": false },
    "platforms": { "type": "array", "items": { "type": "string", "enum": ["ethical","learn","earn"] } },
    "all_platforms": { "type": "boolean", "default": false }
  },
  "required": ["user_email"]
}`
  },
  {
    name: 'entities/Follow.json',
    category: 'Entities',
    code: `{
  "name": "Follow",
  "type": "object",
  "properties": {
    "user_email": { "type": "string" },
    "creator_id": { "type": "string" },
    "creator_email": { "type": "string" }
  },
  "required": ["user_email","creator_id","creator_email"]
}`
  },
  {
    name: 'entities/Withdrawal.json',
    category: 'Entities',
    code: `{
  "name": "Withdrawal",
  "type": "object",
  "properties": {
    "user_email": { "type": "string" },
    "amount": { "type": "number" },
    "bank_name": { "type": "string" },
    "account_number": { "type": "string" },
    "account_holder_name": { "type": "string" },
    "status": { "type": "string", "enum": ["pending","processing","completed","rejected"], "default": "pending" },
    "notes": { "type": "string" }
  },
  "required": ["user_email","amount","bank_name","account_number","account_holder_name"]
}`
  },
  {
    name: 'entities/ContentView.json + ContentDownload.json + ContentReaction.json + ContentComment.json',
    category: 'Entities',
    code: `// ContentView.json
{ "name": "ContentView", "properties": { "content_id": {"type":"string"}, "user_email": {"type":"string"} }, "required": ["content_id","user_email"] }

// ContentDownload.json
{ "name": "ContentDownload", "properties": { "content_id": {"type":"string"}, "user_email": {"type":"string"} }, "required": ["content_id","user_email"] }

// ContentReaction.json
{ "name": "ContentReaction", "properties": {
    "content_id": {"type":"string"}, "user_email": {"type":"string"},
    "reaction_type": {"type":"string","enum":["like","love","wow"],"default":"like"}
  }, "required": ["content_id","user_email"]
}

// ContentComment.json
{ "name": "ContentComment", "properties": {
    "content_id": {"type":"string"}, "user_email": {"type":"string"},
    "user_name": {"type":"string"}, "comment_text": {"type":"string"}
  }, "required": ["content_id","user_email","comment_text"]
}`
  },
  {
    name: 'entities/CreatorVpnFile.json + CreatorVpsServer.json + CreatorCourse.json + CreatorResource.json',
    category: 'Entities',
    code: `// CreatorVpnFile.json
{ "name": "CreatorVpnFile", "properties": {
    "creator_email":{}, "file_name":{}, "file_type":{"enum":["ovpn","ssh","ssl","v2ray","wireguard","other"],"default":"ovpn"},
    "server_location":{}, "protocol":{}, "description":{}, "file_url":{},
    "is_public":{"type":"boolean","default":false}, "download_count":{"type":"number","default":0}
  }, "required":["creator_email","file_name"]
}

// CreatorVpsServer.json
{ "name": "CreatorVpsServer", "properties": {
    "creator_email":{}, "server_name":{}, "ip_address":{}, "location":{}, "os":{},
    "website_url":{}, "scripts":{"type":"array"}, "is_public":{"type":"boolean","default":false}
  }, "required":["creator_email","server_name"]
}

// CreatorCourse.json
{ "name": "CreatorCourse", "properties": {
    "creator_email":{}, "title":{}, "description":{},
    "category":{"enum":["graphic_design","content_writing","web_dev","digital_marketing","video_editing","programming","other"],"default":"other"},
    "video_url":{}, "thumbnail_url":{}, "duration":{},
    "is_free":{"type":"boolean","default":false}, "price":{"type":"number","default":0},
    "is_published":{"type":"boolean","default":false}, "enrollment_count":{"type":"number","default":0}
  }, "required":["creator_email","title"]
}

// CreatorResource.json
{ "name": "CreatorResource", "properties": {
    "creator_email":{}, "title":{},
    "resource_type":{"enum":["forex_signal","trading_robot","trading_course","passive_income","ai_tool","mentorship","other"],"default":"forex_signal"},
    "file_url":{}, "external_link":{}, "thumbnail_url":{},
    "is_free":{}, "price":{}, "is_published":{}, "tags":{}
  }, "required":["creator_email","title","resource_type"]
}`
  },
  {
    name: 'entities/AdminSession.json',
    category: 'Entities',
    code: `{
  "name": "AdminSession",
  "type": "object",
  "properties": {
    "session_token": { "type": "string" },
    "session_expires_at": { "type": "string", "format": "date-time" },
    "is_active": { "type": "boolean", "default": true },
    "admin_email": { "type": "string" }
  }
}`
  },
  {
    name: 'pages/Home.jsx',
    category: 'Pages',
    code: `// Main home dashboard
// - PIN lock via localStorage('app_pin') → shows PinLock component on start
// - Loads UserProfile, active Subscriptions, CreatorProfile, Follow counts
// - Shows profile picture (only for premium users with custom pic), otherwise default logo
// - Wallet menu: show/hide credit balance, navigate to EarnCredits/BuyCredits/WithdrawCredits
// - Plan badge: detects combo plans (All-In-One, Ethical+Learn, etc.)
// - Creator Mode toggle (requires active subscription)
// - Explore Creators toggle (available to all users)
// - Creator Dashboard link shown when creator mode is ON
// - Category cards: Ethical Internet, Learn Skills, Earn Online, Premium Subscription
// - Search → Discover page, Following feed → Following page
// - Featured "Start Your Journey" CTA
//
// Key state: profile, user, activeSubs, isCreatorMode, exploreCreatorsMode, followerCount
// localStorage keys used: app_pin, creator_mode_active, show_credit, explore_creators_mode`
  },
  {
    name: 'pages/EthicalInternet.jsx',
    category: 'Pages',
    code: `// Ethical Free Internet section
// 3 modes:
//   1. Creator Mode (isCreatorMode + canCreatorForSection('ethical_internet')) → <CreatorEthicalInternet />
//   2. Explore Creators (localStorage explore_creators_mode=true) → <ExploreCreatorsView theme="ethical" />
//   3. Default: VPN recommendation (Lets VPN Go), Essential Tools, Topics
//
// Recommended VPN: Lets VPN Go (PlayStore + direct APK download links)
// Tools: Termux, Scripts, Speed Test, Host & SNI Finder → HostScanner page
// Topics: Privacy Basics, Secure Browsing, Digital Footprint, Free Resources, Network Security`
  },
  {
    name: 'pages/LearnSkills.jsx',
    category: 'Pages',
    code: `// Learn Digital Skills section
// 3 modes same as EthicalInternet but theme="learn"
// Default: sample course cards (Graphic Design, Content Writing, Web Dev, etc.)
// Each course shows: title, description, category, duration, lesson count, free/paid badge`
  },
  {
    name: 'pages/EarnOnline.jsx',
    category: 'Pages',
    code: `// Earn Online section
// 3 modes same pattern, theme="earn"
// Default: Opportunities list: Forex, Freelancing, Affiliate Marketing, Content Creation, Referrals
// Each card shows potential monthly earnings
// CTA → LearnSkills page`
  },
  {
    name: 'pages/Subscribe.jsx',
    category: 'Pages',
    code: `// Subscription purchase page
// Plans: Ethical Internet (R50), Learn Skills (R50), Earn Online (R200), All In One (R300)
// Smart renewal: new period starts from end of current active sub
// Blocks double-submit: shows "Pending Review" if payment already submitted
// Payment: FNB Bank — Account 63182436524, Branch 250655, Holder: Masters DeoVex
// Upload proof image/PDF → Subscription entity status='pending'
// Admin approves from Admin page`
  },
  {
    name: 'pages/MySubscription.jsx',
    category: 'Pages',
    code: `// Subscription history & creator toggle
// Groups subs by plan, shows active/expired badges, date ranges
// Creator Mode ON/OFF toggle (localStorage creator_mode_active)
// "Open Creator Dashboard" → CreatorMode page
// Renew button shown if expired or no active sub`
  },
  {
    name: 'pages/Admin.jsx',
    category: 'Pages',
    code: `// Wrapped in <AdminGuard> component
// 3 tabs: Subscriptions | Users | Settings
//
// Subscriptions tab:
//   - Approve / Reject / Cancel subscriptions
//   - Grant Creator Mode, Verify Creator, Toggle Public visibility
//   - Ban/Unban users, add admin notes
//   - View payment proof images
//
// Users tab:
//   - List all users with online status (last_seen within 5 min = online)
//   - Ban/Unban with reason, join date, plan badges
//
// Settings tab:
//   - VPS host + token config for CDN/WAF Scanner (saved to localStorage)
//
// ADMIN_EMAIL = '772mastersunlimited@gmail.com'`
  },
  {
    name: 'pages/AdminPanel.jsx',
    category: 'Pages',
    code: `// 3-step admin login: email → staticCode → secondCode
// ADMIN_EMAIL = '772mastersunlimited@gmail.com'
// STATIC_CODE = '0000ADMIN'
// SECOND_CODE = 'MASTER2025'
// On success: creates AdminSession in DB, stores sessionId + token in localStorage
// Session expires in 24 hours
// Existing valid session → auto-redirects to Admin page`
  },
  {
    name: 'pages/Profile.jsx',
    category: 'Pages',
    code: `// Account / More menu page
// Shows: Masters DeoVex logo, welcome message
// Membership badge: All-In-One Premium / Premium Member / Free Member
// Menu: My Profile → Settings, Browse Creators, Help & Support, Settings, Admin Panel
// Sign Out button: confirm → clear app_pin + pending_signup → base44.auth.logout()`
  },
  {
    name: 'pages/Settings.jsx',
    category: 'Pages',
    code: `// Full user settings page
// Profile editing: nickname, username, phone, handle
// Profile picture upload (premium only)
// Creator type selection modal
// Preferences: notifications, dark mode, language toggles
// Security: 4-digit PIN setup/removal (localStorage app_pin)
// Account: logout button`
  },
  {
    name: 'pages/AuthScreen.jsx',
    category: 'Pages',
    code: `// If authenticated: shows logout confirmation modal ("Yes, Logout" / "Cancel")
// If not authenticated: redirects to base44.auth.redirectToLogin()
// Logout clears: app_pin, pending_signup, creator_mode_active from localStorage
// Cancel → navigate back to Home`
  },
  {
    name: 'pages/CreatorDashboard.jsx',
    category: 'Pages',
    code: `// Creator management hub (requires active subscription)
// Sections: Profile, Content Overview, Analytics, Platform Management
// Toggle public visibility per platform (ethical/learn/earn) or all
// Save bio, change creator type
// Request profile verification from admin
// Shows follower count, content counts (VPN files, courses, resources)`
  },
  {
    name: 'pages/BrowseCreators.jsx',
    category: 'Pages',
    code: `// Public creator directory
// Loads all non-banned CreatorProfiles where settings.is_public=true
// Filter tabs: All | Ethical Free Internet | Learn Digital Skills | Earn Online
// Each creator card: avatar, nickname, handle, bio, followers, rating, TrustBadge
// Links to CreatorProfile?id={creator.id}`
  },
  {
    name: 'pages/CreatorProfile.jsx',
    category: 'Pages',
    code: `// Individual creator public profile page
// Shows creator info, bio, verified badge, trust score
// Follow/Unfollow button (tracks Follow entity)
// Content tabs: VPN Files, Courses, Resources
// Uses ContentItem component for each content card`
  },
  {
    name: 'pages/HostScanner.jsx',
    category: 'Pages',
    code: `// Navigation hub for all scanning tools
// Tools listed:
//   - Datafree Website Scanner → ZeroRatedScan
//   - SNI Bug Host Scanner → SniBugScanner
//   - CDN & WAF Scanner → CdnWafScanner
//   - JSON Cleaner → JsonCleaner
// Each tool: icon, title, description, version badge, color theme`
  },
  {
    name: 'pages/ZeroRatedScan.jsx',
    category: 'Pages',
    code: `// Datafree Website Scanner — 3 tabs: Scanner | Scripts | Termux Guide
//
// Scanner tab:
//   - Hosts input: textarea, file upload (.txt/.json/.csv), Smart Filter (Keep Ports/Paths, Auto-Clean)
//   - Carrier detection via no-cors fetch probes on CARRIER_PROBES domains
//   - Zero balance check: Google unreachable = zero SIM
//   - Batch scan (10 hosts/batch), results: zero-rated (reachable) / blocked
//   - Termux Mode: copies hosts to clipboard + opens Termux via intent
//   - Download results (all or zero-rated only)
//   - Balance error warning, progress bar, stats grid
//
// Scripts tab:
//   - Python script v8.3 (for Termux)
//   - App JS code (browser CORS detection)
//   - APK File Structure section (stats, folder breakdown, tech stack)
//   - APK download button
//
// Termux Guide tab:
//   - 8-step setup: Install Termux → Storage → Python → Folder → Hosts → Script → Run → Results
//
// Carriers: Vodacom, MTN, Telkom, Cell C, Rain, Knect, Melon, Capitec, Afrihost, MWEB, MVNO...
// localStorage key: 'shared_target_hosts'`
  },
  {
    name: 'pages/SniBugScanner.jsx',
    category: 'Pages',
    code: `// SNI Bug Host Scanner
// Uses base44.integrations.Core.InvokeLLM with add_context_from_internet=true
// Protocols tested: ssl (SSL Tick), ws (WebSocket/WSS), http (HTTP CONNECT Tunnel)
// Ports: :80, :443
// Score 0-6 per test (+1 TCP, +2 TLS, +1 tunnel stable, +2 SSH verified)
// Classifications: FULL TUNNEL VERIFIED > SSL TUNNEL READY > WEBSOCKET READY > ...
// History saved to localStorage('sni_scan_history')
// Components: HistoryView, SettingsPage, ResultsFilter, ExportShare`
  },
  {
    name: 'pages/CdnWafScanner.jsx',
    category: 'Pages',
    code: `// CDN & WAF infrastructure detector
// Shares host list via localStorage('shared_target_hosts')
// Calls VPS API: POST https://{vpsHost}/run/M@☆  plugin: CDNWAF_Scanner
// batch size: 3 concurrent
// Options: IP & Org Lookup toggle, Full Headers toggle
// Smart Filter same as ZeroRatedScan
// DEFAULT_HOST = 'fx.tkmaster.qzz.io', DEFAULT_TOKEN = '123000'`
  },
  {
    name: 'pages/JsonCleaner.jsx',
    category: 'Pages',
    code: `// JSON to hosts/IPs extractor
// Parses NDJSON, JSON arrays, single objects
// Extracts hosts (subdomain/host/domain/hostname/url/target/fqdn)
// Extracts IPs (ip/IP/ip_address/ipAddress/ips/addresses/resolved_ip)
// 3 output modes: Host Only | IP Only | Both
// File upload: .json, .txt, .ndjson
// Copy + Download output as .txt`
  },
  {
    name: 'pages/Following.jsx',
    category: 'Pages',
    code: `// Following feed page
// Loads Follow records for current user
// Fetches profiles of followed creators + their public content
// Sorts content chronologically
// Shows "Browse Creators" CTA if not following anyone`
  },
  {
    name: 'pages/Discover.jsx',
    category: 'Pages',
    code: `// Search/discovery hub
// Cards for: Ethical Free Internet, Learn Digital Skills, Earn Online
// Browse Creators section → BrowseCreators page`
  },
  {
    name: 'pages/HelpSupport.jsx',
    category: 'Pages',
    code: `// Help & Support page
// FAQ accordion, contact info, troubleshooting tips`
  },
  {
    name: 'pages/BuyCredits.jsx',
    category: 'Pages',
    code: `// Credit packages page
// Packages: various amounts with bonus credits
// Shows current balance from UserProfile.credits
// Payment integration placeholder (alert for now)
//
// BACK NAVIGATION LOGIC:
// Reads ?from=Wallet URL param:
//   - If from=Wallet → back button goes to Wallet page
//   - Otherwise → back button goes to Home
// const fromWallet = new URLSearchParams(window.location.search).get('from') === 'Wallet';
// Links from Wallet page include ?from=Wallet, links from Home dropdown do NOT`
  },
  {
    name: 'pages/EarnCredits.jsx',
    category: 'Pages',
    code: `// Earn credits page
// Referral system: generates referral code, copy link button
// Ad watching placeholder
// How It Works section
//
// BACK NAVIGATION LOGIC:
// Reads ?from=Wallet URL param:
//   - If from=Wallet → back button goes to Wallet page
//   - Otherwise → back button goes to Home
// const fromWallet = new URLSearchParams(window.location.search).get('from') === 'Wallet';`
  },
  {
    name: 'pages/WithdrawCredits.jsx',
    category: 'Pages',
    code: `// Withdraw credits to bank account
// Form: amount, bank name (South African banks), account number, account holder
// Validates minimum amount, creates Withdrawal entity, deducts from UserProfile.credits
//
// BACK NAVIGATION LOGIC:
// Reads ?from=Wallet URL param:
//   - If from=Wallet → back button goes to Wallet page
//   - Otherwise → back button goes to Home
// const fromWallet = new URLSearchParams(window.location.search).get('from') === 'Wallet';`
  },
  {
    name: 'pages/Forex.jsx',
    category: 'Pages',
    code: `// Forex trading info page (static)
// 4 tool cards: Trading Bots, Robot Systems, Trading Signals, Market Analysis
// Risk warning banner
// CTA → LearnSkills page`
  },
  {
    name: 'pages/Premium.jsx',
    category: 'Pages',
    code: `// Premium upsell page (static)
// Features: courses, earning, mentorship, community, certificates, support
// Price: $9.99/month
// 3 locked course previews
// "Upgrade Now" button (placeholder)`
  },
  {
    name: 'pages/SetupPin.jsx',
    category: 'Pages',
    code: `// 4-digit PIN setup page
// Enter new PIN → confirm PIN → save to localStorage('app_pin')
// Option to remove existing PIN`
  },
  {
    name: 'components/PinLock.jsx',
    category: 'Components',
    code: `// 4-digit PIN lock screen
// Reads savedPin from localStorage('app_pin')
// 4 dot indicators + numpad (1-9, 0, delete)
// Auto-validates when 4 digits entered
// Calls onUnlock() on match, error + reset on mismatch
// "Forgot PIN?" clears pin & reloads`
  },
  {
    name: 'components/AdminGuard.jsx',
    category: 'Components',
    code: `// Protects admin routes
// Reads adminSessionId + adminSessionToken from localStorage
// Validates against AdminSession entity in DB
// Checks session_expires_at, deactivates if expired
// Redirects to AdminPanel if invalid
// Renders children only on valid session`
  },
  {
    name: 'components/AuthContext.jsx',
    category: 'Components',
    code: `// Global auth state via React Context + useReducer
// Actions: SET_USER, CLEAR_USER, SET_LOADING, SET_ERROR
// initialState: { currentUser: null, loading: false, error: null }
// Exported: AuthContext, AuthProvider`
  },
  {
    name: 'components/useCreatorMode.js',
    category: 'Components',
    code: `// Hook: manages creator mode state
// Fetches user auth + active subscriptions
// isCreatorEligible: true if any active sub exists
// isCreatorMode: from localStorage('creator_mode_active')
// toggleCreatorMode(): toggles and saves to localStorage
// canCreatorForSection(section): checks if user has sub for that section
// Returns: { user, isCreatorMode, isCreatorEligible, activePlans, toggleCreatorMode, canCreatorForSection, loading }`
  },
  {
    name: 'components/creator/CreatorModeToggle.jsx',
    category: 'Components',
    code: `// Toggle switch for creator mode
// Only renders if isCreatorEligible
// Purple when ON, gray when OFF
// Zap icon when active, ZapOff when inactive`
  },
  {
    name: 'components/creator/ExploreCreatorsView.jsx',
    category: 'Components',
    code: `// Creator discovery browser
// Themes: ethical (blue/cyan), learn (purple/blue), earn (emerald/cyan)
// CreatorCard: avatar/initials, nickname, handle, bio, followers, rating, trust score, verified badge
// Links to CreatorProfile?id={creator.id}
// Handles loading + empty states`
  },
  {
    name: 'components/creator/TrustBadge.jsx',
    category: 'Components',
    code: `// Rank badge for verified creators only
// score 0   → Verified (blue)
// score 1-39  → Bronze Creator (orange)
// score 40-59 → Silver Creator (gray)
// score 60-79 → Gold Creator (yellow)
// score 80+   → Elite Creator (amber crown)`
  },
  {
    name: 'components/creator/ContentItem.jsx',
    category: 'Components',
    code: `// Universal content card (VPN files, courses, resources, VPS)
// On mount: tracks ContentView, loads views/downloads/reactions/comments counts
// handleReaction(): toggles ContentReaction (like)
// handleDownload(): tracks ContentDownload, opens file_url/video_url/external_link
// handleShare(): Web Share API or clipboard fallback
// handleComment(): creates ContentComment
// Actions: ❤️ Like | ▶ Watch/⬇ Download/🔗 Visit | Share | 💬 Comments`
  },
  {
    name: 'components/sni/HistoryView.jsx',
    category: 'Components',
    code: `// Scan history bottom sheet for SNI Scanner
// localStorage key: 'sni_scan_history' (max 30 entries)
// saveToHistory(networkName, results): prepends new entry
// Each entry: networkName, date, ready count, blocked count
// Actions per entry: Reload (restores to scanner), Delete`
  },
  {
    name: 'components/sni/ResultsFilter.jsx',
    category: 'Components',
    code: `// Protocol filter tabs for SNI Scanner
// Tabs: All | SSL/TLS | WebSocket | HTTP
// Each tab shows count + green/red dots
// Props: results[], activeFilter, onFilterChange(proto)`
  },
  {
    name: 'components/sni/ExportShare.jsx',
    category: 'Components',
    code: `// Export & share SNI scan results
// 4 buttons: JSON | TXT | Copy | Share
// exportJSON() → sni_scan_{network}_{ts}.json
// exportTxt()  → sni_scan_{network}_{ts}.txt
// share() → Web Share API or clipboard fallback`
  },
  {
    name: 'components/sni/SettingsPage.jsx',
    category: 'Components',
    code: `// SNI Scanner settings bottom sheet
// Sections: About | Protocol Guide | Score Guide | Data Management
// Data Management: Export All Scans, Clear Scan History, Clear Shared Hosts, Clear All Cache`
  },
  {
    name: 'package.json (key dependencies)',
    category: 'Config',
    code: `{
  "dependencies": {
    "@base44/sdk": "^0.8.18",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.26.0",
    "framer-motion": "^11.16.4",
    "tailwindcss": "(via vite config)",
    "lucide-react": "^0.475.0",
    "@tanstack/react-query": "^5.84.1",
    "date-fns": "^3.6.0",
    "recharts": "^2.15.4",
    "react-quill": "^2.0.0",
    "react-markdown": "^9.0.1",
    "react-hook-form": "^7.54.2",
    "@hello-pangea/dnd": "^17.0.0",
    "react-leaflet": "^4.2.1",
    "three": "^0.171.0",
    "lodash": "^4.17.21",
    "moment": "^2.30.1",
    "canvas-confetti": "^1.9.4",
    "jspdf": "^4.0.0",
    "html2canvas": "^1.4.1"
  }
}`
  }
];

// ── Component ───────────────────────────────────────────────────────────────

function CopyBtn({ text }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <button onClick={copy} className="flex items-center gap-1 text-xs text-gray-400 hover:text-white px-2 py-1 rounded-lg hover:bg-gray-700/50 transition-all flex-shrink-0">
      {copied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
      {copied ? 'Copied!' : 'Copy'}
    </button>
  );
}

function FileBlock({ file, index }) {
  const [expanded, setExpanded] = useState(false);

  const categoryColors = {
    Core: 'bg-blue-500/10 border-blue-500/30 text-blue-300',
    Entities: 'bg-amber-500/10 border-amber-500/30 text-amber-300',
    Pages: 'bg-purple-500/10 border-purple-500/30 text-purple-300',
    Components: 'bg-green-500/10 border-green-500/30 text-green-300',
    Config: 'bg-gray-500/10 border-gray-500/30 text-gray-300',
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.02 }}
      className="bg-gray-900/80 rounded-2xl border border-gray-700/50 overflow-hidden"
    >
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-700/40 bg-gray-800/50">
        <div className="flex items-center gap-2 min-w-0">
          <Code className="w-4 h-4 text-cyan-400 flex-shrink-0" />
          <span className="text-xs font-mono text-white truncate">{file.name}</span>
          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border flex-shrink-0 ${categoryColors[file.category]}`}>
            {file.category}
          </span>
        </div>
        <div className="flex items-center gap-1 flex-shrink-0">
          <CopyBtn text={file.code} />
          <button onClick={() => setExpanded(!expanded)} className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-gray-700/50 transition-all">
            {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>
      {expanded && (
        <pre className="text-xs text-gray-300 p-4 overflow-x-auto leading-relaxed whitespace-pre-wrap font-mono">
          {file.code}
        </pre>
      )}
      {!expanded && (
        <button onClick={() => setExpanded(true)} className="w-full text-center text-xs text-gray-600 hover:text-gray-400 py-2 bg-gray-900/40 transition-all">
          Expand to view code ↓
        </button>
      )}
    </motion.div>
  );
}

export default function CodeBackup() {
  const categories = ['Core', 'Entities', 'Pages', 'Components', 'Config'];
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredFiles = activeCategory === 'All' ? FILES : FILES.filter(f => f.category === activeCategory);

  const copyAll = () => {
    const allCode = FILES.map(f => `\n${'='.repeat(60)}\n// FILE: ${f.name}\n${'='.repeat(60)}\n\n${f.code}`).join('\n');
    navigator.clipboard.writeText(allCode);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      {/* Header */}
      <div className="px-4 pt-6 pb-4 sticky top-0 bg-[#0a0a0f]/95 backdrop-blur-xl z-10 border-b border-gray-800/50">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-3">
            <Link to={createPageUrl('Profile')} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors">
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div>
              <h1 className="text-lg font-bold">Code Backup</h1>
              <p className="text-xs text-cyan-400">All source files — copy as plain text</p>
            </div>
          </div>
          <button
            onClick={copyAll}
            className="flex items-center gap-1.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-semibold px-3 py-2 rounded-xl transition-all"
          >
            <Copy className="w-3.5 h-3.5" />
            Copy All
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="px-4 pt-4 pb-3">
        <div className="grid grid-cols-3 gap-2 mb-4">
          <div className="bg-gray-800/40 rounded-xl p-3 border border-gray-700/40 text-center">
            <p className="text-lg font-bold text-white">{FILES.length}</p>
            <p className="text-xs text-gray-500">Files</p>
          </div>
          <div className="bg-amber-500/10 rounded-xl p-3 border border-amber-500/20 text-center">
            <p className="text-lg font-bold text-amber-400">{FILES.filter(f=>f.category==='Entities').length}</p>
            <p className="text-xs text-gray-500">Entities</p>
          </div>
          <div className="bg-purple-500/10 rounded-xl p-3 border border-purple-500/20 text-center">
            <p className="text-lg font-bold text-purple-400">{FILES.filter(f=>f.category==='Pages').length}</p>
            <p className="text-xs text-gray-500">Pages</p>
          </div>
        </div>

        {/* Category filter */}
        <div className="flex gap-2 overflow-x-auto pb-1">
          {['All', ...categories].map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-all border ${
                activeCategory === cat
                  ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                  : 'bg-gray-800/40 text-gray-500 border-gray-700/40'
              }`}
            >
              {cat} {cat !== 'All' && `(${FILES.filter(f=>f.category===cat).length})`}
            </button>
          ))}
        </div>
      </div>

      {/* File list */}
      <div className="px-4 space-y-3">
        {filteredFiles.map((file, index) => (
          <FileBlock key={file.name} file={file} index={index} />
        ))}
      </div>

      <div className="px-4 mt-6">
        <div className="bg-blue-500/10 border border-blue-500/20 rounded-2xl p-4 text-xs text-blue-300">
          💡 Expand any file to view its code, then use the Copy button to copy it. Use "Copy All" at the top to copy everything at once as a single text block.
        </div>
      </div>
    </div>
  );
}