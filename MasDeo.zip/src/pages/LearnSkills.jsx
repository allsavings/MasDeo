import React, { useState, useEffect } from 'react';
import { useWIPLock } from '@/lib/WIPLockContext';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, BookOpen, Play, Clock, Lock, Star, Shield, Eye, Heart, X, Plus, Bot, GraduationCap, ChevronRight, Search } from 'lucide-react';
import ExploreCreatorsView from '../components/creator/ExploreCreatorsView';
import CreatorSectionDisplay from '../components/creator/CreatorSectionDisplay';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useCreatorMode } from '../components/useCreatorMode';
import CreatorModeToggle from '../components/creator/CreatorModeToggle';
import CreatorSectionEditor from '../components/creator/CreatorSectionEditor';
import VideoCard from '../components/VideoCard';
import YouTubePlayer from '../components/YouTubePlayer';
import { base44 } from '@/api/base44Client';


export default function LearnSkills() {
  const navigate = useNavigate();
  const { isRouteLocked } = useWIPLock();
  const { isCreatorMode, isCreatorEligible, canCreatorForSection, toggleCreatorMode, user } = useCreatorMode();
  const showCreator = isCreatorMode && canCreatorForSection('learn_skills') && !isRouteLocked('/CreatorMode');
  const [exploreMode, setExploreMode] = useState(() => localStorage.getItem('explore_creators_mode') === 'true');
  const [creators, setCreators] = useState([]);
  const [loadingCreators, setLoadingCreators] = useState(false);
  const [selectedCreatorEmail, setSelectedCreatorEmail] = useState(null);
  const [videos, setVideos] = useState([]);
  const [loadingVideos, setLoadingVideos] = useState(true);
  const [selectedVideo, setSelectedVideo] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [userData, setUserData] = useState(null);
  const [isFreemium, setIsFreemium] = useState(false);
  const [videoSearch, setVideoSearch] = useState('');
  const [videoFilter, setVideoFilter] = useState('all'); // 'all' | 'free' | 'paid'

  useEffect(() => {
    loadUserData();
    loadVideos();
    checkUserFreemiumStatus();
  }, []);

  const checkUserFreemiumStatus = async () => {
    try {
      const user = await base44.auth.me();
      const userProfile = await base44.entities.UserProfile.filter({ created_by: user.email });
      if (userProfile[0]) {
        setIsFreemium(!userProfile[0].is_premium);
      }
    } catch (error) {
      console.error('Error checking freemium status:', error);
      setIsFreemium(true);
    }
  };



  useEffect(() => {
    const checkExploreMode = () => {
      setExploreMode(localStorage.getItem('explore_creators_mode') === 'true');
    };
    window.addEventListener('storage', checkExploreMode);
    const interval = setInterval(checkExploreMode, 500);
    return () => {
      window.removeEventListener('storage', checkExploreMode);
      clearInterval(interval);
    };
  }, []);

  useEffect(() => {
    if (exploreMode) {
      loadCreatorsAndCourses();
    }
  }, [exploreMode]);

  const loadUserData = async () => {
    try {
      const user = await base44.auth.me();
      setUserData(user);
      const profiles = await base44.entities.UserProfile.filter({ created_by: user.email });
      if (profiles.length > 0) {
        setUserProfile(profiles[0]);
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  };

  const loadVideos = async () => {
    setLoadingVideos(true);
    try {
      const allVideos = await base44.entities.Video.filter({ 
        section: 'learn',
        is_published: true 
      });
      setVideos(allVideos);
    } catch (error) {
      console.error('Error loading videos:', error);
    } finally {
      setLoadingVideos(false);
    }
  };

  const loadCreatorsAndCourses = async () => {
    setLoadingCreators(true);
    try {
      const [allCreators, allSettings, allFollows] = await Promise.all([
        base44.entities.CreatorProfile.list(),
        base44.entities.CreatorSettings.list(),
        base44.entities.Follow.list()
      ]);

      const eligibleCreators = allCreators.filter(creator => {
        const setting = allSettings.find(s => s.user_email === creator.user_email);
        return setting?.is_public && (setting.all_platforms || setting.platforms?.includes('learn'));
      });

      const profiles = await Promise.all(
        eligibleCreators.map(creator =>
          base44.entities.UserProfile.filter({ created_by: creator.user_email })
        )
      );

      const publicCreators = eligibleCreators.map((creator, i) => ({
        ...creator,
        profile: profiles[i][0] || null,
        followerCount: allFollows.filter(f => f.creator_email === creator.user_email).length
      }));

      setCreators(publicCreators);
    } catch (error) {
      console.error('Error loading creators:', error);
    } finally {
      setLoadingCreators(false);
    }
  };

  const sampleCourses = [
    { title: "Web Development Basics", description: "Learn HTML, CSS & JavaScript", duration: "8 hours", lessons: 24, image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=400&h=300&fit=crop", free: true },
    { title: "Digital Marketing 101", description: "Social media & SEO fundamentals", duration: "6 hours", lessons: 18, image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=300&fit=crop", free: true },
    { title: "Graphic Design Mastery", description: "Create stunning visuals", duration: "12 hours", lessons: 36, image: "https://images.unsplash.com/photo-1561070791-2526d30994b5?w=400&h=300&fit=crop", free: false },
    { title: "Content Writing Pro", description: "Write compelling content", duration: "5 hours", lessons: 15, image: "https://images.unsplash.com/photo-1455390582262-044cdead277a?w=400&h=300&fit=crop", free: false }
  ];

  const handleAdRequiredClick = (e) => {
    if (!isFreemium) return;
    
    const clickedLink = e.target.closest('a');
    if (!clickedLink) return;
    
    // Check if ads are globally disabled or user has disabled them
    const globalAdsEnabled = localStorage.getItem('global_ads_enabled') !== 'false';
    const userAdsDisabled = localStorage.getItem('user_ads_disabled') === 'true';
    if (!globalAdsEnabled || userAdsDisabled) return;
    
    const isFreeClick = sessionStorage.getItem('next_click_free') === 'true';
    if (isFreeClick) {
      sessionStorage.removeItem('next_click_free');
      return;
    }

    e.preventDefault();
    navigate('/AdView', { state: { from: '/LearnSkills' } });
  };

  // Video detail modal
  if (selectedVideo && userData && userProfile) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-10" onClick={isFreemium ? handleAdRequiredClick : undefined}>

        <div className="px-6 pt-6 pb-4 flex items-center justify-between relative z-40">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setSelectedVideo(null);
            }}
            className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-lg font-bold">Watch Video</h2>
          <div className="w-10" />
        </div>

        <div className="px-6 space-y-4">
          <YouTubePlayer
            videoId={selectedVideo.youtube_video_id}
            title={selectedVideo.title}
            description={selectedVideo.description}
            creditCost={selectedVideo.credit_cost}
            videoType={selectedVideo.video_type || 'reward'}
            userCredits={userProfile.credits}
            userEmail={userData.email}
            onClose={() => setSelectedVideo(null)}
            onVideoWatched={() => loadUserData()}
          />

          {selectedVideo.guide_content && (
            <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 p-4">
              <h3 className="text-white font-bold text-sm mb-2">Guide Content</h3>
              <div className="text-gray-400 text-sm leading-relaxed whitespace-pre-wrap">
                {selectedVideo.guide_content}
              </div>
            </div>
          )}

          {selectedVideo.guide_resources && selectedVideo.guide_resources.length > 0 && (
            <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 p-4">
              <h3 className="text-white font-bold text-sm mb-3">Resources</h3>
              <div className="space-y-2">
                {selectedVideo.guide_resources.map((resource, idx) => (
                  <a
                    key={idx}
                    href={resource.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-3 bg-cyan-500/10 border border-cyan-500/30 rounded-lg hover:bg-cyan-500/20 transition-all"
                  >
                    <div>
                      <p className="text-sm text-white font-medium">{resource.name}</p>
                      <p className="text-xs text-gray-400">Cost: R{resource.credit_cost?.toFixed(2) || '0.00'}</p>
                    </div>
                    <Play className="w-4 h-4 text-cyan-400" />
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32" onClick={isFreemium ? handleAdRequiredClick : undefined}>

      {/* Header */}
      <div className="px-6 pt-6 pb-4 relative z-40">
        <div className="flex items-center gap-4 mb-4">
          <Link to={createPageUrl("Home")} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors" onClick={e => e.stopPropagation()}>
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-xl font-bold">Learn Digital Skills</h1>
          {isCreatorMode && isCreatorEligible && (
            <div className="ml-auto p-2 bg-purple-500/20 border border-purple-500/30 rounded-xl">
              <Plus className="w-5 h-5 text-purple-400" />
            </div>
          )}
        </div>
      </div>

      {/* Creator Mode Toggle */}
      {!isRouteLocked('/CreatorMode') && (
        <div className="relative z-40">
          <CreatorModeToggle
            isCreatorMode={isCreatorMode}
            isCreatorEligible={isCreatorEligible && canCreatorForSection('learn_skills')}
            onToggle={toggleCreatorMode}
          />
        </div>
      )}

      {/* CREATOR MODE CONTENT */}
      {showCreator ? (
        <CreatorSectionEditor user={user} sectionPage="learn" />
      ) : selectedCreatorEmail ? (
        <CreatorSectionDisplay 
          creatorEmail={selectedCreatorEmail} 
          sectionPage="learn" 
          theme="learn" 
          onBack={() => setSelectedCreatorEmail(null)}
          isFreemium={isFreemium}
          navigate={navigate}
        />
      ) : exploreMode && !isRouteLocked('/ExploreCreators') ? (
        <ExploreCreatorsView creators={creators} loading={loadingCreators} theme="learn" prioritySection="learn" onSelectCreator={setSelectedCreatorEmail} />
      ) : (
       <>
         {/* Hero */}
         <div className="px-6">
           <motion.div
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
             className="bg-gradient-to-r from-purple-600/30 to-blue-600/30 rounded-2xl p-6 border border-purple-500/30 mb-6"
           >
             <div className="flex items-center gap-3 mb-3">
               <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
                 <BookOpen className="w-6 h-6 text-white" />
               </div>
               <div>
                 <h2 className="font-bold text-lg">Master New Skills</h2>
                 <p className="text-sm text-gray-400">Free & premium video courses</p>
               </div>
             </div>
             <p className="text-sm text-gray-300">Learn from comprehensive video tutorials with guides and resources. Watch videos in the app with your credits.</p>
           </motion.div>
         </div>

         {/* Video Search & Filter */}
         <div className="px-6 mb-4 space-y-3">
           <div className="relative">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
             <input
               type="text"
               placeholder="Search courses by title..."
               value={videoSearch}
               onChange={e => setVideoSearch(e.target.value)}
               className="w-full bg-gray-800/60 border border-gray-700/60 rounded-xl pl-9 pr-4 py-2.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-purple-500/60"
             />
             {videoSearch && (
               <button onClick={() => setVideoSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2">
                 <X className="w-4 h-4 text-gray-500 hover:text-white" />
               </button>
             )}
           </div>
           <div className="flex gap-2">
             {[['all', 'All'], ['free', 'Free'], ['paid', 'Paid']].map(([val, label]) => (
               <button key={val} onClick={() => setVideoFilter(val)}
                 className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border ${
                   videoFilter === val
                     ? 'bg-purple-500/20 text-purple-300 border-purple-500/50'
                     : 'bg-gray-800/40 text-gray-500 border-gray-700/40 hover:text-gray-300'
                 }`}>{label}</button>
             ))}
           </div>
         </div>

         {/* Video Grid */}
         <div className="px-6 space-y-4">
           {loadingVideos ? (
             <div className="flex items-center justify-center py-10">
               <div className="flex flex-col items-center gap-3">
                 <div className="w-8 h-8 border-2 border-purple-500/30 border-t-purple-500 rounded-full animate-spin" />
                 <p className="text-gray-400 text-sm">Loading videos...</p>
               </div>
             </div>
           ) : videos.length > 0 ? (
             <>
               <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider">Available Videos</h3>
               {(() => {
                 const filtered = videos.filter(v => {
                   const matchesSearch = !videoSearch || v.title?.toLowerCase().includes(videoSearch.toLowerCase());
                   const matchesFilter = videoFilter === 'all' || (videoFilter === 'free' ? (v.credit_cost === 0 || !v.credit_cost) : (v.credit_cost > 0));
                   return matchesSearch && matchesFilter;
                 });
                 if (filtered.length === 0) return (
                   <div className="text-center py-8 bg-gray-800/20 rounded-2xl">
                     <Search className="w-8 h-8 text-gray-600 mx-auto mb-2" />
                     <p className="text-gray-500 text-sm">No courses match your search</p>
                   </div>
                 );
                 return (
               <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                 {filtered.map((video, index) => (
                   <motion.div
                     key={video.id}
                     initial={{ opacity: 0, y: 20 }}
                     animate={{ opacity: 1, y: 0 }}
                     transition={{ delay: index * 0.05 }}
                   >
                     <VideoCard
                       video={video}
                       onClick={() => setSelectedVideo(video)}
                       creditCost={video.credit_cost}
                       userCredits={userProfile?.credits || 0}
                     />
                   </motion.div>
                   ))}
                   </div>
                   );
                   })()}
                   </>
                   ) : (
             <div className="text-center py-10">
               <BookOpen className="w-12 h-12 text-gray-600 mx-auto mb-3" />
               <p className="text-gray-400">No videos available yet</p>
               <p className="text-sm text-gray-500 mt-1">Check back soon for new courses!</p>
             </div>
           )}
         </div>

         {/* AI Tools & Education Nav Cards */}
         <div className="px-6 space-y-3 mt-6">
           <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider mb-1">Free Tools & Learning</h3>

           {[
             { key: 'ai_tools', icon: Bot, label: 'Best Free AI Tools', desc: 'Powerful AI tools available for free', color: 'from-violet-500 to-purple-600', border: 'hover:border-violet-500/60' },
             { key: 'education', icon: GraduationCap, label: 'Education', desc: 'Free world-class learning platforms', color: 'from-emerald-500 to-teal-500', border: 'hover:border-emerald-500/60' },
           ].map((item, i) => (
             <motion.div key={item.key} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}>
               <Link to={createPageUrl(`ServiceDirectory?section=${item.key}`)}>
                 <div className={`bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50 ${item.border} transition-all cursor-pointer group`}>
                   <div className="flex items-center gap-4">
                     <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${item.color} flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                       <item.icon className="w-6 h-6 text-white" />
                     </div>
                     <div className="flex-1">
                       <h4 className="font-semibold text-white mb-0.5">{item.label}</h4>
                       <p className="text-sm text-gray-400">{item.desc}</p>
                     </div>
                     <ChevronRight className="w-4 h-4 text-gray-500 group-hover:text-white transition-colors" />
                   </div>
                 </div>
               </Link>
             </motion.div>
           ))}
         </div>

         {/* Legacy Sample Courses Section */}
         {videos.length === 0 && (
           <div className="px-6 space-y-4 mt-8">
             <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider">Coming Soon</h3>
             {sampleCourses.map((course, index) => (
               <motion.div key={course.title} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}>
                 <div className="bg-gray-800/40 rounded-2xl overflow-hidden border border-gray-700/50 opacity-50 cursor-not-allowed">
                   <div className="relative">
                     <img src={course.image} alt={course.title} className="w-full h-32 object-cover" />
                     <div className="absolute inset-0 bg-gradient-to-t from-gray-900/90 to-transparent" />
                   </div>
                   <div className="p-4">
                     <h4 className="font-semibold text-white mb-1">{course.title}</h4>
                     <p className="text-sm text-gray-400">{course.description}</p>
                   </div>
                 </div>
               </motion.div>
             ))}
           </div>
         )}
       </>
      )}
    </div>
  );
}