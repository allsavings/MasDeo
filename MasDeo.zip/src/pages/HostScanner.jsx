import React from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Search, Wifi, ChevronRight, Shield, Globe, FileJson, Radio, FileText } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import LockedSectionOverlay from '../components/LockedSectionOverlay';
import { useWIPLock } from '@/lib/WIPLockContext';

const tools = [
  {
    title: "Datafree Website Scanner",
    version: "v7.0",
    description: "Identify websites that are zero-rated/data-free on your mobile network.",
    icon: Wifi,
    color: "from-cyan-500 to-blue-500",
    border: "border-cyan-500/30 hover:border-cyan-500/60",
    bg: "from-cyan-600/20 to-blue-600/20",
    page: "ZeroRatedScan",
    badge: "bg-cyan-500/20 text-cyan-300 border-cyan-500/30",
  },
  {
    title: "CDN & WAF Scanner",
    version: "v1.0",
    description: "Detect the cloud infrastructure and firewall protection behind any site.",
    icon: Shield,
    color: "from-purple-500 to-pink-500",
    border: "border-purple-500/30 hover:border-purple-500/60",
    bg: "from-purple-600/20 to-pink-600/20",
    page: "CdnWafScanner",
    badge: "bg-purple-500/20 text-purple-300 border-purple-500/30",
  },
  {
    title: "SNI Bug Host Scanner",
    version: "v1.0",
    description: "Scan SNI bug hosts for tunneling — tests SSL/TLS, WebSocket/WSS & HTTP CONNECT protocols.",
    icon: Radio,
    color: "from-rose-500 to-pink-500",
    border: "border-rose-500/30 hover:border-rose-500/60",
    bg: "from-rose-600/20 to-pink-600/20",
    page: "SniBugScanner",
    badge: "bg-rose-500/20 text-rose-300 border-rose-500/30",
  },
  {
    title: "JSON Cleaner",
    version: "v1.0",
    description: "Extract hosts & IPs from NDJSON records. Choose host only, IP only, or both.",
    icon: FileJson,
    color: "from-amber-500 to-orange-500",
    border: "border-amber-500/30 hover:border-amber-500/60",
    bg: "from-amber-600/20 to-orange-600/20",
    page: "JsonCleaner",
    badge: "bg-amber-500/20 text-amber-300 border-amber-500/30",
  },
  {
    title: "TXT Cleaner",
    version: "v1.0",
    description: "Smart Filter — Extract hosts & IPs from any plain text, logs, or scan output.",
    icon: FileText,
    color: "from-cyan-500 to-blue-500",
    border: "border-cyan-500/30 hover:border-cyan-500/60",
    bg: "from-cyan-600/20 to-blue-600/20",
    page: "TxtCleaner",
    badge: "bg-cyan-500/20 text-cyan-300 border-cyan-500/30",
  },
];

export default function HostScanner() {
  const { isRouteLocked } = useWIPLock();
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      {/* Header */}
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center gap-4 mb-4">
          <Link to={createPageUrl("EthicalInternet")} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-xl font-bold">Website Verification Recon</h1>
            <p className="text-xs text-gray-400">Essential Tools • Ethical Internet</p>
          </div>
        </div>
      </div>

      {/* Hero */}
      <div className="px-6 mb-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-blue-600/20 to-cyan-600/20 rounded-2xl p-5 border border-blue-500/30"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
              <Globe className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-base text-white">Website Verification Recon</h2>
              <p className="text-xs text-gray-400">High-speed bulk scanner</p>
            </div>
          </div>
          <p className="text-sm text-gray-300">High-speed bulk scanner to discover & verify live websites</p>
        </motion.div>
      </div>

      {/* Tools List */}
      <div className="px-6 space-y-4">
        <h3 className="font-semibold text-gray-400 text-xs uppercase tracking-wider">Available Tools</h3>
        {tools.map((tool, i) => (
          <motion.div
            key={tool.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <LockedSectionOverlay isLocked={isRouteLocked(`/${tool.page}`)} sectionName={tool.title} path={`/${tool.page}`}>
              <Link to={createPageUrl(tool.page)}>
                <div className={`bg-gradient-to-r ${tool.bg} rounded-2xl p-5 border ${tool.border} transition-all cursor-pointer group`}>
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${tool.color} flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                      <tool.icon className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold text-white text-sm">{tool.title}</h4>
                      </div>
                      <p className="text-xs text-gray-400 leading-relaxed">{tool.description}</p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-500 group-hover:text-cyan-400 transition-colors flex-shrink-0" />
                  </div>
                </div>
              </Link>
            </LockedSectionOverlay>
          </motion.div>
        ))}
      </div>
    </div>
  );
}