import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';

export default function Welcome() {
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    base44.auth.isAuthenticated().then(authed => {
      if (authed) {
        window.location.href = '/';
      } else {
        setChecking(false);
      }
    });
  }, []);

  const handleLogin = () => {
    window.location.href = '/auth';
  };

  if (checking) {
    return (
      <div className="fixed inset-0 bg-[#0a0a0f] flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-gray-700 border-t-cyan-400 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] flex flex-col items-center justify-between px-6 py-10 overflow-hidden relative">
      {/* Background glow orbs */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-gradient-to-br from-violet-600/20 to-cyan-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top spacer */}
      <div />

      {/* Center content */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
        className="flex flex-col items-center text-center w-full max-w-sm"
      >
        {/* Logo */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.1, duration: 0.5 }}
          className="mb-5"
        >
          <img
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/699aa662b79dd361c7b3904b/7f8e2ae2c_186683c9-e11a-4e07-a3bc-e80e42b08b3e_20260219_212443_00001.png"
            alt="Masters DeoVex"
            className="w-full h-auto max-w-[260px] mx-auto"
          />
        </motion.div>

        {/* App name */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="mb-4"
        >
          <h1 className="text-2xl font-black text-white leading-tight">
            Masters<span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-400 to-cyan-400">|DeoVex</span>
          </h1>
        </motion.div>

        {/* Tagline */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
          className="mb-8 space-y-2"
        >
          <p className="text-sm text-gray-300 leading-relaxed font-medium px-2">
            Master free ethical internet, learn digital skills, earn online, and go premium — sufficient with{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-400 to-cyan-400 font-bold">Masters|DeoVex</span>.
          </p>
          <p className="text-base font-bold text-white">
            ᴜɴʟᴏᴄᴋ ʏᴏᴜʀ ғᴜᴛᴜʀᴇ ᴡᴏʀʟᴅ 💙
          </p>
        </motion.div>

        {/* Feature pills */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.45 }}
          className="flex flex-wrap justify-center gap-2 mb-8"
        >
          {[
            { emoji: '🌐', label: 'Ethical Internet' },
            { emoji: '📚', label: 'Learn Skills' },
            { emoji: '💰', label: 'Earn Online' },
            { emoji: '🚀', label: 'Go Premium' },
          ].map((item) => (
            <div
              key={item.label}
              className="flex items-center gap-1.5 bg-gray-800/60 border border-gray-700/50 rounded-full px-3 py-1.5"
            >
              <span className="text-sm">{item.emoji}</span>
              <span className="text-xs text-gray-300 font-medium">{item.label}</span>
            </div>
          ))}
        </motion.div>

        {/* CTA Button */}
        <motion.button
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.55 }}
          whileTap={{ scale: 0.97 }}
          onClick={handleLogin}
          className="w-full py-4 rounded-2xl font-black text-base text-white mb-3 relative overflow-hidden"
          style={{
            background: 'linear-gradient(135deg, #7c3aed, #06b6d4)',
            boxShadow: '0 0 28px rgba(124,58,237,0.4)',
          }}
        >
          Get Started — Sign In / Sign Up
        </motion.button>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.65 }}
          className="text-xs text-gray-600 text-center px-4"
        >
          By continuing, you agree to our terms of service and privacy policy.
        </motion.p>
      </motion.div>

      {/* Bottom branding */}
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.75 }}
        className="text-[11px] text-gray-700 font-medium"
      >
        © 2026 Masters|DeoVex · All rights reserved
      </motion.p>
    </div>
  );
}