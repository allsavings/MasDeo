import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, MessageCircle, Mail, FileText, ChevronRight, ExternalLink, Send, Phone, Facebook, CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';

export default function HelpSupport() {
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const submitTicket = async () => {
    if (!subject.trim() || !message.trim()) return;
    setSubmitting(true);
    const user = await base44.auth.me();
    await base44.entities.SupportTicket.create({
      user_email: user.email,
      user_name: user.full_name || user.email,
      subject: subject.trim(),
      message: message.trim(),
      status: 'open',
    });
    setSubmitting(false);
    setSubmitted(true);
    setSubject('');
    setMessage('');
  };

  const faqs = [
    {
      question: "How do I upgrade to Premium?",
      answer: "Go to the Premium section and click 'Upgrade Now' to access all features."
    },
    {
      question: "Are the courses really free?",
      answer: "Yes! We offer both free and premium courses. Free courses cover the basics."
    },
    {
      question: "How can I earn money?",
      answer: "Complete our courses first, then explore the 'Earn Online' section for opportunities."
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      {/* Header */}
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center gap-4 mb-6">
          <Link to={createPageUrl("Profile")} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-xl font-bold">Help & Support</h1>
        </div>
      </div>

      <div className="px-6 space-y-6">
        {/* Submit a Ticket */}
        <div>
          <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider mb-3">Submit a Support Ticket</h3>
          {submitted ? (
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
              className="bg-green-500/10 border border-green-500/30 rounded-2xl p-5 flex items-center gap-3">
              <CheckCircle className="w-8 h-8 text-green-400 flex-shrink-0" />
              <div>
                <p className="font-semibold text-white">Ticket Submitted!</p>
                <p className="text-xs text-gray-400 mt-0.5">We'll reply via in-app notification.</p>
              </div>
            </motion.div>
          ) : (
            <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 p-4 space-y-3">
              <Input value={subject} onChange={e => setSubject(e.target.value)}
                placeholder="Subject..." className="bg-gray-900/60 border-gray-700 text-white text-sm" />
              <textarea value={message} onChange={e => setMessage(e.target.value)}
                placeholder="Describe your issue..."
                rows={3}
                className="w-full bg-gray-900/60 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm resize-none focus:outline-none focus:ring-1 focus:ring-blue-500" />
              <button onClick={submitTicket} disabled={submitting || !subject.trim() || !message.trim()}
                className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 disabled:opacity-40 text-white font-semibold text-sm py-2.5 rounded-xl transition-all">
                <Send className="w-4 h-4" /> {submitting ? 'Submitting...' : 'Submit Ticket'}
              </button>
            </div>
          )}
        </div>

        {/* FAQs */}
        <div>
          <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider mb-3">Frequently Asked Questions</h3>
          <div className="space-y-3">
            {faqs.map((faq, index) => (
              <motion.div
                key={faq.question}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + index * 0.1 }}
                className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50"
              >
                <h4 className="font-semibold text-white mb-2 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-cyan-400" />
                  {faq.question}
                </h4>
                <p className="text-sm text-gray-400 pl-6">{faq.answer}</p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Social Media */}
        <div>
          <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider mb-3">Connect With Us</h3>
          <div className="space-y-3">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
            >
              <a href="https://whatsapp.com/channel/0029VbiDw1I4dTnNflB5xj0F" target="_blank" rel="noopener noreferrer" className="block">
                <div className="bg-green-500/10 rounded-2xl p-4 border border-green-500/30 hover:border-green-500/50 transition-all">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-green-500/20 flex items-center justify-center">
                        <MessageCircle className="w-5 h-5 text-green-400" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-white">WhatsApp Channel</h4>
                        <p className="text-xs text-gray-500">Join our community</p>
                      </div>
                    </div>
                    <ExternalLink className="w-4 h-4 text-green-400" />
                  </div>
                </div>
              </a>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
            >
              <a href="https://wa.me/255719595488" target="_blank" rel="noopener noreferrer" className="block">
                <div className="bg-green-500/10 rounded-2xl p-4 border border-green-500/30 hover:border-green-500/50 transition-all">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-green-500/20 flex items-center justify-center">
                        <Phone className="w-5 h-5 text-green-400" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-white">WhatsApp Direct</h4>
                        <p className="text-xs text-gray-500">+255 719 595 488</p>
                      </div>
                    </div>
                    <ExternalLink className="w-4 h-4 text-green-400" />
                  </div>
                </div>
              </a>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 }}
            >
              <a href="https://facebook.com/MastersDeoVex" target="_blank" rel="noopener noreferrer" className="block">
                <div className="bg-blue-500/10 rounded-2xl p-4 border border-blue-500/30 hover:border-blue-500/50 transition-all">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center">
                        <Facebook className="w-5 h-5 text-blue-400" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-white">Facebook</h4>
                        <p className="text-xs text-gray-500">@MastersDeoVex</p>
                      </div>
                    </div>
                    <ExternalLink className="w-4 h-4 text-blue-400" />
                  </div>
                </div>
              </a>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
            >
              <a href="https://t.me/MastersDeoVex" target="_blank" rel="noopener noreferrer" className="block">
                <div className="bg-sky-500/10 rounded-2xl p-4 border border-sky-500/30 hover:border-sky-500/50 transition-all">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-sky-500/20 flex items-center justify-center">
                        <Send className="w-5 h-5 text-sky-400" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-white">Telegram</h4>
                        <p className="text-xs text-gray-500">@MastersDeoVex</p>
                      </div>
                    </div>
                    <ExternalLink className="w-4 h-4 text-sky-400" />
                  </div>
                </div>
              </a>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}