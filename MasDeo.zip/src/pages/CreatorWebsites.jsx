import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { ArrowLeft, Plus, Globe, Trash2, Lock, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';

export default function CreatorWebsites() {
  const [user, setUser] = useState(null);
  const [websites, setWebsites] = useState([]);
  const [showAdd, setShowAdd] = useState(false);
  const [formData, setFormData] = useState({
    site_name: '',
    domain: '',
    description: '',
    site_url: '',
    vps_ip: '',
    ssl_enabled: false,
    is_public: false
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const userData = await base44.auth.me();
    setUser(userData);
    const mySites = await base44.entities.HostedWebsite.filter({ creator_email: userData.email });
    setWebsites(mySites);
  };

  const handleCreate = async () => {
    await base44.entities.HostedWebsite.create({
      creator_email: user.email,
      ...formData
    });
    await loadData();
    setShowAdd(false);
    setFormData({ site_name: '', domain: '', description: '', site_url: '', vps_ip: '', ssl_enabled: false, is_public: false });
  };

  const handleDelete = async (siteId) => {
    if (confirm('Delete this website? This action cannot be undone.')) {
      await base44.entities.HostedWebsite.delete(siteId);
      await loadData();
    }
  };

  const handleTogglePublic = async (site) => {
    await base44.entities.HostedWebsite.update(site.id, {
      is_public: !site.is_public
    });
    await loadData();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] text-white pb-32">
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("CreatorMode")} className="p-2 bg-gray-800/50 rounded-xl">
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <h1 className="text-xl font-bold">Hosted Websites</h1>
          </div>
          <Button onClick={() => setShowAdd(!showAdd)} className="bg-blue-600">
            <Plus className="w-4 h-4 mr-2" />
            Add
          </Button>
        </div>

        {showAdd && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50 mb-6"
          >
            <h3 className="font-semibold mb-4">Register Website</h3>
            <div className="space-y-3">
              <Input
                placeholder="Site Name"
                value={formData.site_name}
                onChange={(e) => setFormData({...formData, site_name: e.target.value})}
                className="bg-gray-700/50 border-gray-600"
              />
              <Input
                placeholder="Domain"
                value={formData.domain}
                onChange={(e) => setFormData({...formData, domain: e.target.value})}
                className="bg-gray-700/50 border-gray-600"
              />
              <Input
                placeholder="Website URL"
                value={formData.site_url}
                onChange={(e) => setFormData({...formData, site_url: e.target.value})}
                className="bg-gray-700/50 border-gray-600"
              />
              <Textarea
                placeholder="Description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                className="bg-gray-700/50 border-gray-600"
              />
              <Input
                placeholder="VPS IP"
                value={formData.vps_ip}
                onChange={(e) => setFormData({...formData, vps_ip: e.target.value})}
                className="bg-gray-700/50 border-gray-600"
              />
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-400">SSL Enabled</span>
                <Switch
                  checked={formData.ssl_enabled}
                  onCheckedChange={(checked) => setFormData({...formData, ssl_enabled: checked})}
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-400">List Publicly</span>
                <Switch
                  checked={formData.is_public}
                  onCheckedChange={(checked) => setFormData({...formData, is_public: checked})}
                />
              </div>
              <Button onClick={handleCreate} className="w-full bg-blue-600">
                Register Website
              </Button>
            </div>
          </motion.div>
        )}

        <div className="space-y-4">
          {websites.map((site) => (
            <motion.div
              key={site.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-semibold text-white">{site.site_name}</h4>
                    {site.ssl_enabled && (
                      <span className="bg-green-500/20 text-green-400 text-xs px-2 py-0.5 rounded-full flex items-center gap-1">
                        <Lock className="w-3 h-3" />
                        SSL
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-cyan-400 mb-2">{site.domain}</p>
                  <p className="text-sm text-gray-400 mb-2">{site.description}</p>
                  <div className="flex gap-3 text-xs text-gray-500">
                    <span>IP: {site.vps_ip}</span>
                    <span>•</span>
                    <span>{site.monthly_visitors || 0} visitors/mo</span>
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                {site.site_url && (
                  <Button
                    onClick={() => window.open(site.site_url, '_blank')}
                    size="sm"
                    className="flex-1 bg-blue-600"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Visit
                  </Button>
                )}
                <Button
                  onClick={() => handleTogglePublic(site)}
                  size="sm"
                  variant="outline"
                  className="flex-1"
                >
                  {site.is_public ? 'Make Private' : 'Make Public'}
                </Button>
                <Button
                  onClick={() => handleDelete(site.id)}
                  size="sm"
                  variant="ghost"
                  className="text-red-400"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}