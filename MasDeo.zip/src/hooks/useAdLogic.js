import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';

export function useAdLogic(user, profile) {
  const [appConfig, setAppConfig] = useState(null);
  const [shouldShowAds, setShouldShowAds] = useState(false);

  const evaluateAdVisibility = (config, currentUser, currentProfile) => {
    if (!config || !config.ads_enabled) {
      setShouldShowAds(false);
      return;
    }

    // If user has explicit override, use it
    if (currentUser && currentProfile?.ads_enabled_override !== null && currentProfile?.ads_enabled_override !== undefined) {
      setShouldShowAds(currentProfile.ads_enabled_override);
      return;
    }

    // Otherwise check plan-based settings
    if (!currentUser) {
      setShouldShowAds(false);
      return;
    }

    const isPremium = currentProfile?.membership_type === 'premium';
    if (isPremium) {
      setShouldShowAds(config.premium_ads_enabled);
    } else {
      setShouldShowAds(config.free_ads_enabled);
    }
  };

  const loadAdConfig = async () => {
    try {
      if (!navigator.onLine) {
        setShouldShowAds(false);
        return;
      }

      const configs = await base44.entities.AppConfig.filter({ key: 'global' });
      const config = configs[0];
      setAppConfig(config);
      evaluateAdVisibility(config, user, profile);

      // Subscribe to real-time config updates
      return base44.entities.AppConfig.subscribe((event) => {
        if (event.type === 'update' && event.data?.key === 'global') {
          setAppConfig(event.data);
          evaluateAdVisibility(event.data, user, profile);
        }
      });
    } catch (error) {
      console.error('Error loading ad config:', error);
      setShouldShowAds(false);
    }
  };

  useEffect(() => {
    let unsub;
    loadAdConfig().then(unsubscribe => { unsub = unsubscribe; });
    return () => { if (unsub) unsub(); };
  }, [user, profile]);

  const getAdFrequency = useCallback(() => {
    return appConfig?.ad_frequency || 50;
  }, [appConfig]);

  const isOnline = useCallback(() => {
    return navigator.onLine;
  }, []);

  const canShowAds = useCallback(() => {
    return shouldShowAds && isOnline();
  }, [shouldShowAds]);

  return {
    shouldShowAds,
    canShowAds,
    getAdFrequency,
    appConfig,
    isOnline,
    refetch: loadAdConfig
  };
}