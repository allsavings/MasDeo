// Masters | DeoVex — Native Push Notification Hook
// Production-grade: safely handles all browsers, Service Worker persistence,
// Android notification shade delivery, and permission state tracking.
import { useState, useEffect, useCallback } from 'react';

// Cross-browser icons — Android picks the best fit automatically
const ICON_512 = 'https://media.base44.com/images/public/69fbae3c9d10c5e17ae8e806/f423cbc89_Icon-512.png';
const ICON_192 = 'https://media.base44.com/images/public/69fbae3c9d10c5e17ae8e806/b2b33f270_Icon-192.png';
// Android-compliant monochrome badge icons
const BADGE   = 'https://media.base44.com/images/public/69fbae3c9d10c5e17ae8e806/d929a25aa_badge-96.png';

// ─── Safe permission check (SSR / unsupported browsers) ────────────────────
function getPermission() {
  if (typeof window === 'undefined' || !('Notification' in window)) return 'default';
  return Notification.permission;
}

// ─── Get the active SW registration (waits for SW to be ready) ─────────────
async function getSwReg() {
  if (!('serviceWorker' in navigator)) return null;
  return navigator.serviceWorker.ready.catch(() => null);
}

/**
 * useNotifications
 *
 * Provides:
 *  - requestPermission()           → asks user, returns 'granted'|'denied'|'default'
 *  - showLocalNotification(title, options) → fires native OS notification via SW
 *  - notifyFromAppNotification(notif)      → fires when a new AppNotification arrives
 *  - fillOfflineCache(urls) / clearOfflineCache() → for offline mode
 *  - permission, supported, isGranted
 */
export function useNotifications() {
  const [permission, setPermission] = useState(getPermission);
  const [supported, setSupported]   = useState(false);

  useEffect(() => {
    const ok = 'Notification' in window && 'serviceWorker' in navigator;
    setSupported(ok);
    setPermission(getPermission());
  }, []);

  // ── Request OS permission ─────────────────────────────────────────────────
  const requestPermission = useCallback(async () => {
    if (!('Notification' in window)) return 'unsupported';
    // Some old Android WebViews only support the callback form
    let result;
    try {
      result = await Notification.requestPermission();
    } catch {
      result = await new Promise(resolve => Notification.requestPermission(resolve));
    }
    setPermission(result);
    return result;
  }, []);

  // ── Fire a native notification (lands in Android notification shade) ───────
  const showLocalNotification = useCallback(async (title, options = {}) => {
    if (!('Notification' in window)) return;

    let perm = Notification.permission;
    if (perm !== 'granted') {
      perm = await requestPermission();
      if (perm !== 'granted') return;
    }

    // Show native notifications in standalone PWA mode OR if running as browser but SW is active
    // This ensures timely delivery even when the app is in the background
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches
      || window.navigator.standalone === true;
    const hasSW = 'serviceWorker' in navigator;
    if (!isStandalone && !hasSW) return;

    const opts = {
      icon:   ICON_512,
      badge:  BADGE,
      // DO NOT set image by default — only include if caller provides it
      vibrate: [200, 100, 200],
      requireInteraction: false,
      silent: false,
      ...options,
    };

    // Prefer SW showNotification — the ONLY way to reliably hit the Android shade
    const reg = await getSwReg();
    if (reg?.showNotification) {
      return reg.showNotification(title, opts);
    }

    // Fallback: basic Notification API (desktop browsers, older iOS)
    return new Notification(title, opts);
  }, [requestPermission]);

  // ── Trigger from a new AppNotification record ─────────────────────────────
  const notifyFromAppNotification = useCallback(async (notif) => {
    // Always fire native notification — admin sent it deliberately
    await showLocalNotification(notif.title || 'Masters | DeoVex', {
      body:  notif.message || notif.body || 'You have a new notification.',
      tag:   `app-notif-${notif.id}`,
      data:  { url: '/' },
    });
  }, [showLocalNotification]);

  // ── Offline cache helpers ─────────────────────────────────────────────────
  const fillOfflineCache = useCallback(async (urls = []) => {
    const reg = await getSwReg();
    reg?.active?.postMessage({ type: 'OFFLINE_CACHE_URLS', urls });
  }, []);

  const clearOfflineCache = useCallback(async () => {
    const reg = await getSwReg();
    reg?.active?.postMessage({ type: 'CLEAR_OFFLINE_CACHE' });
  }, []);

  return {
    permission,
    supported,
    isGranted: permission === 'granted',
    requestPermission,
    showLocalNotification,
    notifyFromAppNotification,
    fillOfflineCache,
    clearOfflineCache,
  };
}