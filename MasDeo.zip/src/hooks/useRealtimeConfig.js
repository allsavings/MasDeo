import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';

// Default config used until DB record loads
const DEFAULTS = {
  ads_enabled: true,
  ad_run_count: parseInt(localStorage.getItem('ad_run_count') || '2'),
  ad_rest_count: parseInt(localStorage.getItem('ad_rest_count') || '2'),
  smartlink_url: 'https://www.profitablecpmratenetwork.com/urqr7wfnua?key=db9b47c361e775cf04acee3a85050b11',
  popunder_url: 'https://pl28899947.effectivegatecpm.com/33/81/3a/33813a9f8e0dcb2744308e39cd9b8144.js',
};

let cachedConfig = null;

/**
 * useRealtimeConfig
 * Subscribes to the AppConfig entity in real-time.
 * Returns { config, loading, updateConfig }
 * config is guaranteed to always have all DEFAULTS keys.
 */
export function useRealtimeConfig() {
  const [config, setConfig] = useState(cachedConfig || DEFAULTS);
  const [loading, setLoading] = useState(!cachedConfig);
  const [recordId, setRecordId] = useState(null);

  // Merge DB record onto defaults so missing fields always have a value
  const merge = (record) => ({ ...DEFAULTS, ...record });

  useEffect(() => {
    let unsub;

    const init = async () => {
      try {
        const records = await base44.entities.AppConfig.filter({ key: 'global' });
        let record;
        if (records.length === 0) {
          // First-time setup: create the global config record
          record = await base44.entities.AppConfig.create({
            key: 'global',
            ads_enabled: true,
            ad_run_count: DEFAULTS.ad_run_count,
            ad_rest_count: DEFAULTS.ad_rest_count,
            smartlink_url: DEFAULTS.smartlink_url,
            popunder_url: DEFAULTS.popunder_url,
          });
        } else {
          record = records[0];
        }

        setRecordId(record.id);
        const merged = merge(record);
        cachedConfig = merged;
        setConfig(merged);

        // Sync localStorage for modules that still read from it
        localStorage.setItem('global_ads_enabled', merged.ads_enabled ? 'true' : 'false');
        localStorage.setItem('ad_run_count', String(merged.ad_run_count));
        localStorage.setItem('ad_rest_count', String(merged.ad_rest_count));
      } catch (e) {
        console.error('[useRealtimeConfig] init error:', e);
      } finally {
        setLoading(false);
      }

      // Real-time subscription
      unsub = base44.entities.AppConfig.subscribe((event) => {
        if (event.type === 'update' && event.data?.key === 'global') {
          const merged = merge(event.data);
          cachedConfig = merged;
          setConfig(merged);
          // Keep localStorage in sync for legacy readers
          localStorage.setItem('global_ads_enabled', merged.ads_enabled ? 'true' : 'false');
          localStorage.setItem('ad_run_count', String(merged.ad_run_count));
          localStorage.setItem('ad_rest_count', String(merged.ad_rest_count));
        }
      });
    };

    init();
    return () => { if (unsub) unsub(); };
  }, []);

  const updateConfig = async (patch) => {
    if (!recordId) {
      console.error('[useRealtimeConfig] Cannot update: recordId is null');
      throw new Error('Config record not initialized');
    }
    try {
      await base44.entities.AppConfig.update(recordId, patch);
      // Optimistic local update (subscription will confirm)
      const next = merge({ ...config, ...patch });
      cachedConfig = next;
      setConfig(next);
    } catch (error) {
      console.error('[useRealtimeConfig] Update failed:', error, 'patch:', patch);
      throw error;
    }
  };

  return { config, loading, updateConfig };
}