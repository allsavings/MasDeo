import { useState, useCallback, useRef, useEffect } from 'react';
import { OptimisticUpdateHandler } from '@/components/mobile/OptimisticUpdateHandler';

/**
 * useMobileEnhancements
 * Custom hook that combines error handling, optimistic updates, and error boundaries
 * for mobile-optimized applications
 */
export function useMobileEnhancements() {
  const [errors, setErrors] = useState({});
  const [optimisticUpdates, setOptimisticUpdates] = useState({});
  const updateHandlerRef = useRef(
    new OptimisticUpdateHandler((key, errorMsg) => {
      setErrors(prev => ({
        ...prev,
        [key]: {
          message: errorMsg,
          severity: 'warning',
          persistent: false,
        },
      }));
    })
  );

  /**
   * Execute an optimistic update with error handling
   */
  const executeUpdate = useCallback(async (
    key,
    optimisticFn,
    apiFn,
    rollbackFn,
    onSuccess
  ) => {
    try {
      const result = await updateHandlerRef.current.execute(
        key,
        () => {
          optimisticFn?.();
          setOptimisticUpdates(prev => ({
            ...prev,
            [key]: true,
          }));
        },
        apiFn,
        () => {
          rollbackFn?.();
          setOptimisticUpdates(prev => {
            const next = { ...prev };
            delete next[key];
            return next;
          });
        }
      );

      // Clear error on success
      setErrors(prev => {
        const next = { ...prev };
        delete next[key];
        return next;
      });

      // Clear optimistic update flag
      setOptimisticUpdates(prev => {
        const next = { ...prev };
        delete next[key];
        return next;
      });

      onSuccess?.(result);
      return result;
    } catch (error) {
      console.error(`Update ${key} failed:`, error);
      throw error;
    }
  }, []);

  /**
   * Add an error notification
   */
  const addError = useCallback((key, message, options = {}) => {
    setErrors(prev => ({
      ...prev,
      [key]: {
        message,
        ...options,
      },
    }));
  }, []);

  /**
   * Remove an error notification
   */
  const removeError = useCallback((key) => {
    setErrors(prev => {
      const next = { ...prev };
      delete next[key];
      return next;
    });
  }, []);

  /**
   * Clear all errors
   */
  const clearErrors = useCallback(() => {
    setErrors({});
  }, []);

  /**
   * Check if an update is pending
   */
  const isUpdating = useCallback((key) => {
    return !!optimisticUpdates[key];
  }, [optimisticUpdates]);

  /**
   * Get all pending keys
   */
  const getPendingKeys = useCallback(() => {
    return Object.keys(optimisticUpdates);
  }, [optimisticUpdates]);

  return {
    errors,
    optimisticUpdates,
    executeUpdate,
    addError,
    removeError,
    clearErrors,
    isUpdating,
    getPendingKeys,
    updateHandler: updateHandlerRef.current,
  };
}

/**
 * usePullToRefresh
 * Hook for managing pull-to-refresh state
 */
export function usePullToRefresh(onRefresh) {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);
    try {
      await onRefresh?.();
    } catch (error) {
      console.error('Refresh failed:', error);
      throw error;
    } finally {
      setIsRefreshing(false);
      setPullDistance(0);
    }
  }, [onRefresh]);

  return {
    isRefreshing,
    pullDistance,
    setPullDistance,
    handleRefresh,
  };
}

/**
 * useBottomSheetSelect
 * Hook for managing bottom sheet select state
 */
export function useBottomSheetSelect(initialValue = null) {
  const [isOpen, setIsOpen] = useState(false);
  const [value, setValue] = useState(initialValue);
  const [error, setError] = useState(null);

  const handleSelect = useCallback((newValue) => {
    try {
      setValue(newValue);
      setError(null);
      setIsOpen(false);
    } catch (err) {
      setError(err.message);
    }
  }, []);

  const handleClose = useCallback(() => {
    setIsOpen(false);
  }, []);

  const handleOpen = useCallback(() => {
    setIsOpen(true);
  }, []);

  return {
    isOpen,
    value,
    error,
    handleOpen,
    handleClose,
    handleSelect,
    setValue,
    setError,
  };
}

/**
 * useResponsiveUI
 * Hook for responsive UI handling on mobile
 */
export function useResponsiveUI() {
  const [isMobile, setIsMobile] = useState(
    typeof window !== 'undefined' && window.innerWidth < 768
  );

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return {
    isMobile,
    isTablet: !isMobile && typeof window !== 'undefined' && window.innerWidth < 1024,
    isDesktop: typeof window !== 'undefined' && window.innerWidth >= 1024,
  };
}