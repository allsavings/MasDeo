import { useState, useEffect } from 'react';

/**
 * useTheme – returns [isDark, setDark]
 * 'null' stored theme means "follow system preference".
 * Calling setDark(true/false) stores an explicit override;
 * calling setDark(null) reverts to system preference.
 */
export function useTheme() {
  const getSystemDark = () =>
    window.matchMedia('(prefers-color-scheme: dark)').matches;

  const getInitialDark = () => {
    try {
      const stored = localStorage.getItem('theme');
      if (stored === 'dark') return true;
      if (stored === 'light') return false;
    } catch (_) {}
    return getSystemDark();
  };

  const [isDark, setIsDark] = useState(getInitialDark);

  // Sync class on html element whenever isDark changes
  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDark);
  }, [isDark]);

  const setDark = (value) => {
    if (value === null) {
      try { localStorage.removeItem('theme'); } catch (_) {}
      setIsDark(getSystemDark());
    } else {
      try { localStorage.setItem('theme', value ? 'dark' : 'light'); } catch (_) {}
      setIsDark(value);
    }
  };

  // Listen for system-level changes when no manual override is stored
  useEffect(() => {
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = (e) => {
      try {
        if (!localStorage.getItem('theme')) setIsDark(e.matches);
      } catch (_) {}
    };
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  return [isDark, setDark];
}