// Re-export from the shared context so all callers share one instance
export { useWIPLock } from '@/lib/WIPLockContext';