import { useState, useEffect } from 'react';

export function useControlDemoLock() {
  const [lockedElements, setLockedElements] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('control_demo_locked') || '[]');
    } catch {
      return [];
    }
  });
  
  const [isPinMode, setIsPinMode] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [unlockedByPin, setUnlockedByPin] = useState(() => {
    return localStorage.getItem('control_demo_admin_unlocked') === 'true';
  });

  const ADMIN_PIN = '1234'; // Change to your actual admin PIN

  const toggleLock = (elementId) => {
    setLockedElements(prev => {
      const updated = prev.includes(elementId)
        ? prev.filter(id => id !== elementId)
        : [...prev, elementId];
      localStorage.setItem('control_demo_locked', JSON.stringify(updated));
      return updated;
    });
  };

  const verifyPin = (pin) => {
    if (pin === ADMIN_PIN) {
      setUnlockedByPin(true);
      localStorage.setItem('control_demo_admin_unlocked', 'true');
      setPinInput('');
      setIsPinMode(false);
      return true;
    }
    return false;
  };

  const lockAdmin = () => {
    setUnlockedByPin(false);
    localStorage.removeItem('control_demo_admin_unlocked');
    setPinInput('');
  };

  return {
    lockedElements,
    toggleLock,
    isPinMode,
    setIsPinMode,
    pinInput,
    setPinInput,
    verifyPin,
    unlockedByPin,
    lockAdmin,
    isLocked: (elementId) => lockedElements.includes(elementId),
  };
}