import React, { useEffect, useState } from 'react';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';

export default function AdminGuard({ children }) {
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const verifySession = async () => {
      try {
        const sessionId = localStorage.getItem('adminSessionId');
        const sessionToken = localStorage.getItem('adminSessionToken');

        if (!sessionId || !sessionToken) {
          window.location.href = createPageUrl('AdminPanel');
          return;
        }

        // Verify session exists and is valid in database
        const sessions = await base44.entities.AdminSession.filter({
          id: sessionId,
          session_token: sessionToken,
          is_active: true
        });

        if (sessions.length === 0) {
          localStorage.removeItem('adminSessionId');
          localStorage.removeItem('adminSessionToken');
          window.location.href = createPageUrl('AdminPanel');
          return;
        }

        const session = sessions[0];

        // Check if session is expired
        const expiresAt = new Date(session.session_expires_at);
        if (expiresAt < new Date()) {
          await base44.entities.AdminSession.update(session.id, { is_active: false });
          localStorage.removeItem('adminSessionId');
          localStorage.removeItem('adminSessionToken');
          window.location.href = createPageUrl('AdminPanel');
          return;
        }

        // Session is valid
        setIsAuthorized(true);
      } catch (err) {
        console.error('Session verification failed:', err);
        localStorage.removeItem('adminSessionId');
        localStorage.removeItem('adminSessionToken');
        window.location.href = createPageUrl('AdminPanel');
      } finally {
        setLoading(false);
      }
    };

    verifySession();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-400">Verifying session...</p>
        </div>
      </div>
    );
  }

  if (!isAuthorized) {
    return null;
  }

  return children;
}