import React, { useRef, useState, useCallback } from 'react';
import { RefreshCw } from 'lucide-react';

const THRESHOLD = 72; // px of pull needed to trigger refresh

export default function PullToRefresh({ onRefresh, children, className = '' }) {
  const [pullDistance, setPullDistance] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const startYRef = useRef(null);
  const containerRef = useRef(null);

  const handleTouchStart = useCallback((e) => {
    const el = containerRef.current;
    if (el && el.scrollTop === 0) {
      startYRef.current = e.touches[0].clientY;
    }
  }, []);

  const handleTouchMove = useCallback((e) => {
    if (startYRef.current === null || refreshing) return;
    const dy = e.touches[0].clientY - startYRef.current;
    if (dy > 0) {
      // Dampen the pull with sqrt scaling for natural feel
      setPullDistance(Math.min(Math.sqrt(dy) * 6, THRESHOLD * 1.4));
    }
  }, [refreshing]);

  const handleTouchEnd = useCallback(async () => {
    if (pullDistance >= THRESHOLD && !refreshing) {
      setRefreshing(true);
      setPullDistance(THRESHOLD);
      try {
        await onRefresh?.();
      } finally {
        setRefreshing(false);
        setPullDistance(0);
      }
    } else {
      setPullDistance(0);
    }
    startYRef.current = null;
  }, [pullDistance, refreshing, onRefresh]);

  const indicatorOpacity = Math.min(pullDistance / THRESHOLD, 1);
  const indicatorScale = 0.5 + indicatorOpacity * 0.5;
  const isReady = pullDistance >= THRESHOLD;

  return (
    <div
      ref={containerRef}
      className={`relative overflow-y-auto scroll-container ${className}`}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Pull indicator */}
      <div
        className="absolute top-0 left-0 right-0 flex justify-center z-20 pointer-events-none overflow-hidden"
        style={{ height: `${pullDistance}px`, transition: refreshing ? 'none' : 'height 0.2s ease' }}
      >
        <div
          className="flex items-center justify-center mt-2"
          style={{ opacity: indicatorOpacity, transform: `scale(${indicatorScale})`, transition: 'transform 0.15s ease' }}
        >
          <div className={`w-9 h-9 rounded-full flex items-center justify-center shadow-lg ${
            isReady ? 'bg-cyan-500' : 'bg-gray-700'
          }`}>
            <RefreshCw
              className={`w-4 h-4 text-white ptr-spinner`}
              style={{ animation: refreshing ? undefined : 'none', transform: `rotate(${pullDistance * 3}deg)` }}
            />
          </div>
        </div>
      </div>

      <div style={{ transform: `translateY(${pullDistance}px)`, transition: refreshing ? 'transform 0.2s ease' : 'none' }}>
        {children}
      </div>
    </div>
  );
}