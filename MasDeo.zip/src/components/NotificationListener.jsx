import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { Bell, X } from 'lucide-react';
import { useNotifications } from '@/hooks/useNotifications';

export default function NotificationListener() {
  const [notifications, setNotifications] = useState([]);
  const [userEmail, setUserEmail] = useState(null);
  // Toast queue — top-of-screen popups for new arrivals
  const [toasts, setToasts] = useState([]);
  const { showLocalNotification } = useNotifications();

  useEffect(() => {
    let email = null;
    let userCreatedDate = null;

    const mapN = (n) => ({ id: n.id, dbId: n.id, title: n.title, body: n.body || n.message, read_by: n.read_by || [], read_count: n.read_count || 0, type: n.type || 'info', imageUrl: n.file_url || '' });

    const fetchNotifications = async (currentEmail, signupDate) => {
      // Fetch both targeted notifications AND broadcast (no user_email) ones
      const [personal, broadcast] = await Promise.all([
        base44.entities.AppNotification.filter({ user_email: currentEmail }, '-created_date', 50),
        base44.entities.AppNotification.list('-created_date', 50),
      ]);
      // Merge & deduplicate, keeping only broadcast (no user_email) + personal
      const all = [...personal];
      broadcast.forEach(n => {
        if (!n.user_email && !all.find(x => x.id === n.id)) all.push(n);
      });
      const unread = all.filter(n => {
        const notifCreatedDate = new Date(n.created_date);
        const notRead = !(n.read_by || []).includes(currentEmail);
        return notifCreatedDate >= signupDate && notRead;
      });
      setNotifications(unread.map(n => mapN(n)));
    };

    const init = async () => {
      try {
        const user = await base44.auth.me();
        email = user?.email;
        userCreatedDate = new Date(user?.created_date);
        setUserEmail(email);
        await fetchNotifications(email, userCreatedDate);

        // Register periodic background sync (fires even when app is closed)
        if ('serviceWorker' in navigator && 'periodicSync' in ServiceWorkerRegistration.prototype) {
          try {
            const reg = await navigator.serviceWorker.ready;
            await reg.periodicSync.register('sync-notifications', { minInterval: 5 * 60 * 1000 });
          } catch (_) { /* periodic sync may not be available */ }
        }
      } catch (e) {
        console.error(e);
      }
    };

    // Listen for SW sync messages (background sync trigger)
    const swMessageHandler = (event) => {
      if (event.data?.type === 'SYNC_NOTIFICATIONS' && email && userCreatedDate) {
        fetchNotifications(email, userCreatedDate);
      }
    };
    navigator.serviceWorker?.addEventListener('message', swMessageHandler);

    init();

    const unsubscribe = base44.entities.AppNotification.subscribe((event) => {
      if (event.type === 'create') {
        const n = event.data;
        // Accept: broadcast (no user_email) OR targeted to this user
        const isBroadcast = !n.user_email || n.user_email === '';
        const isPersonal = n.user_email === email;
        if (!isBroadcast && !isPersonal) return;
        const alreadyRead = (n.read_by || []).includes(email);
        if (!alreadyRead) {
          const mapped = mapN(n);
          setNotifications(prev => {
            if (prev.find(x => x.dbId === n.id)) return prev;
            return [mapped, ...prev];
          });
          // Show a brief in-app toast popup
          setToasts(prev => [...prev, mapped]);
          setTimeout(() => setToasts(prev => prev.filter(t => t.id !== mapped.id)), 5000);
          // Fire native Android/OS notification (shows in the notification shade)
          const notifOpts = {
            body: n.message || n.body || 'You have a new notification.',
            tag: `app-notif-${n.id}`,
            data: { url: '/' },
          };
          // Only include image if file_url is provided
          if (n.file_url) {
            notifOpts.image = n.file_url;
          }
          showLocalNotification(n.title || 'Masters | DeoVex', notifOpts);
        }
      }
    });

    return () => {
      unsubscribe();
      navigator.serviceWorker?.removeEventListener('message', swMessageHandler);
    };
  }, []);

  const dismissToast = (id) => setToasts(prev => prev.filter(t => t.id !== id));

  const TYPE_COLOR = {
    success: 'border-green-500/40 bg-green-500/10',
    error:   'border-red-500/40 bg-red-500/10',
    warning: 'border-amber-500/40 bg-amber-500/10',
    info:    'border-blue-500/30 bg-blue-500/8',
  };

  const BELL_COLOR = {
    success: 'from-green-500 to-emerald-600',
    error:   'from-red-500 to-rose-600',
    warning: 'from-amber-500 to-orange-600',
    info:    'from-blue-500 to-purple-600',
  };

  return (
    <>
      {/* Toast popups — top of screen for new arriving notifications */}
      <div className="fixed top-4 left-0 right-0 z-[9999] flex flex-col items-center gap-2 pointer-events-none px-4">
        <AnimatePresence>
          {toasts.map(n => (
            <motion.div
              key={`toast-${n.id}`}
              initial={{ opacity: 0, y: -30, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.95 }}
              className={`pointer-events-auto w-full max-w-sm bg-gray-900/95 backdrop-blur-xl border rounded-2xl shadow-2xl px-4 py-3 flex items-start gap-3 ${TYPE_COLOR[n.type] || TYPE_COLOR.info}`}
            >
              <div className={`w-8 h-8 rounded-xl bg-gradient-to-br ${BELL_COLOR[n.type] || BELL_COLOR.info} flex items-center justify-center flex-shrink-0 mt-0.5`}>
                <Bell className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-white">{n.title}</p>
                <p className="text-xs text-gray-400 mt-0.5 leading-relaxed">{n.body}</p>
              </div>
              <button onClick={() => dismissToast(n.id)} className="text-gray-500 hover:text-white transition-colors flex-shrink-0 mt-0.5">
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

    </>
  );
}