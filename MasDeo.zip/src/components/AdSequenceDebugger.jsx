import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

/**
 * AdSequenceDebugger
 * Displays real-time ad sequence cycle information for verification
 * Shows: counter, position in cycle, whether ad should show, and the logic
 */
export default function AdSequenceDebugger() {
  const [debugInfo, setDebugInfo] = useState({
    counter: 0,
    adRunCount: 2,
    adRestCount: 2,
    totalCycle: 4,
    nextPosition: 0,
    shouldShowAd: false,
    lastUpdated: new Date(),
    history: []
  });

  // Listen for navigation and update debug info
  useEffect(() => {
    const handleStorageChange = () => {
      const counter = parseInt(sessionStorage.getItem('ad_click_counter') || '0');
      const adRunCount = parseInt(localStorage.getItem('ad_run_count') || '2');
      const adRestCount = parseInt(localStorage.getItem('ad_rest_count') || '2');
      const totalCycle = adRunCount + adRestCount;
      
      const nextCounter = counter + 1;
      const positionInCycle = ((nextCounter - 1) % totalCycle) + 1;
      const shouldShowAd = positionInCycle <= adRunCount;

      setDebugInfo(prev => ({
        counter,
        adRunCount,
        adRestCount,
        totalCycle,
        nextPosition: positionInCycle,
        shouldShowAd,
        lastUpdated: new Date(),
        history: [
          ...prev.history.slice(-9),
          {
            counter,
            position: positionInCycle,
            showAd: shouldShowAd,
            time: new Date().toLocaleTimeString()
          }
        ]
      }));
    };

    // Initial check
    handleStorageChange();

    // Listen for storage changes (from other tabs/navigation)
    window.addEventListener('storage', handleStorageChange);
    
    // Listen for navigation changes
    const handlePopState = () => handleStorageChange();
    window.addEventListener('popstate', handlePopState);

    // Periodic check
    const interval = setInterval(handleStorageChange, 500);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('popstate', handlePopState);
      clearInterval(interval);
    };
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed bottom-24 right-4 z-40 max-w-sm bg-gray-900/95 border border-cyan-500/40 rounded-xl p-4 backdrop-blur-sm"
    >
      <div className="space-y-3">
        <h3 className="text-sm font-bold text-cyan-400">Ad Sequence Debugger</h3>
        
        {/* Configuration */}
        <div className="bg-gray-800/50 rounded-lg p-3 space-y-2">
          <div className="flex justify-between text-xs">
            <span className="text-gray-400">ad_run_count:</span>
            <span className="text-white font-bold">{debugInfo.adRunCount}</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-gray-400">ad_rest_count:</span>
            <span className="text-white font-bold">{debugInfo.adRestCount}</span>
          </div>
          <div className="flex justify-between text-xs border-t border-gray-700 pt-2">
            <span className="text-gray-400">Total cycle:</span>
            <span className="text-white font-bold">{debugInfo.totalCycle}</span>
          </div>
        </div>

        {/* Current State */}
        <div className="bg-gray-800/50 rounded-lg p-3 space-y-2">
          <div className="flex justify-between text-xs">
            <span className="text-gray-400">Click counter:</span>
            <span className="text-white font-bold">{debugInfo.counter}</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-gray-400">Next position:</span>
            <span className="text-cyan-400 font-bold">{debugInfo.nextPosition}</span>
          </div>
          <div className="flex justify-between text-xs border-t border-gray-700 pt-2">
            <span className="text-gray-400">Show ad?</span>
            <motion.span
              key={debugInfo.shouldShowAd}
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              className={`font-bold px-2 py-1 rounded text-xs ${
                debugInfo.shouldShowAd
                  ? 'bg-red-500/30 text-red-400'
                  : 'bg-green-500/30 text-green-400'
              }`}
            >
              {debugInfo.shouldShowAd ? '✓ YES' : '✗ NO'}
            </motion.span>
          </div>
        </div>

        {/* Logic Explanation */}
        <div className="bg-blue-900/20 border border-blue-500/30 rounded-lg p-2">
          <p className="text-[10px] text-blue-300 leading-tight">
            {debugInfo.shouldShowAd ? (
              <>Position <strong>{debugInfo.nextPosition}</strong> is ≤ {debugInfo.adRunCount} → <strong>SHOW AD</strong></>
            ) : (
              <>Position <strong>{debugInfo.nextPosition}</strong> is {">"}  {debugInfo.adRunCount} → <strong>SKIP AD</strong></>
            )}
          </p>
        </div>

        {/* History */}
        {debugInfo.history.length > 0 && (
          <div className="bg-gray-800/50 rounded-lg p-2 max-h-32 overflow-y-auto">
            <p className="text-[10px] text-gray-400 mb-2 font-semibold">Last clicks:</p>
            <div className="space-y-1">
              {debugInfo.history.map((entry, idx) => (
                <div key={idx} className="text-[9px] text-gray-400 flex justify-between">
                  <span>
                    Click <strong>{entry.counter}</strong> → Pos {entry.position}
                  </span>
                  <span className={entry.showAd ? 'text-red-400' : 'text-green-400'}>
                    {entry.showAd ? 'AD' : '—'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Last Updated */}
        <p className="text-[9px] text-gray-500 text-right">
          Updated {debugInfo.lastUpdated.toLocaleTimeString()}
        </p>
      </div>
    </motion.div>
  );
}