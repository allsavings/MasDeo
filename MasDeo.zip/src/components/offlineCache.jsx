const PREFIX = 'mdv_cache_';

export const saveCache = (key, data) => {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(data));
    localStorage.setItem(PREFIX + 'timestamp', Date.now().toString());
  } catch (e) {
    // localStorage full - silently skip
  }
};

export const loadCache = (key) => {
  try {
    const data = localStorage.getItem(PREFIX + key);
    return data ? JSON.parse(data) : null;
  } catch (e) {
    return null;
  }
};