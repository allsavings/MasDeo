import { useContext } from 'react';
import { AuthContext } from './AuthContext';
import { uploadFile } from './vpsAPI';

export function useFileUpload() {
  const { dispatch } = useContext(AuthContext);

  const upload = async (file) => {
    dispatch({ type: 'SET_LOADING', payload: true });
    try {
      const result = await uploadFile(file);
      return result.url;
    } catch (err) {
      dispatch({ type: 'SET_ERROR', payload: err.message });
      throw err;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  return { upload };
}