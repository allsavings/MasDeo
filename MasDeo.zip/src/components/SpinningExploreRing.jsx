import React from 'react';

const r = 28;
const cx = 36;
const cy = 36;
const circleD = `M ${cx},${cy} m -${r},0 a ${r},${r} 0 1,1 ${r * 2},0 a ${r},${r} 0 1,1 -${r * 2},0`;

export default function SpinningExploreRing() {
  return (
    <>
      <style>{`
        @keyframes exploreRingSpin {
          from { transform: rotate(0deg); }
          to   { transform: rotate(360deg); }
        }
        .explore-ring-spin {
          animation: exploreRingSpin 8s linear infinite;
          transform-origin: 36px 36px;
        }
      `}</style>
      <svg
        width="72"
        height="72"
        viewBox="0 0 72 72"
        className="absolute pointer-events-none"
        style={{ top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }}
        overflow="visible"
      >
        <defs>
          <path id="exploreRingPath" d={circleD} />
          <linearGradient id="exploreRingGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#22d3ee" />
            <stop offset="50%" stopColor="#60a5fa" />
            <stop offset="100%" stopColor="#22d3ee" />
          </linearGradient>
        </defs>
        <g className="explore-ring-spin">
          <text
            fontSize="7"
            fontWeight="700"
            letterSpacing="1.6"
            fontFamily="ui-sans-serif, system-ui, sans-serif"
          >
            <textPath href="#exploreRingPath" startOffset="0%">
              <tspan fill="url(#exploreRingGrad)" opacity="0.9">
                Explore Creators • Explore Creators •
              </tspan>
            </textPath>
          </text>
        </g>
      </svg>
    </>
  );
}