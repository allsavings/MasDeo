import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, Trash2, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { base44 } from '@/api/base44Client';

/**
 * DeleteAccountDialog
 * Props:
 *   open (bool) – controls visibility
 *   onClose (fn) – called when user cancels
 *   userEmail (string) – user's email, must type it to confirm
 */
export default function DeleteAccountDialog({ open, onClose, userEmail }) {
  const [step, setStep] = useState(1); // 1 = warning, 2 = confirm email, 3 = deleting
  const [confirmInput, setConfirmInput] = useState('');
  const [error, setError] = useState('');

  const handleClose = () => {
    setStep(1);
    setConfirmInput('');
    setError('');
    onClose?.();
  };

  const handleDelete = async () => {
    if (confirmInput.trim().toLowerCase() !== (userEmail || '').toLowerCase()) {
      setError('Email does not match. Please try again.');
      return;
    }
    setStep(3);
    try {
      // Delete all user data from known entities
      const email = userEmail;

      const [profiles, creatorProfiles, wallets, notifications] = await Promise.allSettled([
        base44.entities.UserProfile.filter({ created_by: email }),
        base44.entities.CreatorProfile.filter({ user_email: email }),
        base44.entities.Wallet.filter({ created_by: email }),
        base44.entities.Notification.filter({ recipient_email: email }),
      ]);

      const deleteAll = async (result) => {
        if (result.status === 'fulfilled') {
          for (const item of result.value) {
            await base44.entities[item.__type || Object.keys(item)[0]] // fallback
              .delete?.(item.id).catch(() => {});
          }
        }
      };

      // Delete profile records individually
      if (profiles.status === 'fulfilled') {
        for (const p of profiles.value) await base44.entities.UserProfile.delete(p.id).catch(() => {});
      }
      if (creatorProfiles.status === 'fulfilled') {
        for (const p of creatorProfiles.value) await base44.entities.CreatorProfile.delete(p.id).catch(() => {});
      }
      if (wallets.status === 'fulfilled') {
        for (const p of wallets.value) await base44.entities.Wallet.delete(p.id).catch(() => {});
      }
      if (notifications.status === 'fulfilled') {
        for (const p of notifications.value) await base44.entities.Notification.delete(p.id).catch(() => {});
      }

      // Sign out – account is effectively wiped
      await base44.auth.logout('/AuthScreen');
    } catch (err) {
      setError('Something went wrong. Please contact support.');
      setStep(2);
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            onClick={handleClose}
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.92, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.92, y: 20 }}
            className="relative bg-[#0f0f1a] border border-red-500/30 rounded-2xl p-6 max-w-md w-full shadow-2xl z-10"
          >
            {/* Close */}
            <button
              onClick={handleClose}
              aria-label="Close"
              className="absolute top-4 right-4 w-8 h-8 flex items-center justify-center rounded-full bg-gray-800 hover:bg-gray-700 transition-colors"
            >
              <X className="w-4 h-4 text-gray-400" />
            </button>

            {step === 3 ? (
              <div className="text-center py-6">
                <div className="w-12 h-12 rounded-full bg-red-500/20 flex items-center justify-center mx-auto mb-4">
                  <div className="w-5 h-5 border-2 border-red-400 border-t-transparent rounded-full animate-spin" />
                </div>
                <p className="text-white font-semibold">Deleting your account…</p>
                <p className="text-sm text-gray-400 mt-2">This may take a few seconds.</p>
              </div>
            ) : step === 1 ? (
              <>
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-12 h-12 rounded-xl bg-red-500/20 flex items-center justify-center flex-shrink-0">
                    <AlertTriangle className="w-6 h-6 text-red-400" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">Delete Account</h3>
                    <p className="text-sm text-gray-400">This action is permanent and irreversible.</p>
                  </div>
                </div>

                <div className="space-y-3 mb-6 text-sm text-gray-300">
                  <p className="font-medium text-red-400">Deleting your account will permanently remove:</p>
                  <ul className="space-y-2 text-gray-400">
                    {[
                      'Your profile and all personal data',
                      'Your wallet balance and transaction history',
                      'Your creator profile and published content',
                      'All subscriptions and earned credits',
                      'Any followers, following, and social data',
                    ].map((item) => (
                      <li key={item} className="flex items-start gap-2">
                        <span className="text-red-400 mt-0.5">✕</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                  <p className="text-gray-500 text-xs pt-1">
                    This cannot be undone. There is no grace period or recovery option.
                  </p>
                </div>

                <div className="flex gap-3">
                  <Button onClick={handleClose} variant="outline" className="flex-1">
                    Keep Account
                  </Button>
                  <Button
                    onClick={() => setStep(2)}
                    className="flex-1 bg-red-600 hover:bg-red-700 text-white"
                  >
                    Continue
                  </Button>
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-12 h-12 rounded-xl bg-red-500/20 flex items-center justify-center flex-shrink-0">
                    <Trash2 className="w-6 h-6 text-red-400" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">Confirm Deletion</h3>
                    <p className="text-sm text-gray-400">Type your email to confirm.</p>
                  </div>
                </div>

                <p className="text-sm text-gray-400 mb-3">
                  To permanently delete your account, type{' '}
                  <span className="text-white font-medium">{userEmail}</span> below:
                </p>

                <Input
                  value={confirmInput}
                  onChange={(e) => { setConfirmInput(e.target.value); setError(''); }}
                  placeholder="Your email address"
                  className="bg-gray-800/60 border-gray-600 text-white mb-3"
                  autoComplete="off"
                />

                {error && (
                  <p className="text-xs text-red-400 mb-3">{error}</p>
                )}

                <div className="flex gap-3">
                  <Button onClick={() => { setStep(1); setConfirmInput(''); setError(''); }} variant="outline" className="flex-1">
                    Back
                  </Button>
                  <Button
                    onClick={handleDelete}
                    disabled={!confirmInput}
                    className="flex-1 bg-red-600 hover:bg-red-700 text-white disabled:opacity-40"
                  >
                    Delete Forever
                  </Button>
                </div>
              </>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}