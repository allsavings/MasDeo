import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { Trash2, Globe, BookOpen, DollarSign, FileText, Search, AlertTriangle } from 'lucide-react';
import { Input } from '@/components/ui/input';

const SECTIONS = [
  { key: 'vpn', label: 'VPN Files', icon: Globe, entity: 'CreatorVpnFile', color: 'text-cyan-400' },
  { key: 'courses', label: 'Courses', icon: BookOpen, entity: 'CreatorCourse', color: 'text-purple-400' },
  { key: 'resources', label: 'Resources', icon: DollarSign, entity: 'CreatorResource', color: 'text-amber-400' },
];

export default function ContentModTab() {
  const [activeSection, setActiveSection] = useState('vpn');
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [confirmDelete, setConfirmDelete] = useState(null);

  useEffect(() => {
    loadContent();

    const section = SECTIONS.find(s => s.key === activeSection);
    const unsub = base44.entities[section.entity].subscribe((event) => {
      if (event.type === 'create') {
        setItems(prev => [event.data, ...prev]);
      } else if (event.type === 'update') {
        setItems(prev => prev.map(item => item.id === event.id ? event.data : item));
      } else if (event.type === 'delete') {
        setItems(prev => prev.filter(item => item.id !== event.id));
      }
    });
    return unsub;
  }, [activeSection]);

  const loadContent = async () => {
    setLoading(true);
    const section = SECTIONS.find(s => s.key === activeSection);
    const data = await base44.entities[section.entity].list('-created_date', 100);
    setItems(data);
    setLoading(false);
  };

  const deleteItem = async (id) => {
    const section = SECTIONS.find(s => s.key === activeSection);
    await base44.entities[section.entity].delete(id);
    setConfirmDelete(null);
    // No manual reload needed — subscription handles it
  };

  const filtered = items.filter(item =>
    search === '' ||
    item.title?.toLowerCase().includes(search.toLowerCase()) ||
    item.file_name?.toLowerCase().includes(search.toLowerCase()) ||
    item.creator_email?.toLowerCase().includes(search.toLowerCase())
  );

  const section = SECTIONS.find(s => s.key === activeSection);

  return (
    <div className="px-4 space-y-3 py-2">
      {/* Section Tabs */}
      <div className="flex gap-2">
        {SECTIONS.map(s => (
          <button key={s.key} onClick={() => setActiveSection(s.key)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all border flex-1 justify-center ${
              activeSection === s.key ? 'bg-gray-700/80 border-gray-500/50 text-white' : 'bg-gray-800/40 border-gray-700/50 text-gray-500'
            }`}>
            <s.icon className={`w-3.5 h-3.5 ${activeSection === s.key ? s.color : ''}`} />
            {s.label}
          </button>
        ))}
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by title or creator..."
          className="bg-gray-800/40 border-gray-700 text-white text-sm pl-9" />
      </div>

      <div className="text-xs text-gray-500">{filtered.length} items</div>

      {loading && <p className="text-center text-gray-600 text-sm py-8">Loading...</p>}

      <div className="space-y-2">
        {filtered.map((item, i) => (
          <motion.div key={item.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.02 }}
            className="bg-gray-800/40 rounded-xl border border-gray-700/50 p-3 flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white truncate">{item.title || item.file_name || 'Untitled'}</p>
              <p className="text-xs text-gray-500 mt-0.5">{item.creator_email}</p>
              <div className="flex items-center gap-2 mt-1 flex-wrap">
                {item.file_type && <span className="text-[10px] bg-gray-700/50 text-gray-400 px-1.5 py-0.5 rounded">{item.file_type}</span>}
                {item.is_public !== undefined && (
                  <span className={`text-[10px] px-1.5 py-0.5 rounded ${item.is_public ? 'bg-green-500/20 text-green-400' : 'bg-gray-700/50 text-gray-500'}`}>
                    {item.is_public ? 'Public' : 'Private'}
                  </span>
                )}
                {item.is_published !== undefined && (
                  <span className={`text-[10px] px-1.5 py-0.5 rounded ${item.is_published ? 'bg-green-500/20 text-green-400' : 'bg-gray-700/50 text-gray-500'}`}>
                    {item.is_published ? 'Published' : 'Draft'}
                  </span>
                )}
                <span className="text-[10px] text-gray-600">{new Date(item.created_date).toLocaleDateString()}</span>
              </div>
            </div>
            {confirmDelete === item.id ? (
              <div className="flex gap-1.5">
                <button onClick={() => deleteItem(item.id)} className="text-xs bg-red-500/20 text-red-400 border border-red-500/30 px-2 py-1 rounded-lg hover:bg-red-500/30">Confirm</button>
                <button onClick={() => setConfirmDelete(null)} className="text-xs bg-gray-700/50 text-gray-400 px-2 py-1 rounded-lg">Cancel</button>
              </div>
            ) : (
              <button onClick={() => setConfirmDelete(item.id)} className="text-gray-600 hover:text-red-400 transition-colors flex-shrink-0">
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </motion.div>
        ))}
        {!loading && filtered.length === 0 && (
          <p className="text-center text-gray-600 text-sm py-10">No content found.</p>
        )}
      </div>
    </div>
  );
}