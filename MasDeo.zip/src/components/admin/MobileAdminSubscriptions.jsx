import React, { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import MobileErrorBoundary from '@/components/mobile/MobileErrorBoundary';
import { OptimisticUpdateHandler } from '@/components/mobile/OptimisticUpdateHandler';
import { CheckCircle, XCircle, Ban, ShieldCheck } from 'lucide-react';

/**
 * MobileAdminSubscriptions
 * Mobile-optimized subscriptions list with optimistic updates and error handling
 * Touch-friendly design with proper error recovery
 */
export default function MobileAdminSubscriptions({
  subscriptions = [],
  onApprove,
  onReject,
  onBan,
  loading = false,
}) {
  const [errors, setErrors] = useState({});
  const [optimisticUpdates, setOptimisticUpdates] = useState({});

  const updateHandler = new OptimisticUpdateHandler((key, errorMsg) => {
    setErrors(prev => ({
      ...prev,
      [key]: {
        message: errorMsg,
        title: 'Update Failed',
        severity: 'warning',
        persistent: false,
      },
    }));
    
    // Rollback optimistic update
    setOptimisticUpdates(prev => {
      const next = { ...prev };
      delete next[key];
      return next;
    });
  });

  const handleApprove = useCallback(async (subscriptionId, subscription) => {
    const key = `approve-${subscriptionId}`;
    const previousState = { ...subscription, status: subscription.status };

    try {
      await updateHandler.execute(
        key,
        () => {
          // Optimistic update: mark as approved
          setOptimisticUpdates(prev => ({
            ...prev,
            [key]: { ...previousState, status: 'active' },
          }));
        },
        async () => {
          // API call
          return onApprove?.(subscriptionId) || Promise.resolve();
        },
        () => {
          // Rollback
          setOptimisticUpdates(prev => {
            const next = { ...prev };
            delete next[key];
            return next;
          });
        }
      );

      // Clear error on success
      setErrors(prev => {
        const next = { ...prev };
        delete next[key];
        return next;
      });
    } catch (error) {
      console.error('Approve failed:', error);
    }
  }, [onApprove, updateHandler]);

  const handleReject = useCallback(async (subscriptionId, subscription) => {
    const key = `reject-${subscriptionId}`;
    const previousState = { ...subscription };

    try {
      await updateHandler.execute(
        key,
        () => {
          setOptimisticUpdates(prev => ({
            ...prev,
            [key]: { ...previousState, status: 'rejected' },
          }));
        },
        async () => {
          return onReject?.(subscriptionId) || Promise.resolve();
        },
        () => {
          setOptimisticUpdates(prev => {
            const next = { ...prev };
            delete next[key];
            return next;
          });
        }
      );

      setErrors(prev => {
        const next = { ...prev };
        delete next[key];
        return next;
      });
    } catch (error) {
      console.error('Reject failed:', error);
    }
  }, [onReject, updateHandler]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-3 px-4 pb-6">
      {/* Error notifications */}
      <MobileErrorBoundary errors={errors} onDismiss={(key) => {
        setErrors(prev => {
          const next = { ...prev };
          delete next[key];
          return next;
        });
      }} />

      {subscriptions.length === 0 ? (
        <div className="text-center py-8 text-gray-600 text-sm">
          No subscriptions found
        </div>
      ) : (
        subscriptions.map(sub => {
          const key = `sub-${sub.id}`;
          const optimisticState = optimisticUpdates[key];
          const displaySub = optimisticState || sub;
          const isUpdating = !!optimisticState;

          return (
            <motion.div
              key={sub.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gray-800/40 rounded-xl border border-gray-700/50 p-4 overflow-hidden"
              style={{ opacity: isUpdating ? 0.6 : 1 }}
            >
              {/* Header */}
              <div className="mb-3">
                <div className="flex items-start justify-between gap-2 mb-1">
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-white text-sm truncate">
                      {sub.user_name || sub.user_email}
                    </p>
                    <p className="text-xs text-gray-500 truncate">{sub.user_email}</p>
                  </div>
                  <span className={`text-xs font-bold px-2 py-1 rounded-full flex-shrink-0 ${
                    displaySub.status === 'pending'
                      ? 'bg-amber-500/20 text-amber-400'
                      : displaySub.status === 'active'
                      ? 'bg-green-500/20 text-green-400'
                      : 'bg-red-500/20 text-red-400'
                  }`}>
                    {displaySub.status}
                  </span>
                </div>
              </div>

              {/* Details */}
              <div className="bg-gray-900/50 rounded-lg p-3 mb-4 text-xs text-gray-400 space-y-1">
                <p>Plan: {sub.plan}</p>
                {sub.amount_paid && <p>Amount: R{sub.amount_paid}</p>}
                {sub.created_date && (
                  <p>Submitted: {new Date(sub.created_date).toLocaleDateString()}</p>
                )}
              </div>

              {/* Actions */}
              {displaySub.status === 'pending' && (
                <div className="flex gap-2 flex-wrap">
                  <button
                    onClick={() => handleApprove(sub.id, sub)}
                    disabled={isUpdating}
                    className="flex-1 min-h-[44px] flex items-center justify-center gap-1 text-xs bg-green-500/20 text-green-400 border border-green-500/30 rounded-lg hover:bg-green-500/30 disabled:opacity-50 transition-colors"
                  >
                    <CheckCircle className="w-3.5 h-3.5" />
                    Approve
                  </button>
                  <button
                    onClick={() => handleReject(sub.id, sub)}
                    disabled={isUpdating}
                    className="flex-1 min-h-[44px] flex items-center justify-center gap-1 text-xs bg-red-500/20 text-red-400 border border-red-500/30 rounded-lg hover:bg-red-500/30 disabled:opacity-50 transition-colors"
                  >
                    <XCircle className="w-3.5 h-3.5" />
                    Reject
                  </button>
                </div>
              )}

              {/* Error message for this subscription */}
              {errors[`approve-${sub.id}`] && (
                <div className="mt-2 text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg p-2">
                  {errors[`approve-${sub.id}`].message}
                </div>
              )}
              {errors[`reject-${sub.id}`] && (
                <div className="mt-2 text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg p-2">
                  {errors[`reject-${sub.id}`].message}
                </div>
              )}
            </motion.div>
          );
        })
      )}
    </div>
  );
}