import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { Server, RefreshCw, Download, Trash2, RotateCcw, ExternalLink, Copy, Check, AlertCircle, Search, HardDrive } from 'lucide-react';
import { Input } from '@/components/ui/input';

export default function VpsFilesTab() {
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [actionStatus, setActionStatus] = useState({});
  const [copiedId, setCopiedId] = useState(null);

  // Restore mode: fetch all file_urls stored in DB (Base44 backup)
  const [dbFiles, setDbFiles] = useState([]);
  const [tab, setTab] = useState('vps'); // 'vps' | 'backup'
  const [restoreNewUrl, setRestoreNewUrl] = useState({});
  const [restoreLoading, setRestoreLoading] = useState({});

  useEffect(() => {
    if (tab === 'vps') loadVpsFiles();
    else loadDbBackup();
  }, [tab]);

  const loadVpsFiles = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await base44.functions.invoke('vpsFileManager', { action: 'list' });
      setFiles(res.data.files || []);
    } catch (e) {
      setError('Could not list VPS files. Make sure your VPS /list endpoint is configured.');
    }
    setLoading(false);
  };

  const loadDbBackup = async () => {
    setLoading(true);
    setError('');
    try {
      // Collect all file URLs stored in DB entities
      const [vpnFiles, creatorVpnFiles, profiles, subs, items, resources, courses] = await Promise.all([
        base44.entities.VpnFile.list(),
        base44.entities.CreatorVpnFile.list(),
        base44.entities.UserProfile.list(),
        base44.entities.Subscription.list(),
        base44.entities.CreatorItem.list(),
        base44.entities.CreatorResource.list(),
        base44.entities.CreatorCourse.list(),
      ]);

      const collected = [];
      vpnFiles.forEach(f => f.file_url && collected.push({ url: f.file_url, entity: 'VpnFile', id: f.id, name: f.file_name }));
      creatorVpnFiles.forEach(f => f.file_url && collected.push({ url: f.file_url, entity: 'CreatorVpnFile', id: f.id, name: f.file_name }));
      profiles.forEach(p => p.profile_picture_url && collected.push({ url: p.profile_picture_url, entity: 'Profile', id: p.id, name: p.nickname || p.created_by }));
      subs.forEach(s => s.payment_proof_url && collected.push({ url: s.payment_proof_url, entity: 'Subscription', id: s.id, name: `${s.user_email} - ${s.plan}` }));
      items.forEach(it => {
        if (it.file_url) collected.push({ url: it.file_url, entity: 'CreatorItem', id: it.id, name: it.title });
        if (it.icon_image_url) collected.push({ url: it.icon_image_url, entity: 'CreatorItem (icon)', id: it.id, name: it.title });
      });
      resources.forEach(r => {
        if (r.file_url) collected.push({ url: r.file_url, entity: 'CreatorResource', id: r.id, name: r.title });
        if (r.thumbnail_url) collected.push({ url: r.thumbnail_url, entity: 'CreatorResource (thumb)', id: r.id, name: r.title });
      });
      courses.forEach(c => c.thumbnail_url && collected.push({ url: c.thumbnail_url, entity: 'CreatorCourse (thumb)', id: c.id, name: c.title }));

      setDbFiles(collected);
    } catch (e) {
      setError('Failed to load backup files from database.');
    }
    setLoading(false);
  };

  const handleDelete = async (fileUrl, idx) => {
    if (!confirm('Delete this file from your VPS?')) return;
    setActionStatus(s => ({ ...s, [idx]: 'deleting' }));
    try {
      await base44.functions.invoke('vpsFileManager', { action: 'delete', file_url: fileUrl });
      setFiles(f => f.filter((_, i) => i !== idx));
    } catch (e) {
      alert('Delete failed: ' + e.message);
    }
    setActionStatus(s => ({ ...s, [idx]: null }));
  };

  const handleRestore = async (backupUrl, idx) => {
    setRestoreLoading(s => ({ ...s, [idx]: true }));
    try {
      const res = await base44.functions.invoke('vpsFileManager', { action: 'restore', file_url: backupUrl });
      setRestoreNewUrl(s => ({ ...s, [idx]: res.data.new_url }));
    } catch (e) {
      alert('Restore failed: ' + e.message);
    }
    setRestoreLoading(s => ({ ...s, [idx]: false }));
  };

  const handleBulkReplace = async (oldUrl, newUrl, idx) => {
    if (!newUrl) { alert('Restore file first to get new URL'); return; }
    setActionStatus(s => ({ ...s, [`replace_${idx}`]: 'loading' }));
    try {
      const res = await base44.functions.invoke('vpsFileManager', { action: 'bulk_replace_url', file_url: oldUrl, new_vps_url: newUrl });
      setActionStatus(s => ({ ...s, [`replace_${idx}`]: 'done' }));
      alert(`✅ Updated ${res.data.updated} record(s) in database.`);
    } catch (e) {
      alert('Bulk replace failed: ' + e.message);
      setActionStatus(s => ({ ...s, [`replace_${idx}`]: null }));
    }
  };

  const copyUrl = (url, id) => {
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filteredVps = files.filter(f => !search || (typeof f === 'string' ? f : f.name || f.url || '').toLowerCase().includes(search.toLowerCase()));
  const filteredDb = dbFiles.filter(f => !search || f.url.toLowerCase().includes(search.toLowerCase()) || f.name?.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="px-4 py-4 space-y-4">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-600/20 to-teal-600/20 rounded-2xl p-4 border border-emerald-500/30">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center">
            <Server className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-white">VPS File Manager</h3>
            <p className="text-xs text-gray-400">media.mastersdeovex.co.za — Manage & restore files</p>
          </div>
        </div>
        <div className="text-xs text-gray-300 space-y-1">
          <p>• <span className="text-emerald-400 font-semibold">VPS Files</span> — view & delete files on your live VPS</p>
          <p>• <span className="text-cyan-400 font-semibold">DB Backup</span> — restore files from Base44 to a new VPS when you switch servers</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 bg-gray-800/50 rounded-xl p-1 border border-gray-700/40">
        {[
          { id: 'vps', label: '🖥 VPS Files', desc: 'Live on server' },
          { id: 'backup', label: '☁️ DB Backup', desc: 'Restore to new VPS' },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`flex-1 py-2 rounded-lg text-xs font-semibold transition-all ${
              tab === t.id ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white' : 'text-gray-500 hover:text-gray-300'
            }`}>
            {t.label}
            <div className={`text-[9px] font-normal mt-0.5 ${tab === t.id ? 'text-emerald-100' : 'text-gray-600'}`}>{t.desc}</div>
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search files..."
          className="bg-gray-800/40 border-gray-700 text-white text-sm pl-9" />
      </div>

      {/* Error */}
      {error && (
        <div className="flex items-start gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-xs text-red-300">
          <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
          {error}
        </div>
      )}

      {/* Refresh */}
      <div className="flex items-center justify-between">
        <span className="text-xs text-gray-500">{tab === 'vps' ? `${filteredVps.length} VPS files` : `${filteredDb.length} backup entries`}</span>
        <button onClick={tab === 'vps' ? loadVpsFiles : loadDbBackup}
          className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white px-3 py-1.5 bg-gray-800/60 rounded-lg transition-all">
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} /> Refresh
        </button>
      </div>

      {/* VPS FILES TAB */}
      {tab === 'vps' && (
        <div className="space-y-2">
          {loading && <div className="text-center py-8 text-gray-500 text-sm">Loading VPS files...</div>}
          {!loading && filteredVps.length === 0 && (
            <div className="text-center py-8 bg-gray-800/20 rounded-2xl">
              <HardDrive className="w-8 h-8 text-gray-600 mx-auto mb-2" />
              <p className="text-gray-500 text-sm">No files found on VPS</p>
              <p className="text-gray-600 text-xs mt-1">Make sure your /list endpoint is set up on your VPS</p>
            </div>
          )}
          {filteredVps.map((file, idx) => {
            const url = typeof file === 'string' ? file : (file.url || file.name || '');
            const name = url.split('/').pop();
            return (
              <motion.div key={idx} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}
                className="bg-gray-800/40 rounded-xl p-3 border border-gray-700/50 flex items-center gap-3">
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-mono text-white truncate">{name}</p>
                  <p className="text-[10px] text-gray-500 truncate">{url}</p>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button onClick={() => copyUrl(url, idx)}
                    className="p-1.5 rounded-lg bg-gray-700/50 hover:bg-gray-700 transition-colors">
                    {copiedId === idx ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3 text-gray-400" />}
                  </button>
                  <a href={url} target="_blank" rel="noopener noreferrer"
                    className="p-1.5 rounded-lg bg-gray-700/50 hover:bg-blue-500/20 transition-colors">
                    <ExternalLink className="w-3 h-3 text-blue-400" />
                  </a>
                  <button onClick={() => handleDelete(url, idx)} disabled={actionStatus[idx] === 'deleting'}
                    className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 transition-colors disabled:opacity-40">
                    <Trash2 className="w-3 h-3 text-red-400" />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* DB BACKUP TAB */}
      {tab === 'backup' && (
        <div className="space-y-2">
          <div className="bg-cyan-500/10 border border-cyan-500/20 rounded-xl px-4 py-3 text-xs text-cyan-300">
            💡 <strong>How to restore to a new VPS:</strong> Click "Restore to VPS" for each file — it downloads from Base44 and re-uploads to your new VPS. Then click "Update DB" to replace the old URL in the database.
          </div>
          {loading && <div className="text-center py-8 text-gray-500 text-sm">Loading DB files...</div>}
          {!loading && filteredDb.length === 0 && (
            <div className="text-center py-8 bg-gray-800/20 rounded-2xl">
              <p className="text-gray-500 text-sm">No file URLs found in database</p>
            </div>
          )}
          {filteredDb.map((item, idx) => {
            const isBase44 = item.url.includes('base44') || item.url.includes('supabase');
            const newUrl = restoreNewUrl[idx];
            return (
              <motion.div key={idx} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}
                className="bg-gray-800/40 rounded-xl p-3 border border-gray-700/50 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full border flex-shrink-0 ${
                        isBase44
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                          : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                      }`}>
                        {isBase44 ? '☁ Base44' : '🖥 VPS'}
                      </span>
                      <span className="text-[9px] text-gray-500 bg-gray-700/50 px-1.5 py-0.5 rounded-full">{item.entity}</span>
                    </div>
                    <p className="text-xs font-medium text-white truncate">{item.name}</p>
                    <p className="text-[10px] text-gray-500 truncate">{item.url}</p>
                  </div>
                  <button onClick={() => copyUrl(item.url, `db_${idx}`)}
                    className="p-1.5 rounded-lg bg-gray-700/50 hover:bg-gray-700 flex-shrink-0 transition-colors">
                    {copiedId === `db_${idx}` ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3 text-gray-400" />}
                  </button>
                </div>

                {/* New URL after restore */}
                {newUrl && (
                  <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg px-2.5 py-1.5 text-[10px]">
                    <span className="text-emerald-400 font-semibold">✓ Restored: </span>
                    <span className="text-gray-300 font-mono truncate block">{newUrl}</span>
                  </div>
                )}

                <div className="flex gap-2">
                  <button onClick={() => handleRestore(item.url, idx)} disabled={restoreLoading[idx]}
                    className="flex-1 flex items-center justify-center gap-1.5 text-xs bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/30 py-1.5 rounded-lg transition-all disabled:opacity-40">
                    <RotateCcw className={`w-3 h-3 ${restoreLoading[idx] ? 'animate-spin' : ''}`} />
                    {restoreLoading[idx] ? 'Restoring...' : 'Restore to VPS'}
                  </button>
                  {newUrl && (
                    <button
                      onClick={() => handleBulkReplace(item.url, newUrl, idx)}
                      disabled={actionStatus[`replace_${idx}`] === 'loading'}
                      className="flex-1 flex items-center justify-center gap-1.5 text-xs bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 py-1.5 rounded-lg transition-all disabled:opacity-40"
                    >
                      {actionStatus[`replace_${idx}`] === 'done' ? '✓ Updated' : actionStatus[`replace_${idx}`] === 'loading' ? 'Updating...' : 'Update DB'}
                    </button>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}