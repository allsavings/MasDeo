import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Input } from '@/components/ui/input';
import { Save, AlertCircle, Zap, TrendingUp, Users } from 'lucide-react';
import NovaToggle from '@/components/ui/NovaToggle';
import { useRealtimeConfig } from '@/hooks/useRealtimeConfig';

// Simple Star Toggle Component
function StarToggle({ isEnabled, onToggle }) {
  return (
    <button
      onClick={() => onToggle(!isEnabled)}
      className="flex items-center justify-center w-10 h-10 rounded-lg bg-gray-700/40 hover:bg-gray-700/60 transition-all duration-200"
    >
      <motion.span
        key={isEnabled ? 'on' : 'off'}
        initial={{ scale: 0.8, rotate: 0 }}
        animate={{ scale: 1, rotate: isEnabled ? 5 : 0 }}
        className={`text-2xl ${isEnabled ? 'text-yellow-400' : 'text-gray-500'}`}
      >
        {isEnabled ? '★' : '☆'}
      </motion.span>
    </button>
  );
}

export default function AdControlTab() {
  const { config, loading, updateConfig } = useRealtimeConfig();
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [users, setUsers] = useState([]);
  const [userOverrides, setUserOverrides] = useState({});
  const [localConfig, setLocalConfig] = useState(null);

  useEffect(() => {
    loadUsers();
  }, []);

  // Sync realtime config to local state (sanitized to prevent circular refs)
  useEffect(() => {
    if (config) {
      setLocalConfig(sanitizeConfig(config));
    }
  }, [config]);

  // Sanitize config to extract only clean primitive values (no React internals)
  const sanitizeConfig = useCallback((cfg) => ({
    key: String(cfg?.key || 'global'),
    ads_enabled: Boolean(cfg?.ads_enabled ?? true),
    premium_ads_enabled: Boolean(cfg?.premium_ads_enabled ?? false),
    free_ads_enabled: Boolean(cfg?.free_ads_enabled ?? true),
    ad_frequency: Number(cfg?.ad_frequency || 50),
    ad_run_count: Number(cfg?.ad_run_count || 2),
    ad_rest_count: Number(cfg?.ad_rest_count || 2),
    smartlink_url: String(cfg?.smartlink_url || ''),
    popunder_url: String(cfg?.popunder_url || '')
  }), []);

  const loadUsers = async () => {
    try {
      const allUsers = await base44.entities.UserProfile.list();
      setUsers(allUsers);
    } catch (error) {
      console.error('Error loading users:', error);
    }
  };

  const saveConfig = async () => {
    if (!localConfig || loading) return;
    setSaving(true);
    try {
      const payload = sanitizeConfig(localConfig);
      await updateConfig(payload);
      setMessage('✓ Configuration saved successfully!');
      setTimeout(() => setMessage(''), 3000);
    } catch (error) {
      console.error('Error saving config:', error.message, error);
      setMessage(`✗ Error: ${error.message || 'check admin access'}`);
    } finally {
      setSaving(false);
    }
  };

  const handleUserOverride = async (userId, enabled) => {
    try {
      await base44.entities.UserProfile.update(userId, {
        ads_enabled_override: enabled
      });
      setUserOverrides(prev => ({ ...prev, [userId]: enabled }));
      setMessage('User override updated!');
      setTimeout(() => setMessage(''), 3000);
    } catch (error) {
      console.error('Error updating user override:', error);
      setMessage('Error updating user');
    }
  };

  const handleMasterToggle = useCallback(async (newValue) => {
    // Update state immediately for responsive UI
    setLocalConfig(prev => ({ ...prev, ads_enabled: newValue }));

    // Auto-save to database
    try {
      const updatedConfig = sanitizeConfig({ ...localConfig, ads_enabled: newValue });
      await updateConfig(updatedConfig);
      setMessage('✓ Master switch updated!');
      setTimeout(() => setMessage(''), 3000);
    } catch (error) {
      console.error('Error updating master switch:', error);
      setMessage(`✗ Error: ${error.message}`);
      setTimeout(() => setMessage(''), 3000);
      // Revert on error
      setLocalConfig(prev => ({ ...prev, ads_enabled: !newValue }));
    }
  }, [localConfig, updateConfig, sanitizeConfig]);

  if (loading || !localConfig) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-6">
      {/* Status Message */}
      {message && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`p-3 rounded-lg text-sm font-medium ${
            message.includes('Error')
              ? 'bg-red-500/20 text-red-400 border border-red-500/30'
              : 'bg-green-500/20 text-green-400 border border-green-500/30'
          }`}
        >
          {message}
        </motion.div>
      )}

      {/* MASTER AD SWITCH */}
      <div className="bg-gradient-to-br from-cyan-600/20 to-blue-600/20 rounded-2xl p-5 border border-cyan-500/30">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-white text-lg">Master Ad Switch</h3>
            <p className="text-xs text-gray-400">Control ad delivery for all users</p>
          </div>
        </div>

        <div className="bg-gray-900/40 rounded-xl p-4 mb-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white font-medium text-sm mb-1">Global Ad Status</p>
              <p className="text-xs text-gray-400">{localConfig.ads_enabled ? '✓ Ads are running normally' : '✗ All ads are disabled'}</p>
            </div>
            <NovaToggle
              isActive={localConfig.ads_enabled}
              onToggle={handleMasterToggle}
              activeColorClass="from-cyan-400 to-blue-500"
            />
          </div>
        </div>

        <div className={`text-xs p-3 rounded-lg border font-medium ${
          localConfig.ads_enabled
            ? 'bg-green-500/10 border-green-500/30 text-green-400'
            : 'bg-red-500/10 border-red-500/30 text-red-400'
        }`}>
          {localConfig.ads_enabled ? '✓ Ads enabled — AdView opens on user navigation' : '✗ Ads disabled — Content loads immediately'}
        </div>
      </div>

      {/* PLAN-BASED AD CONTROLS */}
      <div className="grid grid-cols-2 gap-3">
        {/* Premium Ads Switch */}
        <div className="bg-gradient-to-br from-amber-600/20 to-orange-600/20 rounded-2xl p-4 border border-amber-500/30">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center">
              <span className="text-white text-sm">👑</span>
            </div>
            <div>
              <p className="text-white font-semibold text-xs">Premium Users</p>
              <p className="text-[10px] text-gray-400">Subscribers only</p>
            </div>
          </div>
          <div className="flex items-center justify-between bg-gray-900/40 rounded-lg p-3">
            <div className="flex-1">
              <p className="text-xs text-gray-300">Show Ads</p>
              <p className="text-[10px] text-gray-500">{localConfig.premium_ads_enabled ? 'Enabled' : 'Disabled'}</p>
            </div>
            <StarToggle
              isEnabled={localConfig.premium_ads_enabled}
              onToggle={(value) => setLocalConfig(prev => ({ ...prev, premium_ads_enabled: value }))}
            />
          </div>
        </div>

        {/* Free Ads Switch */}
        <div className="bg-gradient-to-br from-cyan-600/20 to-teal-600/20 rounded-2xl p-4 border border-cyan-500/30">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-teal-500 flex items-center justify-center">
              <span className="text-white text-sm">⭐</span>
            </div>
            <div>
              <p className="text-white font-semibold text-xs">Free Users</p>
              <p className="text-[10px] text-gray-400">No subscription</p>
            </div>
          </div>
          <div className="flex items-center justify-between bg-gray-900/40 rounded-lg p-3">
            <div className="flex-1">
              <p className="text-xs text-gray-300">Show Ads</p>
              <p className="text-[10px] text-gray-500">{localConfig.free_ads_enabled ? 'Enabled' : 'Disabled'}</p>
            </div>
            <StarToggle
              isEnabled={localConfig.free_ads_enabled}
              onToggle={(value) => setLocalConfig(prev => ({ ...prev, free_ads_enabled: value }))}
            />
          </div>
        </div>
      </div>

      {/* DYNAMIC AD SEQUENCE CONTROL */}
      <div className="bg-gradient-to-br from-purple-600/20 to-pink-600/20 rounded-2xl p-5 border border-purple-500/30">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-white text-lg">Dynamic Ad Sequence</h3>
            <p className="text-xs text-gray-400">Control ad frequency in real-time</p>
          </div>
        </div>

        <div className="bg-gray-900/40 rounded-xl p-4 mb-4 space-y-5">
          {/* Ads ON Control */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-white font-semibold text-sm">Ads ON</label>
              <span className="text-purple-400 font-bold text-sm">{localConfig.ad_run_count} click{localConfig.ad_run_count !== 1 ? 's' : ''}</span>
            </div>
            <p className="text-xs text-gray-400 mb-3">How many clicks in a row show an ad</p>
            <div className="flex items-center gap-3">
              <input
                type="range"
                min="1"
                max="10"
                value={localConfig.ad_run_count}
                onChange={(e) => setLocalConfig(prev => ({ ...prev, ad_run_count: parseInt(e.target.value) }))}
                className="flex-1 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-purple-500"
              />
              <input
                type="number"
                min="1"
                max="10"
                value={localConfig.ad_run_count}
                onChange={(e) => setLocalConfig(prev => ({ ...prev, ad_run_count: Math.min(10, Math.max(1, parseInt(e.target.value) || 1)) }))}
                className="w-14 bg-gray-800 border border-gray-700 rounded-lg px-2 py-1.5 text-white text-sm text-center font-semibold"
              />
            </div>
          </div>

          {/* Ads OFF Control */}
          <div className="border-t border-gray-700/30 pt-4">
            <div className="flex items-center justify-between mb-2">
              <label className="text-white font-semibold text-sm">Ads OFF</label>
              <span className="text-pink-400 font-bold text-sm">{localConfig.ad_rest_count} click{localConfig.ad_rest_count !== 1 ? 's' : ''}</span>
            </div>
            <p className="text-xs text-gray-400 mb-3">How many clicks skip the ad</p>
            <div className="flex items-center gap-3">
              <input
                type="range"
                min="1"
                max="10"
                value={localConfig.ad_rest_count}
                onChange={(e) => setLocalConfig(prev => ({ ...prev, ad_rest_count: parseInt(e.target.value) }))}
                className="flex-1 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-pink-500"
              />
              <input
                type="number"
                min="1"
                max="10"
                value={localConfig.ad_rest_count}
                onChange={(e) => setLocalConfig(prev => ({ ...prev, ad_rest_count: Math.min(10, Math.max(1, parseInt(e.target.value) || 1)) }))}
                className="w-14 bg-gray-800 border border-gray-700 rounded-lg px-2 py-1.5 text-white text-sm text-center font-semibold"
              />
            </div>
          </div>
        </div>

        {/* Cycle Pattern Visualization */}
        <div className="bg-purple-900/20 border border-purple-500/20 rounded-xl p-3 space-y-2">
          <p className="text-xs font-semibold text-purple-300 uppercase tracking-wider">Cycle Pattern</p>
          <div className="flex items-center gap-1 flex-wrap">
            {Array.from({ length: localConfig.ad_run_count + localConfig.ad_rest_count }).map((_, i) => (
              <motion.div
                key={i}
                className={`w-7 h-7 rounded-md flex items-center justify-center text-[10px] font-bold border ${
                  i < localConfig.ad_run_count
                    ? 'bg-purple-500/40 border-purple-500/60 text-purple-300'
                    : 'bg-gray-700/40 border-gray-600/60 text-gray-400'
                }`}
                whileHover={{ scale: 1.1 }}
              >
                {i + 1}
              </motion.div>
            ))}
          </div>
          <p className="text-[10px] text-gray-400 mt-2">
            <span className="text-purple-400 font-semibold">1-{localConfig.ad_run_count}</span> show ad • <span className="text-gray-500 font-semibold">{localConfig.ad_run_count + 1}-{localConfig.ad_run_count + localConfig.ad_rest_count}</span> skip • Total cycle: <span className="text-white font-bold">{localConfig.ad_run_count + localConfig.ad_rest_count}</span>
          </p>
        </div>

        {/* Save Button */}
        <button
          onClick={saveConfig}
          disabled={saving}
          className="w-full mt-4 flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 disabled:opacity-50 text-white py-3 rounded-xl font-semibold transition-all"
        >
          <Save className="w-4 h-4" />
          {saving ? 'Saving...' : 'Save Configuration'}
        </button>
      </div>

      {/* Ad Frequency Info */}
      <div className="bg-blue-500/10 rounded-xl border border-blue-500/30 p-4 space-y-2">
        <p className="text-sm text-blue-300 font-semibold">📊 Ad Frequency Setting</p>
        <p className="text-xs text-blue-200">Current: Every <span className="font-bold">{localConfig?.ad_frequency || 50}</span> navigations</p>
        <p className="text-xs text-blue-200/70">This controls how often ads appear based on user actions across the entire app.</p>
      </div>

      {/* User-Level Overrides */}
      <div className="bg-gradient-to-br from-indigo-600/20 to-purple-600/20 rounded-2xl border border-indigo-500/30 p-5">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center">
            <Users className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-white text-lg">User-Specific Ad Control</h3>
            <p className="text-xs text-gray-400">Override ad settings for individual users</p>
          </div>
        </div>

        {users.length > 0 ? (
          <div className="space-y-2 max-h-96 overflow-y-auto scroll-container">
            {users.map(user => {
              const userMembershipType = user.membership_type || 'free';
              const isOverridden = userOverrides[user.id] !== undefined;
              const overrideValue = userOverrides[user.id] ?? user.ads_enabled_override;
              
              return (
                <motion.div
                  key={user.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="bg-gray-900/40 rounded-lg p-3 border border-gray-700/50 hover:border-indigo-500/30 transition-all"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="text-white text-sm font-semibold truncate">{user.nickname}</p>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border flex-shrink-0 ${
                          userMembershipType === 'premium'
                            ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                            : 'bg-gray-700/40 text-gray-400 border-gray-600/30'
                        }`}>
                          {userMembershipType === 'premium' ? '👑 Premium' : '⭐ Free'}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500 font-mono truncate">{user.created_by}</p>
                      <p className={`text-[11px] font-semibold mt-1.5 ${
                        overrideValue === true ? 'text-yellow-400' :
                        overrideValue === false ? 'text-gray-400' :
                        'text-gray-500'
                      }`}>
                        {overrideValue === true ? 'Override: Ads Enabled ★' :
                         overrideValue === false ? 'Override: Ads Disabled ☆' :
                         'Using App Default'}
                      </p>
                    </div>
                    <div className="flex flex-col items-center gap-2 flex-shrink-0">
                      <div className="flex flex-col items-center">
                        <StarToggle
                          isEnabled={overrideValue === true}
                          onToggle={(value) => handleUserOverride(user.id, value ? true : false)}
                        />
                        <span className="text-[9px] text-gray-500 mt-1 text-center w-10">
                          {overrideValue === true ? 'Ads On' :
                           overrideValue === false ? 'Ads Off' :
                           'Default'}
                        </span>
                      </div>
                      <button
                        onClick={() => handleUserOverride(user.id, null)}
                        className="text-[10px] px-2 py-1 rounded-lg bg-gray-700/40 hover:bg-gray-700/60 text-gray-400 hover:text-gray-300 transition-all"
                      >
                        Reset
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        ) : (
          <div className="flex items-center justify-center gap-2 p-6 bg-gray-900/30 rounded-lg border border-yellow-500/30">
            <AlertCircle className="w-4 h-4 text-yellow-500 flex-shrink-0" />
            <p className="text-sm text-yellow-400 font-medium">No users found</p>
          </div>
        )}
      </div>

      {/* Info Section */}
      <div className="bg-blue-500/10 rounded-xl border border-blue-500/30 p-4 space-y-2">
        <p className="text-sm text-blue-300 font-medium">📋 How Ad Control Works</p>
        <ul className="text-xs text-blue-200 space-y-1 ml-4">
          <li>✓ Master switch overrides everything</li>
          <li>✓ Plan switches only apply when master is ON</li>
          <li>✓ User overrides bypass plan settings</li>
          <li>✓ Offline users never see ads (automatic)</li>
          <li>✓ Ad frequency controls navigation interval</li>
        </ul>
      </div>
    </div>
  );
}