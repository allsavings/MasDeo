import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, Unlock, Eye, EyeOff, AlertCircle, Check } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useControlDemoLock } from '@/hooks/useControlDemoLock';

export default function ControlDemoTab() {
  const {
    lockedElements,
    toggleLock,
    isPinMode,
    setIsPinMode,
    pinInput,
    setPinInput,
    verifyPin,
    unlockedByPin,
    lockAdmin,
    isLocked
  } = useControlDemoLock();

  const [pinError, setPinError] = useState('');
  const [sections] = useState([
    { id: 'section_1', name: 'Ethical Internet Tools', icon: '🌐' },
    { id: 'section_2', name: 'Learn Skills Tools', icon: '📚' },
    { id: 'section_3', name: 'Earn Online Tools', icon: '💰' },
    { id: 'section_4', name: 'Creator Dashboard', icon: '⭐' },
    { id: 'section_5', name: 'Admin Panel', icon: '🔐' },
    { id: 'button_subscribe', name: 'Subscribe Button', icon: '✅' },
  ]);

  const handlePinSubmit = (e) => {
    e.preventDefault();
    setPinError('');
    if (verifyPin(pinInput)) {
      // Success handled in verifyPin
    } else {
      setPinError('Invalid PIN. Access denied.');
      setTimeout(() => setPinError(''), 3000);
    }
  };

  return (
    <div className="space-y-6 pb-8">
      {/* PIN Lock Interface */}
      <div className="bg-gradient-to-br from-red-600/20 to-pink-600/20 rounded-2xl p-5 border border-red-500/30">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-500 to-pink-500 flex items-center justify-center">
            <Lock className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-white text-lg">Control Demo Lock</h3>
            <p className="text-xs text-gray-400">
              {unlockedByPin ? 'Admin unlocked — You can edit' : 'Locked — Enter PIN to unlock'}
            </p>
          </div>
        </div>

        <div className="bg-gray-900/40 rounded-xl p-4">
          {!unlockedByPin ? (
            <form onSubmit={handlePinSubmit} className="space-y-3">
              <div>
                <label className="block text-xs text-gray-300 mb-2">Admin PIN</label>
                <Input
                  type="password"
                  placeholder="Enter 4-digit PIN"
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value.slice(0, 4))}
                  maxLength="4"
                  className="bg-gray-800 border-gray-700 text-white text-center text-2xl tracking-widest font-bold"
                  autoFocus
                />
              </div>
              {pinError && (
                <motion.div
                  initial={{ opacity: 0, y: -5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-2 p-2 bg-red-500/20 border border-red-500/30 rounded-lg"
                >
                  <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                  <p className="text-xs text-red-400">{pinError}</p>
                </motion.div>
              )}
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-500 hover:to-pink-500 text-white font-semibold"
              >
                <Unlock className="w-4 h-4 mr-2" />
                Unlock Admin Mode
              </Button>
            </form>
          ) : (
            <div className="space-y-3">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center gap-2 p-3 bg-green-500/10 border border-green-500/30 rounded-lg"
              >
                <Check className="w-4 h-4 text-green-400 flex-shrink-0" />
                <p className="text-sm text-green-400 font-medium">Admin mode active — You can lock/unlock sections</p>
              </motion.div>
              <Button
                onClick={lockAdmin}
                variant="outline"
                className="w-full border-red-500/30 text-red-400 hover:bg-red-500/10"
              >
                <Lock className="w-4 h-4 mr-2" />
                Lock Admin Mode
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Section Controls */}
      {unlockedByPin && (
        <div className="bg-gradient-to-br from-purple-600/20 to-indigo-600/20 rounded-2xl p-5 border border-purple-500/30">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-indigo-500 flex items-center justify-center">
              <Eye className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-white text-lg">Section Controls</h3>
              <p className="text-xs text-gray-400">Lock sections to hide from normal users</p>
            </div>
          </div>

          <div className="space-y-2">
            {sections.map(section => (
              <motion.div
                key={section.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-gray-900/40 rounded-lg p-3 flex items-center justify-between border border-gray-700/50 hover:border-purple-500/30 transition-all"
              >
                <div className="flex items-center gap-3 flex-1">
                  <span className="text-xl">{section.icon}</span>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-white">{section.name}</p>
                    <p className="text-xs text-gray-500">
                      {isLocked(section.id) ? '🔒 Locked' : '🔓 Visible'}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => toggleLock(section.id)}
                  className={`flex items-center justify-center w-10 h-10 rounded-lg transition-all font-medium text-sm ${
                    isLocked(section.id)
                      ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30 border border-red-500/30'
                      : 'bg-green-500/20 text-green-400 hover:bg-green-500/30 border border-green-500/30'
                  }`}
                >
                  {isLocked(section.id) ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* User View Preview */}
      <div className="bg-gradient-to-br from-cyan-600/20 to-blue-600/20 rounded-2xl p-5 border border-cyan-500/30">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center">
            <EyeOff className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-white text-lg">User View Preview</h3>
            <p className="text-xs text-gray-400">See what normal users will see</p>
          </div>
        </div>

        <div className="bg-gray-900/40 rounded-xl p-4 space-y-2">
          <p className="text-xs text-gray-300 mb-3">Locked sections ({lockedElements.length}):</p>
          {lockedElements.length > 0 ? (
            <div className="space-y-1">
              {lockedElements.map(id => {
                const section = sections.find(s => s.id === id);
                return (
                  <div key={id} className="flex items-center gap-2 p-2 bg-red-500/10 border border-red-500/20 rounded-lg">
                    <span className="text-red-400 text-sm">🔒</span>
                    <p className="text-xs text-red-300">{section?.name || 'Unknown Section'}</p>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-xs text-gray-500 italic">No sections locked — everything is visible</p>
          )}
        </div>
      </div>

      {/* Info */}
      <div className="bg-blue-500/10 rounded-xl border border-blue-500/30 p-4 space-y-2">
        <p className="text-sm text-blue-300 font-medium">📋 How Control Demo Works</p>
        <ul className="text-xs text-blue-200 space-y-1 ml-4">
          <li>✓ Locked sections appear blurred to normal users</li>
          <li>✓ Clicking locked sections shows "Coming Soon" message</li>
          <li>✓ Admin PIN unlocks section management</li>
          <li>✓ Settings persist in localStorage</li>
          <li>✓ Perfect for upcoming features or maintenance</li>
        </ul>
      </div>
    </div>
  );
}