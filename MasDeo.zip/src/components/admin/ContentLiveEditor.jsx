import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Edit2, Save, X, Eye, Lock } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useControlDemoLock } from '@/hooks/useControlDemoLock';

/**
 * ContentLiveEditor
 * Real-time admin editor for managing app content, WIP sections, and publishing state
 */
export default function ContentLiveEditor() {
  const { lockedElements, toggleLock, unlockedByPin } = useControlDemoLock();
  const [sections, setSections] = useState([
    {
      id: 'hero',
      name: 'Hero Section',
      description: 'Main landing hero content',
      isWip: false,
      isPublished: true,
      content: 'Welcome to Masters DeoVex'
    },
    {
      id: 'features',
      name: 'Features Section',
      description: 'App features showcase',
      isWip: false,
      isPublished: true,
      content: 'Explore our features'
    },
    {
      id: 'earning',
      name: 'Earning Module',
      description: 'Earn online features',
      isWip: true,
      isPublished: false,
      content: 'In Development'
    },
    {
      id: 'trading',
      name: 'Forex Trading',
      description: 'Trading signals and tools',
      isWip: true,
      isPublished: false,
      content: 'Coming Soon'
    }
  ]);
  
  const [editingId, setEditingId] = useState(null);
  const [editData, setEditData] = useState({});
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');

  const startEdit = (section) => {
    setEditingId(section.id);
    setEditData({ ...section });
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditData({});
  };

  const saveEdit = async () => {
    setSaving(true);
    try {
      setSections(prev => prev.map(s => s.id === editingId ? editData : s));
      setMessage('✓ Content updated successfully!');
      setTimeout(() => setMessage(''), 3000);
      setEditingId(null);
      setEditData({});
    } catch (error) {
      setMessage(`✗ Error: ${error.message}`);
    } finally {
      setSaving(false);
    }
  };

  const toggleWipStatus = async (sectionId) => {
    setSections(prev =>
      prev.map(s =>
        s.id === sectionId ? { ...s, isWip: !s.isWip } : s
      )
    );
  };

  const togglePublished = async (sectionId) => {
    setSections(prev =>
      prev.map(s =>
        s.id === sectionId ? { ...s, isPublished: !s.isPublished } : s
      )
    );
  };

  if (!unlockedByPin) {
    return (
      <div className="bg-red-500/10 border border-red-500/30 rounded-2xl p-6 text-center">
        <Lock className="w-12 h-12 text-red-400 mx-auto mb-4" />
        <p className="text-white font-semibold mb-2">Admin Lock Active</p>
        <p className="text-gray-400 text-sm">Enter admin PIN to access live content editor</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600/20 to-cyan-600/20 rounded-2xl p-4 border border-blue-500/30">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
            <Edit2 className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-white">Live Content Editor</h3>
            <p className="text-xs text-gray-400">Edit app content in real-time</p>
          </div>
        </div>
      </div>

      {/* Status Message */}
      {message && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`p-3 rounded-lg text-sm font-medium ${
            message.includes('Error')
              ? 'bg-red-500/20 text-red-400 border border-red-500/30'
              : 'bg-green-500/20 text-green-400 border border-green-500/30'
          }`}
        >
          {message}
        </motion.div>
      )}

      {/* Content Sections Grid */}
      <div className="space-y-3">
        {sections.map(section => (
          <motion.div
            key={section.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`rounded-xl border p-4 transition-all ${
              editingId === section.id
                ? 'bg-gray-900/80 border-cyan-500/50'
                : 'bg-gray-900/40 border-gray-700/50 hover:border-gray-700'
            }`}
          >
            {editingId === section.id ? (
              // Edit Mode
              <div className="space-y-4">
                <div>
                  <label className="text-xs text-gray-400 font-semibold uppercase">Name</label>
                  <input
                    type="text"
                    value={editData.name}
                    onChange={(e) => setEditData({ ...editData, name: e.target.value })}
                    className="w-full mt-1 bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="text-xs text-gray-400 font-semibold uppercase">Description</label>
                  <input
                    type="text"
                    value={editData.description}
                    onChange={(e) => setEditData({ ...editData, description: e.target.value })}
                    className="w-full mt-1 bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="text-xs text-gray-400 font-semibold uppercase">Content</label>
                  <textarea
                    value={editData.content}
                    onChange={(e) => setEditData({ ...editData, content: e.target.value })}
                    rows={3}
                    className="w-full mt-1 bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 resize-none"
                  />
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={saveEdit}
                    disabled={saving}
                    className="flex-1 flex items-center justify-center gap-2 bg-green-600 hover:bg-green-500 disabled:opacity-50 text-white py-2 rounded-lg font-semibold transition-all"
                  >
                    <Save className="w-4 h-4" />
                    {saving ? 'Saving...' : 'Save'}
                  </button>
                  <button
                    onClick={cancelEdit}
                    className="flex-1 flex items-center justify-center gap-2 bg-gray-700 hover:bg-gray-600 text-white py-2 rounded-lg font-semibold transition-all"
                  >
                    <X className="w-4 h-4" />
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              // View Mode
              <div>
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-white font-semibold">{section.name}</h4>
                      <div className="flex gap-1">
                        {section.isWip && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-yellow-500/20 text-yellow-400 font-semibold">WIP</span>
                        )}
                        {!section.isPublished && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-gray-600/40 text-gray-400 font-semibold">Draft</span>
                        )}
                      </div>
                    </div>
                    <p className="text-xs text-gray-400">{section.description}</p>
                  </div>
                </div>

                <p className="text-sm text-gray-300 mb-4 bg-gray-800/50 p-2 rounded">{section.content}</p>

                <div className="grid grid-cols-2 gap-2 mb-4">
                  <button
                    onClick={() => toggleWipStatus(section.id)}
                    className={`text-xs py-2 rounded-lg font-semibold transition-all ${
                      section.isWip
                        ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30'
                        : 'bg-green-500/20 text-green-400 border border-green-500/30'
                    }`}
                  >
                    {section.isWip ? 'Mark Ready' : 'Mark WIP'}
                  </button>
                  <button
                    onClick={() => togglePublished(section.id)}
                    className={`text-xs py-2 rounded-lg font-semibold transition-all flex items-center justify-center gap-1 ${
                      section.isPublished
                        ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                        : 'bg-gray-600/40 text-gray-400 border border-gray-600/30'
                    }`}
                  >
                    <Eye className="w-3 h-3" />
                    {section.isPublished ? 'Published' : 'Hidden'}
                  </button>
                </div>

                <button
                  onClick={() => startEdit(section)}
                  className="w-full flex items-center justify-center gap-2 bg-cyan-600 hover:bg-cyan-500 text-white py-2 rounded-lg font-semibold transition-all"
                >
                  <Edit2 className="w-4 h-4" />
                  Edit Content
                </button>
              </div>
            )}
          </motion.div>
        ))}
      </div>

      {/* Info */}
      <div className="bg-blue-500/10 rounded-xl border border-blue-500/30 p-3 text-xs text-blue-200 space-y-1">
        <p className="font-semibold">💡 Live Editor Tips:</p>
        <ul className="ml-4 space-y-0.5">
          <li>• Mark sections as WIP to blur them for public users</li>
          <li>• Toggle published status to control visibility</li>
          <li>• Changes apply immediately to the live app</li>
          <li>• Use this as your command center for content management</li>
        </ul>
      </div>
    </div>
  );
}