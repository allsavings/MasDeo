import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { Bell, Send, CheckCircle, AlertTriangle, Loader, Eye, Trash2, Users, User, ImagePlus, Link, Shield } from 'lucide-react';
import { Input } from '@/components/ui/input';

const TYPE_OPTIONS = [
  { val: 'info',    label: 'Info',    color: 'text-blue-400',   bg: 'bg-blue-500/10 border-blue-500/30' },
  { val: 'success', label: 'Success', color: 'text-green-400',  bg: 'bg-green-500/10 border-green-500/30' },
  { val: 'warning', label: 'Warning', color: 'text-amber-400',  bg: 'bg-amber-500/10 border-amber-500/30' },
  { val: 'error',   label: 'Error',   color: 'text-red-400',    bg: 'bg-red-500/10 border-red-500/30' },
];

const BROADCAST_PRESETS = [
  { title: '🔔 New Content Available', body: 'New VPN configs and resources have been added. Check them out now!' },
  { title: '⚠️ Maintenance Notice', body: 'We will be performing maintenance shortly. Please save your work.' },
  { title: '🎉 New Feature Released', body: 'A new feature has been added to the app. Explore it now!' },
  { title: '💰 Credits Bonus', body: 'You have received bonus credits! Check your wallet.' },
];

const PERSONAL_PRESETS = [
  { title: '✅ Subscription Approved', body: 'Your subscription has been approved! You now have full access.' },
  { title: '❌ Subscription Rejected', body: 'Your subscription was rejected. Please contact support.' },
  { title: '📦 Package Ready', body: 'Your VPN package is ready! Check your dashboard.' },
  { title: '⏳ Expiring Soon', body: 'Your subscription expires in 3 days. Renew now to stay connected.' },
];

const PAID_PRESETS = [
  { title: '🔑 New Config Available', body: 'A new VLESS/V2Ray config has been deployed for your node. Check your dashboard.' },
  { title: '⚠️ Node Maintenance', body: 'Your paid node will undergo brief maintenance. Connectivity may be temporarily affected.' },
  { title: '🔄 Node Renewed', body: 'Your node has been successfully renewed! Enjoy uninterrupted access.' },
  { title: '📡 Server Update', body: 'Server upgrades completed. Reconnect to experience improved speeds.' },
];

function ComposeSection({ title: sectionTitle, icon: Icon, iconColor, description, presets, userEmail, setUserEmail, showUserField, allUsers, onSent }) {
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [type, setType] = useState('info');
  const [imageMode, setImageMode] = useState('url'); // 'url' | 'upload'
  const [imageUrl, setImageUrl] = useState('');
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState('');
  const [uploadingImage, setUploadingImage] = useState(false);
  const [sending, setSending] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const fileInputRef = useRef(null);

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
  };

  const send = async () => {
    if (!title.trim() || !message.trim()) { setError('Please fill in both title and message.'); return; }
    if (showUserField && !userEmail?.trim()) { setError('Please enter a user email.'); return; }
    setError(''); setResult(null); setSending(true);
    try {
      let finalImageUrl = '';

      // Handle raw image upload
      if (imageMode === 'upload' && imageFile) {
        setUploadingImage(true);
        const { file_url } = await base44.integrations.Core.UploadFile({ file: imageFile });
        finalImageUrl = file_url;
        setUploadingImage(false);
      } else if (imageMode === 'url' && imageUrl.trim()) {
        finalImageUrl = imageUrl.trim();
      }

      const payload = {
        title: title.trim(),
        message: message.trim(),
        body: message.trim(),
        type,
        user_email: showUserField ? userEmail.trim() : '',
      };
      if (finalImageUrl) payload.file_url = finalImageUrl;

      await base44.entities.AppNotification.create(payload);
      setResult(true);
      setTitle(''); setMessage(''); setType('info'); setImageUrl('');
      setImageFile(null); setImagePreview('');
      if (onSent) onSent();
    } catch (e) {
      setError('Failed to send: ' + e.message);
      setUploadingImage(false);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 overflow-hidden">
      <div className="px-4 py-3 border-b border-gray-700/50 flex items-center gap-2">
        <Icon className={`w-4 h-4 ${iconColor}`} />
        <span className="font-semibold text-white text-sm">{sectionTitle}</span>
      </div>
      <div className="p-4 space-y-3">
        <p className="text-xs text-gray-500 leading-relaxed">{description}</p>

        {/* User email field for personal */}
        {showUserField && (
          <div>
            <label className="text-xs text-gray-400 mb-1.5 block">Target User Email</label>
            <input
              value={userEmail}
              onChange={e => setUserEmail(e.target.value)}
              placeholder="user@email.com"
              list="user-email-list"
              className="w-full bg-gray-900/60 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
            <datalist id="user-email-list">
              {(allUsers || []).map(u => <option key={u.email} value={u.email} />)}
            </datalist>
          </div>
        )}

        {/* Type selector */}
        <div>
          <label className="text-xs text-gray-400 mb-1.5 block">Type</label>
          <div className="flex gap-1.5 flex-wrap">
            {TYPE_OPTIONS.map(t => (
              <button key={t.val} onClick={() => setType(t.val)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold border transition-all ${type === t.val ? t.bg + ' ' + t.color : 'border-gray-700/40 bg-gray-800/50 text-gray-500'}`}>
                {t.label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="text-xs text-gray-400 mb-1.5 block">Title</label>
          <Input value={title} onChange={e => setTitle(e.target.value)} placeholder="Notification title..." maxLength={80}
            className="bg-gray-900/60 border-gray-700 text-white text-sm" />
          <p className="text-[10px] text-gray-600 mt-1 text-right">{title.length}/80</p>
        </div>
        <div>
          <label className="text-xs text-gray-400 mb-1.5 block">Message</label>
          <textarea value={message} onChange={e => setMessage(e.target.value)} rows={3} maxLength={300}
            placeholder="Message body..."
            className="w-full bg-gray-900/60 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm resize-none focus:outline-none focus:ring-1 focus:ring-blue-500" />
          <p className="text-[10px] text-gray-600 mt-1 text-right">{message.length}/300</p>
        </div>

        {/* Image Section */}
        <div>
          <label className="text-xs text-gray-400 mb-1.5 block">Notification Image (Optional)</label>
          {/* Toggle */}
          <div className="flex gap-1.5 mb-2">
            <button onClick={() => setImageMode('url')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${imageMode === 'url' ? 'bg-blue-500/20 border-blue-500/50 text-blue-300' : 'bg-gray-800/50 border-gray-700/40 text-gray-500'}`}>
              <Link className="w-3 h-3" /> URL Link
            </button>
            <button onClick={() => setImageMode('upload')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${imageMode === 'upload' ? 'bg-violet-500/20 border-violet-500/50 text-violet-300' : 'bg-gray-800/50 border-gray-700/40 text-gray-500'}`}>
              <ImagePlus className="w-3 h-3" /> Upload Raw
            </button>
          </div>
          {imageMode === 'url' ? (
            <Input value={imageUrl} onChange={e => setImageUrl(e.target.value)} placeholder="https://example.com/image.png"
              className="bg-gray-900/60 border-gray-700 text-white text-sm" />
          ) : (
            <div>
              <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
              <button onClick={() => fileInputRef.current?.click()}
                className="w-full flex items-center justify-center gap-2 bg-gray-900/60 border border-dashed border-gray-600 rounded-lg px-3 py-3 text-gray-400 text-xs hover:border-violet-500/50 hover:text-violet-300 transition-all">
                <ImagePlus className="w-4 h-4" />
                {imageFile ? imageFile.name : 'Click to pick an image'}
              </button>
              {imagePreview && (
                <img src={imagePreview} alt="preview" className="mt-2 rounded-lg w-full max-h-32 object-cover border border-gray-700" />
              )}
            </div>
          )}
          <p className="text-[10px] text-gray-600 mt-1">Leave blank to send with icon only (no large image)</p>
        </div>

        {/* Presets */}
        <div>
          <p className="text-xs text-gray-500 mb-1.5">Quick Presets</p>
          <div className="flex flex-wrap gap-1.5">
            {presets.map((p, i) => (
              <button key={i} onClick={() => { setTitle(p.title); setMessage(p.body); setResult(null); setError(''); }}
                className="px-2.5 py-1.5 bg-gray-900/50 hover:bg-gray-700/60 border border-gray-700/50 rounded-lg text-[11px] text-gray-300 transition-all text-left">
                {p.title}
              </button>
            ))}
          </div>
        </div>

        {error && (
          <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">
            <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
            <p className="text-xs text-red-400">{error}</p>
          </div>
        )}
        {result && (
          <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-2 bg-green-500/10 border border-green-500/20 rounded-xl px-3 py-2">
            <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
            <p className="text-xs text-green-400">Notification sent successfully!</p>
          </motion.div>
        )}

        <button onClick={send} disabled={sending || !title.trim() || !message.trim()}
          className={`w-full flex items-center justify-center gap-2 disabled:opacity-40 text-white font-semibold text-sm py-3 rounded-xl transition-all ${showUserField ? 'bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500' : 'bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500'}`}>
          {sending ? <Loader className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          {sending ? 'Sending...' : (showUserField ? 'Send to User' : 'Broadcast to All Users')}
        </button>
      </div>
    </div>
  );
}

export default function NotifyTab({ allUsers }) {
  const [sentAll, setSentAll] = useState([]);
  const [personalEmail, setPersonalEmail] = useState('');
  const [paidNodeUsers, setPaidNodeUsers] = useState([]);
  const [sendingPaid, setSendingPaid] = useState(false);
  const [paidTitle, setPaidTitle] = useState('');
  const [paidMessage, setPaidMessage] = useState('');
  const [paidType, setPaidType] = useState('info');
  const [paidResult, setPaidResult] = useState(null);
  const [paidError, setPaidError] = useState('');

  const loadSent = async () => {
    const all = await base44.entities.AppNotification.list('-created_date', 60);
    setSentAll(all);
  };

  useEffect(() => {
    loadSent();
    // Load approved paid version users
    base44.entities.ISPNode.filter({ status: 'active' }, '-created_date', 200).then(nodes => {
      const emails = [...new Set(nodes.map(n => n.user_email).filter(Boolean))];
      setPaidNodeUsers(emails);
    }).catch(() => {});
  }, []);

  const deleteNotification = async (id) => {
    await base44.entities.AppNotification.delete(id);
    loadSent();
  };

  const sendToPaidUsers = async () => {
    if (!paidTitle.trim() || !paidMessage.trim()) { setPaidError('Please fill in both title and message.'); return; }
    if (paidNodeUsers.length === 0) { setPaidError('No active paid users found.'); return; }
    setPaidError(''); setPaidResult(null); setSendingPaid(true);
    try {
      await Promise.all(paidNodeUsers.map(email =>
        base44.entities.AppNotification.create({
          title: paidTitle.trim(),
          message: paidMessage.trim(),
          body: paidMessage.trim(),
          type: paidType,
          user_email: email,
        })
      ));
      setPaidResult(paidNodeUsers.length);
      setPaidTitle(''); setPaidMessage(''); setPaidType('info');
      loadSent();
    } catch (e) {
      setPaidError('Failed: ' + e.message);
    } finally {
      setSendingPaid(false);
    }
  };

  const broadcasts = sentAll.filter(n => !n.user_email || n.user_email === '');
  const personal   = sentAll.filter(n => n.user_email && n.user_email !== '');

  return (
    <div className="px-4 space-y-5 py-2">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-2">
        <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-3 text-center">
          <p className="text-xl font-bold text-blue-400">{allUsers.length}</p>
          <p className="text-[10px] text-gray-500">Total Users</p>
        </div>
        <div className="bg-violet-500/10 border border-violet-500/20 rounded-xl p-3 text-center">
          <p className="text-xl font-bold text-violet-400">{personal.length}</p>
          <p className="text-[10px] text-gray-500">Personal Sent</p>
        </div>
        <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-3 text-center">
          <p className="text-xl font-bold text-emerald-400">{paidNodeUsers.length}</p>
          <p className="text-[10px] text-gray-500">Paid Users</p>
        </div>
      </div>

      {/* ── Broadcast Section ── */}
      <ComposeSection
        sectionTitle="📢 Broadcast to All Users"
        icon={Users}
        iconColor="text-blue-400"
        description="Sends a notification to every DeoVex app user. Perfect for announcements, maintenance alerts, and new features."
        presets={BROADCAST_PRESETS}
        showUserField={false}
        allUsers={allUsers}
        onSent={loadSent}
      />

      {/* ── Paid Version Users Section ── */}
      <div className="bg-gray-800/40 rounded-2xl border border-emerald-700/40 overflow-hidden">
        <div className="px-4 py-3 border-b border-emerald-700/30 flex items-center gap-2">
          <Shield className="w-4 h-4 text-emerald-400" />
          <span className="font-semibold text-white text-sm">🛡️ Paid Version Users Only</span>
          <span className="ml-auto text-xs text-emerald-400 font-bold bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">{paidNodeUsers.length} active</span>
        </div>
        <div className="p-4 space-y-3">
          <p className="text-xs text-gray-500 leading-relaxed">Sends to all users with an <span className="text-emerald-400 font-semibold">active</span> ISP Node subscription only.</p>

          <div>
            <label className="text-xs text-gray-400 mb-1.5 block">Type</label>
            <div className="flex gap-1.5 flex-wrap">
              {TYPE_OPTIONS.map(t => (
                <button key={t.val} onClick={() => setPaidType(t.val)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold border transition-all ${paidType === t.val ? t.bg + ' ' + t.color : 'border-gray-700/40 bg-gray-800/50 text-gray-500'}`}>
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs text-gray-400 mb-1.5 block">Title</label>
            <Input value={paidTitle} onChange={e => setPaidTitle(e.target.value)} placeholder="Notification title..." maxLength={80}
              className="bg-gray-900/60 border-gray-700 text-white text-sm" />
          </div>
          <div>
            <label className="text-xs text-gray-400 mb-1.5 block">Message</label>
            <textarea value={paidMessage} onChange={e => setPaidMessage(e.target.value)} rows={3} maxLength={300}
              placeholder="Message body..."
              className="w-full bg-gray-900/60 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm resize-none focus:outline-none focus:ring-1 focus:ring-emerald-500" />
          </div>

          {/* Presets */}
          <div>
            <p className="text-xs text-gray-500 mb-1.5">Quick Presets</p>
            <div className="flex flex-wrap gap-1.5">
              {PAID_PRESETS.map((p, i) => (
                <button key={i} onClick={() => { setPaidTitle(p.title); setPaidMessage(p.body); setPaidResult(null); setPaidError(''); }}
                  className="px-2.5 py-1.5 bg-gray-900/50 hover:bg-gray-700/60 border border-gray-700/50 rounded-lg text-[11px] text-gray-300 transition-all text-left">
                  {p.title}
                </button>
              ))}
            </div>
          </div>

          {paidError && (
            <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">
              <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
              <p className="text-xs text-red-400">{paidError}</p>
            </div>
          )}
          {paidResult && (
            <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 rounded-xl px-3 py-2">
              <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <p className="text-xs text-emerald-400">Sent to {paidResult} paid users!</p>
            </motion.div>
          )}

          <button onClick={sendToPaidUsers} disabled={sendingPaid || !paidTitle.trim() || !paidMessage.trim() || paidNodeUsers.length === 0}
            className="w-full flex items-center justify-center gap-2 disabled:opacity-40 text-white font-semibold text-sm py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 transition-all">
            {sendingPaid ? <Loader className="w-4 h-4 animate-spin" /> : <Shield className="w-4 h-4" />}
            {sendingPaid ? 'Sending...' : `Send to ${paidNodeUsers.length} Paid Users`}
          </button>
        </div>
      </div>

      {/* ── Personal Section ── */}
      <ComposeSection
        sectionTitle="🎯 Send to Specific User"
        icon={User}
        iconColor="text-violet-400"
        description="Targets one specific user by email. Used for subscription approvals, rejections, and personal updates."
        presets={PERSONAL_PRESETS}
        showUserField={true}
        userEmail={personalEmail}
        setUserEmail={setPersonalEmail}
        allUsers={allUsers}
        onSent={loadSent}
      />

      {/* ── History: Broadcasts ── */}
      {broadcasts.length > 0 && (
        <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-700/50 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="w-3.5 h-3.5 text-blue-400" />
              <span className="font-semibold text-white text-sm">Broadcast History</span>
            </div>
            <span className="text-xs text-gray-500">{broadcasts.length}</span>
          </div>
          <div className="divide-y divide-gray-700/40">
            {broadcasts.map(n => (
              <div key={n.id} className="px-4 py-3 flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-white truncate">{n.title}</p>
                  <p className="text-[11px] text-gray-500 mt-0.5 line-clamp-1">{n.message || n.body}</p>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="flex items-center gap-1 text-[10px] text-cyan-400"><Eye className="w-3 h-3" /> {n.read_count || 0} seen</span>
                    <span className="text-[10px] text-gray-600">{new Date(n.created_date).toLocaleDateString()}</span>
                  </div>
                </div>
                <button onClick={() => deleteNotification(n.id)} className="text-gray-600 hover:text-red-400 transition-colors flex-shrink-0 mt-0.5">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── History: Personal ── */}
      {personal.length > 0 && (
        <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-700/50 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <User className="w-3.5 h-3.5 text-violet-400" />
              <span className="font-semibold text-white text-sm">Personal History</span>
            </div>
            <span className="text-xs text-gray-500">{personal.length}</span>
          </div>
          <div className="divide-y divide-gray-700/40">
            {personal.map(n => (
              <div key={n.id} className="px-4 py-3 flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] text-violet-400 font-mono mb-0.5">{n.user_email}</p>
                  <p className="text-xs font-semibold text-white truncate">{n.title}</p>
                  <p className="text-[11px] text-gray-500 mt-0.5 line-clamp-1">{n.message || n.body}</p>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="flex items-center gap-1 text-[10px] text-cyan-400"><Eye className="w-3 h-3" /> {n.read_count || 0} seen</span>
                    <span className="text-[10px] text-gray-600">{new Date(n.created_date).toLocaleDateString()}</span>
                  </div>
                </div>
                <button onClick={() => deleteNotification(n.id)} className="text-gray-600 hover:text-red-400 transition-colors flex-shrink-0 mt-0.5">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}