import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { ShieldCheck, ShieldX, AlertTriangle, Star, Search, RefreshCw } from 'lucide-react';
import { Input } from '@/components/ui/input';

export default function CreatorMgmtTab() {
  const [creators, setCreators] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    load();
    const unsub = base44.entities.CreatorProfile.subscribe((event) => {
      if (event.type === 'create') {
        setCreators(prev => [event.data, ...prev]);
      } else if (event.type === 'update') {
        setCreators(prev => prev.map(c => c.id === event.id ? event.data : c));
      } else if (event.type === 'delete') {
        setCreators(prev => prev.filter(c => c.id !== event.id));
      }
    });
    return unsub;
  }, []);

  const load = async () => {
    setLoading(true);
    const data = await base44.entities.CreatorProfile.list('-created_date', 100);
    setCreators(data);
    setLoading(false);
  };

  const update = async (id, data) => {
    await base44.entities.CreatorProfile.update(id, data);
    // No manual reload needed — subscription handles it
  };

  const addStrike = async (creator) => {
    const newStrikes = (creator.strikes || 0) + 1;
    await base44.entities.CreatorProfile.update(creator.id, {
      strikes: newStrikes,
      banned: newStrikes >= 3,
    });
    // No manual reload needed — subscription handles it
  };

  const filtered = creators.filter(c =>
    search === '' || c.user_email?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="px-4 space-y-3 py-2">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by email..."
          className="bg-gray-800/40 border-gray-700 text-white text-sm pl-9" />
      </div>

      <div className="grid grid-cols-3 gap-2">
        {[
          { label: 'Total', value: creators.length, color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/20' },
          { label: 'Verified', value: creators.filter(c => c.verified).length, color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/20' },
          { label: 'Banned', value: creators.filter(c => c.banned).length, color: 'text-red-400', bg: 'bg-red-500/10', border: 'border-red-500/20' },
        ].map(s => (
          <div key={s.label} className={`${s.bg} border ${s.border} rounded-xl p-2.5 text-center`}>
            <p className={`text-lg font-bold ${s.color}`}>{s.value}</p>
            <p className="text-[10px] text-gray-500">{s.label}</p>
          </div>
        ))}
      </div>

      {loading && <p className="text-center text-gray-600 text-sm py-8">Loading...</p>}

      <div className="space-y-2">
        {filtered.map((c, i) => (
          <motion.div key={c.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}
            className={`bg-gray-800/40 rounded-2xl border overflow-hidden ${c.banned ? 'border-red-500/30' : 'border-gray-700/50'}`}>
            <div className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="text-sm font-semibold text-white">{c.user_email}</p>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <span className="text-[10px] bg-gray-700/50 text-gray-400 px-1.5 py-0.5 rounded capitalize">{c.creator_type?.replace(/_/g, ' ')}</span>
                    {c.verified && <span className="text-[10px] bg-blue-500/20 text-blue-400 px-1.5 py-0.5 rounded">✓ Verified</span>}
                    {c.banned && <span className="text-[10px] bg-red-500/20 text-red-400 px-1.5 py-0.5 rounded">Banned</span>}
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1 justify-end">
                    <Star className="w-3 h-3 text-amber-400" />
                    <span className="text-xs text-amber-400 font-semibold">{c.average_rating?.toFixed(1) || '0.0'}</span>
                  </div>
                  <p className="text-[10px] text-gray-600">{c.total_ratings || 0} ratings</p>
                </div>
              </div>

              {/* Trust score bar */}
              <div className="mb-3">
                <div className="flex justify-between mb-1">
                  <span className="text-[10px] text-gray-500">Trust Score</span>
                  <span className="text-[10px] text-gray-400">{c.trust_score || 0}/100</span>
                </div>
                <div className="h-1.5 bg-gray-700 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-green-500 to-cyan-500 rounded-full transition-all"
                    style={{ width: `${c.trust_score || 0}%` }} />
                </div>
              </div>

              {/* Strikes */}
              <div className="flex items-center gap-2 mb-3">
                <span className="text-xs text-gray-400">Strikes:</span>
                {[1, 2, 3].map(n => (
                  <div key={n} className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                    (c.strikes || 0) >= n ? 'bg-red-500/30 text-red-400 border border-red-500/40' : 'bg-gray-700/50 text-gray-600 border border-gray-700'
                  }`}>{n}</div>
                ))}
              </div>

              <div className="flex gap-2 flex-wrap">
                {!c.verified && (
                  <button onClick={() => update(c.id, { verified: true })}
                    className="flex items-center gap-1 text-xs bg-blue-500/20 text-blue-400 border border-blue-500/30 px-2.5 py-1.5 rounded-xl hover:bg-blue-500/30 transition-colors">
                    <ShieldCheck className="w-3 h-3" /> Verify
                  </button>
                )}
                <button onClick={() => addStrike(c)}
                  className="flex items-center gap-1 text-xs bg-orange-500/20 text-orange-400 border border-orange-500/30 px-2.5 py-1.5 rounded-xl hover:bg-orange-500/30 transition-colors">
                  <AlertTriangle className="w-3 h-3" /> Strike
                </button>
                {c.strikes > 0 && (
                  <button onClick={() => update(c.id, { strikes: 0, banned: false })}
                    className="flex items-center gap-1 text-xs bg-gray-700/50 text-gray-400 border border-gray-700/50 px-2.5 py-1.5 rounded-xl hover:bg-gray-700 transition-colors">
                    <RefreshCw className="w-3 h-3" /> Reset
                  </button>
                )}
                {c.banned && (
                  <button onClick={() => update(c.id, { banned: false, strikes: 0 })}
                    className="flex items-center gap-1 text-xs bg-green-500/20 text-green-400 border border-green-500/30 px-2.5 py-1.5 rounded-xl hover:bg-green-500/30 transition-colors">
                    <ShieldCheck className="w-3 h-3" /> Unban
                  </button>
                )}
                <div className="flex items-center gap-1 ml-auto">
                  <span className="text-[10px] text-gray-500">Trust:</span>
                  <input type="number" min="0" max="100" defaultValue={c.trust_score || 0}
                    onBlur={e => update(c.id, { trust_score: Number(e.target.value) })}
                    className="w-14 bg-gray-900/60 border border-gray-700 rounded-lg px-2 py-1 text-xs text-white text-center" />
                </div>
              </div>
            </div>
          </motion.div>
        ))}
        {!loading && filtered.length === 0 && (
          <p className="text-center text-gray-600 text-sm py-10">No creators found.</p>
        )}
      </div>
    </div>
  );
}