import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { MessageSquare, ChevronDown, ChevronUp, CheckCircle, Clock, Send } from 'lucide-react';

const STATUS_COLORS = {
  open: 'text-amber-400 bg-amber-500/20 border-amber-500/30',
  in_progress: 'text-blue-400 bg-blue-500/20 border-blue-500/30',
  resolved: 'text-green-400 bg-green-500/20 border-green-500/30',
};

export default function SupportTab() {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(null);
  const [replies, setReplies] = useState({});
  const [filter, setFilter] = useState('open');

  useEffect(() => { load(); }, []);

  const load = async () => {
    setLoading(true);
    const data = await base44.entities.SupportTicket.list('-created_date', 100);
    setTickets(data);
    setLoading(false);
  };

  const update = async (id, data) => {
    await base44.entities.SupportTicket.update(id, data);
    load();
  };

  const sendReply = async (ticket) => {
    const reply = replies[ticket.id]?.trim();
    if (!reply) return;
    const me = await base44.auth.me();
    await update(ticket.id, {
      admin_reply: reply,
      replied_by: me?.email,
      replied_at: new Date().toISOString(),
      status: 'resolved',
    });
    setReplies(p => ({ ...p, [ticket.id]: '' }));
    // Also send an in-app notification to the user
    await base44.entities.AppNotification.create({
      title: '✉️ Support Reply',
      body: `Admin replied to your ticket "${ticket.subject}": ${reply}`,
      sent_by: 'admin',
      is_active: true,
    });
  };

  const filtered = tickets.filter(t => filter === 'all' || t.status === filter);

  const open = tickets.filter(t => t.status === 'open').length;
  const inProgress = tickets.filter(t => t.status === 'in_progress').length;
  const resolved = tickets.filter(t => t.status === 'resolved').length;

  return (
    <div className="px-4 space-y-3 py-2">
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: 'Open', value: open, color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20' },
          { label: 'In Progress', value: inProgress, color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/20' },
          { label: 'Resolved', value: resolved, color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/20' },
        ].map(s => (
          <div key={s.label} className={`${s.bg} border ${s.border} rounded-xl p-2.5 text-center`}>
            <p className={`text-lg font-bold ${s.color}`}>{s.value}</p>
            <p className="text-[10px] text-gray-500">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="flex gap-1.5">
        {['open', 'in_progress', 'resolved', 'all'].map(f => (
          <button key={f} onClick={() => setFilter(f)}
            className={`flex-1 py-1.5 rounded-xl text-[11px] font-semibold transition-all border ${
              filter === f ? 'bg-gray-700/80 border-gray-500/50 text-white' : 'bg-gray-800/40 border-gray-700/50 text-gray-500'
            }`}>
            {f === 'in_progress' ? 'Active' : f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      {loading && <p className="text-center text-gray-600 text-sm py-8">Loading...</p>}

      {!loading && filtered.length === 0 && (
        <div className="text-center py-12">
          <MessageSquare className="w-10 h-10 text-gray-700 mx-auto mb-3" />
          <p className="text-gray-600 text-sm">No tickets here.</p>
        </div>
      )}

      <div className="space-y-2">
        {filtered.map((ticket, i) => {
          const isOpen = expanded === ticket.id;
          return (
            <motion.div key={ticket.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}
              className="bg-gray-800/40 rounded-2xl border border-gray-700/50 overflow-hidden">
              <div className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-white">{ticket.subject}</p>
                    <p className="text-xs text-gray-500 mt-0.5">{ticket.user_name || ticket.user_email}</p>
                    <div className="flex items-center gap-2 mt-1.5">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full border ${STATUS_COLORS[ticket.status]}`}>{ticket.status}</span>
                      <span className="text-[10px] text-gray-600">{new Date(ticket.created_date).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <button onClick={() => setExpanded(isOpen ? null : ticket.id)} className="p-1.5 rounded-lg bg-gray-700/50 flex-shrink-0">
                    {isOpen ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
                  </button>
                </div>

                <AnimatePresence>
                  {isOpen && (
                    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="mt-3 space-y-3">
                      <div className="bg-gray-900/50 rounded-xl p-3 text-xs text-gray-300 leading-relaxed">
                        {ticket.message}
                      </div>

                      {ticket.admin_reply && (
                        <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-3">
                          <p className="text-[10px] text-blue-400 mb-1">Your reply ({ticket.replied_at ? new Date(ticket.replied_at).toLocaleDateString() : ''}):</p>
                          <p className="text-xs text-gray-300">{ticket.admin_reply}</p>
                        </div>
                      )}

                      {ticket.status !== 'resolved' && (
                        <>
                          {ticket.status === 'open' && (
                            <button onClick={() => update(ticket.id, { status: 'in_progress' })}
                              className="flex items-center gap-1 text-xs bg-blue-500/20 text-blue-400 border border-blue-500/30 px-3 py-1.5 rounded-xl hover:bg-blue-500/30 transition-colors">
                              <Clock className="w-3 h-3" /> Mark In Progress
                            </button>
                          )}
                          <div className="flex gap-2">
                            <textarea
                              value={replies[ticket.id] || ''}
                              onChange={e => setReplies(p => ({ ...p, [ticket.id]: e.target.value }))}
                              placeholder="Type your reply..."
                              rows={2}
                              className="flex-1 bg-gray-900/60 border border-gray-700 rounded-xl px-3 py-2 text-white text-xs resize-none focus:outline-none focus:ring-1 focus:ring-blue-500"
                            />
                            <button onClick={() => sendReply(ticket)} disabled={!replies[ticket.id]?.trim()}
                              className="flex items-center gap-1 bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white text-xs px-3 rounded-xl transition-colors">
                              <Send className="w-3 h-3" />
                            </button>
                          </div>
                        </>
                      )}

                      {ticket.status === 'resolved' && !ticket.admin_reply && (
                        <button onClick={() => update(ticket.id, { status: 'open' })}
                          className="text-xs text-gray-500 hover:text-gray-300 transition-colors">Reopen ticket</button>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}