import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Server, Wifi, WifiOff, Loader, CheckCircle, XCircle,
  RefreshCw, Shield, Database, Zap, Power, ChevronDown, ChevronUp,
  AlertTriangle, Clock, Globe
} from 'lucide-react';

// ── Static VPS node definitions ──────────────────────────────────────────────
const VPS_NODES = [
  {
    id: 'scanner',
    label: 'Scanner VPS',
    host: null, // loaded from localStorage
    hostKey: 'vps_host',
    defaultHost: 'fx.tkmaster.qzz.io',
    tokenKey: 'vps_token',
    defaultToken: '123000',
    color: 'from-purple-500 to-pink-500',
    borderColor: 'border-purple-500/30',
    bgColor: 'bg-purple-500/10',
    textColor: 'text-purple-300',
    purpose: 'CDN & WAF Scanner engine',
    plugins: [
      { id: 'cdnwaf', label: 'CDNWAF_Scanner [M@☆]', protocol: 'POST /run/M@☆', default_active: true },
      { id: 'sni', label: 'SNI Bug Finder', protocol: 'POST /run/SNI', default_active: true },
      { id: 'zero_rated', label: 'Zero-Rated Scan', protocol: 'POST /run/ZR', default_active: true },
      { id: 'host_scan', label: 'Host Scanner', protocol: 'GET /scan', default_active: false },
    ],
  },
  {
    id: 'media',
    label: 'Media VPS',
    host: null, // derived from VPS_UPLOAD_URL env
    hostKey: null,
    defaultHost: 'media.mastersdeovex.co.za',
    tokenKey: null,
    color: 'from-cyan-500 to-blue-500',
    borderColor: 'border-cyan-500/30',
    bgColor: 'bg-cyan-500/10',
    textColor: 'text-cyan-300',
    purpose: 'File hosting & CDN backup storage',
    plugins: [
      { id: 'upload', label: 'File Upload Endpoint', protocol: 'POST /upload', default_active: true },
      { id: 'list', label: 'File List Endpoint', protocol: 'GET /list', default_active: true },
      { id: 'delete', label: 'File Delete Endpoint', protocol: 'POST /delete', default_active: true },
      { id: 'snapshot_store', label: 'Snapshot Storage', protocol: 'POST /upload (JSON)', default_active: true },
    ],
  },
];

// ── Status Badge ─────────────────────────────────────────────────────────────
function StatusBadge({ status }) {
  if (status === 'checking') return (
    <span className="flex items-center gap-1 text-[10px] text-amber-300 bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded-full">
      <Loader className="w-2.5 h-2.5 animate-spin" /> Checking...
    </span>
  );
  if (status === 'online') return (
    <span className="flex items-center gap-1 text-[10px] text-green-300 bg-green-500/15 border border-green-500/30 px-2 py-0.5 rounded-full">
      <CheckCircle className="w-2.5 h-2.5" /> Online
    </span>
  );
  if (status === 'offline') return (
    <span className="flex items-center gap-1 text-[10px] text-red-300 bg-red-500/15 border border-red-500/30 px-2 py-0.5 rounded-full">
      <XCircle className="w-2.5 h-2.5" /> Offline
    </span>
  );
  return (
    <span className="flex items-center gap-1 text-[10px] text-gray-400 bg-gray-700/40 border border-gray-700/40 px-2 py-0.5 rounded-full">
      <Clock className="w-2.5 h-2.5" /> Idle
    </span>
  );
}

// ── Plugin Slot ───────────────────────────────────────────────────────────────
function PluginSlot({ plugin, isActive, onToggle, nodeColor, nodeTextColor }) {
  return (
    <div className={`flex items-center justify-between bg-gray-900/60 border rounded-xl px-3 py-2.5 transition-all ${isActive ? 'border-gray-600/50' : 'border-gray-800/50 opacity-60'}`}>
      <div className="flex-1 min-w-0">
        <p className={`text-xs font-semibold ${isActive ? 'text-white' : 'text-gray-500'}`}>{plugin.label}</p>
        <p className="text-[10px] text-gray-600 font-mono truncate">{plugin.protocol}</p>
      </div>
      <button
        onClick={() => onToggle(plugin.id)}
        className={`relative w-9 h-5 rounded-full transition-all flex-shrink-0 ml-3 ${isActive ? `bg-gradient-to-r ${nodeColor}` : 'bg-gray-700'}`}
      >
        <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all ${isActive ? 'left-4' : 'left-0.5'}`} />
      </button>
    </div>
  );
}

// ── VPS Node Card ─────────────────────────────────────────────────────────────
function VpsNodeCard({ node, pluginStates, onTogglePlugin }) {
  const [status, setStatus] = useState('idle');
  const [checkResult, setCheckResult] = useState(null);
  const [expanded, setExpanded] = useState(true);
  const [checking, setChecking] = useState(false);

  const vpsHost = node.hostKey
    ? (localStorage.getItem(node.hostKey) || node.defaultHost)
    : node.defaultHost;
  const vpsToken = node.tokenKey
    ? (localStorage.getItem(node.tokenKey) || node.defaultToken)
    : null;

  const runHealthCheck = async () => {
    setChecking(true);
    setStatus('checking');
    setCheckResult(null);
    try {
      const payload = node.id === 'scanner'
        ? { action: 'ping_scanner', vps_host: vpsHost, vps_token: vpsToken }
        : { action: 'ping_media' };

      const res = await base44.functions.invoke('vpsHealthCheck', payload);
      const data = res.data;
      setStatus(data.overall ? 'online' : 'offline');
      setCheckResult(data);
    } catch (err) {
      setStatus('offline');
      setCheckResult({ error: err?.response?.data?.error || err.message });
    } finally {
      setChecking(false);
    }
  };

  const activePlugins = (pluginStates[node.id] || {});
  const activeCount = node.plugins.filter(p => activePlugins[p.id] !== false).length;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`bg-gray-800/40 rounded-2xl border ${node.borderColor} overflow-hidden`}
    >
      {/* Color bar */}
      <div className={`h-1 bg-gradient-to-r ${node.color}`} />

      <div className="p-4">
        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${node.color} flex items-center justify-center flex-shrink-0`}>
              <Server className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-bold text-white text-sm">{node.label}</h3>
                <StatusBadge status={status} />
              </div>
              <p className="text-[11px] text-gray-500 font-mono">{vpsHost}</p>
              <p className="text-[10px] text-gray-600">{node.purpose}</p>
            </div>
          </div>
          <button onClick={() => setExpanded(!expanded)} className="text-gray-600 hover:text-white transition-colors ml-2">
            {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>

        {/* Stats row */}
        <div className="flex items-center gap-2 mb-3">
          <div className={`flex items-center gap-1 text-[10px] ${node.textColor} ${node.bgColor} border ${node.borderColor} px-2 py-0.5 rounded-full`}>
            <Zap className="w-2.5 h-2.5" />
            {activeCount}/{node.plugins.length} plugins active
          </div>
          {checkResult?.ping?.latency_ms && (
            <div className="flex items-center gap-1 text-[10px] text-gray-400 bg-gray-700/40 border border-gray-700/40 px-2 py-0.5 rounded-full">
              <Clock className="w-2.5 h-2.5" />
              {checkResult.ping.latency_ms}ms
            </div>
          )}
          {checkResult?.upload?.latency_ms && (
            <div className="flex items-center gap-1 text-[10px] text-gray-400 bg-gray-700/40 border border-gray-700/40 px-2 py-0.5 rounded-full">
              <Clock className="w-2.5 h-2.5" />
              {checkResult.upload.latency_ms}ms upload
            </div>
          )}
        </div>

        {/* Health Check Button */}
        <button
          onClick={runHealthCheck}
          disabled={checking}
          className={`w-full flex items-center justify-center gap-2 py-2 rounded-xl text-xs font-semibold transition-all border mb-3 ${
            checking
              ? 'bg-gray-700/40 border-gray-700/40 text-gray-500 cursor-not-allowed'
              : `bg-gradient-to-r ${node.color} bg-opacity-20 border-transparent text-white hover:opacity-90`
          }`}
        >
          {checking ? <Loader className="w-3.5 h-3.5 animate-spin" /> : <Wifi className="w-3.5 h-3.5" />}
          {checking ? 'Running health check...' : 'Run Health Check'}
        </button>

        {/* Health Check Results */}
        <AnimatePresence>
          {checkResult && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-3 space-y-1.5"
            >
              {checkResult.error ? (
                <div className="flex items-start gap-2 bg-red-500/10 border border-red-500/30 rounded-xl px-3 py-2">
                  <AlertTriangle className="w-3.5 h-3.5 text-red-400 flex-shrink-0 mt-0.5" />
                  <p className="text-[11px] text-red-300">{checkResult.error}</p>
                </div>
              ) : (
                <>
                  {/* Scanner results */}
                  {checkResult.ping && (
                    <div className={`flex items-center justify-between rounded-xl px-3 py-2 border ${checkResult.ping.ok ? 'bg-green-500/8 border-green-500/20' : 'bg-red-500/8 border-red-500/20'}`}>
                      <div className="flex items-center gap-2">
                        {checkResult.ping.ok ? <CheckCircle className="w-3 h-3 text-green-400" /> : <XCircle className="w-3 h-3 text-red-400" />}
                        <span className="text-[11px] text-gray-300">Basic Connectivity</span>
                      </div>
                      <span className="text-[10px] text-gray-500">{checkResult.ping.latency_ms}ms</span>
                    </div>
                  )}
                  {checkResult.integration && (
                    <div className={`flex items-center justify-between rounded-xl px-3 py-2 border ${checkResult.integration.ok ? 'bg-green-500/8 border-green-500/20' : 'bg-red-500/8 border-red-500/20'}`}>
                      <div className="flex items-center gap-2">
                        {checkResult.integration.ok ? <CheckCircle className="w-3 h-3 text-green-400" /> : <XCircle className="w-3 h-3 text-red-400" />}
                        <span className="text-[11px] text-gray-300">Scanner Plugin Test</span>
                      </div>
                      <span className="text-[10px] text-gray-500">{checkResult.integration.latency_ms}ms</span>
                    </div>
                  )}
                  {checkResult.integration?.error && (
                    <p className="text-[10px] text-red-400 px-3">Plugin error: {checkResult.integration.error}</p>
                  )}
                  {/* Media results */}
                  {checkResult.upload && (
                    <div className={`flex items-center justify-between rounded-xl px-3 py-2 border ${checkResult.upload.ok ? 'bg-green-500/8 border-green-500/20' : 'bg-red-500/8 border-red-500/20'}`}>
                      <div className="flex items-center gap-2">
                        {checkResult.upload.ok ? <CheckCircle className="w-3 h-3 text-green-400" /> : <XCircle className="w-3 h-3 text-red-400" />}
                        <span className="text-[11px] text-gray-300">Dummy File Upload</span>
                      </div>
                      <span className="text-[10px] text-gray-500">{checkResult.upload.latency_ms}ms</span>
                    </div>
                  )}
                  {checkResult.retrieve && (
                    <div className={`flex items-center justify-between rounded-xl px-3 py-2 border ${checkResult.retrieve.ok ? 'bg-green-500/8 border-green-500/20' : 'bg-red-500/8 border-red-500/20'}`}>
                      <div className="flex items-center gap-2">
                        {checkResult.retrieve.ok ? <CheckCircle className="w-3 h-3 text-green-400" /> : <XCircle className="w-3 h-3 text-red-400" />}
                        <span className="text-[11px] text-gray-300">File Retrieve & Content Match</span>
                      </div>
                      <span className="text-[10px] text-gray-500">{checkResult.retrieve.latency_ms}ms</span>
                    </div>
                  )}
                  {checkResult.retrieve?.error && (
                    <p className="text-[10px] text-red-400 px-3">Retrieve error: {checkResult.retrieve.error}</p>
                  )}
                  {/* Overall */}
                  <div className={`text-center text-xs font-bold py-1.5 rounded-xl ${checkResult.overall ? 'text-green-300 bg-green-500/10' : 'text-red-300 bg-red-500/10'}`}>
                    {checkResult.overall ? '✅ All systems operational' : '❌ One or more checks failed'}
                  </div>
                </>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Plugin Slots */}
        <AnimatePresence>
          {expanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-2"
            >
              <p className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider mb-1.5">Plugin Slots</p>
              {node.plugins.map(plugin => (
                <PluginSlot
                  key={plugin.id}
                  plugin={plugin}
                  isActive={(activePlugins[plugin.id] ?? plugin.default_active) !== false}
                  onToggle={(pid) => onTogglePlugin(node.id, pid)}
                  nodeColor={node.color}
                  nodeTextColor={node.textColor}
                />
              ))}
              {/* Future slot placeholder */}
              <div className="flex items-center gap-2 border border-dashed border-gray-700/50 rounded-xl px-3 py-2.5 opacity-40">
                <Zap className="w-3.5 h-3.5 text-gray-600" />
                <p className="text-[10px] text-gray-600 italic">+ Future plugin slot available</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

// ── Main Tab ──────────────────────────────────────────────────────────────────
const STORAGE_KEY = 'vps_plugin_states';

export default function VpsManagementTab() {
  const [pluginStates, setPluginStates] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    } catch {
      return {};
    }
  });

  const handleTogglePlugin = (nodeId, pluginId) => {
    setPluginStates(prev => {
      const node = prev[nodeId] || {};
      const currentNode = VPS_NODES.find(n => n.id === nodeId);
      const plugin = currentNode?.plugins.find(p => p.id === pluginId);
      const currentActive = node[pluginId] ?? plugin?.default_active ?? true;
      const updated = { ...prev, [nodeId]: { ...node, [pluginId]: !currentActive } };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      return updated;
    });
  };

  return (
    <div className="px-4 space-y-4">
      {/* Header */}
      <div className="bg-gradient-to-r from-violet-600/20 to-blue-600/20 rounded-2xl p-4 border border-violet-500/30">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-blue-500 flex items-center justify-center">
            <Globe className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-white text-sm">VPS Management</h3>
            <p className="text-xs text-gray-400">Monitor, verify & manage connected VPS nodes</p>
          </div>
          <div className="ml-auto text-right">
            <p className="text-[10px] text-gray-500">{VPS_NODES.length} nodes registered</p>
            <p className="text-[10px] text-gray-600">Plugin states saved locally</p>
          </div>
        </div>
      </div>

      {/* VPS Node Cards */}
      {VPS_NODES.map(node => (
        <VpsNodeCard
          key={node.id}
          node={node}
          pluginStates={pluginStates}
          onTogglePlugin={handleTogglePlugin}
        />
      ))}
    </div>
  );
}