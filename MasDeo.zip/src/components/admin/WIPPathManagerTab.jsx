import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, Unlock, Save, Plus, Trash2, KeyRound, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useWIPLock } from '@/lib/WIPLockContext';

// All public routes that can be locked
const PUBLIC_ROUTES = [
  { path: '/', name: 'Home', icon: '🏠' },
  { path: '/EthicalInternet', name: 'Ethical Internet', icon: '🌐' },
  { path: '/LearnSkills', name: 'Learn Skills', icon: '📚' },
  { path: '/EarnOnline', name: 'Earn Online', icon: '💰' },
  { path: '/Profile', name: 'Profile / More', icon: '👤' },
  { path: '/ExploreCreators', name: 'Explore Creators', icon: '⭐' },
  { path: '/BrowseCreators', name: 'Browse Creators', icon: '👥' },
  { path: '/Premium', name: 'Premium Plans', icon: '✨' },
  { path: '/Subscribe', name: 'Subscribe', icon: '💳' },
  { path: '/MySubscription', name: 'My Subscription', icon: '📋' },
  { path: '/Discover', name: 'Discover', icon: '🔍' },
  { path: '/HostScanner', name: 'Host Scanner', icon: '🔧' },
  { path: '/CdnWafScanner', name: 'CDN/WAF Scanner', icon: '⚔️' },
  { path: '/SniBugScanner', name: 'SNI Bug Scanner', icon: '🐛' },
  { path: '/ZeroRatedScan', name: 'Zero Rated Scan', icon: '📡' },
  { path: '/InternetProtection', name: 'Internet Protection', icon: '🛡️' },
  { path: '/ServiceDirectory', name: 'Service Directory', icon: '📋' },
  { path: '/LetsVPNGoInfo', name: 'Lets VPN Go Info', icon: '🔒' },
  { path: '/Forex', name: 'Forex Signals', icon: '📈' },
  { path: '/EarnCredits', name: 'Earn Credits', icon: '🪙' },
  { path: '/BuyCredits', name: 'Buy Credits', icon: '💵' },
  { path: '/Wallet', name: 'Wallet', icon: '👛' },
  { path: '/WithdrawCredits', name: 'Withdraw Credits', icon: '🏦' },
  { path: '/CreatorDashboard', name: 'Creator Dashboard', icon: '🎨' },
  { path: '/CreatorMode', name: 'Creator Mode', icon: '⚡' },
  { path: '/CreatorProfile', name: 'Creator Profile', icon: '🪪' },
  { path: '/CreatorEthical', name: 'Creator Ethical', icon: '🌐' },
  { path: '/CreatorLearn', name: 'Creator Learn', icon: '📚' },
  { path: '/CreatorEarn', name: 'Creator Earn', icon: '💰' },
  { path: '/CreatorFiles', name: 'Creator Files', icon: '📁' },
  { path: '/CreatorVps', name: 'Creator VPS', icon: '🖥️' },
  { path: '/CreatorWebsites', name: 'Creator Websites', icon: '🌍' },
  { path: '/CreatorSkills', name: 'Creator Skills', icon: '🎓' },
  { path: '/Following', name: 'Following', icon: '❤️' },
  { path: '/HelpSupport', name: 'Help & Support', icon: '🆘' },
  { path: '/Settings', name: 'Settings', icon: '⚙️' },
  { path: '/SetupPin', name: 'Setup PIN', icon: '🔑' },
  { path: '/JsonCleaner', name: 'JSON Cleaner', icon: '🧹' },
  { path: '/TxtCleaner', name: 'TXT Cleaner', icon: '📝' },
  { path: '/CodeBackup', name: 'Code Backup', icon: '💾' },
  { path: '/ISPNodeSetup', name: 'ISP Node Setup', icon: '🖥️' },
  { path: '/ISPNodeDashboard', name: 'ISP Node Dashboard', icon: '📊' },
];

export default function WIPPathManagerTab() {
  const { lockedRoutes, loading, lockRoute, unlockRoute, vipPin, routePins, updatePin, updateRoutePin } = useWIPLock();
  const [pinInput, setNewPinInput] = useState('');
  const [showPinForm, setShowPinForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [customPath, setCustomPath] = useState('');
  // Per-route PIN editing state: { [path]: inputValue }
  const [routePinEdits, setRoutePinEdits] = useState({});
  const [editingRoutePin, setEditingRoutePin] = useState(null);

  // Combine predefined + any locked custom routes not in predefined list
  const predefinedPaths = PUBLIC_ROUTES.map(r => r.path);
  const customLockedRoutes = lockedRoutes.filter(r => !predefinedPaths.includes(r));

  const filteredRoutes = PUBLIC_ROUTES.filter(route =>
    route.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    route.path.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const showMsg = (msg) => { setMessage(msg); setTimeout(() => setMessage(''), 3000); };

  const handleToggleLock = async (path) => {
    try {
      if (lockedRoutes.includes(path)) {
        await unlockRoute(path);
      } else {
        await lockRoute(path);
      }
    } catch {
      showMsg('Error updating lock status');
    }
  };

  const handleAddCustomPath = async () => {
    if (!customPath.trim()) return;
    const path = customPath.startsWith('/') ? customPath.trim() : `/${customPath.trim()}`;
    if (lockedRoutes.includes(path)) {
      showMsg('Path is already locked');
      return;
    }
    try {
      await lockRoute(path);
      setCustomPath('');
      showMsg(`✓ Locked: ${path}`);
    } catch {
      showMsg('Error locking custom path');
    }
  };

  const handleUpdatePin = async (e) => {
    e.preventDefault();
    if (!pinInput || pinInput.length < 4) { showMsg('PIN must be at least 4 characters'); return; }
    setSaving(true);
    try {
      await updatePin(pinInput);
      showMsg('✓ VIP PIN updated successfully!');
      setNewPinInput('');
      setShowPinForm(false);
    } catch {
      showMsg('Error updating PIN');
    } finally { setSaving(false); }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-6">
      {/* Status Message */}
      <AnimatePresence>
        {message && (
          <motion.div
            initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
            className={`p-3 rounded-lg text-sm font-medium ${
              message.includes('Error') ? 'bg-red-500/20 text-red-400 border border-red-500/30' : 'bg-green-500/20 text-green-400 border border-green-500/30'
            }`}
          >
            {message}
          </motion.div>
        )}
      </AnimatePresence>

      {/* VIP PIN Manager */}
      <div className="bg-gradient-to-br from-purple-600/20 to-pink-600/20 rounded-2xl p-5 border border-purple-500/30">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
            <Lock className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-white text-lg">VIP PIN Manager</h3>
            <p className="text-xs text-gray-400">Set your custom unlock PIN for WIP routes</p>
          </div>
        </div>
        <div className="bg-gray-900/40 rounded-xl p-4 space-y-3">
          {!showPinForm ? (
            <>
              <div className="flex items-center justify-between p-3 bg-gray-800/60 rounded-lg border border-gray-700/50">
                <div>
                  <p className="text-xs text-gray-400 mb-1">Current PIN</p>
                  <p className="text-sm font-mono text-purple-400">{vipPin ? '••••••••' : 'Not set'}</p>
                </div>
                <Button onClick={() => setShowPinForm(true)} variant="outline" size="sm" className="border-purple-500/30 text-purple-400 hover:bg-purple-500/10">
                  Change
                </Button>
              </div>
              <p className="text-[11px] text-gray-500">⚠️ This PIN unlocks WIP-locked routes for VIP users.</p>
            </>
          ) : (
            <form onSubmit={handleUpdatePin} className="space-y-3">
              <div>
                <label className="block text-xs text-gray-300 mb-2">New PIN</label>
                <Input type="password" placeholder="Enter new PIN (min 4 chars)" value={pinInput}
                  onChange={(e) => setNewPinInput(e.target.value)} className="bg-gray-800 border-gray-700 text-white" autoFocus />
              </div>
              <div className="flex gap-2">
                <Button type="submit" disabled={saving || !pinInput || pinInput.length < 4}
                  className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500">
                  <Save className="w-4 h-4 mr-2" />
                  {saving ? 'Saving...' : 'Save PIN'}
                </Button>
                <Button type="button" onClick={() => { setShowPinForm(false); setNewPinInput(''); }} variant="outline">Cancel</Button>
              </div>
            </form>
          )}
        </div>
      </div>

      {/* Custom Path Locker */}
      <div className="bg-gradient-to-br from-orange-600/20 to-red-600/20 rounded-2xl p-5 border border-orange-500/30">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center">
            <Plus className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-white text-lg">Lock Custom Path</h3>
            <p className="text-xs text-gray-400">Lock any unlisted or future route</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Input
            placeholder="/MySecretBeta or MySecretBeta"
            value={customPath}
            onChange={(e) => setCustomPath(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAddCustomPath()}
            className="bg-gray-800/40 border-gray-700 text-white text-sm font-mono flex-1"
          />
          <Button onClick={handleAddCustomPath} disabled={!customPath.trim()}
            className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-500 hover:to-red-500 flex-shrink-0">
            <Lock className="w-4 h-4 mr-1" /> Lock
          </Button>
        </div>
        {/* Custom locked routes list */}
        {customLockedRoutes.length > 0 && (
          <div className="mt-3 space-y-1.5">
            <p className="text-xs text-gray-400 font-medium">Custom locked paths:</p>
            {customLockedRoutes.map(path => {
              const hasPin = !!routePins?.[path];
              const isEditing = editingRoutePin === path;
              return (
                <div key={path} className="bg-red-500/10 border border-red-500/20 rounded-lg overflow-hidden">
                  <div className="flex items-center justify-between px-3 py-2 gap-2">
                    <div className="flex-1 min-w-0">
                      <span className="text-xs font-mono text-red-300 truncate block">{path}</span>
                      {hasPin && <span className="text-[9px] text-purple-400">custom PIN set</span>}
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      <button
                        onClick={() => {
                          setEditingRoutePin(isEditing ? null : path);
                          setRoutePinEdits(prev => ({ ...prev, [path]: routePins?.[path] || '' }));
                        }}
                        className={`flex items-center justify-center w-7 h-7 rounded-lg transition-all border ${isEditing || hasPin ? 'bg-purple-500/20 text-purple-400 border-purple-500/30' : 'bg-gray-700/40 text-gray-500 border-gray-600/40 hover:border-purple-500/40'}`}
                        title="Set custom PIN"
                      >
                        <KeyRound className="w-3 h-3" />
                      </button>
                      <button onClick={() => handleToggleLock(path)} className="flex items-center gap-1 text-[10px] text-red-400 hover:text-red-300 transition-colors px-1.5 py-1 rounded-lg hover:bg-red-500/10">
                        <Trash2 className="w-3 h-3" /> Remove
                      </button>
                    </div>
                  </div>
                  <AnimatePresence>
                    {isEditing && (
                      <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.15 }}
                        className="border-t border-purple-500/20 bg-purple-500/5 px-3 py-2.5 overflow-hidden">
                        <p className="text-[10px] text-purple-300 mb-1.5 font-medium">Custom PIN (leave empty to use global PIN)</p>
                        <div className="flex gap-2">
                          <Input type="password" placeholder={`Global PIN fallback`}
                            value={routePinEdits[path] || ''}
                            onChange={(e) => setRoutePinEdits(prev => ({ ...prev, [path]: e.target.value }))}
                            className="bg-gray-800 border-gray-700 text-white text-xs flex-1 h-7" autoFocus />
                          <Button size="sm" onClick={async () => {
                            const pin = routePinEdits[path] || '';
                            await updateRoutePin(path, pin || null);
                            setEditingRoutePin(null);
                            showMsg(pin ? `✓ Custom PIN set for ${path}` : `✓ Using global PIN for ${path}`);
                          }} className="bg-purple-600 hover:bg-purple-500 h-7 px-2.5 text-xs flex-shrink-0">
                            <Save className="w-3 h-3 mr-1" />Save
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => setEditingRoutePin(null)} className="h-7 px-2 border-gray-600 flex-shrink-0">
                            <X className="w-3 h-3" />
                          </Button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Route Lock Manager */}
      <div className="bg-gradient-to-br from-cyan-600/20 to-blue-600/20 rounded-2xl p-5 border border-cyan-500/30">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center">
            <Unlock className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-white text-lg">All Routes</h3>
            <p className="text-xs text-gray-400">{lockedRoutes.length} locked · {PUBLIC_ROUTES.length - lockedRoutes.filter(r => predefinedPaths.includes(r)).length} unlocked</p>
          </div>
        </div>

        {/* Search */}
        <div className="mb-4">
          <Input placeholder="Search routes..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-gray-800/40 border-gray-700 text-white text-sm" />
        </div>

        {/* Routes List */}
        <div className="space-y-2 max-h-[500px] overflow-y-auto scroll-container">
          <AnimatePresence>
            {filteredRoutes.map(route => {
              const isLocked = lockedRoutes.includes(route.path);
              const hasCustomPin = !!routePins?.[route.path];
              const isEditingPin = editingRoutePin === route.path;
              return (
                <motion.div key={route.path} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }}
                  className="bg-gray-900/40 rounded-lg border border-gray-700/50 hover:border-cyan-500/30 transition-all overflow-hidden">
                  <div className="p-3 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <span className="text-lg flex-shrink-0">{route.icon}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-white truncate">{route.name}</p>
                        <div className="flex items-center gap-1.5">
                          <p className="text-xs text-gray-500 font-mono truncate">{route.path}</p>
                          {hasCustomPin && <span className="text-[9px] bg-purple-500/20 text-purple-400 border border-purple-500/30 px-1.5 py-0.5 rounded-full font-semibold flex-shrink-0">custom PIN</span>}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      {isLocked && (
                        <button
                          onClick={() => {
                            setEditingRoutePin(isEditingPin ? null : route.path);
                            setRoutePinEdits(prev => ({ ...prev, [route.path]: routePins?.[route.path] || '' }));
                          }}
                          className={`flex items-center justify-center w-8 h-8 rounded-lg transition-all border ${
                            isEditingPin ? 'bg-purple-500/30 text-purple-300 border-purple-500/40' : hasCustomPin ? 'bg-purple-500/20 text-purple-400 border-purple-500/30' : 'bg-gray-700/40 text-gray-500 border-gray-600/40 hover:border-purple-500/40 hover:text-purple-400'
                          }`}
                          title="Set custom PIN for this route"
                        >
                          <KeyRound className="w-3.5 h-3.5" />
                        </button>
                      )}
                      <motion.button
                        onClick={() => handleToggleLock(route.path)}
                        className={`flex items-center justify-center w-9 h-9 rounded-lg transition-all flex-shrink-0 ${
                          isLocked ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30 border border-red-500/30' : 'bg-green-500/20 text-green-400 hover:bg-green-500/30 border border-green-500/30'
                        }`}
                        whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                      >
                        {isLocked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
                      </motion.button>
                    </div>
                  </div>

                  {/* Inline per-route PIN editor */}
                  <AnimatePresence>
                    {isEditingPin && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="border-t border-gray-700/50 bg-purple-500/5 px-3 py-3 overflow-hidden"
                      >
                        <p className="text-[11px] text-purple-300 mb-2 font-medium">Custom PIN for this route (leave empty to use global PIN)</p>
                        <div className="flex gap-2">
                          <Input
                            type="password"
                            placeholder={`Global PIN is used (${vipPin ? '••••' : 'not set'})`}
                            value={routePinEdits[route.path] || ''}
                            onChange={(e) => setRoutePinEdits(prev => ({ ...prev, [route.path]: e.target.value }))}
                            className="bg-gray-800 border-gray-700 text-white text-sm flex-1 h-8"
                            autoFocus
                          />
                          <Button
                            size="sm"
                            onClick={async () => {
                              const pin = routePinEdits[route.path] || '';
                              await updateRoutePin(route.path, pin || null);
                              setEditingRoutePin(null);
                              showMsg(pin ? `✓ Custom PIN set for ${route.path}` : `✓ Removed custom PIN for ${route.path}`);
                            }}
                            className="bg-purple-600 hover:bg-purple-500 h-8 px-3 text-xs flex-shrink-0"
                          >
                            <Save className="w-3 h-3 mr-1" />Save
                          </Button>
                          <Button
                            size="sm" variant="outline"
                            onClick={() => setEditingRoutePin(null)}
                            className="h-8 px-2 border-gray-600 flex-shrink-0"
                          >
                            <X className="w-3 h-3" />
                          </Button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>

        {/* Stats */}
        <div className="mt-4 p-3 bg-gray-800/40 rounded-lg border border-gray-700/50 flex items-center justify-between">
          <div>
            <p className="text-xs text-gray-400">Total Locked</p>
            <p className="text-sm font-bold text-white mt-0.5">{lockedRoutes.length} routes locked</p>
          </div>
          <div className="flex gap-2">
            {lockedRoutes.length > 0 && (
              <span className="text-xs bg-red-500/20 text-red-400 border border-red-500/30 px-2 py-1 rounded-full font-medium">🔒 {lockedRoutes.length}</span>
            )}
            <span className="text-xs bg-green-500/20 text-green-400 border border-green-500/30 px-2 py-1 rounded-full font-medium">
              🔓 {PUBLIC_ROUTES.length - lockedRoutes.filter(r => predefinedPaths.includes(r)).length}
            </span>
          </div>
        </div>
      </div>

      {/* Info */}
      <div className="bg-blue-500/10 rounded-xl border border-blue-500/30 p-4 space-y-2">
        <p className="text-sm text-blue-300 font-medium">📌 How WIP Lock Works</p>
        <ul className="text-xs text-blue-200 space-y-1 ml-4">
          <li>✓ Locked routes show frosted-glass blur on Home page cards</li>
          <li>✓ Direct URL access triggers full-page lock screen</li>
          <li>✓ Users must enter VIP PIN to unlock their session</li>
          <li>✓ Changes sync instantly across all devices in real-time</li>
          <li>✓ Custom paths let you lock any future or unlisted route</li>
        </ul>
      </div>
    </div>
  );
}