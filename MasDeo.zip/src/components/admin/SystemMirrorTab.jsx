import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import {
  Camera, DownloadCloud, RefreshCw, CheckCircle, AlertCircle,
  Loader, Database, CloudUpload, Eye, Clock
} from 'lucide-react';

export default function SystemMirrorTab() {
  const [snapshots, setSnapshots] = useState([]);
  const [loadingSnapshots, setLoadingSnapshots] = useState(false);
  const [snapshotError, setSnapshotError] = useState('');

  const [takingSnapshot, setTakingSnapshot] = useState(false);
  const [snapshotResult, setSnapshotResult] = useState(null);
  const [snapshotErr, setSnapshotErr] = useState('');

  const [restoreUrl, setRestoreUrl] = useState('');
  const [dryRunResult, setDryRunResult] = useState(null);
  const [restoring, setRestoring] = useState(false);
  const [restoreResult, setRestoreResult] = useState(null);
  const [restoreErr, setRestoreErr] = useState('');
  const [confirmRestore, setConfirmRestore] = useState(false);

  useEffect(() => { loadSnapshots(); }, []);

  const loadSnapshots = async () => {
    setLoadingSnapshots(true);
    setSnapshotError('');
    try {
      const res = await base44.functions.invoke('vpsFileManager', { action: 'list' });
      const all = res.data?.files || [];
      // Only show snapshot JSON files
      const filtered = all.filter(f =>
        typeof f === 'string'
          ? f.includes('snapshot_') && f.endsWith('.json')
          : (f.name || f.url || '').includes('snapshot_')
      );
      setSnapshots(filtered);
    } catch (e) {
      setSnapshotError('Could not load snapshots from VPS.');
    }
    setLoadingSnapshots(false);
  };

  const handleTakeSnapshot = async () => {
    setTakingSnapshot(true);
    setSnapshotResult(null);
    setSnapshotErr('');
    try {
      const res = await base44.functions.invoke('backupAllData', {});
      setSnapshotResult(res.data);
      loadSnapshots();
    } catch (e) {
      setSnapshotErr(e?.response?.data?.error || e.message || 'Snapshot failed');
    }
    setTakingSnapshot(false);
  };

  const handleDryRun = async (url) => {
    setRestoreUrl(url);
    setDryRunResult(null);
    setRestoreResult(null);
    setRestoreErr('');
    setConfirmRestore(false);
    try {
      const res = await base44.functions.invoke('restoreFromBackup', { backup_url: url, dry_run: true });
      setDryRunResult(res.data);
    } catch (e) {
      setRestoreErr(e?.response?.data?.error || e.message || 'Preview failed');
    }
  };

  const handleRestore = async () => {
    setRestoring(true);
    setRestoreResult(null);
    setRestoreErr('');
    try {
      const res = await base44.functions.invoke('restoreFromBackup', { backup_url: restoreUrl });
      setRestoreResult(res.data);
      setDryRunResult(null);
      setConfirmRestore(false);
    } catch (e) {
      setRestoreErr(e?.response?.data?.error || e.message || 'Restore failed');
    }
    setRestoring(false);
  };

  const getFileName = (f) => {
    const url = typeof f === 'string' ? f : (f.url || f.name || '');
    return url.split('/').pop() || url;
  };

  const getFileUrl = (f) => typeof f === 'string' ? f : (f.url || f.file_url || '');

  return (
    <div className="px-4 space-y-4 py-2">

      {/* Header */}
      <div className="bg-gradient-to-r from-violet-600/20 to-cyan-600/20 rounded-2xl p-4 border border-violet-500/30">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-cyan-500 flex items-center justify-center">
            <Database className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-white text-sm">System Mirror</h3>
            <p className="text-xs text-gray-400">Backup & restore via media.mastersdeovex.co.za</p>
          </div>
        </div>
        <div className="bg-cyan-500/10 border border-cyan-500/20 rounded-xl px-3 py-2">
          <p className="text-[11px] text-cyan-300 leading-relaxed">
            📸 Snapshots capture ALL entity data and upload to your VPS. On a cloned app, deploy a snapshot to restore everything instantly — file URLs stay the same, users re-link by email automatically.
          </p>
        </div>
      </div>

      {/* Take Snapshot */}
      <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 overflow-hidden">
        <div className="px-4 py-3 border-b border-gray-700/50 flex items-center gap-2">
          <Camera className="w-4 h-4 text-violet-400" />
          <span className="font-semibold text-white text-sm">Take Snapshot Now</span>
        </div>
        <div className="p-4 space-y-3">
          <p className="text-xs text-gray-400">Dumps all entity records into one JSON file and uploads it to your VPS.</p>

          {snapshotResult && (
            <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}
              className="bg-green-500/10 border border-green-500/20 rounded-xl p-3 space-y-1">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
                <p className="text-xs text-green-400 font-semibold">Snapshot created! {snapshotResult.total} records saved.</p>
              </div>
              <p className="text-[10px] text-gray-500 font-mono break-all">{snapshotResult.snapshot_url}</p>
            </motion.div>
          )}

          {snapshotErr && (
            <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">
              <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
              <p className="text-xs text-red-400">{snapshotErr}</p>
            </div>
          )}

          <button onClick={handleTakeSnapshot} disabled={takingSnapshot}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-violet-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 disabled:opacity-50 text-white font-bold text-sm py-3 rounded-xl transition-all">
            {takingSnapshot ? <Loader className="w-4 h-4 animate-spin" /> : <CloudUpload className="w-4 h-4" />}
            {takingSnapshot ? 'Creating Snapshot...' : 'Take Snapshot'}
          </button>
        </div>
      </div>

      {/* Stored Snapshots */}
      <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 overflow-hidden">
        <div className="px-4 py-3 border-b border-gray-700/50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-cyan-400" />
            <span className="font-semibold text-white text-sm">Stored Snapshots</span>
            <span className="text-xs text-gray-500">({snapshots.length})</span>
          </div>
          <button onClick={loadSnapshots} className="p-1.5 hover:bg-gray-700/50 rounded-lg transition-colors">
            <RefreshCw className={`w-3.5 h-3.5 text-gray-400 ${loadingSnapshots ? 'animate-spin' : ''}`} />
          </button>
        </div>

        <div className="p-4 space-y-2">
          {snapshotError && (
            <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">
              <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
              <p className="text-xs text-red-400">{snapshotError}</p>
            </div>
          )}

          {loadingSnapshots ? (
            <div className="flex items-center justify-center py-6 text-gray-500 gap-2">
              <Loader className="w-4 h-4 animate-spin" /> Loading...
            </div>
          ) : snapshots.length === 0 ? (
            <p className="text-center text-gray-600 text-xs py-6">No snapshots yet. Take one above.</p>
          ) : (
            snapshots.map((f, i) => {
              const name = getFileName(f);
              const url = getFileUrl(f);
              const isSelected = restoreUrl === url;
              return (
                <motion.div key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                  className={`rounded-xl border p-3 transition-all ${isSelected ? 'border-cyan-500/50 bg-cyan-500/5' : 'border-gray-700/50 bg-gray-900/40'}`}>
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-mono text-white truncate">{name}</p>
                      <p className="text-[10px] text-gray-600 truncate mt-0.5">{url}</p>
                    </div>
                    <button onClick={() => handleDryRun(url)}
                      className="flex items-center gap-1 text-[11px] text-cyan-400 bg-cyan-500/10 border border-cyan-500/20 px-2.5 py-1.5 rounded-lg hover:bg-cyan-500/20 transition-colors flex-shrink-0">
                      <Eye className="w-3 h-3" /> Preview
                    </button>
                  </div>
                </motion.div>
              );
            })
          )}
        </div>
      </div>

      {/* Restore Section */}
      <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 overflow-hidden">
        <div className="px-4 py-3 border-b border-gray-700/50 flex items-center gap-2">
          <DownloadCloud className="w-4 h-4 text-emerald-400" />
          <span className="font-semibold text-white text-sm">Deploy Snapshot to This App</span>
        </div>
        <div className="p-4 space-y-3">

          {/* Manual URL input */}
          <div>
            <label className="text-xs text-gray-400 mb-1.5 block">Snapshot URL (from VPS or paste manually)</label>
            <input
              value={restoreUrl}
              onChange={e => { setRestoreUrl(e.target.value); setDryRunResult(null); setRestoreResult(null); setConfirmRestore(false); }}
              placeholder="https://media.mastersdeovex.co.za/uploads/snapshot_..."
              className="w-full bg-gray-900/60 border border-gray-700 rounded-xl px-3 py-2.5 text-xs text-white placeholder-gray-600 focus:outline-none focus:border-cyan-500/50"
            />
          </div>

          <button onClick={() => handleDryRun(restoreUrl)} disabled={!restoreUrl}
            className="w-full flex items-center justify-center gap-2 bg-gray-700/60 hover:bg-gray-700 disabled:opacity-40 text-white text-sm py-2.5 rounded-xl transition-all">
            <Eye className="w-4 h-4" /> Preview Snapshot
          </button>

          {/* Dry Run Result */}
          {dryRunResult && (
            <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}
              className="bg-gray-900/60 border border-gray-700/50 rounded-xl p-3 space-y-2">
              <p className="text-xs font-semibold text-white">Snapshot Preview</p>
              <div className="text-[11px] text-gray-400 space-y-0.5">
                <p>Backed up: <span className="text-gray-300">{dryRunResult.snapshot_info?.backed_up_at ? new Date(dryRunResult.snapshot_info.backed_up_at).toLocaleString('en-ZA') : '—'}</span></p>
                <p>By: <span className="text-gray-300">{dryRunResult.snapshot_info?.backed_up_by || '—'}</span></p>
                <p>Total records: <span className="text-cyan-300 font-bold">{dryRunResult.snapshot_info?.total_records || '—'}</span></p>
              </div>
              <div className="grid grid-cols-2 gap-1.5 max-h-40 overflow-y-auto">
                {Object.entries(dryRunResult.stats || {}).filter(([, v]) => v > 0).map(([k, v]) => (
                  <div key={k} className="flex items-center justify-between bg-gray-800/60 rounded-lg px-2 py-1">
                    <span className="text-[10px] text-gray-400 truncate">{k}</span>
                    <span className="text-[10px] font-bold text-white ml-1">{v}</span>
                  </div>
                ))}
              </div>

              {!confirmRestore ? (
                <button onClick={() => setConfirmRestore(true)}
                  className="w-full py-2.5 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 transition-all">
                  Deploy This Snapshot
                </button>
              ) : (
                <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-3 space-y-2">
                  <p className="text-xs text-red-300 font-semibold">⚠️ This will create records in the current app. Existing records are NOT deleted. Confirm?</p>
                  <div className="flex gap-2">
                    <button onClick={() => setConfirmRestore(false)} className="flex-1 py-2 rounded-xl text-xs text-gray-400 bg-gray-800 hover:bg-gray-700 transition-colors">Cancel</button>
                    <button onClick={handleRestore} disabled={restoring}
                      className="flex-1 py-2 rounded-xl text-xs text-white font-bold bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 disabled:opacity-50 flex items-center justify-center gap-1.5 transition-all">
                      {restoring ? <Loader className="w-3 h-3 animate-spin" /> : null}
                      {restoring ? 'Deploying...' : 'Yes, Deploy'}
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {/* Restore Result */}
          {restoreResult && (
            <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}
              className="bg-green-500/10 border border-green-500/20 rounded-xl p-3 space-y-1">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
                <p className="text-xs text-green-400 font-semibold">Snapshot deployed! {restoreResult.total_restored} records created, {restoreResult.total_skipped} skipped.</p>
              </div>
            </motion.div>
          )}

          {restoreErr && (
            <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">
              <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
              <p className="text-xs text-red-400">{restoreErr}</p>
            </div>
          )}
        </div>
      </div>

    </div>
  );
}