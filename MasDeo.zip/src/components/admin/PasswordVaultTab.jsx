import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, Mail, Send, RefreshCw, Search, AlertCircle, CheckCircle, Loader, Eye, EyeOff, KeyRound, Pencil, X } from 'lucide-react';
import { Input } from '@/components/ui/input';

// Decode on frontend too (same XOR key) for display
function decode(encoded) {
  const key = 'MDV2025XK';
  try {
    const str = atob(encoded);
    let result = '';
    for (let i = 0; i < str.length; i++) {
      result += String.fromCharCode(str.charCodeAt(i) ^ key.charCodeAt(i % key.length));
    }
    return result;
  } catch {
    return '(decode error)';
  }
}

export default function PasswordVaultTab() {
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [visibleIds, setVisibleIds] = useState(new Set());
  const [actionLoading, setActionLoading] = useState({});
  const [actionResult, setActionResult] = useState({});
  const [setPasswordModal, setSetPasswordModal] = useState(null); // { email }
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [showNewPw, setShowNewPw] = useState(false);
  const [setPasswordLoading, setSetPasswordLoading] = useState(false);
  const [setPasswordResult, setSetPasswordResult] = useState(null);

  useEffect(() => { loadEntries(); }, []);

  const loadEntries = async () => {
    setLoading(true);
    try {
      const data = await base44.entities.PasswordVault.list('-updated_at', 500);
      setEntries(data);
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  const toggleVisible = (id) => {
    setVisibleIds(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const runAction = async (email, action) => {
    const key = `${email}_${action}`;
    setActionLoading(prev => ({ ...prev, [key]: true }));
    setActionResult(prev => ({ ...prev, [key]: null }));
    try {
      const res = await base44.functions.invoke('adminSendPassword', { email, action });
      setActionResult(prev => ({ ...prev, [key]: { ok: true, msg: res.data?.message || 'Done!' } }));
    } catch (err) {
      const msg = err?.response?.data?.error || err?.message || 'Failed';
      setActionResult(prev => ({ ...prev, [key]: { ok: false, msg } }));
    } finally {
      setActionLoading(prev => ({ ...prev, [key]: false }));
    }
  };

  const openSetPassword = (email) => {
    setSetPasswordModal({ email });
    setNewPasswordInput('');
    setShowNewPw(false);
    setSetPasswordResult(null);
  };

  const closeSetPassword = () => {
    setSetPasswordModal(null);
    setNewPasswordInput('');
    setSetPasswordResult(null);
  };

  const handleSetPassword = async () => {
    if (!newPasswordInput || newPasswordInput.length < 6) {
      setSetPasswordResult({ ok: false, msg: 'Password must be at least 6 characters' });
      return;
    }
    setSetPasswordLoading(true);
    setSetPasswordResult(null);
    try {
      const res = await base44.functions.invoke('adminSetPassword', {
        email: setPasswordModal.email,
        newPassword: newPasswordInput
      });
      setSetPasswordResult({ ok: true, msg: res.data?.message || 'Password updated!' });
      // Refresh vault entries
      loadEntries();
    } catch (err) {
      const msg = err?.response?.data?.error || err?.message || 'Failed';
      setSetPasswordResult({ ok: false, msg });
    } finally {
      setSetPasswordLoading(false);
    }
  };

  const filtered = entries.filter(e =>
    search === '' || e.email?.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) return (
    <div className="flex items-center justify-center py-12">
      <div className="flex items-center gap-3 text-gray-400">
        <Loader className="w-5 h-5 animate-spin" /> Loading vault...
      </div>
    </div>
  );

  return (
    <div className="px-4 space-y-4">
      {/* Header */}
      <div className="bg-gradient-to-r from-violet-600/20 to-purple-600/20 rounded-2xl p-4 border border-violet-500/30">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
            <Lock className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-white text-sm">Password Vault</h3>
            <p className="text-xs text-gray-400">Admin-only — {entries.length} accounts stored</p>
          </div>
        </div>
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl px-3 py-2">
          <p className="text-[11px] text-amber-300">⚠️ Sensitive data. Never share vault access. Use actions below to help users recover access.</p>
        </div>
      </div>

      {/* Search + Refresh */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <Input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search by email..."
            className="bg-gray-800/40 border-gray-700 text-white text-sm pl-9" />
        </div>
        <button onClick={loadEntries} className="p-2 bg-gray-800/60 rounded-lg hover:bg-gray-700/60 transition-colors">
          <RefreshCw className="w-4 h-4 text-gray-400" />
        </button>
      </div>

      {/* Entries */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="text-center py-10 text-gray-600 text-sm">
            <KeyRound className="w-6 h-6 mx-auto mb-2 opacity-40" />
            No vault entries found.
          </div>
        ) : (
          filtered.map((entry, i) => {
            const decoded = decode(entry.encoded_password);
            const isVisible = visibleIds.has(entry.id);
            const sendKey = `${entry.email}_send_email`;
            const resetKey = `${entry.email}_auto_reset`;

            return (
              <motion.div key={entry.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.02 }}
                className="bg-gray-800/40 rounded-2xl border border-gray-700/50 p-4 space-y-3">

                {/* Email + timestamp */}
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-gray-500" />
                      <p className="text-sm font-semibold text-white">{entry.email}</p>
                    </div>
                    {entry.updated_at && (
                      <p className="text-[10px] text-gray-600 mt-0.5 ml-6">
                        Updated: {new Date(entry.updated_at).toLocaleString()}
                      </p>
                    )}
                  </div>
                  <button onClick={() => toggleVisible(entry.id)}
                    className="flex items-center gap-1 text-xs text-gray-500 hover:text-white bg-gray-700/50 hover:bg-gray-700 px-2 py-1 rounded-lg transition-all">
                    {isVisible ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    {isVisible ? 'Hide' : 'View'}
                  </button>
                </div>

                {/* Password reveal */}
                {isVisible && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}
                    className="bg-gray-900/60 border border-gray-700/50 rounded-xl px-3 py-2 font-mono text-sm text-green-300 flex items-center justify-between">
                    <span>{decoded}</span>
                  </motion.div>
                )}

                {/* Action Buttons */}
                <div className="flex gap-2 flex-wrap">
                  {/* Send password via email */}
                  <button
                    onClick={() => runAction(entry.email, 'send_email')}
                    disabled={!!actionLoading[sendKey]}
                    className="flex items-center gap-1.5 text-xs bg-blue-500/20 text-blue-300 border border-blue-500/30 px-3 py-1.5 rounded-xl hover:bg-blue-500/30 transition-colors disabled:opacity-50"
                  >
                    {actionLoading[sendKey] ? <Loader className="w-3 h-3 animate-spin" /> : <Send className="w-3 h-3" />}
                    Send Password Email
                  </button>

                  {/* Auto reset — email password + trigger platform reset link */}
                  <button
                    onClick={() => runAction(entry.email, 'auto_reset')}
                    disabled={!!actionLoading[resetKey]}
                    className="flex items-center gap-1.5 text-xs bg-amber-500/20 text-amber-300 border border-amber-500/30 px-3 py-1.5 rounded-xl hover:bg-amber-500/30 transition-colors disabled:opacity-50"
                  >
                    {actionLoading[resetKey] ? <Loader className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
                    Auto Reset
                  </button>

                  {/* Set new password directly */}
                  <button
                    onClick={() => openSetPassword(entry.email)}
                    className="flex items-center gap-1.5 text-xs bg-green-500/20 text-green-300 border border-green-500/30 px-3 py-1.5 rounded-xl hover:bg-green-500/30 transition-colors"
                  >
                    <Pencil className="w-3 h-3" />
                    Set Password
                  </button>
                </div>

                {/* Feedback messages */}
                {actionResult[sendKey] && (
                  <div className={`flex items-center gap-2 text-xs px-3 py-2 rounded-xl border ${actionResult[sendKey].ok ? 'bg-green-500/10 border-green-500/30 text-green-300' : 'bg-red-500/10 border-red-500/30 text-red-300'}`}>
                    {actionResult[sendKey].ok ? <CheckCircle className="w-3.5 h-3.5" /> : <AlertCircle className="w-3.5 h-3.5" />}
                    {actionResult[sendKey].msg}
                  </div>
                )}
                {actionResult[resetKey] && (
                  <div className={`flex items-center gap-2 text-xs px-3 py-2 rounded-xl border ${actionResult[resetKey].ok ? 'bg-green-500/10 border-green-500/30 text-green-300' : 'bg-red-500/10 border-red-500/30 text-red-300'}`}>
                    {actionResult[resetKey].ok ? <CheckCircle className="w-3.5 h-3.5" /> : <AlertCircle className="w-3.5 h-3.5" />}
                    {actionResult[resetKey].msg}
                  </div>
                )}
              </motion.div>
            );
          })
        )}
      </div>

      {/* Set Password Modal */}
      <AnimatePresence>
        {setPasswordModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 px-4"
            onClick={closeSetPassword}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={e => e.stopPropagation()}
              className="w-full max-w-sm bg-gray-900 border border-gray-700 rounded-2xl p-5 space-y-4"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-white font-bold text-sm">Set New Password</h3>
                  <p className="text-gray-500 text-xs mt-0.5">{setPasswordModal.email}</p>
                </div>
                <button onClick={closeSetPassword} className="text-gray-600 hover:text-white transition-colors">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="relative bg-gray-800/60 border border-gray-700 rounded-xl focus-within:border-violet-500/50 transition-colors">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none">
                  <Lock className="w-4 h-4 text-gray-600" />
                </span>
                <input
                  type={showNewPw ? 'text' : 'password'}
                  value={newPasswordInput}
                  onChange={e => setNewPasswordInput(e.target.value)}
                  placeholder="Enter new password"
                  className="w-full bg-transparent pl-10 pr-10 py-3 text-sm text-white placeholder-gray-600 focus:outline-none"
                  onKeyDown={e => e.key === 'Enter' && handleSetPassword()}
                />
                <button
                  type="button"
                  onClick={() => setShowNewPw(!showNewPw)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-600 hover:text-gray-400 transition-colors"
                >
                  {showNewPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {setPasswordResult && (
                <div className={`flex items-center gap-2 text-xs px-3 py-2 rounded-xl border ${setPasswordResult.ok ? 'bg-green-500/10 border-green-500/30 text-green-300' : 'bg-red-500/10 border-red-500/30 text-red-300'}`}>
                  {setPasswordResult.ok ? <CheckCircle className="w-3.5 h-3.5" /> : <AlertCircle className="w-3.5 h-3.5" />}
                  {setPasswordResult.msg}
                </div>
              )}

              <div className="flex gap-2">
                <button
                  onClick={closeSetPassword}
                  className="flex-1 py-2.5 rounded-xl text-sm text-gray-400 bg-gray-800 hover:bg-gray-700 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSetPassword}
                  disabled={setPasswordLoading || !newPasswordInput}
                  className="flex-1 py-2.5 rounded-xl text-sm text-white font-bold bg-gradient-to-r from-violet-600 to-cyan-500 disabled:opacity-50 flex items-center justify-center gap-2 transition-all"
                >
                  {setPasswordLoading ? <Loader className="w-4 h-4 animate-spin" /> : <KeyRound className="w-4 h-4" />}
                  {setPasswordLoading ? 'Saving...' : 'Set & Notify Me'}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}