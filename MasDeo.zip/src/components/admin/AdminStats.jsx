import React from 'react';
import { motion } from 'framer-motion';

export default function AdminStats({ stats }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
      {stats.map((s, i) => (
        <motion.div
          key={s.label}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.05 }}
          className={`rounded-xl p-3 border ${s.bg} ${s.border} text-center`}
        >
          <p className={`text-xl font-bold ${s.color}`}>{s.value}</p>
          <p className="text-[11px] text-gray-400 mt-0.5">{s.label}</p>
        </motion.div>
      ))}
    </div>
  );
}