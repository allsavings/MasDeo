import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Loader, Sparkles } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function AIAssistantTab() {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'Hey! I\'m your AI Assistant. Ask me anything about your Masters DeoVex app, and I\'ll help you out. Need help managing your admin panel, understanding features, or brainstorming ideas? I\'m here for it! 🤖' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setLoading(true);

    try {
      // Use backend function to process admin commands
      const response = await base44.functions.invoke('adminAIAssistant', { message: userMessage });
      
      const assistantMessage = response.data.response || response.data.error;
      setMessages(prev => [...prev, { role: 'assistant', content: assistantMessage }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'assistant', content: `Sorry, I encountered an error: ${error.message}. Please try again.` }]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="space-y-4 pb-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-2xl p-4 border border-purple-500/30">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-white">AI Assistant</h3>
            <p className="text-xs text-gray-400">Talk to me about anything — app management, features, ideas</p>
          </div>
        </div>
      </div>

      {/* Messages Container */}
      <div className="bg-gray-900/60 rounded-2xl border border-gray-700/50 h-96 overflow-y-auto scroll-container flex flex-col">
        <div className="flex-1 p-4 space-y-4">
          <AnimatePresence>
            {messages.map((msg, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-xs px-4 py-2 rounded-xl text-sm ${
                    msg.role === 'user'
                      ? 'bg-purple-600 text-white'
                      : 'bg-gray-800 border border-gray-700 text-gray-100'
                  }`}
                >
                  {msg.content}
                </div>
              </motion.div>
            ))}
            {loading && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex justify-start"
              >
                <div className="bg-gray-800 border border-gray-700 text-gray-100 px-4 py-3 rounded-xl flex items-center gap-2">
                  <Loader className="w-4 h-4 animate-spin" />
                  <span>Thinking...</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Area */}
      <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 p-3 flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Ask me anything..."
          disabled={loading}
          className="flex-1 bg-gray-900/60 border border-gray-700 rounded-lg px-3 py-2 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-purple-500 disabled:opacity-50"
        />
        <button
          onClick={handleSend}
          disabled={loading || !input.trim()}
          className="flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 disabled:opacity-50 text-white px-4 py-2 rounded-lg font-medium transition-all"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>

      {/* Tips */}
      <div className="bg-blue-500/10 rounded-xl border border-blue-500/30 p-3 text-xs text-blue-200 space-y-1">
        <p className="font-semibold">💡 Try asking:</p>
        <ul className="ml-4 space-y-0.5">
          <li>• "Toggle ads globally"</li>
          <li>• "Show user stats"</li>
          <li>• "How many active subscriptions do we have?"</li>
          <li>• "Disable ads for premium users"</li>
          <li>• "View current configuration"</li>
          <li>• "Show recent users"</li>
        </ul>
      </div>
    </div>
  );
}