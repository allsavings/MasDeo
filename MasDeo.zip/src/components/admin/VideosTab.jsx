import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, Eye, EyeOff, Edit2, Check, X, Play, RefreshCw } from 'lucide-react';
import { Input } from '@/components/ui/input';

// Extract video ID from any YouTube URL or plain ID
function extractVideoId(input) {
  if (!input) return '';
  if (!input.includes('/') && !input.includes('.')) return input;
  const match = input.match(
    /(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([a-zA-Z0-9_-]{11})/
  );
  return match ? match[1] : input;
}

export default function VideosTab() {
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [search, setSearch] = useState('');
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    youtube_video_id: '',
    thumbnail_url: '',
    section: 'learn',
    video_type: 'reward',
    duration_minutes: 0,
    credit_cost: 0.05,
    guide_content: '',
    is_published: true
  });
  const [previewThumb, setPreviewThumb] = useState('');
  const [fetchingMeta, setFetchingMeta] = useState(false);
  const [thumbUploadLoading, setThumbUploadLoading] = useState(false);

  useEffect(() => {
    loadVideos();
  }, []);

  const loadVideos = async () => {
    setLoading(true);
    try {
      const allVideos = await base44.entities.Video.list('-created_date', 100);
      setVideos(allVideos);
    } catch (error) {
      console.error('Error loading videos:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingId) {
        await base44.entities.Video.update(editingId, formData);
      } else {
        await base44.entities.Video.create(formData);
      }
      loadVideos();
      resetForm();
    } catch (error) {
      console.error('Error saving video:', error);
    }
  };

  const handleDelete = async (id) => {
    if (confirm('Delete this video?')) {
      try {
        await base44.entities.Video.delete(id);
        loadVideos();
      } catch (error) {
        console.error('Error deleting video:', error);
      }
    }
  };

  const togglePublish = async (id, currentStatus) => {
    try {
      await base44.entities.Video.update(id, { is_published: !currentStatus });
      loadVideos();
    } catch (error) {
      console.error('Error updating video:', error);
    }
  };

  const handleVideoIdChange = async (raw) => {
    const id = extractVideoId(raw);
    setFormData(prev => ({ ...prev, youtube_video_id: raw }));
    if (id.length === 11) {
      setPreviewThumb(`https://img.youtube.com/vi/${id}/hqdefault.jpg`);
      // Auto-fetch title if empty
      if (!formData.title) {
        setFetchingMeta(true);
        fetch(`https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${id}&format=json`)
          .then(r => r.json())
          .then(data => {
            setFormData(prev => ({
              ...prev,
              title: prev.title || data.title || '',
            }));
          })
          .catch(() => {})
          .finally(() => setFetchingMeta(false));
      }
    } else {
      setPreviewThumb('');
    }
  };

  const handleThumbUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setThumbUploadLoading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setFormData(prev => ({ ...prev, thumbnail_url: file_url }));
    setPreviewThumb(file_url);
    setThumbUploadLoading(false);
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      youtube_video_id: '',
      thumbnail_url: '',
      section: 'learn',
      video_type: 'reward',
      duration_minutes: 0,
      credit_cost: 0.05,
      guide_content: '',
      is_published: true
    });
    setPreviewThumb('');
    setEditingId(null);
    setShowForm(false);
  };

  const startEdit = (video) => {
    const id = extractVideoId(video.youtube_video_id);
    setFormData({
      title: video.title || '',
      description: video.description || '',
      youtube_video_id: video.youtube_video_id,
      thumbnail_url: video.thumbnail_url || '',
      section: video.section,
      video_type: video.video_type || 'reward',
      duration_minutes: video.duration_minutes || 0,
      credit_cost: video.credit_cost,
      guide_content: video.guide_content || '',
      is_published: video.is_published
    });
    setPreviewThumb(video.thumbnail_url || `https://img.youtube.com/vi/${id}/hqdefault.jpg`);
    setEditingId(video.id);
    setShowForm(true);
  };

  const getThumbnailUrl = (videoId) => `https://img.youtube.com/vi/${videoId}/default.jpg`;

  const filteredVideos = videos.filter(v =>
    v.title?.toLowerCase().includes(search.toLowerCase()) ||
    v.youtube_video_id?.includes(search) ||
    v.section?.includes(search)
  );

  const sectionColors = {
    ethical: 'from-blue-500 to-cyan-500',
    learn: 'from-purple-500 to-blue-500',
    earn: 'from-emerald-500 to-cyan-500'
  };

  if (loading) {
    return (
      <div className="px-4 py-6 flex items-center justify-center">
        <RefreshCw className="w-5 h-5 animate-spin text-gray-400" />
      </div>
    );
  }

  return (
    <div className="px-4 py-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="relative flex-1 mr-3">
          <Input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search videos..."
            className="bg-gray-800/40 border-gray-700 text-white text-sm"
          />
        </div>
        <button
          onClick={() => {
            resetForm();
            setShowForm(!showForm);
          }}
          className="flex items-center gap-2 bg-purple-600/50 hover:bg-purple-600 text-white text-xs font-bold px-3 py-2 rounded-lg transition-all"
        >
          <Plus className="w-3.5 h-3.5" />
          Add Video
        </button>
      </div>

      {/* Form */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-gray-800/50 rounded-2xl p-4 border border-purple-500/30"
          >
            <form onSubmit={handleSubmit} className="space-y-3">
              {/* YouTube URL/ID */}
              <div className="flex gap-3 items-start">
                <div className="flex-1">
                  <Input
                    placeholder="YouTube URL or Video ID *"
                    value={formData.youtube_video_id}
                    onChange={e => handleVideoIdChange(e.target.value)}
                    className="bg-gray-900/50 border-gray-700 text-white text-sm"
                    required
                  />
                  {fetchingMeta && <p className="text-[10px] text-cyan-400 mt-1">Fetching title from YouTube...</p>}
                </div>
                {previewThumb && (
                  <img src={previewThumb} alt="thumb" className="w-20 h-14 rounded-lg object-cover border border-gray-700 flex-shrink-0" />
                )}
              </div>

              {/* Title - optional */}
              <Input
                placeholder="Video Title (optional – auto-fetched from YouTube)"
                value={formData.title}
                onChange={e => setFormData({ ...formData, title: e.target.value })}
                className="bg-gray-900/50 border-gray-700 text-white text-sm"
              />

              {/* Description - optional */}
              <Input
                placeholder="Description (optional)"
                value={formData.description}
                onChange={e => setFormData({ ...formData, description: e.target.value })}
                className="bg-gray-900/50 border-gray-700 text-white text-sm"
              />

              {/* Thumbnail: URL or Upload */}
              <div className="space-y-1.5">
                <p className="text-[11px] text-gray-400">Custom Thumbnail (optional – uses YouTube thumbnail if empty)</p>
                <div className="flex gap-2">
                  <Input
                    placeholder="Paste thumbnail URL..."
                    value={formData.thumbnail_url}
                    onChange={e => {
                      setFormData({ ...formData, thumbnail_url: e.target.value });
                      if (e.target.value) setPreviewThumb(e.target.value);
                      else {
                        const id = extractVideoId(formData.youtube_video_id);
                        setPreviewThumb(id ? `https://img.youtube.com/vi/${id}/hqdefault.jpg` : '');
                      }
                    }}
                    className="bg-gray-900/50 border-gray-700 text-white text-sm flex-1"
                  />
                  <label className={`flex items-center gap-1.5 px-3 py-2 rounded-lg cursor-pointer text-xs font-bold transition-all ${thumbUploadLoading ? 'bg-gray-700/50 text-gray-400' : 'bg-cyan-600/40 hover:bg-cyan-600/60 text-cyan-300'}`}>
                    {thumbUploadLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
                    {thumbUploadLoading ? 'Uploading...' : 'Upload'}
                    <input type="file" accept="image/*" className="hidden" onChange={handleThumbUpload} disabled={thumbUploadLoading} />
                  </label>
                </div>
              </div>

              {/* Video Type */}
              <div className="space-y-1.5">
                <p className="text-[11px] text-gray-400">Video Type</p>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, video_type: 'reward' })}
                    className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all ${
                      formData.video_type === 'reward'
                        ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400'
                        : 'bg-gray-800/50 border-gray-700 text-gray-400 hover:border-gray-600'
                    }`}
                  >
                    🎁 Reward Video
                    <p className="font-normal text-[10px] mt-0.5 opacity-75">User watches ad → earns R{formData.credit_cost?.toFixed(2)}</p>
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, video_type: 'premium' })}
                    className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all ${
                      formData.video_type === 'premium'
                        ? 'bg-purple-500/20 border-purple-500/50 text-purple-400'
                        : 'bg-gray-800/50 border-gray-700 text-gray-400 hover:border-gray-600'
                    }`}
                  >
                    🔒 Premium Video
                    <p className="font-normal text-[10px] mt-0.5 opacity-75">Ad plays → R{formData.credit_cost?.toFixed(2)} deducted</p>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <select
                  value={formData.section}
                  onChange={e => setFormData({ ...formData, section: e.target.value })}
                  className="bg-gray-900/50 border border-gray-700 text-white text-sm rounded-lg px-3 py-2"
                >
                  <option value="learn">Learn</option>
                  <option value="ethical">Ethical</option>
                  <option value="earn">Earn</option>
                </select>
                <Input
                  type="number"
                  placeholder="Duration (min)"
                  value={formData.duration_minutes}
                  onChange={e => setFormData({ ...formData, duration_minutes: parseInt(e.target.value) })}
                  className="bg-gray-900/50 border-gray-700 text-white text-sm"
                  min="0"
                />
                <Input
                  type="number"
                  placeholder="Credit Cost"
                  value={formData.credit_cost}
                  onChange={e => setFormData({ ...formData, credit_cost: parseFloat(e.target.value) })}
                  className="bg-gray-900/50 border-gray-700 text-white text-sm"
                  step="0.01"
                  min="0"
                />
              </div>

              <textarea
                placeholder="Guide Content (markdown)"
                value={formData.guide_content}
                onChange={e => setFormData({ ...formData, guide_content: e.target.value })}
                className="bg-gray-900/50 border border-gray-700 text-white text-sm rounded-lg px-3 py-2 w-full h-24"
              />

              <div className="flex items-center gap-3">
                <label className="flex items-center gap-2 text-sm text-gray-300">
                  <input
                    type="checkbox"
                    checked={formData.is_published}
                    onChange={e => setFormData({ ...formData, is_published: e.target.checked })}
                    className="w-4 h-4"
                  />
                  Publish
                </label>
              </div>

              <div className="flex gap-2 justify-end">
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-3 py-2 bg-gray-700/50 hover:bg-gray-700 text-white text-xs font-bold rounded-lg transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3 py-2 bg-purple-600/50 hover:bg-purple-600 text-white text-xs font-bold rounded-lg transition-all flex items-center gap-2"
                >
                  <Check className="w-3.5 h-3.5" />
                  {editingId ? 'Update' : 'Create'}
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2">
        <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-2 text-center">
          <p className="text-2xl font-bold text-purple-400">{videos.length}</p>
          <p className="text-[10px] text-gray-500">Total Videos</p>
        </div>
        <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-2 text-center">
          <p className="text-2xl font-bold text-green-400">{videos.filter(v => v.is_published).length}</p>
          <p className="text-[10px] text-gray-500">Published</p>
        </div>
        <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-2 text-center">
          <p className="text-2xl font-bold text-blue-400">{videos.reduce((acc, v) => acc + (v.views_count || 0), 0)}</p>
          <p className="text-[10px] text-gray-500">Total Views</p>
        </div>
      </div>

      {/* Video List */}
      <div className="space-y-2">
        {filteredVideos.length === 0 ? (
          <p className="text-center text-gray-500 text-sm py-6">No videos found</p>
        ) : (
          filteredVideos.map((video, index) => (
            <motion.div
              key={video.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.03 }}
              className="bg-gray-800/40 rounded-xl border border-gray-700/50 overflow-hidden hover:border-purple-500/30 transition-all"
            >
              <div className="p-3 flex gap-3">
                {/* Thumbnail */}
                <div className="relative flex-shrink-0 w-20 h-20 bg-gray-900 rounded-lg overflow-hidden">
                  <img
                    src={getThumbnailUrl(video.youtube_video_id)}
                    alt={video.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                    <Play className="w-3.5 h-3.5 text-white fill-white" />
                  </div>
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <div className="flex-1 min-w-0">
                      <h4 className="text-white font-semibold text-xs truncate">{video.title}</h4>
                      <p className="text-[10px] text-gray-500 truncate">{video.youtube_video_id}</p>
                    </div>
                    <span className={`text-[10px] px-2 py-1 rounded-full bg-gradient-to-r ${sectionColors[video.section]} text-white font-bold flex-shrink-0`}>
                      {video.section}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[10px] bg-gray-700/50 text-gray-300 px-2 py-0.5 rounded">
                      R{video.credit_cost?.toFixed(2)}
                    </span>
                    <span className="text-[10px] bg-gray-700/50 text-gray-300 px-2 py-0.5 rounded">
                      {video.duration_minutes}m
                    </span>
                    <span className="text-[10px] bg-gray-700/50 text-gray-300 px-2 py-0.5 rounded">
                      {video.views_count || 0} views
                    </span>
                    {video.video_type === 'reward' ? (
                      <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/30">
                        🎁 Reward
                      </span>
                    ) : (
                      <span className="text-[10px] bg-purple-500/20 text-purple-400 px-2 py-0.5 rounded border border-purple-500/30">
                        🔒 Premium
                      </span>
                    )}
                    {video.is_published ? (
                      <span className="text-[10px] bg-green-500/20 text-green-400 px-2 py-0.5 rounded border border-green-500/30">
                        ✓ Published
                      </span>
                    ) : (
                      <span className="text-[10px] bg-gray-500/20 text-gray-400 px-2 py-0.5 rounded border border-gray-500/30">
                        Draft
                      </span>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-1.5 flex-shrink-0">
                  <button
                    onClick={() => togglePublish(video.id, video.is_published)}
                    className={`p-1.5 rounded-lg transition-all ${
                      video.is_published
                        ? 'bg-green-500/20 text-green-400 hover:bg-green-500/30'
                        : 'bg-gray-700/50 text-gray-400 hover:bg-gray-700'
                    }`}
                    title={video.is_published ? 'Unpublish' : 'Publish'}
                  >
                    {video.is_published ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                  </button>
                  <button
                    onClick={() => startEdit(video)}
                    className="p-1.5 bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 rounded-lg transition-all"
                    title="Edit"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDelete(video.id)}
                    className="p-1.5 bg-red-500/20 text-red-400 hover:bg-red-500/30 rounded-lg transition-all"
                    title="Delete"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}