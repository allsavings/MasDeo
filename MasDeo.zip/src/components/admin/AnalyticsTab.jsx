import React, { useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { TrendingUp, Users, Crown, DollarSign } from 'lucide-react';

const PLAN_PRICES = { ethical_internet: 50, learn_skills: 100, earn_online: 150, all_in_one: 250 };
const PLAN_LABELS = { ethical_internet: 'Ethical', learn_skills: 'Learn', earn_online: 'Earn', all_in_one: 'All-In-One' };

export default function AnalyticsTab({ allUsers, subscriptions, profiles }) {
  // User growth by month (last 6 months)
  const growthData = useMemo(() => {
    const months = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date();
      d.setMonth(d.getMonth() - i);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const label = d.toLocaleString('default', { month: 'short' });
      const count = allUsers.filter(u => u.created_date?.startsWith(key)).length;
      months.push({ month: label, users: count });
    }
    return months;
  }, [allUsers]);

  // Revenue by plan
  const revenueData = useMemo(() => {
    return Object.entries(PLAN_PRICES).map(([plan, price]) => ({
      plan: PLAN_LABELS[plan],
      revenue: subscriptions.filter(s => s.status === 'active' && s.plan === plan).length * price,
      subs: subscriptions.filter(s => s.status === 'active' && s.plan === plan).length,
    }));
  }, [subscriptions]);

  const totalRevenue = revenueData.reduce((s, r) => s + r.revenue, 0);
  const activeSubs = subscriptions.filter(s => s.status === 'active').length;
  const pendingSubs = subscriptions.filter(s => s.status === 'pending').length;

  const stats = [
    { label: 'Total Users', value: allUsers.length, icon: Users, color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/20' },
    { label: 'Active Subs', value: activeSubs, icon: Crown, color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20' },
    { label: 'Pending', value: pendingSubs, icon: TrendingUp, color: 'text-orange-400', bg: 'bg-orange-500/10', border: 'border-orange-500/20' },
    { label: 'Est. Revenue', value: `R${totalRevenue}`, icon: DollarSign, color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/20' },
  ];

  return (
    <div className="px-4 space-y-4 py-2">
      <div className="grid grid-cols-2 gap-2">
        {stats.map(s => (
          <div key={s.label} className={`${s.bg} border ${s.border} rounded-xl p-3`}>
            <div className="flex items-center gap-2 mb-1">
              <s.icon className={`w-4 h-4 ${s.color}`} />
              <p className="text-[10px] text-gray-500">{s.label}</p>
            </div>
            <p className={`text-xl font-bold ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* User Growth Chart */}
      <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 p-4">
        <p className="text-sm font-semibold text-white mb-3">User Growth (6 months)</p>
        <ResponsiveContainer width="100%" height={140}>
          <AreaChart data={growthData}>
            <defs>
              <linearGradient id="ug" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="month" tick={{ fill: '#6b7280', fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: '#6b7280', fontSize: 11 }} axisLine={false} tickLine={false} width={25} />
            <Tooltip contentStyle={{ background: '#1f2937', border: '1px solid #374151', borderRadius: 8, color: '#fff', fontSize: 12 }} />
            <Area type="monotone" dataKey="users" stroke="#3b82f6" fill="url(#ug)" strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Revenue by Plan */}
      <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 p-4">
        <p className="text-sm font-semibold text-white mb-3">Revenue by Plan (est.)</p>
        <ResponsiveContainer width="100%" height={140}>
          <BarChart data={revenueData} barSize={28}>
            <XAxis dataKey="plan" tick={{ fill: '#6b7280', fontSize: 10 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: '#6b7280', fontSize: 11 }} axisLine={false} tickLine={false} width={40} />
            <Tooltip contentStyle={{ background: '#1f2937', border: '1px solid #374151', borderRadius: 8, color: '#fff', fontSize: 12 }}
              formatter={(v) => [`R${v}`, 'Revenue']} />
            <Bar dataKey="revenue" fill="#f59e0b" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Plan breakdown */}
      <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 overflow-hidden">
        <div className="px-4 py-3 border-b border-gray-700/50">
          <p className="text-sm font-semibold text-white">Active Subscriptions Breakdown</p>
        </div>
        <div className="divide-y divide-gray-700/40">
          {revenueData.map(r => (
            <div key={r.plan} className="px-4 py-3 flex items-center justify-between">
              <span className="text-sm text-gray-300">{r.plan}</span>
              <div className="flex items-center gap-3">
                <span className="text-xs text-gray-500">{r.subs} subs</span>
                <span className="text-sm font-semibold text-green-400">R{r.revenue}/mo</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}