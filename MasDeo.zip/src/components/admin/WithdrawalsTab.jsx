import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import { CheckCircle, XCircle, Clock, ChevronDown, ChevronUp, Search, Banknote } from 'lucide-react';

const STATUS_COLORS = {
  pending: 'text-amber-400 bg-amber-500/20 border-amber-500/30',
  processing: 'text-blue-400 bg-blue-500/20 border-blue-500/30',
  completed: 'text-green-400 bg-green-500/20 border-green-500/30',
  rejected: 'text-red-400 bg-red-500/20 border-red-500/30',
};

export default function WithdrawalsTab({ withdrawals, onRefresh }) {
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [expanded, setExpanded] = useState(null);
  const [noteText, setNoteText] = useState({});

  const updateWithdrawal = async (id, data) => {
    await base44.entities.Withdrawal.update(id, data);
    onRefresh();
  };

  const filtered = withdrawals.filter(w => {
    const matchSearch = search === '' || w.user_email?.toLowerCase().includes(search.toLowerCase()) || w.account_holder_name?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === 'all' || w.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const pending = withdrawals.filter(w => w.status === 'pending').length;

  return (
    <div className="px-4 space-y-3">
      {/* Summary */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: 'Pending', value: withdrawals.filter(w => w.status === 'pending').length, color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20' },
          { label: 'Completed', value: withdrawals.filter(w => w.status === 'completed').length, color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/20' },
          { label: 'Total (R)', value: `R${withdrawals.filter(w => w.status === 'completed').reduce((sum, w) => sum + (w.amount || 0), 0)}`, color: 'text-cyan-400', bg: 'bg-cyan-500/10', border: 'border-cyan-500/20' },
        ].map(s => (
          <div key={s.label} className={`${s.bg} border ${s.border} rounded-xl p-2.5 text-center`}>
            <p className={`text-lg font-bold ${s.color}`}>{s.value}</p>
            <p className="text-[10px] text-gray-500">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Search + Filter */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by email or name..."
            className="bg-gray-800/40 border-gray-700 text-white text-sm pl-9" />
        </div>
        <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}
          className="bg-gray-800/40 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm">
          <option value="all">All</option>
          <option value="pending">Pending</option>
          <option value="processing">Processing</option>
          <option value="completed">Completed</option>
          <option value="rejected">Rejected</option>
        </select>
      </div>

      {filtered.length === 0 && (
        <p className="text-center text-gray-600 text-sm py-10">No withdrawal requests found.</p>
      )}

      {filtered.map((w, i) => {
        const isOpen = expanded === w.id;
        return (
          <motion.div key={w.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}
            className="bg-gray-800/40 rounded-2xl border border-gray-700/50 overflow-hidden">
            <div className="h-1 bg-gradient-to-r from-emerald-500 to-cyan-500" />
            <div className="p-4">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <p className="font-semibold text-white text-sm">{w.account_holder_name}</p>
                  <p className="text-xs text-gray-500">{w.user_email}</p>
                  <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                    <span className={`text-xs px-2 py-0.5 rounded-full border ${STATUS_COLORS[w.status]}`}>{w.status}</span>
                    <span className="text-xs font-bold text-emerald-400">R{w.amount}</span>
                    <span className="text-xs text-gray-500">{w.bank_name}</span>
                  </div>
                </div>
                <button onClick={() => setExpanded(isOpen ? null : w.id)} className="p-1.5 rounded-lg bg-gray-700/50">
                  {isOpen ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
                </button>
              </div>

              {/* Quick action buttons */}
              <div className="flex gap-2 flex-wrap">
                {w.status === 'pending' && (
                  <>
                    <button onClick={() => updateWithdrawal(w.id, { status: 'processing' })}
                      className="flex items-center gap-1 text-xs bg-blue-500/20 text-blue-400 border border-blue-500/30 px-3 py-1.5 rounded-xl hover:bg-blue-500/30 transition-colors">
                      <Clock className="w-3 h-3" /> Processing
                    </button>
                    <button onClick={() => updateWithdrawal(w.id, { status: 'rejected' })}
                      className="flex items-center gap-1 text-xs bg-red-500/20 text-red-400 border border-red-500/30 px-3 py-1.5 rounded-xl hover:bg-red-500/30 transition-colors">
                      <XCircle className="w-3 h-3" /> Reject
                    </button>
                  </>
                )}
                {w.status === 'processing' && (
                  <button onClick={() => updateWithdrawal(w.id, { status: 'completed' })}
                    className="flex items-center gap-1 text-xs bg-green-500/20 text-green-400 border border-green-500/30 px-3 py-1.5 rounded-xl hover:bg-green-500/30 transition-colors">
                    <CheckCircle className="w-3 h-3" /> Mark Paid
                  </button>
                )}
              </div>

              <AnimatePresence>
                {isOpen && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="mt-3 space-y-3">
                    <div className="bg-gray-900/50 rounded-xl p-3 text-xs space-y-1.5 text-gray-400">
                      <p className="flex items-center gap-2"><Banknote className="w-3.5 h-3.5 text-emerald-400" /> <span className="text-white font-mono">{w.account_number}</span></p>
                      <p>Bank: <span className="text-white">{w.bank_name}</span></p>
                      <p>Requested: {new Date(w.created_date).toLocaleString()}</p>
                      {w.notes && <p className="text-amber-400">Note: {w.notes}</p>}
                    </div>
                    <div className="flex gap-2">
                      <Input value={noteText[w.id] ?? w.notes ?? ''} onChange={e => setNoteText(n => ({ ...n, [w.id]: e.target.value }))}
                        placeholder="Admin note..." className="bg-gray-900/50 border-gray-700 text-white text-xs flex-1" />
                      <button onClick={() => updateWithdrawal(w.id, { notes: noteText[w.id] })}
                        className="px-3 py-1.5 bg-blue-600/50 hover:bg-blue-600 rounded-lg text-xs text-white transition-colors">Save</button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}