import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { Clock, Send, CheckCircle, AlertTriangle } from 'lucide-react';

const PLAN_LABELS = { ethical_internet: 'Ethical', learn_skills: 'Learn', earn_online: 'Earn', all_in_one: 'All In One' };

function daysUntil(dateStr) {
  if (!dateStr) return null;
  const diff = new Date(dateStr) - new Date();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

export default function RenewalsTab({ subscriptions }) {
  const [sent, setSent] = useState({});
  const [sending, setSending] = useState({});

  // Find subscriptions expiring in the next 7 days or already expired
  const expiring = useMemo(() => {
    return subscriptions
      .filter(s => s.status === 'active' && s.end_date)
      .map(s => ({ ...s, daysLeft: daysUntil(s.end_date) }))
      .filter(s => s.daysLeft !== null && s.daysLeft <= 7)
      .sort((a, b) => a.daysLeft - b.daysLeft);
  }, [subscriptions]);

  const sendReminder = async (sub) => {
    setSending(p => ({ ...p, [sub.id]: true }));
    const planLabel = PLAN_LABELS[sub.plan] || sub.plan;
    const daysLeft = sub.daysLeft;
    const msg = daysLeft <= 0
      ? `Your ${planLabel} subscription has expired. Renew now to keep access!`
      : `Your ${planLabel} subscription expires in ${daysLeft} day${daysLeft === 1 ? '' : 's'}. Renew now to avoid losing access!`;

    await base44.entities.AppNotification.create({
      title: daysLeft <= 0 ? '⚠️ Subscription Expired' : `⏰ Renew in ${daysLeft} day${daysLeft === 1 ? '' : 's'}`,
      body: msg,
      sent_by: 'admin',
      is_active: true,
    });
    setSending(p => ({ ...p, [sub.id]: false }));
    setSent(p => ({ ...p, [sub.id]: true }));
  };

  const sendAllReminders = async () => {
    for (const sub of expiring) {
      if (!sent[sub.id]) await sendReminder(sub);
    }
  };

  return (
    <div className="px-4 space-y-4 py-2">
      {/* Summary */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: 'Expiring ≤7d', value: expiring.filter(s => s.daysLeft > 0).length, color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20' },
          { label: 'Expired', value: expiring.filter(s => s.daysLeft <= 0).length, color: 'text-red-400', bg: 'bg-red-500/10', border: 'border-red-500/20' },
          { label: 'Reminded', value: Object.values(sent).filter(Boolean).length, color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/20' },
        ].map(s => (
          <div key={s.label} className={`${s.bg} border ${s.border} rounded-xl p-2.5 text-center`}>
            <p className={`text-lg font-bold ${s.color}`}>{s.value}</p>
            <p className="text-[10px] text-gray-500">{s.label}</p>
          </div>
        ))}
      </div>

      {expiring.length > 0 && (
        <button onClick={sendAllReminders}
          className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-semibold text-sm py-3 rounded-xl transition-all">
          <Send className="w-4 h-4" /> Send All Renewal Reminders ({expiring.length})
        </button>
      )}

      {expiring.length === 0 && (
        <div className="text-center py-12">
          <CheckCircle className="w-10 h-10 text-green-500 mx-auto mb-3" />
          <p className="text-gray-400 text-sm">No subscriptions expiring soon!</p>
        </div>
      )}

      <div className="space-y-2">
        {expiring.map((sub, i) => {
          const isExpired = sub.daysLeft <= 0;
          return (
            <motion.div key={sub.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}
              className={`bg-gray-800/40 rounded-2xl border overflow-hidden ${isExpired ? 'border-red-500/30' : 'border-amber-500/30'}`}>
              <div className="p-4 flex items-center justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-white truncate">{sub.user_name || sub.user_email}</p>
                  <p className="text-xs text-gray-500">{sub.user_email}</p>
                  <div className="flex items-center gap-2 mt-1.5">
                    <span className="text-xs text-gray-400">{PLAN_LABELS[sub.plan]}</span>
                    <span className={`flex items-center gap-1 text-xs font-semibold ${isExpired ? 'text-red-400' : 'text-amber-400'}`}>
                      <Clock className="w-3 h-3" />
                      {isExpired ? `Expired ${Math.abs(sub.daysLeft)}d ago` : `${sub.daysLeft}d left`}
                    </span>
                    <span className="text-xs text-gray-600">{sub.end_date}</span>
                  </div>
                </div>
                {sent[sub.id] ? (
                  <div className="flex items-center gap-1 text-xs text-green-400">
                    <CheckCircle className="w-4 h-4" /> Sent
                  </div>
                ) : (
                  <button onClick={() => sendReminder(sub)} disabled={sending[sub.id]}
                    className="flex items-center gap-1.5 text-xs bg-amber-500/20 text-amber-400 border border-amber-500/30 px-3 py-1.5 rounded-xl hover:bg-amber-500/30 transition-colors disabled:opacity-40 flex-shrink-0">
                    <Send className="w-3 h-3" /> {sending[sub.id] ? '...' : 'Remind'}
                  </button>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}