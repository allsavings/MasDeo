import { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Trash2, Upload, Loader, Eye, EyeOff, Image, Edit2, Check, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';



export default function WhatsNewTab() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null); // id of item being edited, or 'new'
  const [form, setForm] = useState({ title: '', body: '', image_url: '', is_published: true });
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const imgRef = useRef();

  const load = async () => {
    setLoading(true);
    const data = await base44.entities.PaidVersionAnnouncement.list('-sort_order', 50);
    setItems(data);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const startNew = () => {
    setForm({ title: '', body: '', image_url: '', is_published: true });
    setEditing('new');
  };

  const startEdit = (item) => {
    setForm({ title: item.title, body: item.body, image_url: item.image_url || '', is_published: item.is_published !== false });
    setEditing(item.id);
  };

  const cancel = () => { setEditing(null); };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    try {
      const { uploadFile } = await import('@/components/vpsAPI');
      const result = await uploadFile(file);
      setForm(f => ({ ...f, image_url: result.url }));
    } catch (err) {
      alert(`Upload failed: ${err.message}`);
    } finally {
      setUploading(false);
    }
  };

  const save = async () => {
    if (!form.title.trim() || !form.body.trim()) return;
    setSaving(true);
    if (editing === 'new') {
      await base44.entities.PaidVersionAnnouncement.create({
        title: form.title,
        body: form.body,
        image_url: form.image_url,
        is_published: form.is_published,
        sort_order: Date.now(),
      });
    } else {
      await base44.entities.PaidVersionAnnouncement.update(editing, {
        title: form.title,
        body: form.body,
        image_url: form.image_url,
        is_published: form.is_published,
      });
    }
    setSaving(false);
    setEditing(null);
    load();
  };

  const togglePublish = async (item) => {
    await base44.entities.PaidVersionAnnouncement.update(item.id, { is_published: !item.is_published });
    load();
  };

  const deleteItem = async (id) => {
    await base44.entities.PaidVersionAnnouncement.delete(id);
    setItems(prev => prev.filter(i => i.id !== id));
  };

  return (
    <div className="px-4 py-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold text-white">What's New — Paid Version</h2>
          <p className="text-xs text-gray-500">Shown on the /PaidVersionSetup welcome page</p>
        </div>
        <button onClick={startNew}
          className="flex items-center gap-1.5 px-3 py-2 bg-violet-600/30 border border-violet-500/50 text-violet-300 text-xs font-bold rounded-xl hover:bg-violet-600/50 transition-all">
          <Plus className="w-3.5 h-3.5" /> Add Post
        </button>
      </div>

      {/* Editor */}
      <AnimatePresence>
        {editing && (
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
            className="bg-gray-900/80 border border-violet-500/30 rounded-2xl p-4 space-y-3">
            <p className="text-xs font-bold text-violet-300 uppercase tracking-wider">
              {editing === 'new' ? '✨ New Announcement' : '✏️ Edit Announcement'}
            </p>

            <input
              value={form.title}
              onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
              placeholder="Title (e.g. New Config Available!)"
              className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-violet-500/60"
            />

            <textarea
              value={form.body}
              onChange={e => setForm(f => ({ ...f, body: e.target.value }))}
              placeholder="What's new? Describe updates, features, configs..."
              rows={4}
              className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-violet-500/60 resize-none"
            />

            {/* Image upload */}
            <div className="space-y-2">
              <input ref={imgRef} type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
              {form.image_url ? (
                <div className="relative">
                  <img src={form.image_url} alt="preview" className="w-full rounded-xl max-h-48 object-cover border border-gray-700/50" />
                  <button onClick={() => setForm(f => ({ ...f, image_url: '' }))}
                    className="absolute top-2 right-2 p-1.5 bg-black/70 rounded-lg text-white hover:bg-red-600/70 transition-colors">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <button onClick={() => imgRef.current?.click()}
                  className="w-full flex items-center justify-center gap-2 py-3 rounded-xl border border-dashed border-gray-600/60 text-gray-500 text-xs hover:border-violet-500/50 hover:text-violet-400 transition-all">
                  {uploading ? <Loader className="w-4 h-4 animate-spin" /> : <Image className="w-4 h-4" />}
                  {uploading ? 'Uploading to VPS...' : 'Upload Image'}
                </button>
              )}
              {/* Manual URL paste — primary method for media.mastersdeovex.co.za links */}
              <input
                value={form.image_url}
                onChange={e => setForm(f => ({ ...f, image_url: e.target.value }))}
                placeholder="Or paste image URL: https://media.mastersdeovex.co.za/..."
                className="w-full bg-gray-800/60 border border-gray-700/50 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-violet-500/60 placeholder-gray-600"
              />
            </div>

            {/* Published toggle */}
            <div className="flex items-center gap-3">
              <button onClick={() => setForm(f => ({ ...f, is_published: !f.is_published }))}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                  form.is_published ? 'bg-green-500/20 border-green-500/40 text-green-300' : 'bg-gray-700/40 border-gray-600/40 text-gray-500'
                }`}>
                {form.is_published ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                {form.is_published ? 'Published' : 'Hidden'}
              </button>
            </div>

            <div className="flex gap-2">
              <button onClick={save} disabled={saving || !form.title.trim() || !form.body.trim()}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-gradient-to-r from-violet-600 to-cyan-600 text-white text-sm font-bold rounded-xl disabled:opacity-40">
                {saving ? <Loader className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                {saving ? 'Saving...' : 'Save'}
              </button>
              <button onClick={cancel} className="px-4 py-2.5 bg-gray-700/50 border border-gray-600/40 text-gray-400 text-sm font-bold rounded-xl hover:bg-gray-700 transition-colors">
                Cancel
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* List */}
      {loading ? (
        <div className="flex items-center justify-center py-10 text-gray-500 gap-2">
          <Loader className="w-4 h-4 animate-spin" /> Loading...
        </div>
      ) : items.length === 0 ? (
        <div className="text-center py-10 text-gray-600 text-sm">No announcements yet. Add one above.</div>
      ) : (
        <div className="space-y-3">
          {items.map(item => (
            <motion.div key={item.id} layout
              className={`bg-gray-800/50 border rounded-2xl overflow-hidden transition-all ${item.is_published ? 'border-violet-500/20' : 'border-gray-700/30 opacity-60'}`}>
              {item.image_url && (
                <img src={item.image_url} alt="" className="w-full max-h-40 object-cover" />
              )}
              <div className="p-3">
                <div className="flex items-start justify-between gap-2 mb-1">
                  <p className="text-sm font-bold text-white leading-tight flex-1">{item.title}</p>
                  <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full border flex-shrink-0 ${item.is_published ? 'bg-green-500/20 text-green-400 border-green-500/30' : 'bg-gray-700/40 text-gray-500 border-gray-600/30'}`}>
                    {item.is_published ? 'Live' : 'Hidden'}
                  </span>
                </div>
                <p className="text-xs text-gray-400 leading-relaxed line-clamp-3">{item.body}</p>
                <div className="flex gap-2 mt-3">
                  <button onClick={() => startEdit(item)}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-blue-500/15 border border-blue-500/30 text-blue-400 text-xs font-bold hover:bg-blue-500/25 transition-all">
                    <Edit2 className="w-3 h-3" /> Edit
                  </button>
                  <button onClick={() => togglePublish(item)}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-gray-700/50 border border-gray-600/40 text-gray-400 text-xs font-bold hover:bg-gray-700 transition-all">
                    {item.is_published ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    {item.is_published ? 'Hide' : 'Show'}
                  </button>
                  <button onClick={() => deleteItem(item.id)}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-red-500/10 border border-red-500/25 text-red-400 text-xs font-bold hover:bg-red-500/20 transition-all ml-auto">
                    <Trash2 className="w-3 h-3" /> Delete
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}