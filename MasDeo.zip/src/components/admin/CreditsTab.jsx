import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import { Search, Plus, Minus, Coins } from 'lucide-react';

export default function CreditsTab({ profiles, allUsers, onRefresh }) {
  const [search, setSearch] = useState('');
  const [creditAmount, setCreditAmount] = useState({});
  const [saving, setSaving] = useState({});

  const updateCredits = async (profile, delta) => {
    const current = profile.credits || 0;
    const newVal = Math.max(0, current + delta);
    setSaving(s => ({ ...s, [profile.id]: true }));
    await base44.entities.UserProfile.update(profile.id, { credits: newVal });
    setSaving(s => ({ ...s, [profile.id]: false }));
    onRefresh();
  };

  const setCredits = async (profile, val) => {
    const parsed = parseInt(val);
    if (isNaN(parsed) || parsed < 0) return;
    setSaving(s => ({ ...s, [profile.id]: true }));
    await base44.entities.UserProfile.update(profile.id, { credits: parsed });
    setSaving(s => ({ ...s, [profile.id]: false }));
    onRefresh();
  };

  const filtered = profiles.filter(p => {
    const user = allUsers.find(u => u.email === p.created_by);
    const name = p.nickname || user?.full_name || '';
    const email = p.created_by || '';
    return search === '' || name.toLowerCase().includes(search.toLowerCase()) || email.toLowerCase().includes(search.toLowerCase());
  });

  const totalCredits = profiles.reduce((sum, p) => sum + (p.credits || 0), 0);

  return (
    <div className="px-4 space-y-3">
      {/* Summary */}
      <div className="grid grid-cols-2 gap-2">
        <div className="bg-cyan-500/10 border border-cyan-500/20 rounded-xl p-3 text-center">
          <p className="text-xl font-bold text-cyan-400">{profiles.length}</p>
          <p className="text-[10px] text-gray-500">Total Users</p>
        </div>
        <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-3 text-center">
          <p className="text-xl font-bold text-amber-400">{totalCredits}</p>
          <p className="text-[10px] text-gray-500">Credits in Circulation</p>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search user..."
          className="bg-gray-800/40 border-gray-700 text-white text-sm pl-9" />
      </div>

      {filtered.length === 0 && (
        <p className="text-center text-gray-600 text-sm py-10">No profiles found.</p>
      )}

      {filtered.map((p, i) => {
        const user = allUsers.find(u => u.email === p.created_by);
        const amount = creditAmount[p.id] ?? '';
        const isSaving = saving[p.id];
        return (
          <motion.div key={p.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}
            className="bg-gray-800/40 rounded-2xl p-4 border border-gray-700/50">
            <div className="flex items-center gap-3 mb-3">
              {p.profile_picture_url ? (
                <img src={p.profile_picture_url} alt="" className="w-10 h-10 rounded-full object-cover flex-shrink-0" />
              ) : (
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                  {(p.nickname || p.created_by || '?')[0].toUpperCase()}
                </div>
              )}
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-white text-sm truncate">{p.nickname}</p>
                <p className="text-xs text-gray-500 truncate">{p.created_by}</p>
              </div>
              <div className="flex items-center gap-1.5 bg-amber-500/10 border border-amber-500/20 rounded-xl px-3 py-1.5">
                <Coins className="w-3.5 h-3.5 text-amber-400" />
                <span className="font-bold text-amber-400 text-sm">{p.credits || 0}</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button onClick={() => updateCredits(p, -(parseInt(amount) || 10))} disabled={isSaving}
                className="flex items-center gap-1 px-3 py-1.5 bg-red-500/20 text-red-400 border border-red-500/30 rounded-xl text-xs hover:bg-red-500/30 transition-colors disabled:opacity-50">
                <Minus className="w-3 h-3" /> Deduct
              </button>
              <Input
                type="number"
                min="1"
                value={amount}
                onChange={e => setCreditAmount(c => ({ ...c, [p.id]: e.target.value }))}
                placeholder="Amount"
                className="bg-gray-900/50 border-gray-700 text-white text-xs h-8 flex-1 text-center"
              />
              <button onClick={() => updateCredits(p, parseInt(amount) || 10)} disabled={isSaving}
                className="flex items-center gap-1 px-3 py-1.5 bg-green-500/20 text-green-400 border border-green-500/30 rounded-xl text-xs hover:bg-green-500/30 transition-colors disabled:opacity-50">
                <Plus className="w-3 h-3" /> Add
              </button>
              <button onClick={() => setCredits(p, amount)} disabled={isSaving || amount === ''}
                className="px-3 py-1.5 bg-blue-600/50 hover:bg-blue-600 rounded-xl text-xs text-white transition-colors disabled:opacity-50">
                Set
              </button>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}