import React, { useState, useCallback } from 'react';
import BottomSheetSelect from '@/components/mobile/BottomSheetSelect';
import MobileErrorBoundary from '@/components/mobile/MobileErrorBoundary';
import PullToRefreshWrapper from '@/components/mobile/PullToRefreshWrapper';
import { OptimisticUpdateHandler } from '@/components/mobile/OptimisticUpdateHandler';

/**
 * MobileAdminPanel
 * Mobile-optimized version of admin controls with bottom sheet selects
 * Replaces native <select> elements and adds error handling
 */
export default function MobileAdminPanel({
  currentFilter,
  onFilterChange,
  onRefresh,
  children,
  className = '',
}) {
  const [errors, setErrors] = useState({});
  const updateHandler = new OptimisticUpdateHandler((key, errorMsg) => {
    setErrors(prev => ({
      ...prev,
      [key]: {
        message: errorMsg,
        severity: 'warning',
        persistent: false,
      },
    }));
  });

  const handleFilterChange = useCallback(async (newFilter) => {
    const key = `filter-${Date.now()}`;
    
    try {
      await updateHandler.execute(
        key,
        () => {
          // Optimistic update
          onFilterChange?.(newFilter);
        },
        async () => {
          // API call (can be added if needed)
          return newFilter;
        },
        () => {
          // Rollback if needed
        }
      );
    } catch (error) {
      console.error('Filter change failed:', error);
    }
  }, [onFilterChange, updateHandler]);

  const handleRefresh = useCallback(async () => {
    try {
      await onRefresh?.();
      setErrors(prev => {
        const next = { ...prev };
        delete next['refresh-error'];
        return next;
      });
    } catch (error) {
      setErrors(prev => ({
        ...prev,
        'refresh-error': {
          message: error?.message || 'Failed to refresh. Please try again.',
          severity: 'warning',
          persistent: false,
        },
      }));
    }
  }, [onRefresh]);

  return (
    <div className={className}>
      {/* Error notifications */}
      <MobileErrorBoundary errors={errors} onDismiss={(key) => {
        setErrors(prev => {
          const next = { ...prev };
          delete next[key];
          return next;
        });
      }} />

      {/* Pull-to-refresh wrapper */}
      <PullToRefreshWrapper onRefresh={handleRefresh}>
        {/* Filter controls */}
        <div className="sticky top-0 bg-gray-900/90 border-b border-gray-800 px-4 py-3 z-10 backdrop-blur-sm">
          <BottomSheetSelect
            value={currentFilter}
            onChange={handleFilterChange}
            options={[
              { value: 'all', label: 'All' },
              { value: 'pending', label: 'Pending' },
              { value: 'active', label: 'Active' },
              { value: 'rejected', label: 'Rejected' },
              { value: 'cancelled', label: 'Cancelled' },
            ]}
            placeholder="Filter status"
            label="Status"
            error={errors['filter']?.message}
            onError={(msg) => {
              if (msg) {
                setErrors(prev => ({
                  ...prev,
                  filter: { message: msg, severity: 'warning' },
                }));
              }
            }}
          />
        </div>

        {/* Content */}
        {children}
      </PullToRefreshWrapper>
    </div>
  );
}