import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Mail, Clock, CheckCircle, XCircle, Copy, Check, Loader, AlertCircle, RefreshCw } from 'lucide-react';
import { Input } from '@/components/ui/input';

function CopyBtn({ text, label = 'Copy' }) {
  const [copied, setCopied] = useState(false);
  const copy = () => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); };
  return (
    <button onClick={copy} className="flex items-center gap-1 text-[11px] text-gray-400 hover:text-white px-2 py-1 rounded-lg hover:bg-gray-700/50 transition-all flex-shrink-0">
      {copied ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
      {copied ? 'Copied!' : label}
    </button>
  );
}

export default function RecoveryRequestsTab() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [expandedId, setExpandedId] = useState(null);

  useEffect(() => {
    loadRequests();
  }, []);

  const loadRequests = async () => {
    setLoading(true);
    try {
      const data = await base44.entities.RecoveryRequest.list('-requested_at', 200);
      setRequests(data);
    } catch (e) {
      console.error('Failed to load recovery requests:', e);
    }
    setLoading(false);
  };

  const updateStatus = async (id, newStatus) => {
    try {
      await base44.entities.RecoveryRequest.update(id, { status: newStatus });
      loadRequests();
    } catch (e) {
      console.error('Failed to update status:', e);
    }
  };

  const filteredRequests = requests.filter(req => {
    const matchSearch = search === '' || req.email?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === 'all' || req.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const pendingCount = requests.filter(r => r.status === 'pending').length;
  const approvedCount = requests.filter(r => r.status === 'approved').length;
  const processedCount = requests.filter(r => r.status === 'processed').length;

  const statusColors = {
    pending: 'text-amber-400 bg-amber-500/20 border-amber-500/30',
    approved: 'text-blue-400 bg-blue-500/20 border-blue-500/30',
    processed: 'text-green-400 bg-green-500/20 border-green-500/30',
  };

  if (loading) return (
    <div className="flex items-center justify-center py-12">
      <div className="flex items-center gap-3 text-gray-400">
        <Loader className="w-5 h-5 animate-spin" /> Loading recovery requests...
      </div>
    </div>
  );

  return (
    <div className="px-4 space-y-4">
      {/* Stats Row */}
      <div className="grid grid-cols-4 gap-2">
        {[
          { label: 'Total', value: requests.length, color: 'text-violet-400', bg: 'bg-violet-500/10', border: 'border-violet-500/20' },
          { label: 'Pending', value: pendingCount, color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20' },
          { label: 'Approved', value: approvedCount, color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/20' },
          { label: 'Processed', value: processedCount, color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/20' },
        ].map(s => (
          <div key={s.label} className={`${s.bg} border ${s.border} rounded-xl p-2 text-center`}>
            <p className={`text-sm font-bold ${s.color}`}>{s.value}</p>
            <p className="text-[9px] text-gray-500 leading-tight">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Search & Filter */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <Input 
            value={search} 
            onChange={e => setSearch(e.target.value)} 
            placeholder="Search by email..."
            className="bg-gray-800/40 border-gray-700 text-white text-sm pl-9" 
          />
        </div>
        <select 
          value={filterStatus} 
          onChange={e => setFilterStatus(e.target.value)}
          className="bg-gray-800/40 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm"
        >
          <option value="all">All Status</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="processed">Processed</option>
        </select>
        <button 
          onClick={loadRequests}
          className="p-2 bg-gray-800/60 rounded-lg hover:bg-gray-700/60 transition-colors"
        >
          <RefreshCw className="w-4 h-4 text-gray-400" />
        </button>
      </div>

      {/* Requests List */}
      <div className="space-y-3">
        {filteredRequests.length === 0 ? (
          <div className="text-center py-10 text-gray-600 text-sm">
            <AlertCircle className="w-6 h-6 mx-auto mb-2 opacity-50" />
            No recovery requests found.
          </div>
        ) : (
          filteredRequests.map(req => {
            const isExpanded = expandedId === req.id;
            return (
              <motion.div 
                key={req.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-gray-800/40 rounded-2xl border border-gray-700/50 overflow-hidden"
              >
                <div className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Mail className="w-4 h-4 text-gray-500" />
                        <p className="font-semibold text-white text-sm truncate">{req.email}</p>
                      </div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`text-xs px-2 py-0.5 rounded-full border ${statusColors[req.status]}`}>
                          {req.status.charAt(0).toUpperCase() + req.status.slice(1)}
                        </span>
                        <span className="text-xs text-gray-500">
                          <Clock className="w-3 h-3 inline mr-1" />
                          {new Date(req.requested_at).toLocaleString()}
                        </span>
                      </div>
                    </div>
                    <button 
                      onClick={() => setExpandedId(isExpanded ? null : req.id)}
                      className="p-1.5 rounded-lg bg-gray-700/50 hover:bg-gray-600/50 transition-colors"
                    >
                      {isExpanded ? '▲' : '▼'}
                    </button>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2 flex-wrap">
                    {req.status === 'pending' && (
                      <>
                        <button 
                          onClick={() => updateStatus(req.id, 'approved')}
                          className="flex items-center gap-1 text-xs bg-blue-500/20 text-blue-400 border border-blue-500/30 px-3 py-1.5 rounded-xl hover:bg-blue-500/30 transition-colors"
                        >
                          <CheckCircle className="w-3 h-3" /> Approve
                        </button>
                        <button 
                          onClick={() => updateStatus(req.id, 'processed')}
                          className="flex items-center gap-1 text-xs bg-red-500/20 text-red-400 border border-red-500/30 px-3 py-1.5 rounded-xl hover:bg-red-500/30 transition-colors"
                        >
                          <XCircle className="w-3 h-3" /> Reject
                        </button>
                      </>
                    )}
                    {req.status === 'approved' && (
                      <button 
                        onClick={() => updateStatus(req.id, 'processed')}
                        className="flex items-center gap-1 text-xs bg-green-500/20 text-green-400 border border-green-500/30 px-3 py-1.5 rounded-xl hover:bg-green-500/30 transition-colors"
                      >
                        <CheckCircle className="w-3 h-3" /> Mark Processed
                      </button>
                    )}
                  </div>

                  {/* Expanded Section */}
                  {isExpanded && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-4 pt-4 border-t border-gray-700/40 space-y-3"
                    >
                      <div className="bg-gray-900/50 rounded-xl p-3 text-xs space-y-1 text-gray-400">
                        <p><strong>Email:</strong> {req.email}</p>
                        <p><strong>Status:</strong> {req.status.charAt(0).toUpperCase() + req.status.slice(1)}</p>
                        <p><strong>Requested:</strong> {new Date(req.requested_at).toLocaleString()}</p>
                        {req.created_date && <p><strong>Created:</strong> {new Date(req.created_date).toLocaleString()}</p>}
                      </div>

                      {/* OTP Recovery Info */}
                      <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-3">
                        <p className="text-xs font-semibold text-blue-400 mb-2">Secure OTP Recovery</p>
                        <p className="text-[10px] text-gray-400">
                          Users will receive an OTP code via email to securely reset their password. No manual intervention required.
                        </p>
                      </div>
                    </motion.div>
                  )}
                </div>
              </motion.div>
            );
          })
        )}
      </div>
    </div>
  );
}