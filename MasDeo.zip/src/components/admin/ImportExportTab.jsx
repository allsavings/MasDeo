import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import {
  Download, Upload, CheckCircle, AlertTriangle, Loader,
  Database, FileJson, Trash2, RefreshCw
} from 'lucide-react';

const ENTITIES = [
  { key: 'UserProfile', label: 'User Profiles', color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/20' },
  { key: 'Subscription', label: 'Subscriptions', color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20' },
  { key: 'CreatorProfile', label: 'Creator Profiles', color: 'text-purple-400', bg: 'bg-purple-500/10', border: 'border-purple-500/20' },
  { key: 'CreatorSettings', label: 'Creator Settings', color: 'text-pink-400', bg: 'bg-pink-500/10', border: 'border-pink-500/20' },
  { key: 'Follow', label: 'Follows', color: 'text-cyan-400', bg: 'bg-cyan-500/10', border: 'border-cyan-500/20' },
  { key: 'Withdrawal', label: 'Withdrawals', color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20' },
];

export default function ImportExportTab() {
  const [exporting, setExporting] = useState(false);
  const [importing, setImporting] = useState(false);
  const [exportStats, setExportStats] = useState(null);
  const [importResult, setImportResult] = useState(null);
  const [importPreview, setImportPreview] = useState(null);
  const [importFile, setImportFile] = useState(null);
  const [error, setError] = useState('');
  const fileRef = useRef();

  const handleExport = async () => {
    setExporting(true);
    setError('');
    setExportStats(null);
    try {
      const results = await Promise.all(
        ENTITIES.map(e => base44.entities[e.key].list('-created_date', 500))
      );
      const data = {};
      const stats = {};
      ENTITIES.forEach((e, i) => {
        data[e.key] = results[i];
        stats[e.key] = results[i].length;
      });

      const exportPayload = {
        version: '1.0',
        app: 'MastersDeoVex',
        exported_at: new Date().toISOString(),
        data,
      };

      const blob = new Blob([JSON.stringify(exportPayload, null, 2)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `MastersDeoVex_data_${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      setExportStats(stats);
    } catch (e) {
      setError('Export failed: ' + e.message);
    }
    setExporting(false);
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setImportFile(file);
    setImportResult(null);
    setError('');

    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const parsed = JSON.parse(ev.target.result);
        if (!parsed.data || !parsed.app) {
          setError('Invalid file format. Please use a file exported from this app.');
          setImportPreview(null);
          return;
        }
        // Build preview counts
        const preview = {};
        ENTITIES.forEach(e => {
          preview[e.key] = (parsed.data[e.key] || []).length;
        });
        setImportPreview({ parsed, preview });
      } catch {
        setError('Could not read file. Make sure it is a valid JSON export.');
        setImportPreview(null);
      }
    };
    reader.readAsText(file);
  };

  const handleImport = async () => {
    if (!importPreview) return;
    setImporting(true);
    setError('');
    setImportResult(null);

    const { parsed } = importPreview;
    const results = {};

    try {
      for (const entity of ENTITIES) {
        const records = parsed.data[entity.key] || [];
        if (records.length === 0) { results[entity.key] = 0; continue; }

        // For each record, strip built-in fields and upsert
        let created = 0;
        for (const record of records) {
          const { id, created_date, updated_date, ...rest } = record;
          try {
            await base44.entities[entity.key].create(rest);
            created++;
          } catch {
            // skip duplicates/errors silently
          }
        }
        results[entity.key] = created;
      }
      setImportResult(results);
      setImportPreview(null);
      setImportFile(null);
      if (fileRef.current) fileRef.current.value = '';
    } catch (e) {
      setError('Import failed: ' + e.message);
    }
    setImporting(false);
  };

  const totalExported = exportStats ? Object.values(exportStats).reduce((a, b) => a + b, 0) : 0;
  const totalImported = importResult ? Object.values(importResult).reduce((a, b) => a + b, 0) : 0;

  return (
    <div className="px-4 space-y-4 py-2">
      {/* Info Banner */}
      <div className="bg-gradient-to-r from-indigo-600/20 to-purple-600/20 rounded-2xl p-4 border border-indigo-500/30">
        <div className="flex items-center gap-3 mb-2">
          <Database className="w-5 h-5 text-indigo-400" />
          <h3 className="font-bold text-white text-sm">Data Sync / Backup</h3>
        </div>
        <p className="text-xs text-gray-400 leading-relaxed">
          Export all your app data to a JSON file. Share it with anyone who cloned this app — they can import it to sync all user profiles, subscriptions, and settings instantly.
        </p>
      </div>

      {/* EXPORT */}
      <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 overflow-hidden">
        <div className="px-4 py-3 border-b border-gray-700/50 flex items-center gap-2">
          <Download className="w-4 h-4 text-cyan-400" />
          <span className="font-semibold text-white text-sm">Export Data</span>
        </div>
        <div className="p-4 space-y-3">
          <div className="grid grid-cols-2 gap-2">
            {ENTITIES.map(e => (
              <div key={e.key} className={`${e.bg} border ${e.border} rounded-xl px-3 py-2 flex items-center justify-between`}>
                <span className={`text-xs font-medium ${e.color}`}>{e.label}</span>
                {exportStats && (
                  <span className="text-xs font-bold text-white">{exportStats[e.key]}</span>
                )}
              </div>
            ))}
          </div>

          {exportStats && (
            <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-2 bg-green-500/10 border border-green-500/20 rounded-xl px-3 py-2">
              <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
              <p className="text-xs text-green-400">Exported <span className="font-bold">{totalExported}</span> records successfully. File downloaded.</p>
            </motion.div>
          )}

          <button onClick={handleExport} disabled={exporting}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:opacity-60 text-white font-semibold text-sm py-3 rounded-xl transition-all">
            {exporting ? <Loader className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
            {exporting ? 'Exporting...' : 'Export All Data'}
          </button>
        </div>
      </div>

      {/* IMPORT */}
      <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 overflow-hidden">
        <div className="px-4 py-3 border-b border-gray-700/50 flex items-center gap-2">
          <Upload className="w-4 h-4 text-emerald-400" />
          <span className="font-semibold text-white text-sm">Import Data</span>
        </div>
        <div className="p-4 space-y-3">
          {/* File picker */}
          <div
            onClick={() => fileRef.current?.click()}
            className="border-2 border-dashed border-gray-600 hover:border-emerald-500/50 rounded-xl p-6 text-center cursor-pointer transition-all group"
          >
            <FileJson className="w-8 h-8 text-gray-500 group-hover:text-emerald-400 mx-auto mb-2 transition-colors" />
            <p className="text-sm text-gray-400 group-hover:text-white transition-colors">
              {importFile ? importFile.name : 'Click to select export file (.json)'}
            </p>
            <p className="text-xs text-gray-600 mt-1">Only files exported from this app</p>
          </div>
          <input ref={fileRef} type="file" accept=".json" onChange={handleFileSelect} className="hidden" />

          {/* Preview */}
          {importPreview && (
            <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}
              className="bg-gray-900/60 rounded-xl p-3 border border-gray-700/50 space-y-2">
              <p className="text-xs font-semibold text-white mb-2">Preview — records to import:</p>
              <div className="grid grid-cols-2 gap-1.5">
                {ENTITIES.map(e => (
                  <div key={e.key} className="flex items-center justify-between bg-gray-800/60 rounded-lg px-2.5 py-1.5">
                    <span className={`text-[11px] ${e.color}`}>{e.label}</span>
                    <span className="text-xs font-bold text-white">{importPreview.preview[e.key]}</span>
                  </div>
                ))}
              </div>
              <p className="text-[10px] text-gray-500 mt-1">
                * Existing records won't be overwritten. Only new records are added.
              </p>
            </motion.div>
          )}

          {/* Import result */}
          {importResult && (
            <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-2 bg-green-500/10 border border-green-500/20 rounded-xl px-3 py-2">
              <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
              <p className="text-xs text-green-400">Imported <span className="font-bold">{totalImported}</span> records successfully.</p>
            </motion.div>
          )}

          {error && (
            <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">
              <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
              <p className="text-xs text-red-400">{error}</p>
            </div>
          )}

          <button
            onClick={handleImport}
            disabled={!importPreview || importing}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 disabled:opacity-40 text-white font-semibold text-sm py-3 rounded-xl transition-all">
            {importing ? <Loader className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
            {importing ? 'Importing...' : 'Import Data'}
          </button>
        </div>
      </div>
    </div>
  );
}