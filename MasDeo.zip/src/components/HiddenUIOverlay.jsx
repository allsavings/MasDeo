import React from 'react';

/**
 * HiddenUIOverlay — now a no-op.
 * The AdView handles its own skip/close UX.
 * This component is kept as a named export so existing imports don't break.
 */
export default function HiddenUIOverlay({ isAdActive, countdown }) {
  return null;
}