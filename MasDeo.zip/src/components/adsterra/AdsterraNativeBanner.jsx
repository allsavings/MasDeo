import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';

const AUTH_PATHS = ['/welcome', '/auth', '/reset-password'];

export default function AdsterraNativeBanner() {
  const location = useLocation();
  const isAuthPath = AUTH_PATHS.some(p => location.pathname.startsWith(p));

  const [adsEnabled, setAdsEnabled] = useState(() => {
    return localStorage.getItem('global_ads_enabled') !== 'false';
  });

  useEffect(() => {
    const handleStorageChange = () => {
      setAdsEnabled(localStorage.getItem('global_ads_enabled') !== 'false');
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  useEffect(() => {
    if (isAuthPath || !adsEnabled) return;

    const script = document.createElement('script');
    script.src = 'https://pl29338408.profitablecpmratenetwork.com/161e7d20534337b63eeba8ca462f87cb/invoke.js';
    script.async = true;
    script.setAttribute('data-cfasync', 'false');
    document.body.appendChild(script);

    return () => {
      if (script.parentNode) script.parentNode.removeChild(script);
    };
  }, [adsEnabled, isAuthPath]);

  if (isAuthPath || !adsEnabled) return null;

  return <div id="container-161e7d20534337b63eeba8ca462f87cb" />;
}