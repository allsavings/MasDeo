import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';

const AUTH_PATHS = ['/welcome', '/auth', '/reset-password'];

export default function AdsterraGlobalScripts() {
  const location = useLocation();
  const isAuthPath = AUTH_PATHS.some(p => location.pathname.startsWith(p));

  const [adsEnabled, setAdsEnabled] = useState(() => {
    return localStorage.getItem('global_ads_enabled') !== 'false';
  });

  useEffect(() => {
    const handleStorageChange = () => {
      setAdsEnabled(localStorage.getItem('global_ads_enabled') !== 'false');
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  useEffect(() => {
    const removeScripts = () => {
      const popunderScript = document.querySelector('script[src*="b84f179556bdb01d6d315182e224adcd"]');
      const socialScript = document.querySelector('script[src*="3ab52daa8ea2567dee8b2832498d7a40"]');
      if (popunderScript?.parentNode) popunderScript.parentNode.removeChild(popunderScript);
      if (socialScript?.parentNode) socialScript.parentNode.removeChild(socialScript);
    };

    if (isAuthPath || !adsEnabled) {
      removeScripts();
      return;
    }

    const popunderScript = document.createElement('script');
    popunderScript.src = 'https://pl29338360.profitablecpmratenetwork.com/b8/4f/17/b84f179556bdb01d6d315182e224adcd.js';
    popunderScript.async = true;
    document.body.appendChild(popunderScript);

    const socialScript = document.createElement('script');
    socialScript.src = 'https://pl29338410.profitablecpmratenetwork.com/3a/b5/2d/3ab52daa8ea2567dee8b2832498d7a40.js';
    socialScript.async = true;
    document.body.appendChild(socialScript);

    return () => {
      if (popunderScript.parentNode) popunderScript.parentNode.removeChild(popunderScript);
      if (socialScript.parentNode) socialScript.parentNode.removeChild(socialScript);
    };
  }, [adsEnabled, isAuthPath]);

  return null;
}