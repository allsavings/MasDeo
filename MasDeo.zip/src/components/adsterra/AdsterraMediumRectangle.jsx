import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';

const AUTH_PATHS = ['/welcome', '/auth', '/reset-password'];

export default function AdsterraMediumRectangle() {
  const location = useLocation();
  const isAuthPath = AUTH_PATHS.some(p => location.pathname.startsWith(p));

  const [adsEnabled, setAdsEnabled] = useState(() => {
    return localStorage.getItem('global_ads_enabled') !== 'false';
  });

  useEffect(() => {
    const handleStorageChange = () => {
      setAdsEnabled(localStorage.getItem('global_ads_enabled') !== 'false');
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  useEffect(() => {
    if (isAuthPath || !adsEnabled) return;

    window.atOptions = {
      key: '856bc780a6de06c30b4a4f4c22e7071a',
      format: 'iframe',
      height: 250,
      width: 300,
      params: {}
    };

    const script = document.createElement('script');
    script.src = 'https://www.highperformanceformat.com/856bc780a6de06c30b4a4f4c22e7071a/invoke.js';
    script.async = true;
    document.body.appendChild(script);

    return () => {
      if (script.parentNode) script.parentNode.removeChild(script);
      delete window.atOptions;
    };
  }, [adsEnabled, isAuthPath]);

  if (isAuthPath || !adsEnabled) return null;

  return <div style={{ display: 'flex', justifyContent: 'center', margin: '1rem 0' }} />;
}