export const serviceSections = {
  cheap_data: {
    title: "Cheap Data Deals",
    iconName: "Smartphone",
    colorClass: "from-cyan-500 to-blue-500",
    borderColor: "border-cyan-500/30",
    bgColor: "bg-cyan-500/10",
    description: "Best prepaid & postpaid data deals in South Africa",
    items: [
      {
        name: "Telkom Mobile",
        link: "https://www.telkom.co.za/mobile",
        facts: [
          "Offers some of the cheapest data bundles in SA — as low as R5 for 50MB.",
          "Monthly Smart bundles include free social media data (WhatsApp, Twitter, Facebook).",
          "Free Unlimited Night Surfer data from 12am–5am on selected plans.",
          "Night Surfer is great for downloading files, updates or streaming late at night for free."
        ]
      },
      {
        name: "MTN",
        link: "https://www.mtn.co.za",
        facts: [
          "MTN offers flexible daily & weekly data bundles starting from R10.",
          "MTN Pulse (for youth) gives bonus data and discounted rates.",
          "XtraTime data loans available when you run out mid-month.",
          "MTN Gig bundles give large data at competitive rates — best for heavy users."
        ]
      },
      {
        name: "Vodacom",
        link: "https://www.vodacom.co.za",
        facts: [
          "Smart data plans from R49/month with rollover — unused data carries over.",
          "Vodacom offers social bundles (WhatsApp, Facebook) for very cheap.",
          "Great USSD codes: *135# to check balance, *135*2# to buy bundles fast.",
          "Vodacom prepaid has 'Just4You' personalised deals — check yours in the app."
        ]
      },
      {
        name: "Cell C",
        link: "https://www.cellc.co.za",
        facts: [
          "Cell C has some of the most affordable data bundles for prepaid users.",
          "Offers unlimited WhatsApp on selected plans.",
          "Cell C uses multiple networks (MTN roaming) so coverage is wide.",
          "Monthly 1GB bundles available for under R50."
        ]
      }
    ]
  },
  wifi_fibre: {
    title: "Affordable WiFi & Fibre",
    iconName: "Wifi",
    colorClass: "from-blue-500 to-indigo-500",
    borderColor: "border-blue-500/30",
    bgColor: "bg-blue-500/10",
    description: "Best home internet & fibre deals in South Africa",
    items: [
      {
        name: "Afrihost",
        link: "https://www.afrihost.com/fibre",
        facts: [
          "One of SA's most popular ISPs — known for great value and reliability.",
          "Fibre plans start from around R299/month for 10Mbps uncapped.",
          "No contracts on most plans — you can cancel any month.",
          "Very fast setup support and easy online account management.",
          "Afrihost also offers ADSL and LTE plans if fibre isn't in your area yet."
        ]
      },
      {
        name: "Telkom Fibre",
        link: "https://www.telkom.co.za/fibre",
        facts: [
          "Telkom's own fibre network — widely available across SA cities.",
          "Uncapped fibre from R399/month — often has promotional deals.",
          "Bundle with Telkom landline for extra savings.",
          "Good for households that need stable speeds for streaming or work from home."
        ]
      },
      {
        name: "Vox",
        link: "https://www.vox.co.za",
        facts: [
          "Vox offers fibre, LTE and wireless broadband options.",
          "Competitive pricing with 24-hour support.",
          "Available on multiple fibre networks (Openserve, Vumatel, etc.).",
          "Good for businesses and home users who need guaranteed uptime."
        ]
      },
      {
        name: "Rain",
        link: "https://rain.co.za",
        facts: [
          "Rain offers unlimited 4G LTE and 5G WiFi at home — no fibre needed.",
          "5G home WiFi from R479/month — great where fibre is unavailable.",
          "Use any WiFi router — just plug in Rain's SIM device.",
          "Night speeds on 5G can be very fast — perfect for overnight downloads."
        ]
      }
    ]
  },
  rewards: {
    title: "Rewards Platforms",
    iconName: "Gift",
    colorClass: "from-amber-500 to-orange-500",
    borderColor: "border-amber-500/30",
    bgColor: "bg-amber-500/10",
    description: "Earn cashback and rewards on everyday spending",
    items: [
      {
        name: "eBucks (FNB)",
        link: "https://www.ebucks.com",
        facts: [
          "FNB's rewards program — earn eBucks on every transaction.",
          "Use eBucks to buy airtime, data, groceries, fuel and flights.",
          "The more you bank with FNB, the higher your eBucks level (1–5).",
          "Level 5 customers can earn up to 40% back at Checkers and Pick n Pay."
        ]
      },
      {
        name: "Capitec Live Better",
        link: "https://www.capitecbank.co.za/rewards",
        facts: [
          "Earn cashback at partner stores just by swiping your Capitec card.",
          "Partners include Clicks, Dis-Chem, Pick n Pay and more.",
          "No fees to join — it's automatically part of your Capitec account.",
          "Cashback is paid directly into your savings account — simple and fast."
        ]
      },
      {
        name: "Smart Shopper (Pick n Pay)",
        link: "https://www.pnp.co.za/smart-shopper",
        facts: [
          "Earn points every time you shop at Pick n Pay.",
          "Get personalised deals and discounts based on what you buy.",
          "Redeem points for free groceries — no minimum spend needed.",
          "Link your Smart Shopper card to the app to track points easily."
        ]
      },
      {
        name: "Clicks ClubCard",
        link: "https://www.clicks.co.za/clubcard",
        facts: [
          "Earn points on every purchase at Clicks stores.",
          "Get 2% back in ClubCard points on most items.",
          "Use points to buy medicines, beauty products and more.",
          "Regular ClubCard members get exclusive sale prices not available to others."
        ]
      },
      {
        name: "mPaisa",
        link: "https://www.mpaisa.co.za",
        facts: [
          "Earn rewards by completing simple online tasks and surveys.",
          "Cash out directly to your bank account or mobile wallet.",
          "Available to South African users — no special skills needed.",
          "Great for earning extra income in your spare time."
        ]
      },
      {
        name: "Back Fight",
        link: "https://www.backfight.co.za",
        facts: [
          "Cashback and rewards platform for everyday online purchases.",
          "Earn back a percentage on every qualifying transaction.",
          "Supports multiple SA retailers and online stores.",
          "Sign up free and start earning cashback immediately."
        ]
      },
      {
        name: "Maholla",
        link: "https://www.maholla.co.za",
        facts: [
          "SA-based rewards app that pays you for shopping and engaging.",
          "Earn points redeemable for airtime, data and vouchers.",
          "Complete brand challenges to boost your earnings.",
          "Available on Android — free to download and join."
        ]
      },
      {
        name: "OM Rewards",
        link: "https://www.oldmutual.co.za/rewards",
        facts: [
          "Old Mutual's loyalty rewards programme.",
          "Earn rewards points on insurance, savings and investments.",
          "Redeem points for travel, shopping vouchers and more.",
          "The more Old Mutual products you hold, the more you earn."
        ]
      },
      {
        name: "Zlto",
        link: "https://www.zlto.co",
        facts: [
          "Digital wallet and rewards token for youth in Africa.",
          "Earn Zlto by completing community tasks, learning and volunteering.",
          "Redeem Zlto for airtime, data, food vouchers and more.",
          "Backed by multiple NGOs and social impact organisations."
        ]
      },
      {
        name: "Binance",
        link: "https://www.binance.com",
        facts: [
          "World's largest crypto exchange — earn by trading or staking.",
          "Binance Earn lets you put your crypto to work and earn interest.",
          "Referral programme pays you a percentage of your friends' trading fees.",
          "Available in SA — supports ZAR deposits via bank transfer."
        ]
      }
    ]
  },
  protection: {
    title: "Protection",
    iconName: "ShieldCheck",
    colorClass: "from-red-500 to-rose-500",
    borderColor: "border-red-500/30",
    bgColor: "bg-red-500/10",
    description: "Free tools to keep your device and data safe",
    items: [
      {
        name: "Avast Mobile Security (Free)",
        link: "https://www.avast.com/free-mobile-security",
        facts: [
          "Free antivirus and phone protection for Android.",
          "Scans apps and files for malware automatically.",
          "Includes a free VPN, app lock and photo vault.",
          "Alerts you when connected to unsecured or fake WiFi networks."
        ]
      },
      {
        name: "Bitdefender Antivirus (Free)",
        link: "https://www.bitdefender.com/solutions/free.html",
        facts: [
          "Lightweight antivirus that won't slow your phone down.",
          "Scans for viruses, ransomware and spyware.",
          "Automatic scanning in the background — no manual action needed.",
          "Trusted by over 500 million users worldwide."
        ]
      },
      {
        name: "Malwarebytes",
        link: "https://www.malwarebytes.com/mobile",
        facts: [
          "Specialises in removing malware that antivirus apps miss.",
          "Free version does on-demand scans whenever you want.",
          "Detects adware, ransomware and suspicious apps.",
          "Great as a second layer of security alongside your main antivirus."
        ]
      },
      {
        name: "Google Password Manager",
        link: "https://passwords.google.com",
        facts: [
          "Free and built into Chrome and Android — no download needed.",
          "Saves and fills passwords automatically across all your devices.",
          "Alerts you if any of your saved passwords were exposed in a data breach.",
          "Use strong unique passwords for every site — Google creates them for you."
        ]
      }
    ]
  },
  ai_tools: {
    title: "Best Free AI Tools",
    iconName: "Bot",
    colorClass: "from-violet-500 to-purple-600",
    borderColor: "border-violet-500/30",
    bgColor: "bg-violet-500/10",
    description: "Powerful AI tools available for free right now",
    items: [
      {
        name: "ChatGPT (OpenAI)",
        link: "https://chat.openai.com",
        facts: [
          "The world's most popular AI assistant — free to use with a basic account.",
          "Can write essays, code, emails, business plans and more in seconds.",
          "Ask it anything — it explains complex topics in simple language.",
          "Great for students: summarise textbooks, get study notes, get exam help."
        ]
      },
      {
        name: "Google Gemini",
        link: "https://gemini.google.com",
        facts: [
          "Google's AI built into Android — access it directly from your phone.",
          "Can answer questions, help plan your day, draft messages and more.",
          "Integrated with Gmail, Docs and Search for smarter results.",
          "Free to use — just sign in with your Google account."
        ]
      },
      {
        name: "Canva AI (Magic Write)",
        link: "https://www.canva.com",
        facts: [
          "Canva is a free design tool — AI features included.",
          "Magic Write generates text for your designs — captions, bios, posts.",
          "Create logos, flyers, CVs and social media posts with AI suggestions.",
          "Free plan gives access to thousands of templates and AI tools."
        ]
      },
      {
        name: "Microsoft Copilot",
        link: "https://copilot.microsoft.com",
        facts: [
          "Microsoft's free AI assistant — powered by GPT-4.",
          "Access it in Bing, Edge browser or via the Copilot app on Android.",
          "Can generate images, write content and answer questions for free.",
          "Great for research — gives answers with real web sources cited."
        ]
      },
      {
        name: "Perplexity AI",
        link: "https://www.perplexity.ai",
        facts: [
          "AI-powered search engine — gives direct answers with sources.",
          "Better than Google for complex questions that need explained answers.",
          "Free to use — no account needed to get started.",
          "Great for research, fact-checking and learning new topics quickly."
        ]
      }
    ]
  },
  education: {
    title: "Education",
    iconName: "GraduationCap",
    colorClass: "from-emerald-500 to-teal-500",
    borderColor: "border-emerald-500/30",
    bgColor: "bg-emerald-500/10",
    description: "Free world-class learning platforms and resources",
    items: [
      {
        name: "Khan Academy",
        link: "https://www.khanacademy.org",
        facts: [
          "100% free — covers Maths, Science, History, Programming and more.",
          "Designed for learners of all ages — from Grade 1 to university level.",
          "Tracks your progress and gives you personalised practice exercises.",
          "Used by over 130 million people worldwide as a free school alternative."
        ]
      },
      {
        name: "Coursera (Free Audit)",
        link: "https://www.coursera.org",
        facts: [
          "Courses from top universities like Harvard, Stanford and Google — for free.",
          "Audit any course for free — you get all lessons but no certificate.",
          "Pay only if you want an official certificate for your CV.",
          "Topics include IT, Business, Data Science, Design and more."
        ]
      },
      {
        name: "YouTube Learning",
        link: "https://www.youtube.com/learning",
        facts: [
          "YouTube has millions of free tutorials on literally any skill.",
          "Search 'learn [skill] for beginners' to find structured playlists.",
          "Channels like freeCodeCamp, Traversy Media, Ali Abdaal are gold.",
          "Download videos offline using YouTube Premium or a downloader app."
        ]
      },
      {
        name: "Codecademy",
        link: "https://www.codecademy.com",
        facts: [
          "Best free platform to learn coding from scratch — no experience needed.",
          "Interactive lessons — you type real code in the browser and see results.",
          "Free tier includes Python, HTML, CSS, JavaScript and SQL basics.",
          "Trusted by millions of beginners who got their first tech job from here."
        ]
      },
      {
        name: "edX",
        link: "https://www.edx.org",
        facts: [
          "Like Coursera — free courses from real universities worldwide.",
          "Topics include Cybersecurity, AI, Business, Finance and more.",
          "Audit for free — pay only if you need a verified certificate.",
          "Microsoft, IBM and MIT offer free professional courses here."
        ]
      }
    ]
  }
};