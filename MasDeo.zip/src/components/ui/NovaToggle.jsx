import React from 'react';
import { motion } from 'framer-motion';

export default function NovaToggle({ isActive, onToggle, activeColorClass = "from-cyan-400 to-blue-500", size = "md" }) {
  const isSm = size === 'sm';

  return (
    <div
      onClick={onToggle}
      className={`flex items-center rounded-full cursor-pointer transition-all duration-300 border ${
        isSm ? 'w-10 h-5 p-0.5' : 'w-14 h-7 p-1'
      } ${isActive ? 'bg-gray-800 border-gray-700' : 'bg-gray-900 border-gray-800'}`}
    >
      <motion.div
        layout
        transition={{ type: "spring", stiffness: 700, damping: 30 }}
        className={`rounded-full flex items-center justify-center shadow-lg ${
          isSm ? 'w-3.5 h-3.5' : 'w-5 h-5'
        } ${isActive ? `bg-gradient-to-r ${activeColorClass}` : 'bg-gray-700'}`}
        style={{ marginLeft: isActive ? 'auto' : '0' }}
      >
        <motion.div
          initial={false}
          animate={{ rotate: isActive ? 360 : 0 }}
          transition={{ duration: 0.4 }}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill={isActive ? "currentColor" : "none"}
            stroke="currentColor"
            strokeWidth={isActive ? "0" : "2"}
            className={`${isSm ? 'w-2 h-2' : 'w-3 h-3'} ${isActive ? 'text-white' : 'text-gray-400'}`}
          >
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
          </svg>
        </motion.div>
      </motion.div>
    </div>
  );
}