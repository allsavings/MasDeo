// Masters | DeoVex — PWA Install & Notification Permission Banner
import { useState, useEffect } from 'react';
import { Bell, X, Smartphone } from 'lucide-react';
import { useNotifications } from '@/hooks/useNotifications';

const ICON = 'https://media.base44.com/images/public/69fbae3c9d10c5e17ae8e806/f423cbc89_Icon-512.png';

function isStandalone() {
  return window.matchMedia('(display-mode: standalone)').matches
    || window.navigator.standalone === true;
}

export default function PWAInstallBanner() {
  const { permission, supported, requestPermission } = useNotifications();
  const [deferredPrompt, setDeferredPrompt] = useState(null);
  const [showInstall, setShowInstall] = useState(false);
  const [showNotifBanner, setShowNotifBanner] = useState(false);
  // Show "notifications are off" warning when in PWA but permission denied/default
  const [showNotifOff, setShowNotifOff] = useState(false);

  // Register install prompt listener once on mount
  useEffect(() => {
    const handler = (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
      if (!isStandalone()) setShowInstall(true);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  // Re-evaluate notification banners whenever permission or supported changes
  useEffect(() => {
    if (!supported) return;
    const standalone = isStandalone();
    if (!standalone) return; // notification banners only for PWA users

    if (permission === 'default') {
      const wasDismissed = sessionStorage.getItem('notif_banner_dismissed');
      if (!wasDismissed) setShowNotifBanner(true);
      else setShowNotifBanner(false);
    } else {
      setShowNotifBanner(false);
    }

    if (permission === 'denied') {
      const wasDismissed = sessionStorage.getItem('notif_off_dismissed');
      if (!wasDismissed) setShowNotifOff(true);
      else setShowNotifOff(false);
    } else {
      setShowNotifOff(false);
    }
  }, [supported, permission]);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    setDeferredPrompt(null);
    setShowInstall(false);
  };

  const handleNotifRequest = async () => {
    await requestPermission();
    setShowNotifBanner(false);
    sessionStorage.setItem('notif_banner_dismissed', '1');
  };

  const dismissNotif = () => {
    setShowNotifBanner(false);
    sessionStorage.setItem('notif_banner_dismissed', '1');
  };

  const dismissNotifOff = () => {
    setShowNotifOff(false);
    sessionStorage.setItem('notif_off_dismissed', '1');
  };

  if (!showInstall && !showNotifBanner && !showNotifOff) return null;

  return (
    <div className="fixed bottom-20 left-4 right-4 z-[8000] space-y-2">

      {/* Notifications are OFF — show warning in PWA */}
      {showNotifOff && (
        <div className="bg-[#13131f] border border-red-500/40 rounded-2xl px-4 py-3 flex items-center gap-3 shadow-xl">
          <div className="w-9 h-9 rounded-xl bg-red-500/20 flex items-center justify-center flex-shrink-0">
            <Bell className="w-5 h-5 text-red-400" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-bold text-white">Notifications are OFF</p>
            <p className="text-[10px] text-gray-400">Go to your phone settings → App info → Enable notifications to stay updated</p>
          </div>
          <button onClick={dismissNotifOff} className="p-1 text-gray-600 hover:text-gray-400 flex-shrink-0">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Enable Notifications — PWA, permission not yet asked */}
      {showNotifBanner && (
        <div className="bg-[#13131f] border border-amber-500/40 rounded-2xl px-4 py-3 flex items-center gap-3 shadow-xl">
          <img src={ICON} alt="icon" className="w-9 h-9 rounded-xl flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-xs font-bold text-white">Enable Notifications</p>
            <p className="text-[10px] text-gray-400">Get alerts for new VPN configs & updates</p>
          </div>
          <button onClick={handleNotifRequest}
            className="px-3 py-1.5 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-bold flex-shrink-0">
            Allow
          </button>
          <button onClick={dismissNotif} className="p-1 text-gray-600 hover:text-gray-400 flex-shrink-0">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Install App Banner — shown only in browser (not standalone) */}
      {showInstall && (
        <div className="bg-[#13131f] border border-cyan-500/40 rounded-2xl px-4 py-3 flex items-center gap-3 shadow-xl">
          <div className="w-9 h-9 rounded-xl bg-cyan-500/20 flex items-center justify-center flex-shrink-0">
            <Smartphone className="w-5 h-5 text-cyan-400" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-bold text-white">Install Masters | DeoVex</p>
            <p className="text-[10px] text-gray-400">Install the app for faster access & notifications</p>
          </div>
          <button onClick={handleInstall}
            className="px-3 py-1.5 rounded-xl bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 text-xs font-bold flex-shrink-0">
            Install
          </button>
          <button onClick={() => setShowInstall(false)} className="p-1 text-gray-600 hover:text-gray-400 flex-shrink-0">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
}