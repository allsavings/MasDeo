import React from 'react';

/**
 * OptimisticUpdateHandler
 * Utility for managing optimistic UI updates with error recovery
 * Ensures failed updates are properly rolled back with user feedback
 */

export class OptimisticUpdateHandler {
  constructor(onError = null) {
    this.onError = onError;
    this.pendingUpdates = new Map();
  }

  /**
   * Execute an optimistic update with error handling
   * @param {string} key - Unique identifier for this update
   * @param {function} optimisticFn - Function to update UI immediately
   * @param {function} apiFn - Async function to make the actual update
   * @param {function} rollbackFn - Function to revert UI if API fails
   * @returns {Promise} Result of API call
   */
  async execute(key, optimisticFn, apiFn, rollbackFn) {
    try {
      // Save state for rollback
      const previousState = { timestamp: Date.now() };
      this.pendingUpdates.set(key, previousState);

      // Apply optimistic update immediately
      optimisticFn?.();

      // Make API call
      const result = await apiFn();

      // Success - clear pending update
      this.pendingUpdates.delete(key);
      return result;
    } catch (error) {
      // Failure - rollback UI and notify user
      const errorMsg = error?.message || 'Update failed. Please try again.';
      
      // Attempt rollback
      try {
        rollbackFn?.();
      } catch (rollbackErr) {
        console.error('Rollback failed:', rollbackErr);
      }

      // Notify user
      this.onError?.(key, errorMsg);
      
      // Clear pending update
      this.pendingUpdates.delete(key);
      
      throw new Error(errorMsg);
    }
  }

  /**
   * Check if an update is still pending
   */
  isPending(key) {
    return this.pendingUpdates.has(key);
  }

  /**
   * Clear all pending updates
   */
  clearPending() {
    this.pendingUpdates.clear();
  }

  /**
   * Get all pending keys
   */
  getPendingKeys() {
    return Array.from(this.pendingUpdates.keys());
  }
}

/**
 * React hook for using OptimisticUpdateHandler
 */
export function useOptimisticUpdates(onError) {
  const [handler] = React.useState(() => new OptimisticUpdateHandler(onError));
  return handler;
}