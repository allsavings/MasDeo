import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertCircle, X } from 'lucide-react';

/**
 * MobileErrorBoundary
 * Manages error notifications for mobile with auto-dismiss
 * Touch-friendly design with proper spacing
 */
export default function MobileErrorBoundary({ errors = {}, onDismiss = null }) {
  const [visibleErrors, setVisibleErrors] = useState(errors);

  useEffect(() => {
    setVisibleErrors(errors);
  }, [errors]);

  const handleDismiss = (key) => {
    setVisibleErrors(prev => {
      const next = { ...prev };
      delete next[key];
      return next;
    });
    onDismiss?.(key);
  };

  // Auto-dismiss non-critical errors after 5 seconds
  useEffect(() => {
    const dismissTimers = Object.entries(visibleErrors).map(([key, error]) => {
      if (error && !error.persistent) {
        return setTimeout(() => handleDismiss(key), 5000);
      }
      return null;
    });

    return () => {
      dismissTimers.forEach(timer => timer && clearTimeout(timer));
    };
  }, [visibleErrors]);

  const errorArray = Object.entries(visibleErrors).filter(([_, err]) => err);

  return (
    <AnimatePresence>
      {errorArray.map(([key, error], idx) => (
        <motion.div
          key={key}
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className={`fixed top-4 left-4 right-4 z-50 rounded-lg border backdrop-blur-sm pointer-events-auto ${
            error?.severity === 'critical'
              ? 'bg-red-500/20 border-red-500/40 text-red-300'
              : 'bg-amber-500/20 border-amber-500/40 text-amber-300'
          }`}
          style={{
            marginTop: `calc(${idx} * 4.5rem)`,
          }}
        >
          <div className="flex items-start gap-3 p-3 min-h-[44px]">
            <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              {error?.title && <p className="font-semibold text-sm">{error.title}</p>}
              <p className="text-xs opacity-90 leading-relaxed">{error?.message || 'An error occurred'}</p>
            </div>
            <button
              onClick={() => handleDismiss(key)}
              className="flex-shrink-0 p-1 hover:bg-black/20 rounded-lg transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
              aria-label="Dismiss error"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Progress bar for auto-dismiss */}
          {!error?.persistent && (
            <motion.div
              initial={{ scaleX: 1 }}
              animate={{ scaleX: 0 }}
              transition={{ duration: 5, ease: 'linear' }}
              className="h-0.5 bg-gradient-to-r from-red-500 to-transparent origin-left"
            />
          )}
        </motion.div>
      ))}
    </AnimatePresence>
  );
}