import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { RefreshCw } from 'lucide-react';

/**
 * PullToRefreshWrapper
 * Mobile pull-to-refresh functionality that respects sticky headers and bottom nav
 * Does not interfere with native scrolling behavior
 */
export default function PullToRefreshWrapper({
  onRefresh,
  children,
  threshold = 80,
  className = '',
  disabled = false,
}) {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);
  const scrollContainerRef = useRef(null);
  const startYRef = useRef(0);
  const isScrollingRef = useRef(false);

  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;

    const handleTouchStart = (e) => {
      // Only start pull-to-refresh if at top of scroll
      if (container.scrollTop === 0 && !disabled) {
        startYRef.current = e.touches[0].clientY;
        isScrollingRef.current = true;
      }
    };

    const handleTouchMove = (e) => {
      if (!isScrollingRef.current || isRefreshing || disabled) return;

      const currentY = e.touches[0].clientY;
      const distance = Math.max(0, currentY - startYRef.current);

      // Only pull if we're really at the top
      if (container.scrollTop === 0) {
        setPullDistance(distance);
        // Prevent default scroll while pulling
        if (distance > 0) {
          e.preventDefault?.();
        }
      } else {
        isScrollingRef.current = false;
      }
    };

    const handleTouchEnd = async () => {
      if (!isScrollingRef.current) return;
      
      isScrollingRef.current = false;

      if (pullDistance >= threshold && !isRefreshing) {
        setIsRefreshing(true);
        try {
          await onRefresh?.();
        } catch (error) {
          console.error('Pull to refresh error:', error);
        } finally {
          setIsRefreshing(false);
          setPullDistance(0);
        }
      } else {
        // Animate back to 0
        setPullDistance(0);
      }
    };

    container.addEventListener('touchstart', handleTouchStart, { passive: true });
    container.addEventListener('touchmove', handleTouchMove, { passive: false });
    container.addEventListener('touchend', handleTouchEnd, { passive: true });

    return () => {
      container.removeEventListener('touchstart', handleTouchStart);
      container.removeEventListener('touchmove', handleTouchMove);
      container.removeEventListener('touchend', handleTouchEnd);
    };
  }, [threshold, disabled, isRefreshing, pullDistance, onRefresh]);

  return (
    <div
      ref={scrollContainerRef}
      className={`relative overflow-y-auto scroll-container ${className}`}
    >
      {/* Pull-to-refresh indicator */}
      <AnimatePresence>
        {(pullDistance > 0 || isRefreshing) && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed top-0 left-0 right-0 bg-gradient-to-b from-gray-800/80 to-transparent pointer-events-none z-20"
            style={{
              height: Math.min(pullDistance, threshold * 1.5),
              paddingTop: 'env(safe-area-inset-top)',
            }}
          >
            {/* Spinner */}
            <div className="flex flex-col items-center justify-center h-full gap-2">
              <motion.div
                animate={{ rotate: isRefreshing ? 360 : 0 }}
                transition={{ 
                  duration: isRefreshing ? 1 : 0.5,
                  repeat: isRefreshing ? Infinity : 0,
                  ease: 'linear'
                }}
              >
                <RefreshCw
                  className={`w-5 h-5 ${
                    pullDistance >= threshold ? 'text-cyan-400' : 'text-gray-400'
                  }`}
                />
              </motion.div>
              {!isRefreshing && (
                <p className="text-xs text-gray-400">
                  {pullDistance >= threshold ? 'Release to refresh' : 'Pull to refresh'}
                </p>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Content with padding for pull indicator */}
      <div
        style={{
          paddingTop: isRefreshing ? '60px' : 0,
          transition: 'padding-top 0.3s ease',
        }}
      >
        {children}
      </div>

      {/* Loading state */}
      <AnimatePresence>
        {isRefreshing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex items-center justify-center py-8"
          >
            <div className="flex flex-col items-center gap-2">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
              >
                <RefreshCw className="w-6 h-6 text-cyan-400" />
              </motion.div>
              <p className="text-xs text-gray-400">Refreshing...</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}