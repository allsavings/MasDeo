import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

/**
 * BottomSheetSelect
 * Mobile-first dropdown component that opens as a bottom sheet
 * Preserves native feel while providing consistent mobile UX
 */
export default function BottomSheetSelect({
  value,
  onChange,
  options = [],
  placeholder = 'Select...',
  className = '',
  disabled = false,
  label = '',
  error = null,
  onError = null,
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedLabel, setSelectedLabel] = useState(
    options.find(opt => opt.value === value)?.label || placeholder
  );

  const handleSelect = async (option) => {
    try {
      setSelectedLabel(option.label);
      onChange?.(option.value);
      setIsOpen(false);
      onError?.(null); // Clear any previous errors
    } catch (err) {
      const errorMsg = err.message || 'Failed to update selection';
      onError?.(errorMsg);
      console.error('BottomSheetSelect error:', err);
    }
  };

  return (
    <div className={`relative ${className}`}>
      {label && <label className="block text-xs text-gray-400 mb-1.5">{label}</label>}
      
      <button
        onClick={() => !disabled && setIsOpen(true)}
        disabled={disabled}
        className={`w-full flex items-center justify-between bg-gray-800/40 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm ${
          disabled ? 'opacity-50 cursor-not-allowed' : 'hover:bg-gray-800/60'
        } transition-colors`}
      >
        <span>{selectedLabel}</span>
        <ChevronDown className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {error && <p className="text-xs text-red-400 mt-1">{error}</p>}

      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-black/40 z-40"
            />

            {/* Bottom Sheet */}
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="fixed bottom-0 left-0 right-0 bg-gray-800 rounded-t-2xl z-50 max-h-[60vh] overflow-y-auto scroll-container"
              style={{ paddingBottom: 'max(env(safe-area-inset-bottom), 1rem)' }}
            >
              {/* Header */}
              <div className="sticky top-0 bg-gray-800 border-b border-gray-700 px-4 py-3 rounded-t-2xl">
                <h3 className="text-white font-semibold text-sm">{label || 'Select an option'}</h3>
              </div>

              {/* Options */}
              <div className="divide-y divide-gray-700">
                {options.map((option, idx) => (
                  <button
                    key={`${option.value}-${idx}`}
                    onClick={() => handleSelect(option)}
                    className={`w-full px-4 py-4 text-left flex items-center justify-between min-h-[44px] ${
                      value === option.value
                        ? 'bg-blue-500/20 text-blue-300'
                        : 'text-gray-300 hover:bg-gray-700/50'
                    } transition-colors`}
                  >
                    <span className="font-medium">{option.label}</span>
                    {value === option.value && (
                      <span className="text-blue-400">✓</span>
                    )}
                  </button>
                ))}
              </div>

              {/* Close Button */}
              <div className="sticky bottom-0 bg-gray-700/50 border-t border-gray-700 px-4 py-3">
                <button
                  onClick={() => setIsOpen(false)}
                  className="w-full py-2.5 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-medium text-sm transition-colors"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}