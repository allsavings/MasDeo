import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, Lock, AlertCircle } from 'lucide-react';
import AdViewer from './AdViewer';
import { base44 } from '@/api/base44Client';

// Extract just the video ID from any YouTube URL format
function extractVideoId(input) {
  if (!input) return '';
  // Already a plain ID (no slashes or dots typical of URLs)
  if (!input.includes('/') && !input.includes('.')) return input;
  // Match various YouTube URL formats
  const match = input.match(
    /(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([a-zA-Z0-9_-]{11})/
  );
  return match ? match[1] : input;
}

const AD_REWARD_PER_AD = 0.05; // each ad earns R0.05

export default function YouTubePlayer({ 
  videoId: rawVideoId, 
  title, 
  description,
  creditCost = 0.05,
  videoType = 'reward',  // 'reward' | 'premium'
  userCredits = 0,
  userEmail,
  onClose,
  onVideoWatched
}) {
  const videoId = extractVideoId(rawVideoId);

  // For premium: how many ads needed to cover the cost given current balance
  const adsNeeded = videoType === 'premium'
    ? Math.max(0, Math.ceil((creditCost - userCredits) / AD_REWARD_PER_AD))
    : 1; // reward videos always show 1 ad

  const [adsWatched, setAdsWatched] = useState(0);
  const [showAd, setShowAd] = useState(true);
  const [hasAccess, setHasAccess] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [resolvedTitle, setResolvedTitle] = useState(title || '');
  const [resolvedDescription, setResolvedDescription] = useState(description || '');
  const [resolvedThumbnail, setResolvedThumbnail] = useState(
    `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`
  );

  useEffect(() => {
    if (!videoId) return;
    setResolvedThumbnail(`https://img.youtube.com/vi/${videoId}/hqdefault.jpg`);
    if (!title || !description) {
      fetch(`https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`)
        .then(res => res.json())
        .then(data => {
          if (!title) setResolvedTitle(data.title || '');
          if (!description) setResolvedDescription('');
          if (!title) setResolvedThumbnail(data.thumbnail_url || `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`);
        })
        .catch(() => {});
    }
  }, [videoId, title, description]);

  const handleAdComplete = async () => {
    const nextAdsWatched = adsWatched + 1;
    setAdsWatched(nextAdsWatched);

    if (nextAdsWatched < adsNeeded) {
      // More ads to watch — keep showing ads (reset AdViewer by toggling)
      setShowAd(false);
      setTimeout(() => setShowAd(true), 300);
      return;
    }

    // All required ads watched — process credits
    setShowAd(false);
    setLoading(true);
    try {
      const profiles = await base44.entities.UserProfile.filter({ created_by: userEmail });
      if (profiles.length > 0) {
        const profile = profiles[0];
        const currentCredits = profile.credits || 0;

        if (videoType === 'reward') {
          // Earn credits
          const newBalance = currentCredits + creditCost;
          await base44.entities.UserProfile.update(profile.id, { credits: newBalance });
          await base44.entities.VideoWatch.create({
            user_email: userEmail,
            video_id: videoId,
            watched_at: new Date().toISOString(),
            credit_deducted: -creditCost,
            completed: true
          });
          setHasAccess(true);
          onVideoWatched?.();
        } else {
          // Premium: credits earned from ads + existing balance, then deduct cost
          const earnedFromAds = nextAdsWatched * AD_REWARD_PER_AD;
          const totalCredits = currentCredits + earnedFromAds;
          const newBalance = Math.max(0, totalCredits - creditCost);
          await base44.entities.UserProfile.update(profile.id, { credits: newBalance });
          await base44.entities.VideoWatch.create({
            user_email: userEmail,
            video_id: videoId,
            watched_at: new Date().toISOString(),
            credit_deducted: creditCost,
            completed: true
          });
          setHasAccess(true);
          onVideoWatched?.();
        }
      }
    } catch (err) {
      setError('Failed to process. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-cyan-500/30 border-t-cyan-500 rounded-full animate-spin" />
          <p className="text-gray-400 text-sm">Unlocking video...</p>
        </div>
      </div>
    );
  }

  if (!hasAccess && !showAd) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl overflow-hidden border border-gray-700/50 bg-gray-800/40"
      >
        <div className="relative">
          <img src={resolvedThumbnail} alt={resolvedTitle} className="w-full h-48 object-cover" />
          <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center gap-3">
            <div className="w-16 h-16 rounded-full bg-cyan-500/80 flex items-center justify-center">
              <Play className="w-8 h-8 text-white fill-white" />
            </div>
          </div>
        </div>

        <div className="p-4 space-y-3">
          <div>
            <h3 className="text-white font-semibold text-sm mb-1">{resolvedTitle}</h3>
            {resolvedDescription && <p className="text-gray-400 text-xs line-clamp-2">{resolvedDescription}</p>}
          </div>

          {error && (
            <div className="flex gap-2 bg-red-500/20 border border-red-500/30 rounded-xl p-2">
              <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-red-400">{error}</p>
            </div>
          )}

          <button
            onClick={() => { setAdsWatched(0); setShowAd(true); }}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white py-2.5 rounded-xl font-medium transition-all"
          >
            <Lock className="w-4 h-4" />
            {adsNeeded > 1 ? `Watch ${adsNeeded} Ads to Unlock` : `Watch Ad to Unlock`}
          </button>

          <p className="text-[10px] text-gray-500 text-center">
            Your balance: R{(userCredits || 0).toFixed(2)} · Cost: R{(creditCost || 0).toFixed(2)}
            {adsNeeded > 1 && ` · Needs ${adsNeeded} ads`}
          </p>
        </div>
      </motion.div>
    );
  }

  return (
    <>
      <AnimatePresence>
        {showAd && (
          <AdViewer
            onAdComplete={handleAdComplete}
            creditReward={AD_REWARD_PER_AD}
            videoType={videoType}
            adNumber={adsWatched + 1}
            totalAds={adsNeeded}
          />
        )}
      </AnimatePresence>

      {hasAccess && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
          <div className="rounded-2xl overflow-hidden border border-gray-700/50 bg-black">
            <div className="aspect-video">
              <iframe
                width="100%"
                height="100%"
                src={`https://www.youtube.com/embed/${videoId}?rel=0&modestbranding=1`}
                title={title}
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
              />
            </div>
          </div>

          {(resolvedTitle || resolvedDescription) && (
            <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 p-4">
              {resolvedTitle && <h2 className="text-white font-bold text-base mb-2">{resolvedTitle}</h2>}
              {resolvedDescription && <p className="text-gray-400 text-sm leading-relaxed">{resolvedDescription}</p>}
            </div>
          )}
        </motion.div>
      )}
    </>
  );
}