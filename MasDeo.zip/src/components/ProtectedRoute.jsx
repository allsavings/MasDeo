import React from 'react';
import { useAuth } from '@/lib/AuthContext';
import { Navigate } from 'react-router-dom';

/**
 * ProtectedRoute Component
 * Wraps sensitive routes with authentication checks.
 * Blocks access to unauthorized users; redirects admins to /welcome
 * Sensitive paths: /Admin, /CodeBackup, /AdminPanel, etc.
 */
export default function ProtectedRoute({ children, requiredRole = null, fallbackPath = '/welcome' }) {
  const { user, isAuthenticated, isLoadingAuth } = useAuth();

  // Block route rendering until auth status is known
  if (isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-[#0a0a0f]">
        <div className="w-8 h-8 border-4 border-gray-700 border-t-cyan-400 rounded-full animate-spin" />
      </div>
    );
  }

  // Check authentication
  if (!isAuthenticated || !user) {
    return <Navigate to={fallbackPath} replace />;
  }

  // Check role if specified
  if (requiredRole && user.role !== requiredRole) {
    return <Navigate to={fallbackPath} replace />;
  }

  return children;
}