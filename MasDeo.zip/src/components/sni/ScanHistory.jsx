import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { History, Trash2, ChevronDown, ChevronUp, Clock, Wifi } from 'lucide-react';

const STATUS_COLOR = {
  'FULL TUNNEL VERIFIED': 'text-green-400',
  'SSL TUNNEL READY':     'text-cyan-400',
  'WEBSOCKET READY':      'text-purple-400',
  'UPGRADE READY':        'text-blue-400',
  'BLIND TUNNEL READY':   'text-yellow-400',
  'PROXY TOLERANT':       'text-yellow-300',
  'BLOCKED':              'text-red-400',
};

function HistoryEntry({ entry, onDelete }) {
  const [open, setOpen] = useState(false);
  const eligible = entry.results.filter(r => !['BLOCKED', 'SCANNING...'].includes(r.classification));

  return (
    <div className="bg-gray-800/50 rounded-xl border border-gray-700/50 overflow-hidden mb-3">
      <button
        className="w-full flex items-center gap-3 p-4 text-left hover:bg-gray-700/20 transition-colors"
        onClick={() => setOpen(v => !v)}
      >
        <Wifi className="w-4 h-4 text-cyan-400 flex-shrink-0" />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-semibold text-white text-sm">{entry.network}</span>
            <span className="text-xs text-gray-500">{entry.timestamp}</span>
          </div>
          <p className="text-xs text-gray-400 mt-0.5">
            {entry.results.length} tests · <span className="text-green-400">{eligible.length} eligible</span>
          </p>
        </div>
        <button
          onClick={e => { e.stopPropagation(); onDelete(entry.id); }}
          className="p-1.5 rounded-lg hover:bg-red-900/30 text-gray-500 hover:text-red-400 transition-colors"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
        {open ? <ChevronUp className="w-4 h-4 text-gray-500" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 border-t border-gray-700/50 pt-3 space-y-1.5">
              {entry.results.map((r, i) => (
                <div key={i} className="flex items-center gap-2 text-xs font-mono">
                  <span className="text-gray-300 truncate flex-1">{r.host}:{r.port}</span>
                  <span className="text-gray-500">[{r.protocolLabel}]</span>
                  <span className={STATUS_COLOR[r.classification] || 'text-gray-400'}>{r.classification}</span>
                  <span className="text-gray-600">{r.score}/6</span>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

const HISTORY_KEY = 'sni_scan_history';

export function loadHistory() {
  try { return JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]'); } catch { return []; }
}

export function saveToHistory(network, results) {
  const history = loadHistory();
  const entry = {
    id: Date.now(),
    network,
    timestamp: new Date().toLocaleString(),
    results,
  };
  history.unshift(entry);
  // keep last 20 scans
  localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, 20)));
}

export default function ScanHistory({ onClose }) {
  const [history, setHistory] = useState(loadHistory);

  const deleteEntry = (id) => {
    const updated = history.filter(e => e.id !== id);
    setHistory(updated);
    localStorage.setItem('sni_scan_history', JSON.stringify(updated));
  };

  const clearAll = () => {
    setHistory([]);
    localStorage.removeItem('sni_scan_history');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="fixed inset-0 z-50 bg-[#0a0a0f]/95 backdrop-blur-sm overflow-y-auto"
    >
      <div className="max-w-2xl mx-auto px-4 py-6 pb-32">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-cyan-400" />
            <h2 className="text-lg font-bold text-white">Scan History</h2>
          </div>
          <div className="flex items-center gap-2">
            {history.length > 0 && (
              <button onClick={clearAll} className="text-xs text-red-400 hover:text-red-300 transition-colors px-2 py-1 rounded-lg hover:bg-red-900/20">
                Clear All
              </button>
            )}
            <button onClick={onClose} className="text-sm text-gray-400 hover:text-white transition-colors px-3 py-1.5 rounded-xl bg-gray-800/60 hover:bg-gray-700/60">
              ✕ Close
            </button>
          </div>
        </div>

        {history.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <Clock className="w-12 h-12 text-gray-600 mb-3" />
            <p className="text-gray-500 text-sm">No scan history yet</p>
            <p className="text-gray-600 text-xs mt-1">Completed scans will appear here</p>
          </div>
        ) : (
          history.map(entry => (
            <HistoryEntry key={entry.id} entry={entry} onDelete={deleteEntry} />
          ))
        )}
      </div>
    </motion.div>
  );
}