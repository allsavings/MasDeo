import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Copy, Check } from 'lucide-react';

export default function IdentityVault({ wsRef, sysInfo = {} }) {
  const [copied, setCopied] = useState('');
  const { user = 'UNKNOWN', hw_id = 'UNKNOWN', license = 'UNKNOWN' } = sysInfo;

  const handleCopy = (text, key) => {
    navigator.clipboard.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(''), 1500);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -16 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl border border-cyan-500/30 bg-gradient-to-br from-gray-900/90 to-[#0a0a0f]/90 backdrop-blur-xl overflow-hidden mb-4"
      style={{ boxShadow: '0 0 24px rgba(6,182,212,0.08), inset 0 1px 0 rgba(6,182,212,0.12)' }}
    >
      {/* Neon M@☆ MASTERS Header */}
      <div className="px-5 pt-4 pb-2 border-b border-cyan-500/20 text-center">
        <h2
          className="text-2xl font-black tracking-[0.15em] text-cyan-400 uppercase select-none"
          style={{
            fontFamily: 'monospace',
            filter: 'drop-shadow(0 0 10px rgba(6,182,212,0.9))',
            textShadow: '0 0 8px rgba(6,182,212,0.6)',
          }}
        >
          M@☆ MASTERS
        </h2>
        <p className="text-[9px] text-cyan-500/60 tracking-[0.3em] uppercase font-mono mt-0.5 font-semibold">
          Sovereign Identity Vault
        </p>
      </div>

      {/* Identity Details */}
      <div className="px-5 py-4 space-y-2.5">
        {/* User */}
        <div className="flex items-center justify-between gap-3 bg-gray-800/40 border border-gray-700/30 rounded-xl px-3.5 py-2.5">
          <div className="flex-1 min-w-0">
            <p className="text-[9px] font-bold text-gray-500 uppercase tracking-wider mb-0.5">User</p>
            <p className="text-xs font-mono text-cyan-300 break-all">{user}</p>
          </div>
          <button
            onClick={() => handleCopy(user, 'user')}
            className={`flex-shrink-0 p-1.5 rounded-lg transition-all ${
              copied === 'user'
                ? 'bg-green-500/20 text-green-400'
                : 'bg-gray-700/40 hover:bg-gray-600/40 text-gray-500 hover:text-gray-300'
            }`}
            title="Copy"
          >
            {copied === 'user' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* HW-ID */}
        <div className="flex items-center justify-between gap-3 bg-gray-800/40 border border-gray-700/30 rounded-xl px-3.5 py-2.5">
          <div className="flex-1 min-w-0">
            <p className="text-[9px] font-bold text-gray-500 uppercase tracking-wider mb-0.5">HW-ID</p>
            <p className="text-xs font-mono text-white break-all">{hw_id}</p>
          </div>
          <button
            onClick={() => handleCopy(hw_id, 'hwid')}
            className={`flex-shrink-0 p-1.5 rounded-lg transition-all ${
              copied === 'hwid'
                ? 'bg-green-500/20 text-green-400'
                : 'bg-gray-700/40 hover:bg-gray-600/40 text-gray-500 hover:text-gray-300'
            }`}
            title="Copy"
          >
            {copied === 'hwid' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* License */}
        <div className="flex items-center justify-between gap-3 bg-gray-800/40 border border-gray-700/30 rounded-xl px-3.5 py-2.5">
          <div className="flex-1 min-w-0">
            <p className="text-[9px] font-bold text-gray-500 uppercase tracking-wider mb-0.5">License</p>
            <p className="text-xs font-mono text-green-300 break-all">{license}</p>
          </div>
          <button
            onClick={() => handleCopy(license, 'license')}
            className={`flex-shrink-0 p-1.5 rounded-lg transition-all ${
              copied === 'license'
                ? 'bg-green-500/20 text-green-400'
                : 'bg-gray-700/40 hover:bg-gray-600/40 text-gray-500 hover:text-gray-300'
            }`}
            title="Copy"
          >
            {copied === 'license' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Get Verification Key Link */}
      <div className="px-5 pb-4 pt-2">
        <a
          href="https://mspy.qzz.io/tkmasterinfo"
          target="_blank"
          rel="noopener noreferrer"
          className="w-full flex items-center justify-center gap-2 bg-blue-600/30 hover:bg-blue-600/50 border border-blue-500/40 text-blue-300 hover:text-blue-200 font-bold py-2.5 rounded-xl transition-all text-xs"
          style={{ textShadow: '0 0 4px rgba(96,165,250,0.4)' }}
        >
          🔐 Get Verification Key
        </a>
      </div>
    </motion.div>
  );
}