import React, { useState } from 'react';
import { Download, Clipboard, Share2, CheckCircle, FileJson } from 'lucide-react';

export default function ExportShare({ results, networkName, eligible }) {
  const [copied, setCopied] = useState(false);

  const exportJSON = () => {
    const data = {
      network: networkName,
      date: new Date().toISOString(),
      summary: {
        total: results.length,
        eligible: eligible.length,
        blocked: results.filter(r => r.classification === 'BLOCKED').length,
      },
      results: results.map(r => ({
        host: r.host,
        port: r.port,
        protocol: r.protocolLabel,
        classification: r.classification,
        score: r.score,
      })),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sni_scan_${networkName}_${Date.now()}.json`;
    a.click();
  };

  const exportTxt = () => {
    const lines = [
      `SNI Bug Host Scan — ${networkName}`,
      `Date: ${new Date().toLocaleString()}`,
      `Total: ${results.length} | Eligible: ${eligible.length} | Blocked: ${results.filter(r => r.classification === 'BLOCKED').length}`,
      '',
      ...results.map(r => `${r.host}:${r.port} [${r.protocolLabel}] — ${r.classification} (${r.score}/6)`),
    ].join('\n');
    const blob = new Blob([lines], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sni_scan_${networkName}_${Date.now()}.txt`;
    a.click();
  };

  const copyToClipboard = async () => {
    const text = results.map(r =>
      `${r.host}:${r.port} [${r.protocolLabel}] — ${r.classification} (${r.score}/6)`
    ).join('\n');
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const share = async () => {
    const text = [
      `📡 SNI Scan — ${networkName}`,
      `✅ ${eligible.length} eligible hosts`,
      '',
      ...eligible.map(r => `${r.host}:${r.port} [${r.protocolLabel}]`),
    ].join('\n');
    if (navigator.share) {
      await navigator.share({ title: `SNI Scan — ${networkName}`, text });
    } else {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const actions = [
    { label: 'JSON',    icon: FileJson,   color: 'text-cyan-400 border-cyan-500/30 bg-cyan-500/10 hover:bg-cyan-500/20',    onClick: exportJSON },
    { label: 'TXT',     icon: Download,   color: 'text-rose-400 border-rose-500/30 bg-rose-500/10 hover:bg-rose-500/20',    onClick: exportTxt },
    { label: copied ? 'Copied!' : 'Copy', icon: copied ? CheckCircle : Clipboard, color: copied ? 'text-green-400 border-green-500/30 bg-green-500/10' : 'text-slate-300 border-slate-600/50 bg-slate-800/60 hover:bg-slate-700/60', onClick: copyToClipboard },
    { label: 'Share',   icon: Share2,     color: 'text-purple-400 border-purple-500/30 bg-purple-500/10 hover:bg-purple-500/20', onClick: share },
  ];

  return (
    <div className="flex gap-2 flex-wrap">
      {actions.map(a => (
        <button
          key={a.label}
          onClick={a.onClick}
          className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-xl border transition-all ${a.color}`}
        >
          <a.icon className="w-3.5 h-3.5" />
          {a.label}
        </button>
      ))}
    </div>
  );
}