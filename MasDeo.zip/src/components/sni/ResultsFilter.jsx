import React from 'react';

const TABS = [
  { id: 'all',  label: 'All',       color: 'text-rose-300',   active: 'bg-rose-500/20 border-rose-500/50 text-rose-300',   inactive: 'bg-slate-800/60 border-slate-700/40 text-slate-500' },
  { id: 'ssl',  label: 'SSL/TLS',   color: 'text-cyan-400',   active: 'bg-cyan-500/20 border-cyan-500/50 text-cyan-300',   inactive: 'bg-slate-800/60 border-slate-700/40 text-slate-500' },
  { id: 'ws',   label: 'WebSocket', color: 'text-purple-400', active: 'bg-purple-500/20 border-purple-500/50 text-purple-300', inactive: 'bg-slate-800/60 border-slate-700/40 text-slate-500' },
  { id: 'http', label: 'HTTP',      color: 'text-yellow-400', active: 'bg-yellow-500/20 border-yellow-500/50 text-yellow-300', inactive: 'bg-slate-800/60 border-slate-700/40 text-slate-500' },
];

function countForProto(results, proto) {
  const list = proto === 'all' ? results : results.filter(r => r.protocol === proto);
  const ready   = list.filter(r => !['BLOCKED', 'SCANNING...'].includes(r.classification)).length;
  const blocked = list.filter(r => r.classification === 'BLOCKED').length;
  return { total: list.length, ready, blocked };
}

export default function ResultsFilter({ results, activeFilter, onFilterChange }) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
      {TABS.map(tab => {
        const { total, ready, blocked } = countForProto(results, tab.id);
        const isActive = activeFilter === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onFilterChange(tab.id)}
            className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all ${isActive ? tab.active : tab.inactive}`}
          >
            {tab.label}
            {total > 0 && (
              <span className="flex items-center gap-1">
                <span className={`${isActive ? '' : 'text-slate-600'} font-mono`}>{total}</span>
                {ready > 0 && (
                  <span className="w-1.5 h-1.5 bg-green-400 rounded-full" title={`${ready} ready`} />
                )}
                {blocked > 0 && (
                  <span className="w-1.5 h-1.5 bg-red-500 rounded-full" title={`${blocked} blocked`} />
                )}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}