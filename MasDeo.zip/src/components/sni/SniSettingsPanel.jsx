import React from 'react';
import { motion } from 'framer-motion';
import { Settings, X, Info, Wifi, Shield, Globe } from 'lucide-react';

export default function SniSettingsPanel({ settings, onChange, onClose }) {
  const set = (key, val) => onChange({ ...settings, [key]: val });

  return (
    <motion.div
      initial={{ opacity: 0, x: '100%' }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: '100%' }}
      transition={{ type: 'tween', duration: 0.25 }}
      className="fixed inset-0 z-50 bg-[#0a0a0f] flex flex-col"
    >
      <div className="flex items-center justify-between px-6 pt-6 pb-4 border-b border-gray-800/50">
        <div className="flex items-center gap-3">
          <Settings className="w-5 h-5 text-cyan-400" />
          <h2 className="font-bold text-white text-lg">Scanner Settings</h2>
        </div>
        <button onClick={onClose} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4 pb-32">
        {/* Probe timeout */}
        <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 p-5">
          <div className="flex items-center gap-2 mb-3">
            <Wifi className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold text-cyan-300 uppercase tracking-wider">Probe Timeout</h3>
          </div>
          <p className="text-xs text-gray-500 mb-3">How long to wait for each host probe (ms)</p>
          <div className="flex gap-2 flex-wrap">
            {[4000, 6000, 8000, 12000].map(t => (
              <button key={t}
                onClick={() => set('timeout', t)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold border transition-all ${
                  settings.timeout === t
                    ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-300'
                    : 'bg-gray-800/60 border-gray-700/50 text-gray-500'
                }`}
              >
                {t / 1000}s
              </button>
            ))}
          </div>
        </div>

        {/* Concurrent delay */}
        <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 p-5">
          <div className="flex items-center gap-2 mb-3">
            <Globe className="w-4 h-4 text-purple-400" />
            <h3 className="text-sm font-semibold text-purple-300 uppercase tracking-wider">Delay Between Tests</h3>
          </div>
          <p className="text-xs text-gray-500 mb-3">Pause between each test (ms)</p>
          <div className="flex gap-2 flex-wrap">
            {[100, 200, 400, 600].map(d => (
              <button key={d}
                onClick={() => set('delay', d)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold border transition-all ${
                  settings.delay === d
                    ? 'bg-purple-500/20 border-purple-500/50 text-purple-300'
                    : 'bg-gray-800/60 border-gray-700/50 text-gray-500'
                }`}
              >
                {d}ms
              </button>
            ))}
          </div>
        </div>

        {/* Auto-save */}
        <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 p-5">
          <div className="flex items-center gap-2 mb-3">
            <Shield className="w-4 h-4 text-yellow-400" />
            <h3 className="text-sm font-semibold text-yellow-300 uppercase tracking-wider">Auto-Save History</h3>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-xs text-gray-400">Automatically save each completed scan</p>
            <button
              onClick={() => set('autoSave', !settings.autoSave)}
              className={`w-11 h-6 rounded-full relative transition-all ${settings.autoSave ? 'bg-yellow-500' : 'bg-gray-700'}`}
            >
              <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all ${settings.autoSave ? 'left-5' : 'left-0.5'}`} />
            </button>
          </div>
        </div>

        {/* About */}
        <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 p-5">
          <div className="flex items-center gap-2 mb-3">
            <Info className="w-4 h-4 text-gray-400" />
            <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">About</h3>
          </div>
          <p className="text-xs text-gray-500 leading-relaxed">
            SNI Bug Host Scanner uses real network probes (fetch-based TCP reachability) to test SSL/TLS, WebSocket/WSS, and HTTP CONNECT tunnel eligibility across selected hosts and ports.
          </p>
          <p className="text-xs text-gray-600 mt-2">Version 2.0 • Real probe engine</p>
        </div>
      </div>
    </motion.div>
  );
}