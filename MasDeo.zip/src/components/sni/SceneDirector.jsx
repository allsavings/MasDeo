import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, XCircle, Copy, Check } from 'lucide-react';
import IdentityVault from './IdentityVault';
import RawFeedConsole from './RawFeedConsole';
import ControlDeck from './ControlDeck';

function CopyHostButton({ host }) {
  const [copied, setCopied] = useState(false);
  const handle = (e) => {
    e.preventDefault();
    navigator.clipboard.writeText(host);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };
  return (
    <button onClick={handle}
      className={`flex-shrink-0 p-1 rounded-md transition-all ${copied ? 'text-green-400' : 'text-gray-600 hover:text-gray-300'}`}>
      {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
    </button>
  );
}

// ─── SEND HELPER ─────────────────────────────────────────────────────────────
function useSend(wsRef) {
  return (payload) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(payload));
    }
  };
}

// ─── SCENE: PIN ENTRY ────────────────────────────────────────────────────────
function ScenePinEntry({ wsRef, sceneError }) {
  const [pin, setPin] = useState('');
  const send = useSend(wsRef);
  const submit = () => { if (pin) { send({ action: 'submit_pin', data: pin }); setPin(''); } };
  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
      className="bg-gray-900/70 border border-amber-500/30 rounded-2xl p-5 mb-4"
      style={{ boxShadow: '0 0 24px rgba(251,191,36,0.08)' }}>
      <p className="text-[10px] text-amber-400/70 uppercase tracking-widest mb-1 font-bold">Engine Prompt</p>
      <h3 className="text-sm font-bold text-white mb-3">🔑 Activation PIN Required</h3>
      {sceneError && (
        <div className="mb-3 px-3 py-2 rounded-xl bg-red-500/10 border border-red-500/30">
          <p className="text-xs text-red-400 font-semibold">{sceneError}</p>
        </div>
      )}
      <input
        type="password"
        inputMode="numeric"
        value={pin}
        onChange={e => setPin(e.target.value)}
        onKeyDown={e => e.key === 'Enter' && submit()}
        placeholder="Enter PIN..."
        className="w-full bg-gray-800/60 border border-amber-500/30 rounded-xl px-4 py-3 text-amber-300 font-mono text-sm focus:outline-none focus:border-amber-400/60 mb-3"
        autoFocus
      />
      <button onClick={submit}
        className="w-full bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold py-3 rounded-xl transition-all text-sm">
        -M@☆ᵉⁿᵗᵉʳ:
      </button>
    </motion.div>
  );
}

// ─── SCENE: COMMAND HUB ───────────────────────────────────────────────────────
function SceneCommandHub({ wsRef }) {
  const send = useSend(wsRef);
  const cmds = [
    { key: '1', label: '1 - Start Execution', icon: '🚀', color: 'bg-cyan-600/30 hover:bg-cyan-600/50 border-cyan-500/40 text-cyan-200' },
    { key: 'G', label: 'G - Guidance Manual', icon: '📖', color: 'bg-blue-600/30 hover:bg-blue-600/50 border-blue-500/40 text-blue-200' },
    { key: 'E', label: 'E - Exit Engine',     icon: '🔴', color: 'bg-red-600/20 hover:bg-red-600/40 border-red-500/40 text-red-300' },
  ];
  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
      className="bg-gray-900/70 border border-gray-700/50 rounded-2xl p-5 mb-4"
      style={{ boxShadow: '0 0 24px rgba(6,182,212,0.06)' }}>
      <p className="text-[10px] text-gray-400/70 uppercase tracking-widest mb-1 font-bold">Engine Prompt</p>
      <h3 className="text-sm font-bold text-white mb-4">⚡ Command Hub</h3>
      <div className="space-y-2">
        {cmds.map(c => (
          <button key={c.key} onClick={() => send({ action: 'user_input', data: c.key })}
            className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-xl border font-bold text-sm transition-all ${c.color}`}>
            <span className="text-lg flex-shrink-0">{c.icon}</span>
            {c.label}
          </button>
        ))}
      </div>
    </motion.div>
  );
}

// ─── SCENE: DRM NAME ─────────────────────────────────────────────────────────
function SceneDrmName({ wsRef }) {
  const [value, setValue] = useState('');
  const send = useSend(wsRef);
  const submit = () => { if (value.trim()) { send({ action: 'user_input', data: value }); setValue(''); } };
  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
      className="bg-gray-900/70 border border-yellow-500/40 rounded-2xl p-5 mb-4"
      style={{ boxShadow: '0 0 28px rgba(234,179,8,0.12)' }}>
      <p className="text-[10px] text-yellow-400/80 uppercase tracking-widest mb-1 font-bold">DRM Authorization</p>
      <h3 className="text-sm font-bold text-white mb-4">🛡️ Master Authorization Required</h3>
      <input
        type="text"
        value={value}
        onChange={e => setValue(e.target.value)}
        onKeyDown={e => e.key === 'Enter' && submit()}
        placeholder="Enter Registered Name"
        className="w-full bg-gray-800/60 border border-yellow-500/30 rounded-xl px-4 py-3 text-yellow-200 font-mono text-sm focus:outline-none focus:border-yellow-400/60 mb-3"
        autoFocus
      />
      <button onClick={submit}
        className="w-full font-bold py-3 rounded-xl transition-all text-sm text-white"
        style={{ background: 'linear-gradient(135deg, #ca8a04, #d97706)', boxShadow: '0 0 16px rgba(234,179,8,0.2)' }}>
        -M@☆ᵉⁿᵗᵉʳ:
      </button>
    </motion.div>
  );
}

// ─── SCENE: DRM KEY ──────────────────────────────────────────────────────────
function SceneDrmKey({ wsRef }) {
  const [value, setValue] = useState('');
  const send = useSend(wsRef);
  const submit = () => { if (value.trim()) { send({ action: 'user_input', data: value }); setValue(''); } };
  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
      className="bg-gray-900/70 border border-yellow-500/40 rounded-2xl p-5 mb-4"
      style={{ boxShadow: '0 0 28px rgba(234,179,8,0.12)' }}>
      <p className="text-[10px] text-yellow-400/80 uppercase tracking-widest mb-1 font-bold">DRM Authorization</p>
      <h3 className="text-sm font-bold text-white mb-4">🔐 Master Authorization Required</h3>
      <input
        type="password"
        value={value}
        onChange={e => setValue(e.target.value)}
        onKeyDown={e => e.key === 'Enter' && submit()}
        placeholder="Enter License Key"
        className="w-full bg-gray-800/60 border border-yellow-500/30 rounded-xl px-4 py-3 text-yellow-200 font-mono text-sm focus:outline-none focus:border-yellow-400/60 mb-3"
        autoFocus
      />
      <button onClick={submit}
        className="w-full font-bold py-3 rounded-xl transition-all text-sm text-white"
        style={{ background: 'linear-gradient(135deg, #ca8a04, #d97706)', boxShadow: '0 0 16px rgba(234,179,8,0.2)' }}>
        -M@☆ᵉⁿᵗᵉʳ:
      </button>
    </motion.div>
  );
}

// ─── SCENE: TARGET DIRECTORY ─────────────────────────────────────────────────
const DIRS = [
  { num: '1', label: '@ATMASTERS', desc: '/sdcard/ATMASTERS/', icon: '🏠' },
  { num: '2', label: 'Downloads', desc: '/sdcard/Download/', icon: '📥' },
  { num: '3', label: 'Current Tool Folder', desc: 'Termux working dir', icon: '📂' },
  { num: '4', label: 'Custom Local', desc: 'Inside current folder', icon: '✏️' },
  { num: '5', label: 'Custom Storage', desc: 'Inside phone storage', icon: '💾' },
];
function SceneTargetDirectory({ wsRef }) {
  const send = useSend(wsRef);
  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
      className="bg-gray-900/70 border border-cyan-500/30 rounded-2xl p-5 mb-4">
      <p className="text-[10px] text-cyan-400/70 uppercase tracking-widest mb-1 font-bold">Engine Prompt</p>
      <h3 className="text-sm font-bold text-white mb-3">📁 Select Target Directory</h3>
      <div className="space-y-2">
        {DIRS.map(d => (
          <button key={d.num} onClick={() => send({ action: 'user_input', data: d.num })}
            className="w-full flex items-center gap-3 bg-gray-800/50 hover:bg-cyan-500/10 border border-gray-700/40 hover:border-cyan-500/40 rounded-xl px-4 py-3 transition-all text-left group">
            <span className="text-xl flex-shrink-0">{d.icon}</span>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-white group-hover:text-cyan-300 transition-colors">[{d.num}] {d.label}</p>
              <p className="text-[10px] text-gray-500 truncate">{d.desc}</p>
            </div>
          </button>
        ))}
      </div>
    </motion.div>
  );
}

// ─── SCENE: OMNI VAULT ───────────────────────────────────────────────────────
function SceneOmniVault({ wsRef }) {
  const send = useSend(wsRef);
  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
      className="bg-gray-900/70 border border-purple-500/30 rounded-2xl p-5 mb-4"
      style={{ boxShadow: '0 0 24px rgba(168,85,247,0.08)' }}>
      <p className="text-[10px] text-purple-400/70 uppercase tracking-widest mb-1 font-bold">Engine Prompt</p>
      <h3 className="text-sm font-bold text-white mb-1">🗄️ OmniVault — Unfinished Scans Detected</h3>
      <p className="text-xs text-gray-400 mb-5">Previous scan data found. Resume or skip to start fresh.</p>
      <div className="space-y-2">
        <button onClick={() => send({ action: 'user_input', data: '' })}
          className="w-full bg-gray-700/60 hover:bg-gray-600/60 border border-gray-600/40 text-white font-semibold py-3 rounded-xl transition-all text-sm">
          ↵ Press Enter to start fresh
        </button>
        <button onClick={() => send({ action: 'user_input', data: 'r' })}
          className="w-full bg-purple-600/40 hover:bg-purple-600/60 border border-purple-500/40 text-purple-200 font-semibold py-3 rounded-xl transition-all text-sm">
          Resume Previous Scan
        </button>
      </div>
    </motion.div>
  );
}

// ─── SCENE: TARGET INPUT ─────────────────────────────────────────────────────
function SceneTargetInput({ wsRef }) {
  const [value, setValue] = useState('');
  const send = useSend(wsRef);
  const submit = () => { send({ action: 'user_input', data: value }); };
  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
      className="bg-gray-900/70 border border-cyan-500/30 rounded-2xl p-5 mb-4">
      <p className="text-[10px] text-cyan-400/70 uppercase tracking-widest mb-1 font-bold">Engine Prompt</p>
      <h3 className="text-sm font-bold text-white mb-3">🎯 Enter SNI Host(s) or Hosts File</h3>
      <input
        type="text"
        value={value}
        onChange={e => setValue(e.target.value)}
        onKeyDown={e => e.key === 'Enter' && submit()}
        placeholder="hosts.txt  or  site.com site2.com  or leave blank"
        className="w-full bg-gray-800/60 border border-cyan-500/20 rounded-xl px-4 py-3 text-cyan-200 font-mono text-sm focus:outline-none focus:border-cyan-400/50 mb-3"
        autoFocus
      />
      <button onClick={submit}
        className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold py-3 rounded-xl transition-all text-sm">
        -M@☆ᵉⁿᵗᵉʳ: Submit Target
      </button>
    </motion.div>
  );
}

// ─── SCENE: SCAN MODE ────────────────────────────────────────────────────────
const SCAN_MODES = [
  { num: '1', label: 'Strict 0-Balance Full', desc: 'Highly Accurate — SIM must have R0 balance', glow: 'border-cyan-500/50 bg-cyan-500/8', text: 'text-cyan-300', dot: 'bg-cyan-400' },
  { num: '2', label: 'Strict 0-Balance Anti-FUP', desc: 'Fast Scan — Saves Data, Highly Accurate', glow: 'border-green-500/50 bg-green-500/8', text: 'text-green-300', dot: 'bg-green-400' },
  { num: '3', label: 'Bypass Active Full', desc: 'Full Scan — Works on Wi-Fi or active data', glow: 'border-amber-500/50 bg-amber-500/8', text: 'text-amber-300', dot: 'bg-amber-400' },
  { num: '4', label: 'Bypass Active Anti-FUP', desc: 'Fast Scan — Low Bandwidth', glow: 'border-fuchsia-500/50 bg-fuchsia-500/8', text: 'text-fuchsia-300', dot: 'bg-fuchsia-400' },
];
function SceneScanMode({ wsRef }) {
  const [selected, setSelected] = useState('2');
  const send = useSend(wsRef);
  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
      className="bg-gray-900/70 border border-gray-700/50 rounded-2xl p-5 mb-4">
      <p className="text-[10px] text-gray-400/70 uppercase tracking-widest mb-1 font-bold">Engine Prompt</p>
      <h3 className="text-sm font-bold text-white mb-3">⚙️ Select Scan Mode</h3>
      <div className="space-y-2 mb-4">
        {SCAN_MODES.map(m => (
          <button key={m.num} onClick={() => setSelected(m.num)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border transition-all ${selected === m.num ? m.glow : 'border-gray-700/40 bg-gray-800/40'}`}>
            <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${selected === m.num ? `border-current ${m.text}` : 'border-gray-600'}`}>
              {selected === m.num && <div className={`w-2 h-2 rounded-full ${m.dot}`} />}
            </div>
            <div className="text-left">
              <p className={`text-xs font-bold ${selected === m.num ? m.text : 'text-gray-300'}`}>[{m.num}] {m.label}</p>
              <p className="text-[10px] text-gray-500 mt-0.5">{m.desc}</p>
            </div>
          </button>
        ))}
      </div>
      <button onClick={() => send({ action: 'user_input', data: selected })}
        className="w-full bg-gradient-to-r from-gray-700 to-gray-600 hover:from-gray-600 hover:to-gray-500 border border-gray-500/40 text-white font-bold py-3 rounded-xl transition-all text-sm">
        -M@☆ᵉⁿᵗᵉʳ: Confirm Mode {selected}
      </button>
    </motion.div>
  );
}

// ─── SCENE: PARAMETERS ───────────────────────────────────────────────────────
function SceneParameters({ wsRef, setCurrentScene }) {
  const send = useSend(wsRef);
  const [timeout, setTimeout_] = useState(5);
  const [retries, setRetries] = useState(0);
  const [threads, setThreads] = useState(200);
  const [batch, setBatch] = useState(100);
  const [fileMark, setFileMark] = useState('DeoVexUI');
  const [recovery, setRecovery] = useState(1);

  const engage = () => {
    send({ action: 'batch_input', data: [timeout, retries, threads, batch, fileMark, recovery] });
    setCurrentScene('live_execution');
  };

  const sliders = [
    { label: 'Timeout (s)', val: timeout, set: setTimeout_, min: 1, max: 60 },
    { label: 'Retries', val: retries, set: setRetries, min: 0, max: 10 },
    { label: 'Threads', val: threads, set: setThreads, min: 1, max: null },
    { label: 'Batch Size', val: batch, set: setBatch, min: 1, max: null },
  ];

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
      className="bg-gray-900/70 border border-gray-700/50 rounded-2xl p-5 mb-4">
      <p className="text-[10px] text-gray-400/70 uppercase tracking-widest mb-1 font-bold">Engine Prompt</p>
      <h3 className="text-sm font-bold text-white mb-4">🔧 Engine Parameters</h3>

      {/* Sliders */}
      <div className="grid grid-cols-2 gap-2 mb-4">
        {sliders.map(({ label, val, set, min, max }) => (
          <div key={label} className="bg-gray-800/50 border border-gray-700/40 rounded-xl p-3">
            <div className="flex items-center justify-between mb-2">
              <p className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider">{label}</p>
              <span className="text-xs font-bold text-cyan-300 font-mono">{val}</span>
            </div>
            {max !== null ? (
              <>
                <input type="range" min={min} max={max} value={val} onChange={e => set(Number(e.target.value))}
                  className="w-full h-1 rounded-full appearance-none bg-gray-700 accent-cyan-500 cursor-pointer" />
                <div className="flex justify-between mt-1">
                  <span className="text-[9px] text-gray-700">{min}</span>
                  <span className="text-[9px] text-gray-700">{max}</span>
                </div>
              </>
            ) : (
              <input type="number" min={min} value={val} onChange={e => set(Number(e.target.value))}
                className="w-full bg-gray-700/60 border border-gray-600/40 rounded-lg px-2 py-1.5 text-cyan-300 font-mono text-xs focus:outline-none focus:border-cyan-500/50 mt-1" />
            )}
          </div>
        ))}
      </div>

      {/* File Mark */}
      <div className="mb-3">
        <p className="text-[10px] text-gray-500 uppercase tracking-wider mb-1.5">File Mark Label</p>
        <input type="text" value={fileMark} onChange={e => setFileMark(e.target.value)}
          className="w-full bg-gray-800/60 border border-gray-700/40 rounded-xl px-3 py-2 text-cyan-300 font-mono text-xs focus:outline-none focus:border-cyan-500/40" />
      </div>

      {/* Recovery */}
      <p className="text-[10px] text-gray-500 uppercase tracking-wider mb-2">Deadlock Recovery</p>
      <div className="flex gap-2 mb-4">
        {[
          { val: 1, label: '1 — Auto-Skip', desc: 'Skip deadlocked hosts' },
          { val: 2, label: '2 — Hard Reset', desc: 'Kill & restart thread' },
          { val: 3, label: '3 — Shizuku Auto-Airplane Mode', desc: 'Hardware-level network reset' },
        ].map(opt => (
          <button key={opt.val} onClick={() => setRecovery(opt.val)}
            className={`flex-1 px-2 py-2 rounded-xl border text-center transition-all ${
              recovery === opt.val ? 'bg-purple-500/15 border-purple-500/50 text-purple-300' : 'bg-gray-800/40 border-gray-700/40 text-gray-500'
            }`}>
            <p className="text-[10px] font-bold leading-tight">{opt.label}</p>
            <p className="text-[9px] opacity-60 mt-0.5 leading-tight">{opt.desc}</p>
          </button>
        ))}
      </div>

      <motion.button
        onClick={engage}
        whileTap={{ scale: 0.97 }}
        className="w-full py-3.5 rounded-xl font-bold text-sm text-white transition-all"
        style={{ background: 'linear-gradient(135deg, #06b6d4, #3b82f6, #8b5cf6)', boxShadow: '0 0 20px rgba(6,182,212,0.3)' }}
      >
        ⚡ Engage Execution
      </motion.button>
    </motion.div>
  );
}

// ─── CAPTIVE PORTAL FILTER ───────────────────────────────────────────────────
const CAPTIVE_TERMS = ['nofunds', 'connectu', 'captive', 'portal', 'redirect', 'login', 'signin'];
function getCleanLink(details = '', host = '') {
  const raw = details.includes('-->') ? details.split('-->')[0].trim() : (details || host);
  // If the extracted part contains captive portal terms, fall back to host
  const lower = raw.toLowerCase();
  const isCaptive = CAPTIVE_TERMS.some(t => lower.includes(t));
  return isCaptive ? host : raw;
}

// ─── SCENE: LIVE EXECUTION ───────────────────────────────────────────────────
export function LiveDashboard({ results, telemetry, liveStats = {}, wsRef, sysInfo = {}, rawLogs = [] }) {
  const {
    batch_prog = '0', batch_size = '0',
    scanned = '0', total = '0',
    zero = '0', bugs = '0',
    elapsed = '00s', eta = '00s', pshd = '0'
  } = liveStats;
  const progressPct = Number(total) > 0 ? Math.min((Number(scanned) / Number(total)) * 100, 100) : 0;



  return (
    <>
      {/* ── Identity Vault Header ── */}
      <IdentityVault wsRef={wsRef} sysInfo={sysInfo} />

      {/* ── Cinematic HUD ── */}
      <div className="rounded-2xl border border-cyan-500/30 bg-[#050a0f]/90 backdrop-blur p-4 mb-3"
        style={{ boxShadow: '0 0 24px rgba(6,182,212,0.12), inset 0 1px 0 rgba(6,182,212,0.08)' }}>
        <div className="flex items-center gap-2 mb-2">
          <span className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse flex-shrink-0" />
          <p className="text-[9px] font-black text-cyan-400 uppercase tracking-[0.3em]">Live Intelligence HUD</p>
        </div>
        {/* Line 1: batch + global progress + zero + bugs */}
        <p className="text-xs font-mono text-white mb-1 leading-relaxed">
          <span className="text-yellow-400">⚡️</span>{' '}
          <span className="text-amber-300">{batch_prog}/{batch_size}</span>
          <span className="text-gray-600 mx-1.5">|</span>
          <span className="text-cyan-400">🌐</span>{' '}
          <span className="text-cyan-200">{scanned}/{total}</span>
          <span className="text-gray-600 mx-1.5">|</span>
          <span className="text-green-400">🟢 0Rated: {zero}</span>
          <span className="text-gray-600 mx-1.5">|</span>
          <span className="text-orange-400">🔥 Bugs: {bugs}</span>
        </p>
        {/* Line 2: timing */}
        <p className="text-xs font-mono text-white mb-3 leading-relaxed">
          <span className="text-blue-400">⏱️ Elapsed: {elapsed}</span>
          <span className="text-gray-600 mx-1.5">|</span>
          <span className="text-purple-400">⏳ ETA: {eta}</span>
          <span className="text-gray-600 mx-1.5">|</span>
          <span className="text-gray-400">👻 Pshd: {pshd}</span>
        </p>
        {/* Progress bar — scanned / total */}
        <div className="w-full bg-gray-800/60 rounded-full h-1.5 overflow-hidden">
          <motion.div
            className="h-1.5 rounded-full"
            style={{ background: 'linear-gradient(90deg, #06b6d4, #3b82f6, #8b5cf6)', boxShadow: '0 0 8px rgba(6,182,212,0.6)' }}
            animate={{ width: `${progressPct}%` }}
            transition={{ duration: 0.4, ease: 'easeOut' }}
          />
        </div>
      </div>

      {/* ── Live Control Deck ── */}
      <ControlDeck wsRef={wsRef} />

      {/* Telemetry bar */}
      {telemetry && (
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl px-4 py-3 mb-4 border border-cyan-500/20 bg-cyan-500/5 backdrop-blur"
        >
          <p className="text-[10px] font-bold text-cyan-400 uppercase tracking-widest mb-1">Telemetry</p>
          <p className="text-xs text-cyan-200 font-mono leading-relaxed break-all">{telemetry}</p>
        </motion.div>
      )}

      {/* Scrollable Results Stream */}
      <div className="max-h-[50vh] overflow-y-auto pr-2 space-y-2" style={{ scrollbarWidth: 'thin', scrollbarColor: '#06b6d430 transparent' }}>
        {results.map((r, i) => {
          const cfg = {
            'zero-rated': { bg: 'bg-green-500/10 border-green-500/20', icon: <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />, text: 'text-green-300' },
            'hidden-bug': { bg: 'bg-cyan-500/10 border-cyan-500/20', icon: <span className="flex-shrink-0 mt-0.5">🔥</span>, text: 'text-cyan-300' },
            'billed':     { bg: 'bg-orange-500/10 border-orange-500/20', icon: <span className="flex-shrink-0 mt-0.5">🚫</span>, text: 'text-orange-300' },
            'blocked':    { bg: 'bg-gray-800/40 border-gray-700/30', icon: <XCircle className="w-4 h-4 text-red-400/60 flex-shrink-0 mt-0.5" />, text: 'text-gray-500' },
          }[r.status] || { bg: 'bg-gray-800/40 border-gray-700/30', icon: null, text: 'text-gray-400' };

          const cleanLink = getCleanLink(r.details, r.host);

          return (
            <motion.div key={i} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.1 }}
              className={`flex items-start gap-2 rounded-xl px-3 py-2.5 border ${cfg.bg}`}>
              {cfg.icon}
              <a
                href={`http://${cleanLink}`}
                target="_blank"
                rel="noopener noreferrer"
                className={`flex-1 text-xs font-mono break-all hover:text-cyan-300 underline decoration-cyan-500/30 leading-relaxed ${cfg.text}`}
              >
                {cleanLink}
              </a>
              <button
                onClick={() => navigator.clipboard.writeText(cleanLink)}
                className="flex-shrink-0 p-1 rounded-md text-gray-600 hover:text-green-400 transition-all mt-0.5"
                title="Copy"
              >
                <Copy className="w-3.5 h-3.5" />
              </button>
            </motion.div>
          );
        })}
      </div>

      {/* ── System Log Console ── */}
      <RawFeedConsole logs={rawLogs} />
    </>
  );
}

// ─── SCENE DIRECTOR (main export) ────────────────────────────────────────────
export default function SceneDirector({ currentScene, setCurrentScene, sceneError, wsRef, results, telemetry, liveStats, sysInfo, rawLogs }) {
  const sceneMap = {
    drm_name:         <SceneDrmName wsRef={wsRef} />,
    drm_key:          <SceneDrmKey wsRef={wsRef} />,
    pin_entry:        <ScenePinEntry wsRef={wsRef} sceneError={sceneError} />,
    command_hub:      <SceneCommandHub wsRef={wsRef} />,
    target_directory: <SceneTargetDirectory wsRef={wsRef} />,
    omni_vault:       <SceneOmniVault wsRef={wsRef} />,
    target_input:     <SceneTargetInput wsRef={wsRef} />,
    scan_mode:        <SceneScanMode wsRef={wsRef} />,
    parameters:       <SceneParameters wsRef={wsRef} setCurrentScene={setCurrentScene} />,
    live_execution:   <LiveDashboard results={results} telemetry={telemetry} liveStats={liveStats} wsRef={wsRef} sysInfo={sysInfo} rawLogs={rawLogs} />,
  };

  if (currentScene === 'idle') return null;

  return (
    <AnimatePresence mode="wait">
      <motion.div key={currentScene}
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        transition={{ duration: 0.2 }}>
        {sceneMap[currentScene] || null}
      </motion.div>
    </AnimatePresence>
  );
}