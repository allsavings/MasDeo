import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, Trash2 } from 'lucide-react';

// ANSI color code parser
function parseANSI(text) {
  const ansiMap = {
    '30': '#000000', '31': '#ff5555', '32': '#55ff55', '33': '#ffff55',
    '34': '#5555ff', '35': '#ff55ff', '36': '#55ffff', '37': '#ffffff',
    '90': '#555555', '91': '#ff7777', '92': '#77ff77', '93': '#ffff77',
    '94': '#7777ff', '95': '#ff77ff', '96': '#77ffff', '97': '#ffffff',
  };

  let html = '';
  let i = 0;
  let currentColor = '#55ff55';
  let currentBg = '#0a0a0f';

  while (i < text.length) {
    if (text[i] === '\x1b' && text[i + 1] === '[') {
      let j = i + 2;
      while (j < text.length && !/[a-zA-Z]/.test(text[j])) j++;
      const code = text.slice(i + 2, j);
      const m = code.match(/^(\d+)/);
      if (m) {
        const num = m[1];
        if (num === '0') {
          currentColor = '#55ff55';
          currentBg = '#0a0a0f';
        } else if (ansiMap[num]) {
          currentColor = ansiMap[num];
        }
      }
      i = j + 1;
    } else {
      let endI = i;
      while (endI < text.length && text[endI] !== '\x1b') endI++;
      if (endI > i) {
        const char = text.slice(i, endI);
        html += `<span style="color:${currentColor};">${char.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</span>`;
        i = endI;
      } else {
        i++;
      }
    }
  }

  return html;
}

export default function RawFeedConsole({ logs = [] }) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [localLogs, setLocalLogs] = useState(logs);
  const scrollRef = useRef(null);

  useEffect(() => {
    setLocalLogs(logs);
  }, [logs]);

  useEffect(() => {
    if (scrollRef.current && isExpanded) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [localLogs, isExpanded]);

  const handleClear = () => {
    setLocalLogs([]);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-xl border border-gray-700/40 bg-[#0a0a0f]/80 backdrop-blur overflow-hidden"
    >
      {/* Header / Toggle */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between px-3.5 py-2.5 bg-gray-900/60 hover:bg-gray-800/60 transition-colors border-b border-gray-700/30"
      >
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse flex-shrink-0" />
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">System Log Console</p>
        </div>
        <motion.div animate={{ rotate: isExpanded ? 180 : 0 }} transition={{ duration: 0.2 }}>
          <ChevronDown className="w-4 h-4 text-gray-500" />
        </motion.div>
      </button>

      {/* Expandable Content */}
      <motion.div
        initial={false}
        animate={{ height: isExpanded ? 'auto' : 0, opacity: isExpanded ? 1 : 0 }}
        transition={{ duration: 0.2 }}
        className="overflow-hidden"
      >
        <div className="flex items-center justify-between px-3.5 py-2 bg-gray-950/60 border-b border-gray-800/30">
          <p className="text-[9px] text-gray-600 font-mono">{localLogs.length} line(s)</p>
          <button
            onClick={handleClear}
            className="text-[10px] text-gray-600 hover:text-red-400 transition-colors flex items-center gap-1"
          >
            <Trash2 className="w-3 h-3" />
            Clear
          </button>
        </div>

        {/* Console Log */}
        <div
          ref={scrollRef}
          className="max-h-64 overflow-y-auto bg-black/60 font-mono text-[10px] text-green-400/80 p-3 space-y-0"
          style={{ scrollbarWidth: 'thin', scrollbarColor: '#06b6d430 transparent' }}
        >
          {localLogs.length === 0 ? (
            <p className="text-gray-600 opacity-50">Waiting for system messages...</p>
          ) : (
            localLogs.map((log, i) => (
              <div
                key={i}
                className="text-xs text-green-400/70 leading-tight break-all whitespace-pre-wrap"
                dangerouslySetInnerHTML={{ __html: parseANSI(log) }}
              />
            ))
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}