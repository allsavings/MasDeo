import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Settings, Info, Download, Trash2, CheckCircle, Radio } from 'lucide-react';
import { loadHistory } from './HistoryView';

const HISTORY_KEY = 'sni_scan_history';
const SHARED_HOSTS_KEY = 'shared_target_hosts';

export default function SettingsPage({ onClose }) {
  const [cleared, setCleared] = useState(null);

  const exportAllScans = () => {
    const history = loadHistory();
    if (!history.length) return;
    const blob = new Blob([JSON.stringify(history, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sni_all_scans_${Date.now()}.json`;
    a.click();
  };

  const clearCache = (type) => {
    if (type === 'history') {
      localStorage.removeItem(HISTORY_KEY);
    } else if (type === 'hosts') {
      localStorage.removeItem(SHARED_HOSTS_KEY);
    } else {
      localStorage.removeItem(HISTORY_KEY);
      localStorage.removeItem(SHARED_HOSTS_KEY);
    }
    setCleared(type);
    setTimeout(() => setCleared(null), 2000);
  };

  const Section = ({ title, children }) => (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider px-4 pt-3 pb-2">{title}</p>
      {children}
    </div>
  );

  const Row = ({ icon: Icon, iconColor, label, sub, action }) => (
    <div className="flex items-center gap-3 px-4 py-3 border-t border-slate-800/60">
      <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 ${iconColor}`}>
        <Icon className="w-4 h-4" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm text-white font-medium">{label}</p>
        {sub && <p className="text-xs text-slate-500">{sub}</p>}
      </div>
      {action}
    </div>
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex flex-col"
    >
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        className="absolute bottom-0 left-0 right-0 bg-slate-950 rounded-t-3xl max-h-[90vh] flex flex-col"
      >
        {/* Handle */}
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 bg-slate-700 rounded-full" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Settings className="w-4 h-4 text-purple-400" />
            <h2 className="text-base font-bold text-white">Settings</h2>
          </div>
          <button onClick={onClose} className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors">
            <X className="w-4 h-4 text-slate-400" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">

          {/* About */}
          <Section title="About">
            <div className="px-4 pb-4 pt-1 flex items-start gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-rose-500 to-pink-500 flex items-center justify-center flex-shrink-0 mt-1">
                <Radio className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-sm font-bold text-white">SNI Bug Host Scanner</p>
                <p className="text-xs text-slate-400 mt-0.5">v2.0 — Real-time network probing for SSL/TLS, WebSocket & HTTP CONNECT tunneling.</p>
                <p className="text-xs text-slate-600 mt-2">Scan history stored locally on your device. No data is sent to external servers.</p>
              </div>
            </div>
          </Section>

          {/* Protocol Guide */}
          <Section title="Protocol Guide">
            {[
              { label: 'SSL/TLS', desc: 'SSL Tick — TLS handshake + cipher negotiation', color: 'bg-cyan-500/15 text-cyan-400' },
              { label: 'WebSocket/WSS', desc: 'Upgrade-based — HTTP 101 switching protocols', color: 'bg-purple-500/15 text-purple-400' },
              { label: 'HTTP CONNECT', desc: 'Blind TCP tunnel — CONNECT + UNLOCK payload', color: 'bg-yellow-500/15 text-yellow-400' },
            ].map(p => (
              <div key={p.label} className="flex items-center gap-3 px-4 py-2.5 border-t border-slate-800/60">
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${p.color}`}>{p.label}</span>
                <p className="text-xs text-slate-400">{p.desc}</p>
              </div>
            ))}
          </Section>

          {/* Score Guide */}
          <Section title="Score Guide">
            {[
              { s: '5–6', label: 'Excellent — Full tunnel ready', color: 'text-green-400' },
              { s: '3–4', label: 'Good — Proxy tolerant', color: 'text-yellow-400' },
              { s: '1–2', label: 'Poor — Likely blocked', color: 'text-orange-400' },
              { s: '0', label: 'Blocked / timeout', color: 'text-red-400' },
            ].map(r => (
              <div key={r.s} className="flex items-center gap-3 px-4 py-2.5 border-t border-slate-800/60">
                <span className={`font-mono text-sm font-bold ${r.color} w-8`}>{r.s}</span>
                <p className="text-xs text-slate-400">{r.label}</p>
              </div>
            ))}
          </Section>

          {/* Data Management */}
          <Section title="Data Management">
            <Row
              icon={Download}
              iconColor="bg-cyan-500/15 text-cyan-400"
              label="Export All Scans"
              sub="Download full history as JSON"
              action={
                <button onClick={exportAllScans}
                  className="text-xs bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-400 border border-cyan-500/30 px-3 py-1.5 rounded-lg transition-all">
                  Export
                </button>
              }
            />
            <Row
              icon={Trash2}
              iconColor="bg-red-500/15 text-red-400"
              label="Clear Scan History"
              sub="Remove all saved scans"
              action={
                <button onClick={() => clearCache('history')}
                  className={`text-xs px-3 py-1.5 rounded-lg border transition-all flex items-center gap-1 ${
                    cleared === 'history'
                      ? 'bg-green-500/15 text-green-400 border-green-500/30'
                      : 'bg-red-500/10 hover:bg-red-500/20 text-red-400 border-red-500/20'
                  }`}>
                  {cleared === 'history' ? <><CheckCircle className="w-3 h-3" /> Done</> : 'Clear'}
                </button>
              }
            />
            <Row
              icon={Trash2}
              iconColor="bg-orange-500/15 text-orange-400"
              label="Clear Shared Hosts"
              sub="Wipe the shared host list"
              action={
                <button onClick={() => clearCache('hosts')}
                  className={`text-xs px-3 py-1.5 rounded-lg border transition-all flex items-center gap-1 ${
                    cleared === 'hosts'
                      ? 'bg-green-500/15 text-green-400 border-green-500/30'
                      : 'bg-orange-500/10 hover:bg-orange-500/20 text-orange-400 border-orange-500/20'
                  }`}>
                  {cleared === 'hosts' ? <><CheckCircle className="w-3 h-3" /> Done</> : 'Clear'}
                </button>
              }
            />
            <Row
              icon={Trash2}
              iconColor="bg-slate-600/40 text-slate-400"
              label="Clear All Cache"
              sub="History + shared hosts"
              action={
                <button onClick={() => clearCache('all')}
                  className={`text-xs px-3 py-1.5 rounded-lg border transition-all flex items-center gap-1 ${
                    cleared === 'all'
                      ? 'bg-green-500/15 text-green-400 border-green-500/30'
                      : 'bg-slate-700/50 hover:bg-slate-700 text-slate-400 border-slate-600/40'
                  }`}>
                  {cleared === 'all' ? <><CheckCircle className="w-3 h-3" /> Done</> : 'Clear All'}
                </button>
              }
            />
          </Section>
        </div>
      </motion.div>
    </motion.div>
  );
}