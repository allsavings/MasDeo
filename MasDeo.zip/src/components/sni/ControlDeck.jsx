import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, Power, Pause, Play, RotateCcw, LogOut } from 'lucide-react';

export default function ControlDeck({ wsRef }) {
  const [userInput, setUserInput] = useState('');
  const [sending, setSending] = useState(false);

  const sendCommand = (cmd) => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;
    if (typeof cmd === 'string') {
      wsRef.current.send(JSON.stringify({ action: 'send_command', command: cmd }));
    } else {
      wsRef.current.send(JSON.stringify(cmd));
    }
  };

  const handleSendInput = () => {
    if (!userInput.trim()) return;
    sendCommand({ action: 'user_input', text: userInput });
    setSending(true);
    setTimeout(() => setSending(false), 500);
    setUserInput('');
  };

  return (
    <motion.div
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.2 }}
      className="sticky bottom-0 left-0 right-0 bg-gradient-to-t from-[#0a0a0f] to-[#0a0a0f]/90 backdrop-blur-lg border-t border-gray-700/40 p-4 space-y-3"
    >
      {/* Input Row */}
      <div className="flex gap-2">
        <input
          type="text"
          value={userInput}
          onChange={e => setUserInput(e.target.value)}
          onKeyPress={e => e.key === 'Enter' && handleSendInput()}
          placeholder="Answer terminal prompt..."
          className="flex-1 bg-gray-900/60 border border-gray-700/50 rounded-lg px-3 py-2 text-xs text-gray-300 focus:outline-none focus:border-cyan-500/50"
        />
        <button
          onClick={handleSendInput}
          disabled={!userInput.trim() || sending}
          className="bg-cyan-600/40 hover:bg-cyan-600/60 disabled:opacity-40 text-cyan-300 border border-cyan-500/30 px-3 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1"
        >
          <Send className="w-3.5 h-3.5" /> Send
        </button>
      </div>

      {/* Control Buttons Grid */}
      <div className="grid grid-cols-5 gap-2">
        {/* Pause */}
        <button
          onClick={() => sendCommand('p')}
          className="bg-amber-600/30 hover:bg-amber-600/50 text-amber-300 border border-amber-500/30 py-2 rounded-lg text-[10px] font-bold transition-all flex flex-col items-center justify-center gap-0.5"
        >
          <Pause className="w-3.5 h-3.5" />
          Pause
        </button>

        {/* Resume */}
        <button
          onClick={() => sendCommand('r')}
          className="bg-green-600/30 hover:bg-green-600/50 text-green-300 border border-green-500/30 py-2 rounded-lg text-[10px] font-bold transition-all flex flex-col items-center justify-center gap-0.5"
        >
          <Play className="w-3.5 h-3.5" />
          Resume
        </button>

        {/* Retry */}
        <button
          onClick={() => sendCommand('r')}
          className="bg-blue-600/30 hover:bg-blue-600/50 text-blue-300 border border-blue-500/30 py-2 rounded-lg text-[10px] font-bold transition-all flex flex-col items-center justify-center gap-0.5"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Retry
        </button>

        {/* Exit & Save */}
        <button
          onClick={() => sendCommand('e')}
          className="bg-purple-600/30 hover:bg-purple-600/50 text-purple-300 border border-purple-500/30 py-2 rounded-lg text-[10px] font-bold transition-all flex flex-col items-center justify-center gap-0.5"
        >
          <LogOut className="w-3.5 h-3.5" />
          Exit
        </button>

        {/* CTRL + C */}
        <button
          onClick={() => sendCommand({ action: 'interrupt' })}
          className="bg-red-600/40 hover:bg-red-600/60 text-red-300 border border-red-500/40 py-2 rounded-lg text-[10px] font-bold transition-all flex flex-col items-center justify-center gap-0.5"
        >
          <Power className="w-3.5 h-3.5" />
          CTRL+C
        </button>
      </div>
    </motion.div>
  );
}