import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, History, ChevronDown, ChevronUp, Trash2, RotateCcw, WifiOff } from 'lucide-react';

const HISTORY_KEY = 'sni_scan_history';

export function loadHistory() {
  try { return JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]'); } catch { return []; }
}

export function saveToHistory(networkName, results) {
  const history = loadHistory();
  const entry = {
    id: Date.now(),
    networkName,
    date: new Date().toISOString(),
    results: results.filter(r => r.classification !== 'SCANNING...'),
  };
  history.unshift(entry);
  localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, 30)));
}

const STATUS_DOT = {
  'FULL TUNNEL VERIFIED': 'bg-green-400',
  'SSL TUNNEL READY':     'bg-cyan-400',
  'WEBSOCKET READY':      'bg-purple-400',
  'UPGRADE READY':        'bg-blue-400',
  'BLIND TUNNEL READY':   'bg-amber-400',
  'PROXY TOLERANT':       'bg-yellow-400',
  'BLOCKED':              'bg-red-500',
};

function HistoryEntry({ entry, onDelete, onReload }) {
  const [expanded, setExpanded] = useState(false);
  const eligible = entry.results.filter(r => !['BLOCKED'].includes(r.classification));
  const blocked = entry.results.filter(r => r.classification === 'BLOCKED');
  const date = new Date(entry.date);

  return (
    <div className="bg-slate-900 border border-slate-700/60 rounded-2xl overflow-hidden">
      <button
        className="w-full flex items-center gap-3 p-4 text-left hover:bg-slate-800/40 transition-colors"
        onClick={() => setExpanded(v => !v)}
      >
        <div className="w-9 h-9 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center flex-shrink-0">
          <History className="w-4 h-4 text-rose-400" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-white truncate">{entry.networkName}</p>
          <p className="text-[11px] text-slate-400">
            {date.toLocaleDateString()} {date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            {' · '}{entry.results.length} tests
          </p>
        </div>
        <div className="flex gap-1.5 items-center mr-2">
          <span className="text-[10px] bg-green-500/15 text-green-400 border border-green-500/30 px-2 py-0.5 rounded-full font-semibold">{eligible.length} ready</span>
          <span className="text-[10px] bg-red-500/15 text-red-400 border border-red-500/30 px-2 py-0.5 rounded-full font-semibold">{blocked.length} blocked</span>
        </div>
        {expanded ? <ChevronUp className="w-4 h-4 text-slate-500 flex-shrink-0" /> : <ChevronDown className="w-4 h-4 text-slate-500 flex-shrink-0" />}
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="border-t border-slate-700/50 p-4 space-y-2">
              <div className="space-y-1.5 max-h-52 overflow-y-auto">
                {entry.results.map((r, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs font-mono">
                    <div className={`w-2 h-2 rounded-full flex-shrink-0 ${STATUS_DOT[r.classification] || 'bg-gray-500'}`} />
                    <span className="text-slate-300 truncate">{r.host}:{r.port}</span>
                    <span className="text-slate-500 text-[10px] flex-shrink-0">{r.classification}</span>
                  </div>
                ))}
              </div>
              <div className="flex gap-2 pt-2">
                <button
                  onClick={() => onReload(entry)}
                  className="flex items-center gap-1.5 text-xs bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-400 border border-cyan-500/30 px-3 py-1.5 rounded-lg transition-all"
                >
                  <RotateCcw className="w-3 h-3" /> Reload
                </button>
                <button
                  onClick={() => onDelete(entry.id)}
                  className="flex items-center gap-1.5 text-xs bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-3 py-1.5 rounded-lg transition-all"
                >
                  <Trash2 className="w-3 h-3" /> Delete
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function HistoryView({ onClose, onReload }) {
  const [history, setHistory] = useState([]);

  useEffect(() => { setHistory(loadHistory()); }, []);

  const deleteEntry = (id) => {
    const updated = history.filter(e => e.id !== id);
    setHistory(updated);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
  };

  const clearAll = () => {
    setHistory([]);
    localStorage.removeItem(HISTORY_KEY);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex flex-col"
    >
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        className="absolute bottom-0 left-0 right-0 bg-slate-950 rounded-t-3xl max-h-[85vh] flex flex-col"
      >
        {/* Handle */}
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 bg-slate-700 rounded-full" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-cyan-400" />
            <h2 className="text-base font-bold text-white">Scan History</h2>
            <span className="text-xs text-slate-500 bg-slate-800 px-2 py-0.5 rounded-full">{history.length}</span>
          </div>
          <div className="flex items-center gap-2">
            {history.length > 0 && (
              <button onClick={clearAll} className="text-xs text-red-400 hover:text-red-300 transition-colors">Clear all</button>
            )}
            <button onClick={onClose} className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors">
              <X className="w-4 h-4 text-slate-400" />
            </button>
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {history.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <WifiOff className="w-10 h-10 text-slate-700 mb-3" />
              <p className="text-slate-500 text-sm">No scan history yet</p>
              <p className="text-slate-600 text-xs mt-1">Completed scans will appear here</p>
            </div>
          ) : (
            history.map(entry => (
              <HistoryEntry key={entry.id} entry={entry} onDelete={deleteEntry} onReload={(e) => { onReload(e); onClose(); }} />
            ))
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}