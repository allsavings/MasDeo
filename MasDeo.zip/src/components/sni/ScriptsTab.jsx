import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Copy, Check, Code, ChevronDown, ChevronUp, Download, Search } from 'lucide-react';

// ─── COPY BUTTON ─────────────────────────────────────────────────────────────
function CopyBtn({ text, label = 'Copy' }) {
  const [copied, setCopied] = useState(false);
  const copy = () => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); };
  return (
    <button onClick={copy} className="flex items-center gap-1 text-xs text-gray-400 hover:text-white px-2 py-1 rounded-lg hover:bg-gray-700/50 transition-all">
      {copied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
      {copied ? 'Copied!' : label}
    </button>
  );
}

// ─── CODE BLOCK ──────────────────────────────────────────────────────────────
export function CodeBlock({ title, icon: Icon, code, color = 'text-green-300', maxH = 'max-h-48' }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className="bg-gray-900/80 rounded-2xl border border-gray-700/50 overflow-hidden mb-4">
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-gray-700/50 bg-gray-800/50">
        <div className="flex items-center gap-2">
          <Icon className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-medium text-gray-300">{title}</span>
        </div>
        <div className="flex items-center gap-1">
          <CopyBtn text={code} />
          <button onClick={() => setExpanded(!expanded)} className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-gray-700/50 transition-all">
            {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>
      <pre className={`text-xs ${color} p-4 overflow-x-auto leading-relaxed whitespace-pre-wrap ${expanded ? '' : maxH + ' overflow-y-hidden'}`}>{code}</pre>
      {!expanded && (
        <button onClick={() => setExpanded(true)} className="w-full text-center text-xs text-gray-500 hover:text-gray-300 py-2 bg-gray-900/60 border-t border-gray-700/30 transition-all">
          Show more ↓
        </button>
      )}
    </div>
  );
}

const PYTHON_SCRIPT = `#!/usr/bin/env python3
"""
@MastersTechSolutions M@☆ - ZERO-RATED SCANNER V11.3
Professional Multi-Threaded SNI Scanner with Async Raw TCP Socket Sniper & Wi-Fi Mode
"""

import os, asyncio, aiohttp, time, sys, ssl
from datetime import datetime
from urllib.parse import urlparse

C_GREEN = '\\033[92m'; C_RED = '\\033[91m'; C_YELLOW = '\\033[93m'
C_CYAN  = '\\033[96m'; C_PURPLE = '\\033[95m'; C_RESET = '\\033[0m'

CARRIER_PROBES = {
    "vodacom": ["www.vodacom.co.za","enrichment.vodacom.co.za"],
    "mtn":     ["mtn.co.za","nofunds.mtn.co.za"],
    "telkom":  ["telkom.co.za","oob.telkom.co.za"],
    "cellc":   ["cellc.co.za","nofunds.cellc.mobi"],
    "knect":   ["knectmobile.co.za"],
    "rain":    ["rain.co.za"]
}

CAPTIVE_PATTERNS = {
    "vodacom":"connectu.vodacom.co.za","mtn":"nofunds.mtn",
    "telkom":"oob.telkom","cellc":"nofunds.cellc",
    "knect":"knectmobile","rain":"rain.co.za/error"
}

CURRENT_DIR = os.getcwd()
UA = "Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 Chrome/112.0.0.0 Mobile Safari/537.36"
SSL_CTX = ssl.create_default_context()
SSL_CTX.check_hostname = False; SSL_CTX.verify_mode = ssl.CERT_NONE

async def http_test(session, host, https=True, timeout_val=5, max_retries=0):
    url = f"{'https' if https else 'http'}://{host}/"
    for attempt in range(max_retries + 1):
        try:
            async with session.get(url, headers={"User-Agent": UA}, timeout=timeout_val, allow_redirects=True, ssl=False) as r:
                body = await r.text()
                return r.status, str(r.url), body[:5000].lower()
        except Exception:
            if attempt < max_retries: await asyncio.sleep(0.5)
    return None, None, ""

async def sniper_test(host, timeout_val):
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(host, 443, ssl=SSL_CTX, server_hostname=host), timeout=timeout_val)
        payload = f"GET / HTTP/1.1\\r\\nHost: {host}\\r\\nConnection: upgrade\\r\\nUpgrade: websocket\\r\\nUser-Agent: {UA}\\r\\n\\r\\n"
        writer.write(payload.encode()); await writer.drain()
        resp = await asyncio.wait_for(reader.read(4096), timeout=timeout_val)
        writer.close(); await writer.wait_closed()
        resp_str = resp.decode('utf-8', errors='ignore').lower()
        first = resp_str.split('\\r\\n')[0]
        code = None
        if 'http/' in first:
            parts = first.split(' ')
            if len(parts) >= 2 and parts[1].isdigit(): code = int(parts[1])
        return code, resp_str
    except Exception: return None, ""

async def check_zero_balance(session, timeout_val):
    status, _, _ = await http_test(session, "www.google.com", https=True, timeout_val=timeout_val)
    if status == 200:
        print(f"{C_RED}[!] ACTIVE DATA DETECTED. Exiting.{C_RESET}"); return False
    print(f"{C_GREEN}[+] Zero balance confirmed.{C_RESET}\\n"); return True

async def detect_carrier(session, timeout_val):
    for carrier, hosts in CARRIER_PROBES.items():
        for h in hosts:
            _, url, body = await http_test(session, h, https=False, timeout_val=timeout_val)
            if url:
                if carrier in url: return carrier
                for c, p in CAPTIVE_PATTERNS.items():
                    if p in url or p in body: return c
    return "UNKNOWN"

def classify(original_host, final_url, status_code, body):
    if not final_url or status_code is None: return f"{C_RED}❌ BLOCKED{C_RESET}", "", "BLOCKED"
    for c, p in CAPTIVE_PATTERNS.items():
        if p in final_url.lower() or p in body:
            return f"{C_RED}🚫 BILLED{C_RESET}", final_url, "BILLED"
    orig_d = urlparse(f"http://{original_host}").netloc.split(':')[0]
    fin_d  = urlparse(final_url).netloc.split(':')[0]
    if orig_d == fin_d or orig_d in fin_d or fin_d in orig_d:
        return f"{C_GREEN}✅ ZERO-RATED{C_RESET}", "", "ZERO-RATED"
    if status_code in [200,204,301,302,400,401,403,404,500,501,502,503,504]:
        return f"{C_YELLOW}✅ ZERO-RATED (Redirect){C_RESET}", final_url, "ZERO-RATED"
    return f"{C_YELLOW}⚠️ UNKNOWN{C_RESET}", final_url, "UNKNOWN"

async def scan_host(session, host, timeout_val, max_retries, results_list, log_file):
    code, url, body = await http_test(session, host, https=True, timeout_val=timeout_val, max_retries=max_retries)
    if not code: code, url, body = await http_test(session, host, https=False, timeout_val=timeout_val, max_retries=max_retries)
    color_class, redirect_url, raw_class = classify(host, url, code, body)
    if raw_class in ["BILLED","BLOCKED"]:
        s_code, s_body = await sniper_test(host, timeout_val)
        if s_code and all(p not in s_body[:5000].lower() for p in CAPTIVE_PATTERNS.values()):
            color_class = f"{C_CYAN}🔥 HIDDEN BUG{C_RESET}"; raw_class = "HIDDEN BUG"; redirect_url = ""; code = s_code
    line = f"{color_class.ljust(25)} | {host}{(' --> ' + redirect_url) if redirect_url else ''} (HTTP:{code})"
    clean_line = f"{raw_class.ljust(15)} | {host}{(' --> ' + redirect_url) if redirect_url else ''} (HTTP:{code})"
    results_list.append((raw_class, clean_line, host)); print(line)
    with open(log_file,"a") as f: f.write(clean_line+"\\n")

async def main():
    print(f"\\n{C_PURPLE}{'='*70}\\n@MastersTechSolutions M@☆ - ZERO-RATED SCANNER V11.3\\n{'='*70}{C_RESET}")
    target_input = input(f"Enter SNI Host(s) OR hosts file (default: {C_CYAN}hosts.txt{C_RESET}): ").strip() or "hosts.txt"
    hosts = []
    if target_input.endswith(".txt") or os.path.exists(os.path.join(CURRENT_DIR, target_input)):
        hosts_file = os.path.join(CURRENT_DIR, target_input)
        if os.path.exists(hosts_file):
            with open(hosts_file) as f: hosts = list(set(h.strip() for h in f if h.strip() and not h.startswith("#")))
        else: print(f"{C_RED}[!] File not found!{C_RESET}"); return
    else: hosts = list(set(target_input.split()))
    print(f"\\n{C_CYAN}Scan Mode:\\n1. Strict 0-Balance\\n2. Bypass (Wi-Fi/Active Data){C_RESET}")
    bypass_data = input("Choice (default 1): ").strip() == "2"
    timeout_val = int(t) if (t := input("Timeout in seconds (default 5): ").strip()).isdigit() else 5
    max_retries = int(r) if (r := input("Max Retries (default 0): ").strip()).isdigit() else 0
    concurrency = int(c) if (c := input("Threads (default 100): ").strip()).isdigit() else 100
    connector = aiohttp.TCPConnector(limit=concurrency, ssl=False)
    timeout_obj = aiohttp.ClientTimeout(total=timeout_val * 2)
    results_list = []; start_time = time.time()
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = os.path.join(CURRENT_DIR, f"M@0scan_LOG_UNKNOWN_{ts}.txt")
    async with aiohttp.ClientSession(connector=connector, timeout=timeout_obj) as session:
        if not bypass_data:
            if not await check_zero_balance(session, timeout_val): return
            carrier = (await detect_carrier(session, timeout_val)).upper()
        else:
            print(f"{C_YELLOW}[!] PRO MODE active{C_RESET}\\n"); carrier = "WIFI"
        new_log = os.path.join(CURRENT_DIR, f"M@0scan_LOG_{carrier}_{ts}.txt")
        if os.path.exists(log_file): os.rename(log_file, new_log)
        log_file = new_log; open(log_file,"w").close()
        print(f"{C_PURPLE}{'='*70}\\nSCANNING... 🚀\\n{'='*70}{C_RESET}")
        await asyncio.gather(*[scan_host(session, h, timeout_val, max_retries, results_list, log_file) for h in hosts])
    zero = [h for c,l,h in results_list if "ZERO" in c]; bugs = [h for c,l,h in results_list if "HIDDEN" in c]
    elapsed = int(time.time() - start_time)
    header = f"# @MastersTechSolutions\\n# M@☆ Scanner V11.3\\n# Network: {carrier}\\n# Duration: {elapsed}s | Scanned: {len(hosts)}\\n# Zero-Rated: {len(zero)} | Bugs: {len(bugs)}\\n# Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\\n{'='*70}\\n"
    zero_file = os.path.join(CURRENT_DIR, f"M@0scan_{carrier}_{ts}.txt")
    with open(zero_file,"w") as f:
        f.write(header)
        for h in zero: f.write(h+"\\n")
        if bugs: f.write("\\n# HIDDEN BUGS\\n"); [f.write(h+"\\n") for h in bugs]
    with open(log_file) as f: lc = f.read()
    with open(log_file,"w") as f: f.write(header+lc)
    print(f"\\n{C_PURPLE}{'='*70}\\n✔ SCAN COMPLETE\\n{'='*70}{C_RESET}")
    print(f"Network: {C_CYAN}{carrier}{C_RESET} | Duration: {elapsed}s | Scanned: {len(hosts)}")
    print(f"Zero-Rated: {C_GREEN}{len(zero)} 🟢{C_RESET} | Bugs: {C_CYAN}{len(bugs)} 🔥{C_RESET} | Blocked: {C_RED}{len(hosts)-len(zero)-len(bugs)} 🔴{C_RESET}")
    print(f"{C_PURPLE}{'='*70}{C_RESET}\\n")

if __name__ == "__main__":
    try: asyncio.run(main())
    except KeyboardInterrupt: print("\\n[!] Scan interrupted.")`;

export default function ScriptsTab({ setTab }) {
  return (
    <div className="px-4">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        {/* Python Scanner */}
        <div className="bg-gradient-to-r from-cyan-600/20 to-blue-600/20 rounded-2xl p-4 border border-cyan-500/30 mb-4">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center">
              <Code className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-sm text-white">M@☆ Zero-Rated Scanner V11.3</h2>
              <p className="text-xs text-gray-400">Python script • Termux compatible</p>
            </div>
          </div>
          <p className="text-xs text-gray-300">Full Python script for zero-rated scanning in Termux. Works on <strong className="text-cyan-300">any network worldwide</strong> — auto-detects carrier, batch scans, saves to device storage.</p>
        </div>

        <div className="space-y-2 mb-4">
          {[
            { e: "🌍", t: "Works globally — auto-detects any carrier worldwide" },
            { e: "⚡", t: "Async batch scanning — 100 concurrent threads" },
            { e: "🔥", t: "Raw TCP Socket Sniper — detects HIDDEN BUGs bypassing DPI" },
            { e: "🔍", t: "HTTPS + HTTP dual-probe with captive portal classification" },
            { e: "📁", t: "Saves results to /storage/emulated/0/MASTERS_scanner/" },
            { e: "🛡️", t: "Auto-verifies zero SIM balance before scanning" },
          ].map((f, i) => (
            <div key={i} className="flex items-center gap-3 bg-gray-800/40 rounded-xl px-4 py-2.5 border border-gray-700/40">
              <span className="text-base">{f.e}</span>
              <span className="text-sm text-gray-300">{f.t}</span>
            </div>
          ))}
        </div>

        {/* Host Scanner explainer */}
        <div className="bg-gray-800/40 rounded-2xl p-4 border border-gray-700/40 mb-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
              <Search className="w-5 h-5 text-white" />
            </div>
            <div>
              <h4 className="font-semibold text-sm text-white">How Host Scanning Works</h4>
              <p className="text-xs text-gray-400">Understanding the scan method</p>
            </div>
          </div>
          <div className="space-y-1.5 text-xs text-gray-300">
            {[
              ['DNS Lookup', 'resolves each hostname to IP addresses'],
              ['HTTPS Probe', 'attempts HTTPS connection, checks response'],
              ['HTTP Fallback', 'retries over HTTP if HTTPS fails'],
              ['Captive Portal Check', 'detects carrier redirect/block pages'],
              ['Classification', 'marks host as ✅ zero-rated, ❌ blocked or 🚫 billed'],
            ].map(([label, desc], i) => (
              <p key={i}>{i + 1}. <span className="text-cyan-400 font-semibold">{label}</span> — {desc}</p>
            ))}
          </div>
        </div>

        <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Python Script (Termux)</h3>
        <CodeBlock title="M@☆_zero_rated_scan.py  V11.3" icon={Code} code={PYTHON_SCRIPT} color="text-gray-300" maxH="max-h-64" />

        <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl px-4 py-3 mb-6">
          <p className="text-xs text-blue-300">💡 Copy the script and follow the <button onClick={() => setTab('termux')} className="underline text-cyan-400 font-semibold">Termux Guide</button> to run it on your device.</p>
        </div>

        {/* APK Download */}
        <a href="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/699aa662b79dd361c7b3904b/MastersDeoVex.apk" download="MastersDeoVex.apk" className="block">
          <div className="bg-gradient-to-r from-emerald-600/20 to-green-600/20 rounded-2xl p-4 border border-emerald-500/30 hover:border-emerald-500/60 transition-all group mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-green-500 flex items-center justify-center group-hover:scale-110 transition-transform flex-shrink-0">
                <Download className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-sm text-white mb-1">Download Masters DeoVex APK</h3>
                <p className="text-xs text-gray-400 mb-2">Direct install — no Play Store required.</p>
                <span className="text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-full px-2 py-0.5">✅ Free Direct Download</span>
              </div>
            </div>
          </div>
        </a>
      </motion.div>
    </div>
  );
}