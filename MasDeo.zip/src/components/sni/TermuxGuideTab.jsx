import React from 'react';
import { motion } from 'framer-motion';
import { Terminal } from 'lucide-react';
import GodCommandCard from './GodCommandCard';
import { CodeBlock } from './ScriptsTab';

const INSTALL_CMDS = `pkg update && pkg upgrade -y
pkg install python python-pip git termux-tools -y
termux-setup-storage
pip install aiohttp`;

export default function TermuxGuideTab({ setTab }) {
  const steps = [
    {
      num: '1', color: 'cyan', title: 'Install Termux',
      content: (
        <>
          <p className="text-xs text-gray-300 mb-3">Download Termux from <span className="text-red-400 font-semibold">F-Droid</span> — NOT Google Play (outdated).</p>
          <div className="space-y-2">
            <a href="https://f-droid.org/en/packages/com.termux/" target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2 bg-green-500/20 border border-green-500/30 rounded-xl px-3 py-2 hover:bg-green-500/30 transition-colors">
              <span className="text-sm">📦</span>
              <span className="text-xs font-medium text-white">Download Termux from F-Droid</span>
            </a>
            <a href="https://github.com/termux/termux-app/releases" target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2 bg-gray-700/40 border border-gray-600/30 rounded-xl px-3 py-2 hover:bg-gray-700/60 transition-colors">
              <span className="text-sm">🐙</span>
              <span className="text-xs font-medium text-gray-300">Or download APK from GitHub Releases</span>
            </a>
          </div>
        </>
      )
    },
    {
      num: '2', color: 'cyan', title: 'Grant Storage Permission',
      content: (
        <>
          <p className="text-xs text-gray-400 mb-2">Run this inside Termux:</p>
          <CodeBlock title="Storage permission" icon={Terminal} code="termux-setup-storage" color="text-green-300" maxH="max-h-20" />
          <p className="text-xs text-gray-500">Accept the popup that appears on screen.</p>
        </>
      )
    },
    {
      num: '3', color: 'cyan', title: 'Update Packages & Install Python',
      content: (
        <>
          <p className="text-xs text-gray-400 mb-2">Paste all at once or run one by one:</p>
          <CodeBlock title="Install dependencies" icon={Terminal} code={INSTALL_CMDS} color="text-green-300" maxH="max-h-32" />
        </>
      )
    },
    {
      num: '4', color: 'cyan', title: 'Create MASTERS_scanner Folder',
      content: (
        <>
          <p className="text-xs text-gray-400 mb-2">Create output folder on phone storage:</p>
          <CodeBlock title="Create folder" icon={Terminal} code="mkdir -p /storage/emulated/0/MASTERS_scanner" color="text-green-300" maxH="max-h-20" />
        </>
      )
    },
    {
      num: '5', color: 'cyan', title: 'Add Your Hosts File',
      content: (
        <>
          <p className="text-xs text-gray-300 mb-2">Place a <span className="text-cyan-400">.txt</span> file with one host per line inside:</p>
          <div className="bg-gray-900/60 rounded-lg px-3 py-2 font-mono text-xs text-cyan-300 mb-2">/storage/emulated/0/MASTERS_scanner/hosts.txt</div>
          <p className="text-xs text-gray-500">Download a hosts list from the Scanner tab and move it using your file manager.</p>
        </>
      )
    },
    {
      num: '6', color: 'cyan', title: 'Save the Script',
      content: (
        <>
          <p className="text-xs text-gray-400 mb-2">Copy the script from the <button onClick={() => setTab('scripts')} className="underline text-cyan-400">Scripts tab</button>, then:</p>
          <CodeBlock title="Create script file" icon={Terminal}
            code={`nano ~/scripts/M@_zero_rated_scan.py\n# Paste script → CTRL+X → Y → Enter`}
            color="text-green-300" maxH="max-h-24" />
        </>
      )
    },
    {
      num: '7', color: 'cyan', title: 'Run the Scanner',
      content: (
        <>
          <p className="text-xs text-gray-400 mb-2">Ensure SIM balance = R0, then run:</p>
          <CodeBlock title="Run script" icon={Terminal}
            code={`python3 ~/scripts/M@_zero_rated_scan.py\n\n# Enter hosts file path or press Enter for hosts.txt\n# Choose Mode 1 (zero balance) or Mode 2 (Wi-Fi/active data)\n# Configure timeout, retries, threads when prompted`}
            color="text-green-300" maxH="max-h-28" />
        </>
      )
    },
    {
      num: '8', color: 'green', title: 'View Results',
      content: (
        <>
          <p className="text-xs text-gray-300 mb-2">Results are saved to your phone storage:</p>
          <div className="bg-gray-900/60 rounded-lg px-3 py-2 font-mono text-xs text-cyan-300 mb-2">/storage/emulated/0/MASTERS_scanner/</div>
          <p className="text-xs text-gray-500">Two files are created: full scan log and a zero-rated hosts file.</p>
        </>
      )
    },
  ];

  return (
    <div className="px-4">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <GodCommandCard />

        <div className="mt-4 space-y-4">
          {steps.map((step) => (
            <div key={step.num} className="mb-0">
              <div className="flex items-center gap-2 mb-2">
                <span className={`w-6 h-6 bg-${step.color}-500/20 text-${step.color}-400 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0`}>
                  {step.num}
                </span>
                <h3 className="text-sm font-semibold text-white">{step.title}</h3>
              </div>
              <div className="bg-gray-800/40 rounded-xl p-4 border border-gray-700/40 ml-8">
                {step.content}
              </div>
            </div>
          ))}
        </div>

        <div className="bg-blue-500/10 border border-blue-500/20 rounded-2xl p-4 mt-4 mb-4">
          <p className="text-xs font-semibold text-blue-300 mb-2">💡 Tips</p>
          <div className="space-y-1.5 text-xs text-gray-400">
            <p>• Run <span className="text-green-400 font-mono">pip install aiohttp --upgrade</span> to keep dependencies updated</p>
            <p>• Use <span className="text-green-400 font-mono">Ctrl+C</span> to stop the scan — partial results are saved</p>
            <p>• For large host lists (1000+), the scan may take 5–10 minutes</p>
            <p>• The in-app Scanner tab is faster for small lists without Termux</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}