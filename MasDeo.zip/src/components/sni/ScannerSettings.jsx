import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Settings, X, Trash2 } from 'lucide-react';

export default function ScannerSettings({ onClose }) {
  const [confirmClear, setConfirmClear] = useState(false);

  const clearHistory = () => {
    localStorage.removeItem('sni_scan_history');
    setConfirmClear(false);
    alert('✅ Scan history cleared');
  };

  const clearSharedHosts = () => {
    localStorage.removeItem('shared_target_hosts');
    alert('✅ Shared hosts cleared');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="fixed inset-0 z-50 bg-[#0a0a0f]/95 backdrop-blur-sm overflow-y-auto"
    >
      <div className="max-w-2xl mx-auto px-4 py-6 pb-32">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-cyan-400" />
            <h2 className="text-lg font-bold text-white">Scanner Settings</h2>
          </div>
          <button onClick={onClose} className="text-sm text-gray-400 hover:text-white transition-colors px-3 py-1.5 rounded-xl bg-gray-800/60 hover:bg-gray-700/60">
            ✕ Close
          </button>
        </div>

        {/* Protocol Info */}
        <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 p-5 mb-4">
          <h3 className="text-xs font-semibold text-cyan-400 uppercase tracking-wider mb-3">Protocol Details</h3>
          <div className="space-y-3 text-sm">
            <div className="flex gap-3">
              <span className="w-2 h-2 rounded-full bg-cyan-400 mt-1.5 flex-shrink-0" />
              <div>
                <p className="text-white font-medium">SSL/TLS (SSL Tick Only)</p>
                <p className="text-gray-400 text-xs mt-0.5">Tests TLS handshake on port 443. Ideal for HTTP Custom SSL Tick method.</p>
              </div>
            </div>
            <div className="flex gap-3">
              <span className="w-2 h-2 rounded-full bg-purple-400 mt-1.5 flex-shrink-0" />
              <div>
                <p className="text-white font-medium">WebSocket/WSS (Upgrade-based)</p>
                <p className="text-gray-400 text-xs mt-0.5">Sends WebSocket upgrade request. 101 Switching Protocols = eligible.</p>
              </div>
            </div>
            <div className="flex gap-3">
              <span className="w-2 h-2 rounded-full bg-yellow-400 mt-1.5 flex-shrink-0" />
              <div>
                <p className="text-white font-medium">HTTP CONNECT (Blind TCP Tunnel)</p>
                <p className="text-gray-400 text-xs mt-0.5">Sends CONNECT + UNLOCK payload. HTTP 400 response = tunnel eligible.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Score Guide */}
        <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 p-5 mb-4">
          <h3 className="text-xs font-semibold text-cyan-400 uppercase tracking-wider mb-3">Score Guide (0–6)</h3>
          <div className="space-y-2 text-xs font-mono">
            {[
              { label: 'FULL TUNNEL VERIFIED', color: 'text-green-400', score: '5–6' },
              { label: 'SSL / WEBSOCKET READY', color: 'text-cyan-400', score: '4' },
              { label: 'UPGRADE / BLIND READY', color: 'text-yellow-400', score: '3' },
              { label: 'PROXY TOLERANT', color: 'text-yellow-300', score: '2–3' },
              { label: 'BLOCKED', color: 'text-red-400', score: '0–1' },
            ].map(s => (
              <div key={s.label} className="flex justify-between">
                <span className={s.color}>{s.label}</span>
                <span className="text-gray-500">score {s.score}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Data Management */}
        <div className="bg-gray-800/40 rounded-2xl border border-gray-700/50 p-5 mb-4">
          <h3 className="text-xs font-semibold text-cyan-400 uppercase tracking-wider mb-3">Data Management</h3>
          <div className="space-y-2">
            <button
              onClick={clearSharedHosts}
              className="w-full flex items-center gap-2 text-sm text-gray-300 hover:text-white bg-gray-700/40 hover:bg-gray-700/70 border border-gray-600/40 rounded-xl px-4 py-3 transition-all"
            >
              <Trash2 className="w-4 h-4 text-yellow-400" />
              Clear Shared Hosts Box
            </button>
            <button
              onClick={() => setConfirmClear(true)}
              className="w-full flex items-center gap-2 text-sm text-gray-300 hover:text-red-300 bg-gray-700/40 hover:bg-red-900/20 border border-gray-600/40 hover:border-red-500/30 rounded-xl px-4 py-3 transition-all"
            >
              <Trash2 className="w-4 h-4 text-red-400" />
              Clear Scan History
            </button>
          </div>
          {confirmClear && (
            <div className="mt-3 bg-red-900/20 border border-red-500/30 rounded-xl p-3">
              <p className="text-xs text-red-300 mb-2">Delete all saved scan history?</p>
              <div className="flex gap-2">
                <button onClick={clearHistory} className="flex-1 text-xs bg-red-500/30 hover:bg-red-500/50 text-red-300 rounded-lg py-2 transition-colors">Yes, delete</button>
                <button onClick={() => setConfirmClear(false)} className="flex-1 text-xs bg-gray-700/60 text-gray-400 rounded-lg py-2 transition-colors">Cancel</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}