import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { History, Trash2, ChevronDown, ChevronUp, X } from 'lucide-react';

const HISTORY_KEY = 'sni_scan_history';

export function saveScanToHistory(networkName, results) {
  const history = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
  const entry = {
    id: Date.now(),
    network: networkName,
    date: new Date().toISOString(),
    total: results.length,
    eligible: results.filter(r => !['BLOCKED', 'SCANNING...'].includes(r.classification)).length,
    results,
  };
  history.unshift(entry);
  // Keep only last 20 scans
  localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, 20)));
}

export function loadHistory() {
  return JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
}

const STATUS_COLORS = {
  'FULL TUNNEL VERIFIED': 'text-green-400',
  'SSL TUNNEL READY':     'text-cyan-400',
  'WEBSOCKET READY':      'text-purple-400',
  'UPGRADE READY':        'text-blue-400',
  'BLIND TUNNEL READY':   'text-yellow-400',
  'PROXY TOLERANT':       'text-yellow-500',
  'BLOCKED':              'text-red-400',
};

function HistoryEntry({ entry, onDelete }) {
  const [expanded, setExpanded] = useState(false);
  const date = new Date(entry.date);
  const dateStr = date.toLocaleDateString();
  const timeStr = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="bg-gray-800/50 rounded-xl border border-gray-700/50 overflow-hidden">
      <button
        className="w-full flex items-center gap-3 p-4 text-left hover:bg-gray-700/20 transition-colors"
        onClick={() => setExpanded(v => !v)}
      >
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            <span className="font-semibold text-sm text-white">{entry.network}</span>
            <span className="text-[10px] bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 px-2 py-0.5 rounded-full">
              {entry.eligible}/{entry.total} eligible
            </span>
          </div>
          <p className="text-xs text-gray-500">{dateStr} at {timeStr}</p>
        </div>
        <button
          onClick={e => { e.stopPropagation(); onDelete(entry.id); }}
          className="p-1.5 text-gray-600 hover:text-red-400 transition-colors"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
        {expanded ? <ChevronUp className="w-4 h-4 text-gray-500" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 border-t border-gray-700/50 pt-3 space-y-1.5 max-h-64 overflow-y-auto">
              {entry.results.map((r, i) => (
                <div key={i} className="flex items-center justify-between text-xs">
                  <span className="font-mono text-gray-300 truncate max-w-[55%]">{r.host}:{r.port}</span>
                  <span className="text-[10px] text-gray-500 mx-1">{r.protocolLabel}</span>
                  <span className={`font-semibold ${STATUS_COLORS[r.classification] || 'text-gray-400'}`}>
                    {r.classification}
                  </span>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function SniHistoryPanel({ onClose }) {
  const [history, setHistory] = useState([]);

  useEffect(() => {
    setHistory(loadHistory());
  }, []);

  const deleteEntry = (id) => {
    const updated = history.filter(e => e.id !== id);
    setHistory(updated);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
  };

  const clearAll = () => {
    setHistory([]);
    localStorage.removeItem(HISTORY_KEY);
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: '100%' }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: '100%' }}
      transition={{ type: 'tween', duration: 0.25 }}
      className="fixed inset-0 z-50 bg-[#0a0a0f] flex flex-col"
    >
      <div className="flex items-center justify-between px-6 pt-6 pb-4 border-b border-gray-800/50">
        <div className="flex items-center gap-3">
          <History className="w-5 h-5 text-cyan-400" />
          <h2 className="font-bold text-white text-lg">Scan History</h2>
        </div>
        <div className="flex items-center gap-2">
          {history.length > 0 && (
            <button onClick={clearAll} className="text-xs text-red-400 hover:text-red-300 transition-colors px-2 py-1">
              Clear All
            </button>
          )}
          <button onClick={onClose} className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-4 space-y-3 pb-32">
        {history.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <History className="w-12 h-12 text-gray-700 mb-3" />
            <p className="text-gray-500 text-sm">No scan history yet</p>
            <p className="text-gray-600 text-xs mt-1">Completed scans will appear here</p>
          </div>
        ) : (
          history.map(entry => (
            <HistoryEntry key={entry.id} entry={entry} onDelete={deleteEntry} />
          ))
        )}
      </div>
    </motion.div>
  );
}