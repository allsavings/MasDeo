import { useContext } from 'react';
import { AuthContext } from './AuthContext';
import { userAPI } from './vpsAPI';

export function useAuth() {
  const { state, dispatch } = useContext(AuthContext);

  const signup = async (email, password, name, additionalData) => {
    dispatch({ type: 'SET_LOADING', payload: true });
    try {
      const userData = {
        email,
        password,
        name,
        ...additionalData,
      };
      const response = await userAPI.saveUser(userData);
      dispatch({ type: 'SET_USER', payload: response });
      localStorage.setItem('userEmail', email);
      return response;
    } catch (err) {
      const errorMsg = err.message || 'Signup failed';
      dispatch({ type: 'SET_ERROR', payload: errorMsg });
      throw err;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const login = async (email, password) => {
    dispatch({ type: 'SET_LOADING', payload: true });
    try {
      // If you have login endpoint on VPS, use it
      // For now, we'll use getUser and verify password on VPS side
      // POST to /api/user with credentials for verification
      const userData = await userAPI.saveUser({ email, password, action: 'login' });
      dispatch({ type: 'SET_USER', payload: userData });
      localStorage.setItem('userEmail', email);
      return userData;
    } catch (err) {
      const errorMsg = err.message || 'Login failed';
      dispatch({ type: 'SET_ERROR', payload: errorMsg });
      throw err;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const getCurrentUser = async (email) => {
    dispatch({ type: 'SET_LOADING', payload: true });
    try {
      const userData = await userAPI.getUser(email);
      dispatch({ type: 'SET_USER', payload: userData });
      return userData;
    } catch (err) {
      const errorMsg = err.message || 'Failed to load user';
      dispatch({ type: 'SET_ERROR', payload: errorMsg });
      throw err;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const logout = () => {
    dispatch({ type: 'CLEAR_USER' });
    localStorage.removeItem('userEmail');
  };

  const restoreSession = async () => {
    const savedEmail = localStorage.getItem('userEmail');
    if (savedEmail) {
      try {
        await getCurrentUser(savedEmail);
      } catch {
        logout();
      }
    }
  };

  return {
    currentUser: state.currentUser,
    loading: state.loading,
    error: state.error,
    signup,
    login,
    logout,
    getCurrentUser,
    restoreSession,
  };
}