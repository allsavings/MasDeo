import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, Unlock, X, AlertCircle } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useWIPLock } from '@/lib/WIPLockContext';

export default function LockedSectionOverlay({ isLocked, children, sectionName = 'Section', compact = false, path = null }) {
  const [showPinModal, setShowPinModal] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');
  const { verifyPin } = useWIPLock();

  if (!isLocked) return children;

  const handleCardClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setShowPinModal(true);
  };

  const handlePinSubmit = (e) => {
    e.preventDefault();
    setPinError('');
    if (verifyPin(pinInput, path)) {
      setShowPinModal(false);
      setPinInput('');
    } else {
      setPinError('Invalid PIN. Access denied.');
      setPinInput('');
      setTimeout(() => setPinError(''), 3000);
    }
  };

  const closeModal = (e) => {
    e.stopPropagation();
    setShowPinModal(false);
    setPinInput('');
    setPinError('');
  };

  return (
    <>
      {/* Card wrapper — overflow-hidden keeps blur strictly inside the card bounds */}
      <div
        onClick={handleCardClick}
        onContextMenu={(e) => e.preventDefault()}
        className="relative overflow-hidden rounded-2xl cursor-pointer"
        style={{ userSelect: 'none', WebkitUserSelect: 'none', WebkitTouchCallout: 'none' }}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => e.key === 'Enter' && handleCardClick(e)}
      >
        {/* Content — blurred behind overlay */}
        <div className="blur-sm opacity-40 pointer-events-none">
          {children}
        </div>

        {/* Frosted glass overlay — absolutely covers only this card */}
        <div className="absolute inset-0 bg-black/50 backdrop-blur-md flex items-center justify-center">
          {compact ? (
            <Lock className="w-3.5 h-3.5 text-cyan-400" />
          ) : (
            <div className="flex flex-col items-center gap-2">
              <motion.div
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
              >
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-500/30 to-blue-500/20 border border-cyan-500/50 flex items-center justify-center">
                  <Lock className="w-5 h-5 text-cyan-400" />
                </div>
              </motion.div>
              <p className="text-white font-semibold text-xs leading-tight">Coming Soon</p>
              <p className="text-gray-400 text-[10px]">{sectionName}</p>
            </div>
          )}
        </div>
      </div>

      {/* Compact PIN Modal — rendered outside the card so it's never clipped */}
      <AnimatePresence>
        {showPinModal && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm"
              onClick={closeModal}
            />

            {/* Compact Modal */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              transition={{ duration: 0.25, ease: 'easeOut' }}
              className="fixed inset-0 z-50 flex items-center justify-center p-6 pointer-events-none"
            >
              <div
                className="w-full max-w-xs bg-gray-900/95 backdrop-blur-2xl border border-gray-700/50 rounded-2xl p-5 shadow-2xl pointer-events-auto"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Header */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center">
                      <Lock className="w-3.5 h-3.5 text-cyan-400" />
                    </div>
                    <div>
                      <p className="text-white font-semibold text-sm">VIP Access</p>
                      <p className="text-cyan-400 text-[10px] font-medium">{sectionName}</p>
                    </div>
                  </div>
                  <button
                    onClick={closeModal}
                    className="w-7 h-7 rounded-lg bg-gray-800/60 hover:bg-gray-700/60 flex items-center justify-center text-gray-400 hover:text-white transition-all"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* PIN Form */}
                <form onSubmit={handlePinSubmit} className="space-y-3">
                  <label className="block text-xs font-semibold text-gray-300 uppercase tracking-wider">Enter VIP PIN</label>
                  <Input
                    type="password"
                    placeholder="••••••••"
                    value={pinInput}
                    onChange={(e) => setPinInput(e.target.value)}
                    className="bg-gray-800/60 border-gray-700/60 text-white text-center tracking-widest font-bold text-lg placeholder-gray-600 focus:border-cyan-500/50 rounded-xl"
                    maxLength="20"
                  />

                  {pinError && (
                    <motion.div
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex items-center gap-2 p-2.5 bg-red-500/10 border border-red-500/30 rounded-lg"
                    >
                      <AlertCircle className="w-3.5 h-3.5 text-red-400 flex-shrink-0" />
                      <p className="text-xs text-red-400">{pinError}</p>
                    </motion.div>
                  )}

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-semibold rounded-xl h-9 text-sm"
                  >
                    <Unlock className="w-3.5 h-3.5 mr-1.5" />
                    Unlock
                  </Button>
                </form>

              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}