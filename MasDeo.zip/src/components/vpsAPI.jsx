const VPS_UPLOAD_URL = 'https://media.mastersdeovex.co.za/upload';
const VPS_UPLOAD_SECRET = 'LoadMoreAds@@Masters@@Deovex$$';

/**
 * Upload file directly to the Masters DeoVex Go reverse proxy.
 * Returns { url: "https://media.mastersdeovex.co.za/uploads/uuid_filename.ext" }
 */
export async function uploadFile(file) {
  const formData = new FormData();
  formData.append('file', file);

  const response = await fetch(VPS_UPLOAD_URL, {
    method: 'POST',
    headers: {
      'X-Upload-Secret': VPS_UPLOAD_SECRET,
      // Do NOT set Content-Type — browser sets multipart boundary automatically
    },
    body: formData,
  });

  if (!response.ok) {
    if (response.status === 403) throw new Error('Upload rejected: Authentication failed with the proxy.');
    if (response.status === 415) throw new Error('Upload rejected: File type not allowed.');
    if (response.status === 413) throw new Error('Upload rejected: File is too large (max 500MB).');
    const err = await response.text();
    throw new Error(`Upload failed (${response.status}): ${err}`);
  }

  const data = await response.json();

  if (!data.file_url) {
    throw new Error(data.error || 'Upload failed — no file_url returned');
  }

  return { url: data.file_url };
}

export default { uploadFile };