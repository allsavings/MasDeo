import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ExternalLink } from 'lucide-react';

/**
 * Reusable expandable section with subsections.
 * 
 * Props:
 *  - title: string
 *  - icon: Lucide icon component
 *  - color: tailwind gradient string e.g. "from-blue-500 to-cyan-500"
 *  - borderColor: tailwind border color e.g. "border-blue-500/30"
 *  - bgColor: tailwind bg e.g. "bg-blue-500/10"
 *  - items: [{ name, link, facts: [string] }]
 */
export default function InfoExpandSection({ title, icon: Icon, color, borderColor, bgColor, items }) {
  const [open, setOpen] = useState(false);
  const [expandedItem, setExpandedItem] = useState(null);

  return (
    <div className={`rounded-2xl border ${borderColor} overflow-hidden`}>
      {/* Main header */}
      <button
        onClick={() => setOpen(!open)}
        className={`w-full flex items-center gap-3 p-4 ${bgColor} hover:opacity-90 transition-opacity`}
      >
        <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center flex-shrink-0`}>
          <Icon className="w-5 h-5 text-white" />
        </div>
        <span className="flex-1 text-left font-semibold text-white text-sm">{title}</span>
        <motion.div animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.2 }}>
          <ChevronDown className="w-4 h-4 text-gray-400" />
        </motion.div>
      </button>

      {/* Subsections */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden"
          >
            <div className="divide-y divide-gray-800/60">
              {items.map((item, idx) => (
                <div key={idx} className="bg-gray-900/60">
                  <button
                    onClick={() => setExpandedItem(expandedItem === idx ? null : idx)}
                    className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-800/40 transition-colors"
                  >
                    <span className={`text-xs font-bold w-5 h-5 rounded-full bg-gradient-to-br ${color} flex items-center justify-center flex-shrink-0 text-white`}>
                      {idx + 1}
                    </span>
                    <span className="flex-1 text-left text-sm text-white font-medium">{item.name}</span>
                    <motion.div animate={{ rotate: expandedItem === idx ? 180 : 0 }} transition={{ duration: 0.2 }}>
                      <ChevronDown className="w-3.5 h-3.5 text-gray-500" />
                    </motion.div>
                  </button>

                  <AnimatePresence>
                    {expandedItem === idx && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden"
                      >
                        <div className="px-4 pb-4 space-y-2">
                          {item.facts.map((fact, fIdx) => (
                            <div key={fIdx} className="flex items-start gap-2">
                              <span className="text-green-400 text-xs mt-0.5 flex-shrink-0">✓</span>
                              <p className="text-xs text-gray-300 leading-relaxed">{fact}</p>
                            </div>
                          ))}
                          {item.link && (
                            <a
                              href={item.link}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1.5 mt-2 text-xs text-gray-500 hover:text-gray-300 transition-colors border border-gray-700/50 hover:border-gray-600/60 rounded-lg px-3 py-1.5"
                            >
                              <ExternalLink className="w-3 h-3" />
                              Visit Website
                            </a>
                          )}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}