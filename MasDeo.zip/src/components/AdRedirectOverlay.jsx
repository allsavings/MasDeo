import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';

export default function AdRedirectOverlay({ isOpen, onClose }) {
  const [countdown, setCountdown] = useState(15);
  const [clickReduceActive, setClickReduceActive] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      setCountdown(15);
      setClickReduceActive(false);
      return;
    }

    setCountdown(15);
    setClickReduceActive(true);
    
    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setTimeout(() => onClose(), 200);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen, onClose]);

  const handleClick = () => {
    if (clickReduceActive && countdown > 5) {
      setCountdown(5);
      setClickReduceActive(false);
    }
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-[998] pointer-events-none" />
      <motion.div
        initial={{ opacity: 0, y: -100 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -100 }}
        transition={{ duration: 0.2 }}
        className="fixed top-4 left-1/2 z-[999] w-full max-w-sm px-4 pointer-events-auto"
        onClick={e => e.stopPropagation()}
        style={{ transform: 'translateX(-50%)' }}
      >
        <div className="bg-gradient-to-r from-cyan-500/90 to-blue-500/90 backdrop-blur-lg rounded-2xl p-4 border border-cyan-400/50 shadow-2xl">
          <div className="flex items-center justify-between gap-3">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-bold text-white/80 uppercase tracking-wider">Ad Loading</span>
                <motion.div 
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 0.5, repeat: Infinity }}
                  className="text-lg font-bold text-white"
                >
                  {countdown}s
                </motion.div>
              </div>
              <div className="w-full bg-white/20 rounded-full h-1.5 overflow-hidden border border-white/30">
                <motion.div
                  className="bg-white h-full"
                  animate={{ width: `${(countdown / 15) * 100}%` }}
                  transition={{ duration: 1, ease: 'linear' }}
                />
              </div>
              {clickReduceActive && countdown > 5 && (
                <p className="text-[10px] text-white/90 mt-1">👆 Tap to skip to 5s</p>
              )}
            </div>
            
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={handleClick}
              className="bg-white text-cyan-600 font-bold px-3 py-2 rounded-lg text-xs whitespace-nowrap hover:bg-white/90 transition-all"
            >
              Skip {countdown}s
            </motion.button>
          </div>
        </div>
      </motion.div>
    </>
  );
}