import { useContext } from 'react';
import { AuthContext } from './AuthContext';
import { userAPI } from './vpsAPI';

export function useUser() {
  const { state, dispatch } = useContext(AuthContext);

  const updateProfile = async (updates) => {
    if (!state.currentUser) throw new Error('No user logged in');
    dispatch({ type: 'SET_LOADING', payload: true });
    try {
      const updatedUser = { ...state.currentUser, ...updates };
      const response = await userAPI.saveUser(updatedUser);
      dispatch({ type: 'SET_USER', payload: response });
      return response;
    } catch (err) {
      dispatch({ type: 'SET_ERROR', payload: err.message });
      throw err;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const updateSubscription = async (plan, status, additionalData) => {
    if (!state.currentUser) throw new Error('No user logged in');
    dispatch({ type: 'SET_LOADING', payload: true });
    try {
      const updatedUser = {
        ...state.currentUser,
        subscription: { plan, status, ...additionalData },
      };
      const response = await userAPI.saveUser(updatedUser);
      dispatch({ type: 'SET_USER', payload: response });
      return response;
    } catch (err) {
      dispatch({ type: 'SET_ERROR', payload: err.message });
      throw err;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const addFile = async (fileName, fileUrl) => {
    if (!state.currentUser) throw new Error('No user logged in');
    dispatch({ type: 'SET_LOADING', payload: true });
    try {
      const files = state.currentUser.files || [];
      const updatedUser = {
        ...state.currentUser,
        files: [...files, { name: fileName, url: fileUrl, uploadedAt: new Date().toISOString() }],
      };
      const response = await userAPI.saveUser(updatedUser);
      dispatch({ type: 'SET_USER', payload: response });
      return response;
    } catch (err) {
      dispatch({ type: 'SET_ERROR', payload: err.message });
      throw err;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  return {
    currentUser: state.currentUser,
    loading: state.loading,
    error: state.error,
    updateProfile,
    updateSubscription,
    addFile,
  };
}