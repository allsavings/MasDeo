import React from 'react';

const r = 28;
const cx = 36;
const cy = 36;
const circleD = `M ${cx},${cy} m -${r},0 a ${r},${r} 0 1,1 ${r * 2},0 a ${r},${r} 0 1,1 -${r * 2},0`;

export default function SpinningCreatorRing() {
  return (
    <>
      <style>{`
        @keyframes creatorRingSpin {
          from { transform: rotate(0deg); }
          to   { transform: rotate(360deg); }
        }
        .creator-ring-spin {
          animation: creatorRingSpin 8s linear infinite;
          transform-origin: 36px 36px;
        }
      `}</style>
      <svg
        width="72"
        height="72"
        viewBox="0 0 72 72"
        className="absolute pointer-events-none"
        style={{ top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }}
        overflow="visible"
      >
        <defs>
          <path id="creatorRingPath" d={circleD} />
          <linearGradient id="creatorRingGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#c084fc" />
            <stop offset="50%" stopColor="#e879f9" />
            <stop offset="100%" stopColor="#c084fc" />
          </linearGradient>
        </defs>
        <g className="creator-ring-spin">
          <text
            fontSize="7"
            fontWeight="700"
            letterSpacing="1.6"
            fontFamily="ui-sans-serif, system-ui, sans-serif"
          >
            <textPath href="#creatorRingPath" startOffset="0%">
              <tspan fill="url(#creatorRingGrad)" opacity="0.9">
                CREATOR MODE • CREATOR MODE •
              </tspan>
            </textPath>
          </text>
        </g>
      </svg>
    </>
  );
}