import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Lock, Delete } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function PinLock({ onUnlock }) {
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const savedPin = localStorage.getItem('app_pin');

  const handleNumberClick = (num) => {
    if (pin.length < 4) {
      const newPin = pin + num;
      setPin(newPin);
      
      if (newPin.length === 4) {
        if (newPin === savedPin) {
          onUnlock();
        } else {
          setError('Incorrect PIN');
          setTimeout(() => {
            setPin('');
            setError('');
          }, 1000);
        }
      }
    }
  };

  const handleDelete = () => {
    setPin(pin.slice(0, -1));
    setError('');
  };

  return (
    <div className="fixed inset-0 bg-gradient-to-b from-[#0a0a0f] to-[#0f0f1a] flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center"
      >
        <div className="w-20 h-20 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
          <Lock className="w-10 h-10 text-blue-400" />
        </div>
        
        <h2 className="text-2xl font-bold text-white mb-2">Enter PIN</h2>
        <p className="text-gray-400 mb-4">Enter your 4-digit PIN to unlock</p>
        
        <button
          onClick={() => {
            if (confirm('Forgot PIN? You will be logged out and need to sign in again.')) {
              localStorage.removeItem('app_pin');
              window.location.reload();
            }
          }}
          className="text-blue-400 text-sm mb-8 hover:underline"
        >
          Forgot PIN?
        </button>

        <div className="flex gap-3 justify-center mb-4">
          {[0, 1, 2, 3].map((i) => (
            <div
              key={i}
              className={`w-4 h-4 rounded-full ${
                pin.length > i ? 'bg-blue-500' : 'bg-gray-700'
              }`}
            />
          ))}
        </div>

        {error && (
          <p className="text-red-400 text-sm mb-4">{error}</p>
        )}

        <div className="grid grid-cols-3 gap-4 max-w-xs mx-auto">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9, '', 0, 'delete'].map((num) => (
            <button
              key={num}
              onClick={() => num === 'delete' ? handleDelete() : num !== '' && handleNumberClick(num.toString())}
              disabled={num === ''}
              className={`w-20 h-20 rounded-2xl text-2xl font-bold transition-all ${
                num === 'delete'
                  ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
                  : num === ''
                  ? 'invisible'
                  : 'bg-gray-800/50 text-white hover:bg-gray-700/50'
              }`}
            >
              {num === 'delete' ? <Delete className="w-6 h-6 mx-auto" /> : num}
            </button>
          ))}
        </div>
      </motion.div>
    </div>
  );
}