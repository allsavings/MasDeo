import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus, BookOpen, Upload, Trash2, Eye, EyeOff,
  Play, CheckCircle, Copy, Youtube, Link2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const CATEGORIES = [
  { value: 'graphic_design', label: 'Graphic Design' },
  { value: 'content_writing', label: 'Content Writing' },
  { value: 'web_dev', label: 'Web Development' },
  { value: 'digital_marketing', label: 'Digital Marketing' },
  { value: 'video_editing', label: 'Video Editing' },
  { value: 'programming', label: 'Programming' },
  { value: 'other', label: 'Other' }
];

export default function CreatorLearnSkills({ user }) {
  const [courses, setCourses] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [uploadingThumb, setUploadingThumb] = useState(false);
  const [copiedId, setCopiedId] = useState(null);

  const [form, setForm] = useState({
    title: '', description: '', category: 'other',
    video_url: '', thumbnail_url: '', duration: '',
    is_free: false, price: 0, is_published: false
  });

  useEffect(() => {
    if (user) loadCourses();
  }, [user]);

  const loadCourses = async () => {
    const data = await base44.entities.CreatorCourse.filter({ creator_email: user.email }, '-created_date');
    setCourses(data);
  };

  const handleThumbUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingThumb(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setForm(f => ({ ...f, thumbnail_url: file_url }));
    setUploadingThumb(false);
  };

  const handleSave = async () => {
    await base44.entities.CreatorCourse.create({ ...form, creator_email: user.email });
    setForm({ title: '', description: '', category: 'other', video_url: '', thumbnail_url: '', duration: '', is_free: false, price: 0, is_published: false });
    setShowForm(false);
    loadCourses();
  };

  const handleDelete = async (id) => {
    await base44.entities.CreatorCourse.delete(id);
    loadCourses();
  };

  const togglePublish = async (course) => {
    await base44.entities.CreatorCourse.update(course.id, { is_published: !course.is_published });
    loadCourses();
  };

  const copyLink = (url, id) => {
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="mt-2">
      {/* Creator header */}
      <div className="mx-4 mb-4 bg-gradient-to-r from-purple-900/40 to-pink-900/40 rounded-2xl p-4 border border-purple-500/30">
        <div className="flex items-center gap-2 mb-1">
          <BookOpen className="w-4 h-4 text-purple-400" />
          <span className="text-sm font-semibold text-purple-300">Creator Dashboard — Learn Skills</span>
        </div>
        <p className="text-xs text-gray-400">Add your courses via YouTube link or any video URL</p>
        <div className="flex gap-4 mt-3 text-xs text-gray-400">
          <span className="flex items-center gap-1"><BookOpen className="w-3 h-3 text-purple-400" />{courses.length} Courses</span>
          <span className="flex items-center gap-1"><Eye className="w-3 h-3 text-green-400" />{courses.filter(c => c.is_published).length} Published</span>
        </div>
      </div>

      <div className="px-4 space-y-3">
        <button
          onClick={() => setShowForm(v => !v)}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl border border-dashed border-purple-500/50 text-purple-400 text-sm hover:bg-purple-500/10 transition-colors"
        >
          <Plus className="w-4 h-4" /> Add Course
        </button>

        <AnimatePresence>
          {showForm && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="bg-gray-800/60 rounded-2xl p-4 border border-gray-700/50 space-y-3"
            >
              <Input placeholder="Course Title *" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} className="bg-gray-900/50 border-gray-700 text-white text-sm" />
              <textarea placeholder="What will students learn?" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                className="w-full bg-gray-900/50 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm resize-none h-16" />

              <div className="grid grid-cols-2 gap-2">
                <select value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}
                  className="bg-gray-900/50 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm">
                  {CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                </select>
                <Input placeholder="Duration (e.g. 2h)" value={form.duration} onChange={e => setForm(f => ({ ...f, duration: e.target.value }))} className="bg-gray-900/50 border-gray-700 text-white text-sm" />
              </div>

              <div className="relative">
                <Youtube className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-red-400" />
                <Input placeholder="YouTube or video URL *" value={form.video_url} onChange={e => setForm(f => ({ ...f, video_url: e.target.value }))} className="bg-gray-900/50 border-gray-700 text-white text-sm pl-9" />
              </div>

              {/* Thumbnail */}
              <div>
                <input type="file" id="thumb-upload" accept="image/*" className="hidden" onChange={handleThumbUpload} />
                <label htmlFor="thumb-upload" className="flex items-center justify-center gap-2 border border-dashed border-gray-600 rounded-xl py-2 cursor-pointer hover:border-purple-500/50 transition-colors text-sm text-gray-400">
                  <Upload className="w-4 h-4" />
                  {uploadingThumb ? 'Uploading...' : form.thumbnail_url ? '✓ Thumbnail uploaded' : 'Upload thumbnail (optional)'}
                </label>
              </div>

              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
                  <input type="checkbox" checked={form.is_free} onChange={e => setForm(f => ({ ...f, is_free: e.target.checked }))} className="accent-purple-500" />
                  Free course
                </label>
                {!form.is_free && (
                  <Input type="number" placeholder="Price (R)" value={form.price} onChange={e => setForm(f => ({ ...f, price: Number(e.target.value) }))} className="bg-gray-900/50 border-gray-700 text-white text-sm w-28" />
                )}
              </div>

              <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
                <input type="checkbox" checked={form.is_published} onChange={e => setForm(f => ({ ...f, is_published: e.target.checked }))} className="accent-purple-500" />
                Publish immediately (visible to subscribers)
              </label>

              <div className="flex gap-2">
                <Button onClick={handleSave} disabled={!form.title || !form.video_url} className="flex-1 bg-purple-600 text-sm py-2 disabled:opacity-50">Save Course</Button>
                <Button onClick={() => setShowForm(false)} variant="outline" className="flex-1 text-sm py-2">Cancel</Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {courses.map((course, i) => (
          <motion.div key={course.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
            className="bg-gray-800/40 rounded-2xl overflow-hidden border border-gray-700/50"
          >
            {course.thumbnail_url && (
              <img src={course.thumbnail_url} alt={course.title} className="w-full h-28 object-cover" />
            )}
            <div className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-semibold text-white text-sm">{course.title}</p>
                    {course.is_published ? (
                      <span className="text-xs bg-green-500/20 text-green-400 px-2 py-0.5 rounded-full">Live</span>
                    ) : (
                      <span className="text-xs bg-gray-700/50 text-gray-400 px-2 py-0.5 rounded-full">Draft</span>
                    )}
                    {course.is_free ? (
                      <span className="text-xs bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded-full">Free</span>
                    ) : (
                      <span className="text-xs bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full">R{course.price}</span>
                    )}
                  </div>
                  <p className="text-xs text-gray-500 mt-0.5">{CATEGORIES.find(c => c.value === course.category)?.label}</p>
                  {course.video_url && (
                    <button onClick={() => copyLink(course.video_url, course.id)} className="mt-1.5 flex items-center gap-1 text-xs text-cyan-400">
                      {copiedId === course.id ? <CheckCircle className="w-3 h-3" /> : <Link2 className="w-3 h-3" />}
                      {copiedId === course.id ? 'Copied!' : 'Copy video link'}
                    </button>
                  )}
                </div>
                <div className="flex flex-col gap-2 ml-2">
                  <button onClick={() => togglePublish(course)} className="p-1.5 rounded-lg bg-gray-700/50 hover:bg-gray-700 transition-colors">
                    {course.is_published ? <Eye className="w-4 h-4 text-green-400" /> : <EyeOff className="w-4 h-4 text-gray-500" />}
                  </button>
                  <button onClick={() => handleDelete(course.id)} className="p-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 transition-colors">
                    <Trash2 className="w-4 h-4 text-red-400" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}

        {courses.length === 0 && (
          <p className="text-center text-gray-600 text-sm py-6">No courses yet. Add your first one above.</p>
        )}
      </div>
    </div>
  );
}