import React, { useState, useEffect } from 'react';
import { Download, Share2, MessageCircle, Heart, Play, ExternalLink, Eye } from 'lucide-react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';

export default function ContentItem({ item }) {
  const [user, setUser] = useState(null);
  const [stats, setStats] = useState({ views: 0, downloads: 0, reactions: 0, comments: 0 });
  const [userReacted, setUserReacted] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [comments, setComments] = useState([]);
  const [commentText, setCommentText] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUserAndStats();
  }, [item.id]);

  const loadUserAndStats = async () => {
    try {
      const userData = await base44.auth.me();
      setUser(userData);

      // Track view
      const existingView = await base44.entities.ContentView.filter({ 
        content_id: item.id, 
        user_email: userData.email 
      });
      if (existingView.length === 0) {
        await base44.entities.ContentView.create({ content_id: item.id, user_email: userData.email });
      }

      // Load stats
      const [views, downloads, reactions, commentsData] = await Promise.all([
        base44.entities.ContentView.filter({ content_id: item.id }),
        base44.entities.ContentDownload.filter({ content_id: item.id }),
        base44.entities.ContentReaction.filter({ content_id: item.id }),
        base44.entities.ContentComment.filter({ content_id: item.id })
      ]);

      setStats({
        views: views.length,
        downloads: downloads.length,
        reactions: reactions.length,
        comments: commentsData.length
      });

      // Check if user already reacted
      const userReaction = reactions.find(r => r.user_email === userData.email);
      setUserReacted(!!userReaction);

      // Load comments sorted by date
      setComments(commentsData.sort((a, b) => new Date(b.created_date) - new Date(a.created_date)));
    } catch (error) {
      console.log('Error loading stats:', error);
    }
    setLoading(false);
  };

  const handleReaction = async () => {
    if (!user) return;
    
    try {
      if (userReacted) {
        // Remove reaction
        const reactions = await base44.entities.ContentReaction.filter({ 
          content_id: item.id, 
          user_email: user.email 
        });
        if (reactions.length > 0) {
          await base44.entities.ContentReaction.delete(reactions[0].id);
        }
        setUserReacted(false);
        setStats(prev => ({ ...prev, reactions: prev.reactions - 1 }));
      } else {
        // Add reaction
        await base44.entities.ContentReaction.create({ 
          content_id: item.id, 
          user_email: user.email,
          reaction_type: 'like'
        });
        setUserReacted(true);
        setStats(prev => ({ ...prev, reactions: prev.reactions + 1 }));
      }
    } catch (error) {
      console.log('Error toggling reaction:', error);
    }
  };

  const handleDownload = async () => {
    if (!user) return;

    try {
      // Track download
      const existingDownload = await base44.entities.ContentDownload.filter({ 
        content_id: item.id, 
        user_email: user.email 
      });
      if (existingDownload.length === 0) {
        await base44.entities.ContentDownload.create({ content_id: item.id, user_email: user.email });
        setStats(prev => ({ ...prev, downloads: prev.downloads + 1 }));
      }

      // Open file
      const url = item.file_url || item.video_url || item.external_link;
      if (url) window.open(url, '_blank');
    } catch (error) {
      console.log('Error tracking download:', error);
    }
  };

  const handleShare = async () => {
    const shareUrl = window.location.origin + window.location.pathname + window.location.search;
    if (navigator.share) {
      try {
        await navigator.share({
          title: item.title || item.file_name || item.server_name,
          text: item.description || 'Check out this content!',
          url: shareUrl,
        });
      } catch (err) {
        console.log('Share cancelled');
      }
    } else {
      navigator.clipboard.writeText(shareUrl);
      alert('Link copied to clipboard!');
    }
  };

  const handleComment = async () => {
    if (!commentText.trim() || !user) return;

    try {
      const userProfiles = await base44.entities.UserProfile.filter({ created_by: user.email });
      const userName = userProfiles.length > 0 ? userProfiles[0].nickname : user.full_name;

      const newComment = await base44.entities.ContentComment.create({
        content_id: item.id,
        user_email: user.email,
        user_name: userName,
        comment_text: commentText
      });

      setComments([newComment, ...comments]);
      setStats(prev => ({ ...prev, comments: prev.comments + 1 }));
      setCommentText('');
    } catch (error) {
      console.log('Error posting comment:', error);
    }
  };

  if (loading) {
    return (
      <div className="bg-gray-800/60 rounded-lg p-4 border border-gray-700/50 animate-pulse">
        <div className="h-20 bg-gray-700/50 rounded"></div>
      </div>
    );
  }

  return (
    <div className="bg-gray-800/60 rounded-lg p-4 border border-gray-700/50">
      {/* Content Display */}
      <div className="flex items-start gap-3 mb-3">
        {item.thumbnail_url && (
          <img 
            src={item.thumbnail_url} 
            alt={item.title || item.file_name}
            className="w-20 h-20 rounded-lg object-cover"
          />
        )}
        <div className="flex-1">
          <h4 className="font-semibold text-white text-sm mb-1">
            {item.title || item.file_name || item.server_name}
          </h4>
          {item.description && (
            <p className="text-xs text-gray-400 mb-2 line-clamp-2">{item.description}</p>
          )}
          <div className="flex items-center gap-2 flex-wrap text-xs">
            <span className="text-gray-500 flex items-center gap-1">
              <Eye className="w-3 h-3" /> {stats.views}
            </span>
            {item.server_location && <span className="text-gray-500">📍 {item.server_location}</span>}
            {item.location && <span className="text-gray-500">📍 {item.location}</span>}
            {item.file_type && <span className="text-blue-400">{item.file_type.toUpperCase()}</span>}
            {item.duration && <span className="text-gray-500">⏱️ {item.duration}</span>}
            {item.resource_type && (
              <span className="text-blue-400">
                {item.resource_type.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
              </span>
            )}
            {(item.is_free !== undefined) && (
              <span className={`px-2 py-0.5 rounded-full ${
                item.is_free ? 'bg-green-500/20 text-green-400' : 'bg-amber-500/20 text-amber-400'
              }`}>
                {item.is_free ? 'Free' : `R${item.price}`}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center gap-2 pt-3 border-t border-gray-700/50">
        <button
          onClick={handleReaction}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs transition-all ${
            userReacted ? 'bg-pink-500/20 text-pink-400' : 'bg-gray-700/50 text-gray-400 hover:bg-gray-700'
          }`}
        >
          <Heart className={`w-3.5 h-3.5 ${userReacted ? 'fill-current' : ''}`} />
          {stats.reactions}
        </button>
        
        {(item.file_url || item.video_url || item.external_link) && (
          <button
            onClick={handleDownload}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 transition-all"
          >
            {item.video_url ? <Play className="w-3.5 h-3.5" /> : item.external_link ? <ExternalLink className="w-3.5 h-3.5" /> : <Download className="w-3.5 h-3.5" />}
            {item.video_url ? 'Watch' : item.external_link ? 'Visit' : 'Download'}
            <span className="text-[10px] text-gray-500">({stats.downloads})</span>
          </button>
        )}
        
        <button
          onClick={handleShare}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs bg-gray-700/50 text-gray-400 hover:bg-gray-700 transition-all"
        >
          <Share2 className="w-3.5 h-3.5" />
          Share
        </button>
        
        <button
          onClick={() => setShowComments(!showComments)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs bg-gray-700/50 text-gray-400 hover:bg-gray-700 transition-all ml-auto"
        >
          <MessageCircle className="w-3.5 h-3.5" />
          {stats.comments}
        </button>
      </div>

      {/* Comments Section */}
      {showComments && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="mt-3 pt-3 border-t border-gray-700/50"
        >
          <div className="space-y-2 mb-3 max-h-40 overflow-y-auto">
            {comments.length === 0 ? (
              <p className="text-xs text-gray-500 text-center py-2">No comments yet. Be the first!</p>
            ) : (
              comments.map((comment) => (
                <div key={comment.id} className="bg-gray-700/30 rounded-lg p-2">
                  <div className="flex items-start justify-between mb-1">
                    <span className="text-xs font-semibold text-gray-300">{comment.user_name}</span>
                    <span className="text-[10px] text-gray-600">
                      {new Date(comment.created_date).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400">{comment.comment_text}</p>
                </div>
              ))
            )}
          </div>
          <div className="flex gap-2">
            <input
              type="text"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleComment()}
              placeholder="Add a comment..."
              className="flex-1 bg-gray-700/50 border border-gray-600 rounded-lg px-3 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
            />
            <button
              onClick={handleComment}
              className="px-3 py-1.5 bg-blue-500 text-white rounded-lg text-xs hover:bg-blue-600 transition-all"
            >
              Post
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
}