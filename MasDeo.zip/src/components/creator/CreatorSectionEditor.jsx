import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus, Pencil, Trash2, Eye, EyeOff, Upload,
  Check, X, Link2, ChevronDown, ChevronUp, FolderPlus, Copy, Plug, ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import DeleteConfirmationDialog from '../DeleteConfirmationDialog';

const DEFAULT_TEMPLATES = {
  ethical: [
    {
      title: 'Recommended VPN',
      items: [
        { 
          title: 'Lets VPN Go', 
          description: 'Fast, secure, and free VPN service. Protect your privacy and access content worldwide.', 
          link_url: 'https://play.google.com/store/apps/details?id=com.letsvpn.vpn', 
          icon_color: 'from-green-500 to-emerald-500', 
          download_links: [
            { label: 'Download from PlayStore', url: 'https://play.google.com/store/apps/details?id=com.letsvpn.vpn' }, 
            { label: 'Download APK Direct', url: 'https://example.com/letsvpn.apk' }
          ], 
          features: ['No registration required', 'Unlimited bandwidth', 'Multiple servers'],
          subsections: []
        },
      ]
    },
  ],
  learn: [
    {
      title: 'Available Courses',
      items: [
        { title: 'Web Development Basics', description: 'Learn HTML, CSS & JavaScript', icon_color: 'from-blue-500 to-cyan-500', subsections: [] },
      ]
    }
  ],
  earn: [
    {
      title: 'Opportunities',
      items: [
        { title: 'Forex Trading', description: 'Trade currencies and earn from market movements', icon_color: 'from-green-500 to-emerald-500', subsections: [] },
      ]
    }
  ]
};

const COLOR_OPTIONS = [
  'from-blue-500 to-cyan-500',
  'from-green-500 to-emerald-500',
  'from-purple-500 to-pink-500',
  'from-amber-500 to-orange-500',
  'from-red-500 to-rose-500',
  'from-indigo-500 to-blue-500',
  'from-cyan-500 to-teal-500',
  'from-emerald-500 to-green-500',
];

export default function CreatorSectionEditor({ user, sectionPage }) {
  const [sections, setSections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [initialized, setInitialized] = useState(false);

  // Delete confirmation state
  const [deleteDialog, setDeleteDialog] = useState({ isOpen: false, type: null, id: null, categoryId: null, name: null });
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteSubDialog, setDeleteSubDialog] = useState({ isOpen: false, idx: null, title: null });
  const [isDeletingSubsection, setIsDeletingSubsection] = useState(false);

  // Category (Section) state
  const [editingCategory, setEditingCategory] = useState(null);
  const [editingCategoryTitle, setEditingCategoryTitle] = useState('');
  const [expandedCategory, setExpandedCategory] = useState(null);

  // Main Section (Item) state
  const [addingItemToCategory, setAddingItemToCategory] = useState(null);
  const [editingItem, setEditingItem] = useState(null);
  const [expandedItem, setExpandedItem] = useState(null);

  // Subsection state
  const [addingSubsectionToItem, setAddingSubsectionToItem] = useState(null);
  const [editingSubsectionIdx, setEditingSubsectionIdx] = useState(null);
  const [subsectionForm, setSubsectionForm] = useState({
    title: '', description: '', link_url: '', icon_color: 'from-blue-500 to-cyan-500', 
    file_url: '', download_links: [], features: []
  });
  const [uploadingSubFile, setUploadingSubFile] = useState(false);
  const [newSubDownloadLabel, setNewSubDownloadLabel] = useState('');
  const [newSubDownloadUrl, setNewSubDownloadUrl] = useState('');
  const [newSubFeature, setNewSubFeature] = useState('');

  const [itemForm, setItemForm] = useState({
    title: '', description: '', link_url: '', icon_color: 'from-blue-500 to-cyan-500',
    icon_image_url: '', file_url: '', download_links: [], features: [], subsections: []
  });

  const [uploadingFile, setUploadingFile] = useState(false);
  const [uploadingIconImage, setUploadingIconImage] = useState(false);
  const [newDownloadLabel, setNewDownloadLabel] = useState('');
  const [newDownloadUrl, setNewDownloadUrl] = useState('');
  const [newFeature, setNewFeature] = useState('');

  useEffect(() => {
    if (user) loadData();
  }, [user, sectionPage]);

  const loadData = async () => {
    setLoading(true);
    const existingSections = await base44.entities.CreatorSection.filter(
      { creator_email: user.email, section_page: sectionPage }, 'sort_order'
    );

    if (existingSections.length === 0 && !initialized) {
      await seedDefaults();
      setInitialized(true);
      return;
    }

    const sectionsWithItems = await Promise.all(
      existingSections.map(async (sec) => {
        const items = await base44.entities.CreatorItem.filter(
          { section_id: sec.id }, 'sort_order'
        );
        return { ...sec, items };
      })
    );
    setSections(sectionsWithItems);
    setLoading(false);
  };

  const seedDefaults = async () => {
    const template = DEFAULT_TEMPLATES[sectionPage] || [];
    for (let si = 0; si < template.length; si++) {
      const tSec = template[si];
      const sec = await base44.entities.CreatorSection.create({
        creator_email: user.email,
        section_page: sectionPage,
        title: tSec.title,
        sort_order: si,
        is_visible: true
      });
      for (let ii = 0; ii < tSec.items.length; ii++) {
        await base44.entities.CreatorItem.create({
          creator_email: user.email,
          section_id: sec.id,
          section_page: sectionPage,
          ...tSec.items[ii],
          sort_order: ii,
          is_visible: true
        });
      }
    }
    loadData();
  };

  const addCategory = async () => {
    if (sections.length >= 4) {
      alert('You can only create up to 4 categories per page');
      return;
    }
    const newSec = await base44.entities.CreatorSection.create({
      creator_email: user.email,
      section_page: sectionPage,
      title: 'New Category',
      sort_order: sections.length,
      is_visible: true
    });
    setSections(prev => [...prev, { ...newSec, items: [] }]);
    setEditingCategory(newSec.id);
    setEditingCategoryTitle('New Category');
  };

  const saveCategoryTitle = async (catId) => {
    await base44.entities.CreatorSection.update(catId, { title: editingCategoryTitle });
    setSections(prev => prev.map(s => s.id === catId ? { ...s, title: editingCategoryTitle } : s));
    setEditingCategory(null);
  };

  const deleteCategory = async (catId) => {
    const sec = sections.find(s => s.id === catId);
    setDeleteDialog({
      isOpen: true,
      type: 'category',
      id: catId,
      categoryId: null,
      name: sec.title
    });
  };

  const confirmDeleteCategory = async () => {
    const catId = deleteDialog.id;
    setIsDeleting(true);
    try {
      const sec = sections.find(s => s.id === catId);
      for (const item of sec.items) {
        await base44.entities.CreatorItem.delete(item.id);
      }
      await base44.entities.CreatorSection.delete(catId);
      setSections(prev => prev.filter(s => s.id !== catId));
    } finally {
      setIsDeleting(false);
      setDeleteDialog({ isOpen: false, type: null, id: null, categoryId: null, name: null });
    }
  };

  const toggleCategoryVisibility = async (sec) => {
    await base44.entities.CreatorSection.update(sec.id, { is_visible: !sec.is_visible });
    setSections(prev => prev.map(s => s.id === sec.id ? { ...s, is_visible: !s.is_visible } : s));
  };

  const openAddMainSection = (catId) => {
    setAddingItemToCategory(catId);
    setEditingItem(null);
    setItemForm({ title: '', description: '', link_url: '', icon_color: 'from-blue-500 to-cyan-500',
      icon_image_url: '', file_url: '', download_links: [], features: [], subsections: [] });
    setNewDownloadLabel('');
    setNewDownloadUrl('');
    setNewFeature('');
    setExpandedCategory(catId);
  };

  const openEditMainSection = (item) => {
    setEditingItem(item.id);
    setAddingItemToCategory(item.section_id);
    setItemForm({
      title: item.title,
      description: item.description || '',
      link_url: item.link_url || '',
      icon_color: item.icon_color || 'from-blue-500 to-cyan-500',
      icon_image_url: item.icon_image_url || '',
      file_url: item.file_url || '',
      download_links: item.download_links || [],
      features: item.features || [],
      subsections: item.subsections || []
    });
    setNewDownloadLabel('');
    setNewDownloadUrl('');
    setNewFeature('');
    setExpandedCategory(item.section_id);
    setExpandedItem(item.id);
  };

  const uploadToVps = async (file) => {
    const { uploadFile } = await import('@/components/vpsAPI');
    const result = await uploadFile(file);
    return result.url;
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingFile(true);
    const file_url = await uploadToVps(file);
    setItemForm(f => ({ ...f, file_url }));
    setUploadingFile(false);
  };

  const handleIconImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingIconImage(true);
    const file_url = await uploadToVps(file);
    setItemForm(f => ({ ...f, icon_image_url: file_url }));
    setUploadingIconImage(false);
  };

  const saveMainSection = async (catId) => {
    if (!itemForm.title) return;
    const sec = sections.find(s => s.id === catId);
    if (editingItem) {
      await base44.entities.CreatorItem.update(editingItem, { ...itemForm });
      setSections(prev => prev.map(s => s.id === catId ? {
        ...s,
        items: s.items.map(it => it.id === editingItem ? { ...it, ...itemForm } : it)
      } : s));
    } else {
      const newItem = await base44.entities.CreatorItem.create({
        creator_email: user.email,
        section_id: catId,
        section_page: sectionPage,
        ...itemForm,
        sort_order: sec.items.length,
        is_visible: true
      });
      setSections(prev => prev.map(s => s.id === catId ? { ...s, items: [...s.items, newItem] } : s));
    }
    setAddingItemToCategory(null);
    setEditingItem(null);
  };

  const deleteMainSection = async (catId, itemId) => {
    const item = sections.find(s => s.id === catId)?.items.find(it => it.id === itemId);
    setDeleteDialog({
      isOpen: true,
      type: 'item',
      id: itemId,
      categoryId: catId,
      name: item?.title
    });
  };

  const confirmDeleteMainSection = async () => {
    const { categoryId, id: itemId } = deleteDialog;
    setIsDeleting(true);
    try {
      await base44.entities.CreatorItem.delete(itemId);
      setSections(prev => prev.map(s => s.id === categoryId ? { ...s, items: s.items.filter(it => it.id !== itemId) } : s));
    } finally {
      setIsDeleting(false);
      setDeleteDialog({ isOpen: false, type: null, id: null, categoryId: null, name: null });
    }
  };

  const toggleItemVisibility = async (catId, item) => {
    await base44.entities.CreatorItem.update(item.id, { is_visible: !item.is_visible });
    setSections(prev => prev.map(s => s.id === catId ? {
      ...s, items: s.items.map(it => it.id === item.id ? { ...it, is_visible: !it.is_visible } : it)
    } : s));
  };

  const handleSubFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingSubFile(true);
    const file_url = await uploadToVps(file);
    setSubsectionForm(f => ({ ...f, file_url }));
    setUploadingSubFile(false);
  };

  const openAddSubsection = () => {
    setEditingSubsectionIdx(null);
    setSubsectionForm({
      title: '', description: '', link_url: '', icon_color: 'from-blue-500 to-cyan-500', 
      file_url: '', download_links: [], features: []
    });
    setNewSubDownloadLabel('');
    setNewSubDownloadUrl('');
    setNewSubFeature('');
    setAddingSubsectionToItem(true);
  };

  const openEditSubsection = (idx) => {
    const subsec = itemForm.subsections[idx];
    setEditingSubsectionIdx(idx);
    setSubsectionForm({
      title: subsec.title || '',
      description: subsec.description || '',
      link_url: subsec.link_url || '',
      icon_color: subsec.icon_color || 'from-blue-500 to-cyan-500',
      file_url: subsec.file_url || '',
      download_links: subsec.download_links || [],
      features: subsec.features || []
    });
    setNewSubDownloadLabel('');
    setNewSubDownloadUrl('');
    setNewSubFeature('');
  };

  const saveSubsection = () => {
    if (!subsectionForm.title.trim()) return;
    if (editingSubsectionIdx !== null) {
      setItemForm(f => ({
        ...f,
        subsections: f.subsections.map((s, i) => i === editingSubsectionIdx ? subsectionForm : s)
      }));
    } else {
      setItemForm(f => ({
        ...f,
        subsections: [...f.subsections, subsectionForm]
      }));
    }
    setAddingSubsectionToItem(null);
    setEditingSubsectionIdx(null);
  };

  const removeSubsection = (idx) => {
    const subsecTitle = itemForm.subsections[idx]?.title || 'Subsection';
    setDeleteSubDialog({
      isOpen: true,
      idx,
      title: subsecTitle
    });
  };

  const confirmDeleteSubsection = () => {
    const idx = deleteSubDialog.idx;
    setIsDeletingSubsection(true);
    setTimeout(() => {
      setItemForm(f => ({
        ...f,
        subsections: f.subsections.filter((_, i) => i !== idx)
      }));
      setDeleteSubDialog({ isOpen: false, idx: null, title: null });
      setIsDeletingSubsection(false);
    }, 300);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <div className="w-6 h-6 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const getDeleteMessage = () => {
    if (deleteDialog.type === 'category') {
      return `Delete category "${deleteDialog.name}"? All items and subsections will be permanently removed.`;
    }
    return `Delete main section "${deleteDialog.name}"? This action cannot be undone.`;
  };

  return (
    <>
    <div className="pb-6">
      {/* Creator Mode Banner */}
      <div className="mx-4 mb-4 bg-gradient-to-r from-purple-900/40 to-blue-900/40 rounded-2xl p-4 border border-purple-500/30">
        <div className="flex items-center justify-between mb-2">
          <div>
            <p className="text-xs font-semibold text-purple-300">✏️ Creator Edit Mode</p>
            <p className="text-[11px] text-gray-400">Build your content hierarchy: Categories → Main Sections → Subsections</p>
          </div>
          <button
            onClick={addCategory}
            className="flex items-center gap-1.5 bg-purple-600/40 hover:bg-purple-600/60 border border-purple-500/50 text-purple-200 text-xs px-3 py-1.5 rounded-xl transition-colors"
          >
            <FolderPlus className="w-3.5 h-3.5" />
            Add Category
          </button>
        </div>
        <div className="bg-purple-500/10 rounded-lg p-2.5 border border-purple-500/20">
          <p className="text-[10px] text-purple-200 leading-relaxed">
            💡 <strong>Structure:</strong> Up to <strong>4 Categories</strong> → Each category has <strong>Main Sections</strong> → Each main section has <strong>Subsections</strong> with code.
          </p>
        </div>
      </div>

      {/* Categories */}
      <div className="px-4 space-y-3">
        {sections.map((cat) => (
          <motion.div key={cat.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            className={`rounded-2xl border ${cat.is_visible ? 'border-gray-700/50 bg-gray-800/30' : 'border-gray-800/50 bg-gray-900/20 opacity-60'}`}
          >
            {/* Category Header */}
            <div className="flex items-center gap-2 p-3 border-b border-gray-700/30">
              {editingCategory === cat.id ? (
                <div className="flex-1 flex items-center gap-2">
                  <Input
                    value={editingCategoryTitle}
                    onChange={e => setEditingCategoryTitle(e.target.value)}
                    className="flex-1 bg-gray-900/50 border-gray-600 text-white text-sm h-8"
                    autoFocus
                    onKeyDown={e => e.key === 'Enter' && saveCategoryTitle(cat.id)}
                  />
                  <button onClick={() => saveCategoryTitle(cat.id)} className="p-1.5 bg-green-600/40 rounded-lg hover:bg-green-600/60 transition-colors">
                    <Check className="w-3.5 h-3.5 text-green-300" />
                  </button>
                  <button onClick={() => setEditingCategory(null)} className="p-1.5 bg-gray-700/50 rounded-lg hover:bg-gray-700 transition-colors">
                    <X className="w-3.5 h-3.5 text-gray-400" />
                  </button>
                </div>
              ) : (
                <>
                  <button
                    onClick={() => setExpandedCategory(expandedCategory === cat.id ? null : cat.id)}
                    className="flex-1 flex items-center gap-2 text-left"
                  >
                    <span className="text-xs font-semibold text-gray-300 uppercase tracking-wider">{cat.title}</span>
                    <span className="text-xs text-gray-600">({cat.items?.length || 0})</span>
                    {expandedCategory === cat.id
                      ? <ChevronUp className="w-3.5 h-3.5 text-gray-500 ml-auto" />
                      : <ChevronDown className="w-3.5 h-3.5 text-gray-500 ml-auto" />
                    }
                  </button>
                  <button onClick={() => { setEditingCategory(cat.id); setEditingCategoryTitle(cat.title); }}
                    className="p-1.5 rounded-lg bg-gray-700/50 hover:bg-gray-700 transition-colors">
                    <Pencil className="w-3 h-3 text-gray-400" />
                  </button>
                  <button onClick={() => toggleCategoryVisibility(cat)}
                    className="p-1.5 rounded-lg bg-gray-700/50 hover:bg-gray-700 transition-colors">
                    {cat.is_visible ? <Eye className="w-3 h-3 text-green-400" /> : <EyeOff className="w-3 h-3 text-gray-500" />}
                  </button>
                  <button onClick={() => deleteCategory(cat.id)}
                    className="p-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 transition-colors">
                    <Trash2 className="w-3 h-3 text-red-400" />
                  </button>
                </>
              )}
            </div>

            {/* Main Sections in Category */}
            <AnimatePresence>
              {expandedCategory === cat.id && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="p-3 space-y-2"
                >
                  {cat.items?.map((item) => (
                    <div key={item.id}>
                      {/* Main Section Item */}
                      <div
                        className={`flex items-center gap-2 bg-gray-800/50 rounded-xl p-2.5 border cursor-pointer transition-all ${
                          item.is_visible ? 'border-gray-700/30' : 'border-gray-800/30 opacity-50'
                        } ${expandedItem === item.id ? 'border-cyan-500/40 bg-cyan-500/5' : ''}`}
                        onClick={() => setExpandedItem(expandedItem === item.id ? null : item.id)}
                      >
                        {item.icon_image_url ? (
                          <img src={item.icon_image_url} alt={item.title} className="w-7 h-7 rounded-lg object-cover flex-shrink-0" />
                        ) : (
                          <div className={`w-7 h-7 rounded-lg bg-gradient-to-br ${item.icon_color || 'from-blue-500 to-cyan-500'} flex-shrink-0`} />
                        )}
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium text-white truncate">{item.title}</p>
                          {item.description && <p className="text-[10px] text-gray-500 truncate">{item.description}</p>}
                        </div>
                        <ChevronRight className={`w-4 h-4 text-gray-500 transition-transform ${expandedItem === item.id ? 'rotate-90' : ''}`} />
                        <button 
                          onClick={(e) => { e.stopPropagation(); openEditMainSection(item); }}
                          className="p-1 rounded-lg hover:bg-gray-700 transition-colors"
                        >
                          <Pencil className="w-3 h-3 text-gray-400" />
                        </button>
                        <button 
                          onClick={(e) => { e.stopPropagation(); toggleItemVisibility(cat.id, item); }}
                          className="p-1 rounded-lg hover:bg-gray-700 transition-colors"
                        >
                          {item.is_visible ? <Eye className="w-3 h-3 text-green-400" /> : <EyeOff className="w-3 h-3 text-gray-500" />}
                        </button>
                        <button 
                          onClick={(e) => { e.stopPropagation(); deleteMainSection(cat.id, item.id); }}
                          className="p-1 rounded-lg hover:bg-red-500/20 transition-colors"
                        >
                          <Trash2 className="w-3 h-3 text-red-400" />
                        </button>
                      </div>

                      {/* Subsections Display */}
                      <AnimatePresence>
                        {expandedItem === item.id && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="ml-6 mt-2 space-y-2"
                          >
                            {item.subsections?.map((subsec, idx) => (
                              <div key={idx} className="bg-gray-900/40 rounded-lg p-2.5 border border-purple-500/20">
                                <p className="text-xs font-semibold text-purple-400 mb-1">{subsec.title}</p>
                                {subsec.code && (
                                  <div className="bg-gray-900/50 rounded p-2 mb-2 border border-purple-500/10">
                                    <pre className="text-[9px] text-purple-300 font-mono overflow-x-auto max-h-24">
                                      {subsec.code}
                                    </pre>
                                  </div>
                                )}
                              </div>
                            ))}

                            {/* Main Section Form (Edit) */}
                            {editingItem === item.id && addingItemToCategory === cat.id && (
                              <motion.div
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: 'auto' }}
                                exit={{ opacity: 0, height: 0 }}
                                className="bg-gray-900/60 rounded-xl p-3 border border-purple-500/30 space-y-2"
                              >
                                <Input
                                  placeholder="Title *"
                                  value={itemForm.title}
                                  onChange={e => setItemForm(f => ({ ...f, title: e.target.value }))}
                                  className="bg-gray-800/50 border-gray-700 text-white text-sm h-8"
                                />
                                <Input
                                  placeholder="Description"
                                  value={itemForm.description}
                                  onChange={e => setItemForm(f => ({ ...f, description: e.target.value }))}
                                  className="bg-gray-800/50 border-gray-700 text-white text-sm h-8"
                                />
                                <div className="relative">
                                  <Link2 className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-cyan-400" />
                                  <Input
                                    placeholder="Link URL (optional)"
                                    value={itemForm.link_url}
                                    onChange={e => setItemForm(f => ({ ...f, link_url: e.target.value }))}
                                    className="bg-gray-800/50 border-gray-700 text-white text-sm h-8 pl-8"
                                  />
                                </div>

                                {/* Icon Image upload (main items only) */}
                                <div>
                                  <p className="text-[10px] text-gray-500 mb-1.5">Custom Icon Image (optional)</p>
                                  <input type="file" id={`item-icon-${cat.id}`} className="hidden" onChange={handleIconImageUpload} accept="image/*" />
                                  <label htmlFor={`item-icon-${cat.id}`}
                                    className="flex items-center justify-center gap-2 border border-dashed border-gray-600 rounded-lg py-1.5 cursor-pointer hover:border-cyan-500/50 transition-colors text-xs text-gray-400">
                                    <Upload className="w-3.5 h-3.5" />
                                    {uploadingIconImage ? 'Uploading...' : itemForm.icon_image_url ? '✓ Icon uploaded' : 'Upload icon image'}
                                  </label>
                                  {itemForm.icon_image_url && (
                                    <div className="mt-2 flex items-center gap-2">
                                      <img src={itemForm.icon_image_url} alt="icon preview" className="w-8 h-8 rounded-lg object-cover" />
                                      <button onClick={() => setItemForm(f => ({ ...f, icon_image_url: '' }))}
                                        className="text-xs text-red-400 hover:text-red-300 transition-colors">Remove</button>
                                    </div>
                                  )}
                                </div>

                                {/* Icon Image upload (main items only) */}
                                <div>
                                  <p className="text-[10px] text-gray-500 mb-1.5">Custom Icon Image (optional)</p>
                                  <input type="file" id={`item-icon-add-${cat.id}`} className="hidden" onChange={handleIconImageUpload} accept="image/*" />
                                  <label htmlFor={`item-icon-add-${cat.id}`}
                                    className="flex items-center justify-center gap-2 border border-dashed border-gray-600 rounded-lg py-1.5 cursor-pointer hover:border-cyan-500/50 transition-colors text-xs text-gray-400">
                                    <Upload className="w-3.5 h-3.5" />
                                    {uploadingIconImage ? 'Uploading...' : itemForm.icon_image_url ? '✓ Icon uploaded' : 'Upload icon image'}
                                  </label>
                                  {itemForm.icon_image_url && (
                                    <div className="mt-2 flex items-center gap-2">
                                      <img src={itemForm.icon_image_url} alt="icon preview" className="w-8 h-8 rounded-lg object-cover" />
                                      <button onClick={() => setItemForm(f => ({ ...f, icon_image_url: '' }))}
                                        className="text-xs text-red-400 hover:text-red-300 transition-colors">Remove</button>
                                    </div>
                                  )}
                                </div>

                                {/* File upload */}
                                <div>
                                  <input type="file" id={`item-file-${cat.id}`} className="hidden" onChange={handleFileUpload} />
                                  <label htmlFor={`item-file-${cat.id}`}
                                    className="flex items-center justify-center gap-2 border border-dashed border-gray-600 rounded-lg py-1.5 cursor-pointer hover:border-purple-500/50 transition-colors text-xs text-gray-400">
                                    <Upload className="w-3.5 h-3.5" />
                                    {uploadingFile ? 'Uploading...' : itemForm.file_url ? '✓ File uploaded' : 'Upload file (optional)'}
                                  </label>
                                </div>

                                {/* Add Subsection */}
                                <button
                                  onClick={() => setAddingSubsectionToItem(addingSubsectionToItem === item.id ? null : item.id)}
                                  className={`w-full flex items-center justify-center gap-2 py-1.5 rounded-xl border text-xs transition-colors ${
                                    addingSubsectionToItem === item.id
                                      ? 'border-purple-500/40 bg-purple-500/10 text-purple-400'
                                      : 'border-dashed border-gray-600 text-gray-500 hover:border-purple-500/40 hover:text-purple-400'
                                  }`}
                                >
                                  <Plug className="w-3.5 h-3.5" />
                                  {addingSubsectionToItem === item.id ? 'Hide Subsection' : '+ Add Subsection (optional)'}
                                </button>

                                {/* Subsections List & Form */}
                                <div className="space-y-2 bg-gray-900/40 rounded-xl p-2.5 border border-purple-500/20">
                                  <p className="text-[10px] text-purple-400 font-semibold">Subsections</p>
                                  {itemForm.subsections?.map((subsec, idx) => (
                                    <div key={idx} className="bg-gray-800/50 p-2 rounded border border-purple-500/10">
                                      <div className="flex items-center justify-between mb-1">
                                        <p className="text-xs font-medium text-white">{subsec.title}</p>
                                        <div className="flex gap-1">
                                          <button
                                            onClick={() => openEditSubsection(idx)}
                                            className="p-0.5 rounded hover:bg-blue-500/20 transition-colors"
                                          >
                                            <Pencil className="w-3 h-3 text-blue-400" />
                                          </button>
                                          <button
                                            onClick={() => removeSubsection(idx)}
                                            className="p-0.5 rounded hover:bg-red-500/20 transition-colors"
                                          >
                                            <Trash2 className="w-3 h-3 text-red-400" />
                                          </button>
                                        </div>
                                      </div>
                                      {subsec.description && <p className="text-[9px] text-gray-500 mb-1">{subsec.description}</p>}
                                    </div>
                                  ))}

                                  {addingSubsectionToItem && editingSubsectionIdx === null && (
                                    <div className="space-y-2 bg-gray-900/60 rounded-lg p-2.5 border border-purple-500/30">
                                      <p className="text-[10px] text-purple-300 font-semibold mb-1">Add New Subsection</p>
                                      <Input
                                        placeholder="Title *"
                                        value={subsectionForm.title}
                                        onChange={e => setSubsectionForm(f => ({ ...f, title: e.target.value }))}
                                        className="bg-gray-800/50 border-gray-700 text-white text-xs h-8"
                                      />
                                      <Input
                                        placeholder="Description"
                                        value={subsectionForm.description}
                                        onChange={e => setSubsectionForm(f => ({ ...f, description: e.target.value }))}
                                        className="bg-gray-800/50 border-gray-700 text-white text-xs h-8"
                                      />
                                      <div className="relative">
                                        <Link2 className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-cyan-400" />
                                        <Input
                                          placeholder="Link URL (optional)"
                                          value={subsectionForm.link_url}
                                          onChange={e => setSubsectionForm(f => ({ ...f, link_url: e.target.value }))}
                                          className="bg-gray-800/50 border-gray-700 text-white text-xs h-8 pl-8"
                                        />
                                      </div>
                                      <div>
                                        <input type="file" id={`sub-file-${item.id}`} className="hidden" onChange={handleSubFileUpload} />
                                        <label htmlFor={`sub-file-${item.id}`}
                                          className="flex items-center justify-center gap-2 border border-dashed border-gray-600 rounded-lg py-1.5 cursor-pointer hover:border-purple-500/50 transition-colors text-xs text-gray-400">
                                          <Upload className="w-3 h-3" />
                                          {uploadingSubFile ? 'Uploading...' : subsectionForm.file_url ? '✓ File uploaded' : 'Upload file (optional)'}
                                        </label>
                                      </div>
                                      <div className="bg-gray-900/60 rounded-lg p-2 border border-blue-500/20">
                                        <p className="text-[9px] text-blue-400 font-semibold mb-1">Download Links</p>
                                        <div className="space-y-1 mb-2">
                                          {subsectionForm.download_links.map((dl, didx) => (
                                            <div key={didx} className="flex items-center gap-2 bg-gray-800/50 p-1.5 rounded text-[9px]">
                                              <span className="flex-1 truncate text-gray-400">{dl.label}</span>
                                              <button onClick={() => setSubsectionForm(f => ({ ...f, download_links: f.download_links.filter((_, i) => i !== didx) }))}
                                                className="p-0.5 rounded hover:bg-red-500/20">
                                                <Trash2 className="w-2.5 h-2.5 text-red-400" />
                                              </button>
                                            </div>
                                          ))}
                                        </div>
                                        <div className="flex gap-1 mb-1">
                                          <Input placeholder="Label" value={newSubDownloadLabel} onChange={e => setNewSubDownloadLabel(e.target.value)}
                                            className="bg-gray-800/50 border-gray-700 text-white text-xs h-7 flex-1" />
                                          <button onClick={() => {
                                            if (newSubDownloadLabel && newSubDownloadUrl) {
                                              setSubsectionForm(f => ({ ...f, download_links: [...f.download_links, { label: newSubDownloadLabel, url: newSubDownloadUrl }] }));
                                              setNewSubDownloadLabel('');
                                              setNewSubDownloadUrl('');
                                            }
                                          }} className="px-2 bg-blue-600/40 hover:bg-blue-600/60 rounded text-blue-300 text-xs font-medium transition-colors">
                                            Add
                                          </button>
                                        </div>
                                        <Input placeholder="URL" value={newSubDownloadUrl} onChange={e => setNewSubDownloadUrl(e.target.value)}
                                          className="bg-gray-800/50 border-gray-700 text-white text-xs h-7" />
                                      </div>
                                      <div className="bg-gray-900/60 rounded-lg p-2 border border-green-500/20">
                                        <p className="text-[9px] text-green-400 font-semibold mb-1">Features</p>
                                        <div className="space-y-1 mb-2">
                                          {subsectionForm.features.map((feat, fidx) => (
                                            <div key={fidx} className="flex items-center gap-2 bg-gray-800/50 p-1 rounded">
                                              <span className="text-[9px] text-gray-300 flex-1">✓ {feat}</span>
                                              <button onClick={() => setSubsectionForm(f => ({ ...f, features: f.features.filter((_, i) => i !== fidx) }))}
                                                className="p-0.5 rounded hover:bg-red-500/20">
                                                <Trash2 className="w-2.5 h-2.5 text-red-400" />
                                              </button>
                                            </div>
                                          ))}
                                        </div>
                                        <div className="flex gap-1">
                                          <Input placeholder="Feature" value={newSubFeature} onChange={e => setNewSubFeature(e.target.value)}
                                            className="bg-gray-800/50 border-gray-700 text-white text-xs h-7 flex-1"
                                            onKeyDown={e => { if (e.key === 'Enter' && newSubFeature) {
                                              setSubsectionForm(f => ({ ...f, features: [...f.features, newSubFeature] }));
                                              setNewSubFeature('');
                                            }}} />
                                          <button onClick={() => { if (newSubFeature) {
                                            setSubsectionForm(f => ({ ...f, features: [...f.features, newSubFeature] }));
                                            setNewSubFeature('');
                                          }}} className="px-2 bg-green-600/40 hover:bg-green-600/60 rounded text-green-300 text-xs font-medium transition-colors">
                                            Add
                                          </button>
                                        </div>
                                      </div>
                                      <div>
                                        <p className="text-[9px] text-gray-500 mb-1">Icon color</p>
                                        <div className="flex gap-1 flex-wrap">
                                          {COLOR_OPTIONS.map(color => (
                                            <button key={color}
                                              onClick={() => setSubsectionForm(f => ({ ...f, icon_color: color }))}
                                              className={`w-5 h-5 rounded bg-gradient-to-br ${color} border-2 transition-all ${subsectionForm.icon_color === color ? 'border-white scale-110' : 'border-transparent'}`}
                                            />
                                          ))}
                                        </div>
                                      </div>
                                      <div className="flex gap-2 pt-1">
                                        <Button onClick={saveSubsection} disabled={!subsectionForm.title} className="flex-1 bg-purple-600 text-xs h-7 disabled:opacity-50">
                                          Add
                                        </Button>
                                        <Button onClick={() => setAddingSubsectionToItem(null)} variant="outline" className="flex-1 text-xs h-7">
                                          Cancel
                                        </Button>
                                      </div>
                                    </div>
                                  )}

                                  {editingSubsectionIdx !== null && (
                                    <div className="space-y-2 bg-gray-900/60 rounded-lg p-2.5 border border-purple-500/30">
                                      <p className="text-[10px] text-purple-300 font-semibold mb-1">Edit Subsection</p>
                                      <Input
                                        placeholder="Title *"
                                        value={subsectionForm.title}
                                        onChange={e => setSubsectionForm(f => ({ ...f, title: e.target.value }))}
                                        className="bg-gray-800/50 border-gray-700 text-white text-xs h-8"
                                      />
                                      <Input
                                        placeholder="Description"
                                        value={subsectionForm.description}
                                        onChange={e => setSubsectionForm(f => ({ ...f, description: e.target.value }))}
                                        className="bg-gray-800/50 border-gray-700 text-white text-xs h-8"
                                      />
                                      <div className="relative">
                                        <Link2 className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-cyan-400" />
                                        <Input
                                          placeholder="Link URL (optional)"
                                          value={subsectionForm.link_url}
                                          onChange={e => setSubsectionForm(f => ({ ...f, link_url: e.target.value }))}
                                          className="bg-gray-800/50 border-gray-700 text-white text-xs h-8 pl-8"
                                        />
                                      </div>
                                      <div>
                                        <input type="file" id={`sub-file-edit-${item.id}`} className="hidden" onChange={handleSubFileUpload} />
                                        <label htmlFor={`sub-file-edit-${item.id}`}
                                          className="flex items-center justify-center gap-2 border border-dashed border-gray-600 rounded-lg py-1.5 cursor-pointer hover:border-purple-500/50 transition-colors text-xs text-gray-400">
                                          <Upload className="w-3 h-3" />
                                          {uploadingSubFile ? 'Uploading...' : subsectionForm.file_url ? '✓ File uploaded' : 'Upload file (optional)'}
                                        </label>
                                      </div>
                                      <div className="bg-gray-900/60 rounded-lg p-2 border border-blue-500/20">
                                        <p className="text-[9px] text-blue-400 font-semibold mb-1">Download Links</p>
                                        <div className="space-y-1 mb-2">
                                          {subsectionForm.download_links.map((dl, didx) => (
                                            <div key={didx} className="flex items-center gap-2 bg-gray-800/50 p-1.5 rounded text-[9px]">
                                              <span className="flex-1 truncate text-gray-400">{dl.label}</span>
                                              <button onClick={() => setSubsectionForm(f => ({ ...f, download_links: f.download_links.filter((_, i) => i !== didx) }))}
                                                className="p-0.5 rounded hover:bg-red-500/20">
                                                <Trash2 className="w-2.5 h-2.5 text-red-400" />
                                              </button>
                                            </div>
                                          ))}
                                        </div>
                                        <div className="flex gap-1 mb-1">
                                          <Input placeholder="Label" value={newSubDownloadLabel} onChange={e => setNewSubDownloadLabel(e.target.value)}
                                            className="bg-gray-800/50 border-gray-700 text-white text-xs h-7 flex-1" />
                                          <button onClick={() => {
                                            if (newSubDownloadLabel && newSubDownloadUrl) {
                                              setSubsectionForm(f => ({ ...f, download_links: [...f.download_links, { label: newSubDownloadLabel, url: newSubDownloadUrl }] }));
                                              setNewSubDownloadLabel('');
                                              setNewSubDownloadUrl('');
                                            }
                                          }} className="px-2 bg-blue-600/40 hover:bg-blue-600/60 rounded text-blue-300 text-xs font-medium transition-colors">
                                            Add
                                          </button>
                                        </div>
                                        <Input placeholder="URL" value={newSubDownloadUrl} onChange={e => setNewSubDownloadUrl(e.target.value)}
                                          className="bg-gray-800/50 border-gray-700 text-white text-xs h-7" />
                                      </div>
                                      <div className="bg-gray-900/60 rounded-lg p-2 border border-green-500/20">
                                        <p className="text-[9px] text-green-400 font-semibold mb-1">Features</p>
                                        <div className="space-y-1 mb-2">
                                          {subsectionForm.features.map((feat, fidx) => (
                                            <div key={fidx} className="flex items-center gap-2 bg-gray-800/50 p-1 rounded">
                                              <span className="text-[9px] text-gray-300 flex-1">✓ {feat}</span>
                                              <button onClick={() => setSubsectionForm(f => ({ ...f, features: f.features.filter((_, i) => i !== fidx) }))}
                                                className="p-0.5 rounded hover:bg-red-500/20">
                                                <Trash2 className="w-2.5 h-2.5 text-red-400" />
                                              </button>
                                            </div>
                                          ))}
                                        </div>
                                        <div className="flex gap-1">
                                          <Input placeholder="Feature" value={newSubFeature} onChange={e => setNewSubFeature(e.target.value)}
                                            className="bg-gray-800/50 border-gray-700 text-white text-xs h-7 flex-1"
                                            onKeyDown={e => { if (e.key === 'Enter' && newSubFeature) {
                                              setSubsectionForm(f => ({ ...f, features: [...f.features, newSubFeature] }));
                                              setNewSubFeature('');
                                            }}} />
                                          <button onClick={() => { if (newSubFeature) {
                                            setSubsectionForm(f => ({ ...f, features: [...f.features, newSubFeature] }));
                                            setNewSubFeature('');
                                          }}} className="px-2 bg-green-600/40 hover:bg-green-600/60 rounded text-green-300 text-xs font-medium transition-colors">
                                            Add
                                          </button>
                                        </div>
                                      </div>
                                      <div>
                                        <p className="text-[9px] text-gray-500 mb-1">Icon color</p>
                                        <div className="flex gap-1 flex-wrap">
                                          {COLOR_OPTIONS.map(color => (
                                            <button key={color}
                                              onClick={() => setSubsectionForm(f => ({ ...f, icon_color: color }))}
                                              className={`w-5 h-5 rounded bg-gradient-to-br ${color} border-2 transition-all ${subsectionForm.icon_color === color ? 'border-white scale-110' : 'border-transparent'}`}
                                            />
                                          ))}
                                        </div>
                                      </div>
                                      <div className="flex gap-2 pt-1">
                                        <Button onClick={saveSubsection} disabled={!subsectionForm.title} className="flex-1 bg-purple-600 text-xs h-7 disabled:opacity-50">
                                          Update
                                        </Button>
                                        <Button onClick={() => setEditingSubsectionIdx(null)} variant="outline" className="flex-1 text-xs h-7">
                                          Cancel
                                        </Button>
                                      </div>
                                    </div>
                                  )}

                                  {!addingSubsectionToItem && editingSubsectionIdx === null && (
                                    <button
                                      onClick={openAddSubsection}
                                      className="w-full flex items-center justify-center gap-2 py-1.5 rounded-lg border border-dashed border-gray-600 text-gray-500 text-xs hover:border-purple-500/50 hover:text-purple-400 transition-colors"
                                    >
                                      <Plus className="w-3 h-3" /> Add Subsection
                                    </button>
                                  )}
                                </div>

                                {/* Download Links */}
                                <div className="bg-gray-900/60 rounded-xl p-2.5 border border-blue-500/20">
                                  <p className="text-[10px] text-blue-400 font-semibold mb-2">Download Links (optional)</p>
                                  <div className="space-y-2 mb-2">
                                    {itemForm.download_links.map((dl, idx) => (
                                      <div key={idx} className="flex items-center gap-2 bg-gray-800/50 p-2 rounded-lg">
                                        <div className="flex-1 min-w-0">
                                          <p className="text-[10px] text-gray-400">{dl.label}</p>
                                          <p className="text-[9px] text-gray-600 truncate">{dl.url}</p>
                                        </div>
                                        <button onClick={() => setItemForm(f => ({ ...f, download_links: f.download_links.filter((_, i) => i !== idx) }))}
                                          className="p-1 rounded hover:bg-red-500/20 transition-colors">
                                          <Trash2 className="w-3 h-3 text-red-400" />
                                        </button>
                                      </div>
                                    ))}
                                  </div>
                                  <div className="flex gap-1.5 mb-1.5">
                                    <Input placeholder="Label (e.g. Download from PlayStore)" value={newDownloadLabel}
                                      onChange={e => setNewDownloadLabel(e.target.value)} className="bg-gray-800/50 border-gray-700 text-white text-xs h-8 flex-1" />
                                    <button onClick={() => {
                                      if (newDownloadLabel && newDownloadUrl) {
                                        setItemForm(f => ({ ...f, download_links: [...f.download_links, { label: newDownloadLabel, url: newDownloadUrl }] }));
                                        setNewDownloadLabel('');
                                        setNewDownloadUrl('');
                                      }
                                    }} className="px-2 py-1 bg-blue-600/40 hover:bg-blue-600/60 rounded text-blue-300 text-xs font-medium transition-colors">
                                      Add
                                    </button>
                                  </div>
                                  <Input placeholder="URL" value={newDownloadUrl} onChange={e => setNewDownloadUrl(e.target.value)}
                                    className="bg-gray-800/50 border-gray-700 text-white text-xs h-8" />
                                </div>

                                {/* Features */}
                                <div className="bg-gray-900/60 rounded-xl p-2.5 border border-green-500/20">
                                  <p className="text-[10px] text-green-400 font-semibold mb-2">Features (optional)</p>
                                  <div className="space-y-1 mb-2">
                                    {itemForm.features.map((feat, idx) => (
                                      <div key={idx} className="flex items-center gap-2 bg-gray-800/50 p-1.5 rounded">
                                        <span className="text-[10px] text-gray-300 flex-1">✓ {feat}</span>
                                        <button onClick={() => setItemForm(f => ({ ...f, features: f.features.filter((_, i) => i !== idx) }))}
                                          className="p-0.5 rounded hover:bg-red-500/20 transition-colors">
                                          <Trash2 className="w-3 h-3 text-red-400" />
                                        </button>
                                      </div>
                                    ))}
                                  </div>
                                  <div className="flex gap-1.5">
                                    <Input placeholder="e.g. No registration required" value={newFeature}
                                      onChange={e => setNewFeature(e.target.value)} className="bg-gray-800/50 border-gray-700 text-white text-xs h-8 flex-1"
                                      onKeyDown={e => { if (e.key === 'Enter' && newFeature) {
                                        setItemForm(f => ({ ...f, features: [...f.features, newFeature] }));
                                        setNewFeature('');
                                      }}} />
                                    <button onClick={() => { if (newFeature) {
                                      setItemForm(f => ({ ...f, features: [...f.features, newFeature] }));
                                      setNewFeature('');
                                    }}} className="px-2 py-1 bg-green-600/40 hover:bg-green-600/60 rounded text-green-300 text-xs font-medium transition-colors">
                                      Add
                                    </button>
                                  </div>
                                </div>

                                {/* Color picker */}
                                <div>
                                  <p className="text-[10px] text-gray-500 mb-1.5">Icon color</p>
                                  <div className="flex gap-1.5 flex-wrap">
                                    {COLOR_OPTIONS.map(color => (
                                      <button key={color}
                                        onClick={() => setItemForm(f => ({ ...f, icon_color: color }))}
                                        className={`w-6 h-6 rounded-lg bg-gradient-to-br ${color} border-2 transition-all ${itemForm.icon_color === color ? 'border-white scale-110' : 'border-transparent'}`}
                                      />
                                    ))}
                                  </div>
                                </div>

                                <div className="flex gap-2">
                                  <Button onClick={() => saveMainSection(cat.id)} disabled={!itemForm.title}
                                    className="flex-1 bg-purple-600 text-xs h-8 disabled:opacity-50">
                                    Update Main Section
                                  </Button>
                                  <Button onClick={() => { setAddingItemToCategory(null); setEditingItem(null); }}
                                    variant="outline" className="flex-1 text-xs h-8">
                                    Cancel
                                  </Button>
                                </div>
                              </motion.div>
                            )}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  ))}

                  {addingItemToCategory === cat.id && !editingItem && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="bg-gray-900/60 rounded-xl p-3 border border-purple-500/30 space-y-2"
                    >
                      <p className="text-xs text-purple-300 font-semibold mb-2">Add New Main Section</p>
                      <Input
                        placeholder="Title *"
                        value={itemForm.title}
                        onChange={e => setItemForm(f => ({ ...f, title: e.target.value }))}
                        className="bg-gray-800/50 border-gray-700 text-white text-sm h-8"
                      />
                      <Input
                        placeholder="Description"
                        value={itemForm.description}
                        onChange={e => setItemForm(f => ({ ...f, description: e.target.value }))}
                        className="bg-gray-800/50 border-gray-700 text-white text-sm h-8"
                      />
                      <div className="relative">
                        <Link2 className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-cyan-400" />
                        <Input
                          placeholder="Link URL (optional)"
                          value={itemForm.link_url}
                          onChange={e => setItemForm(f => ({ ...f, link_url: e.target.value }))}
                          className="bg-gray-800/50 border-gray-700 text-white text-sm h-8 pl-8"
                        />
                      </div>

                      {/* File upload */}
                      <div>
                        <input type="file" id={`item-file-${cat.id}`} className="hidden" onChange={handleFileUpload} />
                        <label htmlFor={`item-file-${cat.id}`}
                          className="flex items-center justify-center gap-2 border border-dashed border-gray-600 rounded-lg py-1.5 cursor-pointer hover:border-purple-500/50 transition-colors text-xs text-gray-400">
                          <Upload className="w-3.5 h-3.5" />
                          {uploadingFile ? 'Uploading...' : itemForm.file_url ? '✓ File uploaded' : 'Upload file (optional)'}
                        </label>
                      </div>

                      {/* Download Links */}
                      <div className="bg-gray-900/60 rounded-xl p-2.5 border border-blue-500/20">
                        <p className="text-[10px] text-blue-400 font-semibold mb-2">Download Links (optional)</p>
                        <div className="space-y-2 mb-2">
                          {itemForm.download_links.map((dl, idx) => (
                            <div key={idx} className="flex items-center gap-2 bg-gray-800/50 p-2 rounded-lg">
                              <div className="flex-1 min-w-0">
                                <p className="text-[10px] text-gray-400">{dl.label}</p>
                                <p className="text-[9px] text-gray-600 truncate">{dl.url}</p>
                              </div>
                              <button onClick={() => setItemForm(f => ({ ...f, download_links: f.download_links.filter((_, i) => i !== idx) }))}
                                className="p-1 rounded hover:bg-red-500/20 transition-colors">
                                <Trash2 className="w-3 h-3 text-red-400" />
                              </button>
                            </div>
                          ))}
                        </div>
                        <div className="flex gap-1.5 mb-1.5">
                          <Input placeholder="Label (e.g. Download from PlayStore)" value={newDownloadLabel}
                            onChange={e => setNewDownloadLabel(e.target.value)} className="bg-gray-800/50 border-gray-700 text-white text-xs h-8 flex-1" />
                          <button onClick={() => {
                            if (newDownloadLabel && newDownloadUrl) {
                              setItemForm(f => ({ ...f, download_links: [...f.download_links, { label: newDownloadLabel, url: newDownloadUrl }] }));
                              setNewDownloadLabel('');
                              setNewDownloadUrl('');
                            }
                          }} className="px-2 py-1 bg-blue-600/40 hover:bg-blue-600/60 rounded text-blue-300 text-xs font-medium transition-colors">
                            Add
                          </button>
                        </div>
                        <Input placeholder="URL" value={newDownloadUrl} onChange={e => setNewDownloadUrl(e.target.value)}
                          className="bg-gray-800/50 border-gray-700 text-white text-xs h-8" />
                      </div>

                      {/* Features */}
                      <div className="bg-gray-900/60 rounded-xl p-2.5 border border-green-500/20">
                        <p className="text-[10px] text-green-400 font-semibold mb-2">Features (optional)</p>
                        <div className="space-y-1 mb-2">
                          {itemForm.features.map((feat, idx) => (
                            <div key={idx} className="flex items-center gap-2 bg-gray-800/50 p-1.5 rounded">
                              <span className="text-[10px] text-gray-300 flex-1">✓ {feat}</span>
                              <button onClick={() => setItemForm(f => ({ ...f, features: f.features.filter((_, i) => i !== idx) }))}
                                className="p-0.5 rounded hover:bg-red-500/20 transition-colors">
                                <Trash2 className="w-3 h-3 text-red-400" />
                              </button>
                            </div>
                          ))}
                        </div>
                        <div className="flex gap-1.5">
                          <Input placeholder="e.g. No registration required" value={newFeature}
                            onChange={e => setNewFeature(e.target.value)} className="bg-gray-800/50 border-gray-700 text-white text-xs h-8 flex-1"
                            onKeyDown={e => { if (e.key === 'Enter' && newFeature) {
                              setItemForm(f => ({ ...f, features: [...f.features, newFeature] }));
                              setNewFeature('');
                            }}} />
                          <button onClick={() => { if (newFeature) {
                            setItemForm(f => ({ ...f, features: [...f.features, newFeature] }));
                            setNewFeature('');
                          }}} className="px-2 py-1 bg-green-600/40 hover:bg-green-600/60 rounded text-green-300 text-xs font-medium transition-colors">
                            Add
                          </button>
                        </div>
                      </div>

                      {/* Color picker */}
                      <div>
                        <p className="text-[10px] text-gray-500 mb-1.5">Icon color</p>
                        <div className="flex gap-1.5 flex-wrap">
                          {COLOR_OPTIONS.map(color => (
                            <button key={color}
                              onClick={() => setItemForm(f => ({ ...f, icon_color: color }))}
                              className={`w-6 h-6 rounded-lg bg-gradient-to-br ${color} border-2 transition-all ${itemForm.icon_color === color ? 'border-white scale-110' : 'border-transparent'}`}
                            />
                          ))}
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <Button onClick={() => saveMainSection(cat.id)} disabled={!itemForm.title}
                          className="flex-1 bg-purple-600 text-xs h-8 disabled:opacity-50">
                          Add Main Section
                        </Button>
                        <Button onClick={() => { setAddingItemToCategory(null); setEditingItem(null); }}
                          variant="outline" className="flex-1 text-xs h-8">
                          Cancel
                        </Button>
                      </div>
                    </motion.div>
                  )}

                  {addingItemToCategory !== cat.id && (
                    <button
                      onClick={() => openAddMainSection(cat.id)}
                      className="w-full flex items-center justify-center gap-2 py-2 rounded-xl border border-dashed border-gray-600 text-gray-500 text-xs hover:border-purple-500/50 hover:text-purple-400 transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add Main Section
                    </button>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        ))}

        {sections.length === 0 && (
          <div className="text-center py-10">
            <p className="text-gray-500 text-sm mb-3">No categories yet.</p>
            <button onClick={addCategory}
              className="text-purple-400 text-sm border border-purple-500/30 px-4 py-2 rounded-xl hover:bg-purple-500/10 transition-colors">
              + Add your first category
            </button>
          </div>
        )}
      </div>

      <DeleteConfirmationDialog
        isOpen={deleteDialog.isOpen}
        title={deleteDialog.type === 'category' ? 'Delete Category' : 'Delete Main Section'}
        description={getDeleteMessage()}
        onConfirm={deleteDialog.type === 'category' ? confirmDeleteCategory : confirmDeleteMainSection}
        onCancel={() => setDeleteDialog({ isOpen: false, type: null, id: null, categoryId: null, name: null })}
        isLoading={isDeleting}
      />

      <DeleteConfirmationDialog
        isOpen={deleteSubDialog.isOpen}
        title="Delete Subsection"
        description={`Are you sure you want to delete "${deleteSubDialog.title}"? This action cannot be undone.`}
        onConfirm={confirmDeleteSubsection}
        onCancel={() => setDeleteSubDialog({ isOpen: false, idx: null, title: null })}
        isLoading={isDeletingSubsection}
      />
    </div>
    </>
  );
}