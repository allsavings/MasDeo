import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Heart, Check } from 'lucide-react';
import { motion } from 'framer-motion';
import TrustBadge from './TrustBadge';

export default function CreatorProfileHeader({ creatorEmail, userProfile, creatorProfile }) {
  const [isFollowing, setIsFollowing] = useState(false);
  const [isFollowLoading, setIsFollowLoading] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    loadCurrentUser();
    checkIfFollowing();
  }, [creatorEmail]);

  const loadCurrentUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error('Error loading current user:', error);
    }
  };

  const checkIfFollowing = async () => {
    try {
      const currentUser = await base44.auth.me();
      if (currentUser) {
        const follows = await base44.entities.Follow.filter({
          creator_email: creatorEmail,
          user_email: currentUser.email
        });
        setIsFollowing(follows.length > 0);
      }
    } catch (error) {
      console.error('Error checking follow status:', error);
    }
  };

  const handleFollow = async () => {
    if (!user || isFollowLoading) return;
    
    const previousState = isFollowing;
    // Optimistic update: immediately change UI
    setIsFollowing(!isFollowing);
    setIsFollowLoading(true);
    
    try {
      if (previousState) {
        // Was following, now unfollow
        const follows = await base44.entities.Follow.filter({
          creator_email: creatorEmail,
          user_email: user.email
        });
        if (follows.length > 0) {
          await base44.entities.Follow.delete(follows[0].id);
        }
      } else {
        // Was not following, now follow
        await base44.entities.Follow.create({
          creator_email: creatorEmail,
          creator_id: creatorProfile?.id,
          user_email: user.email
        });
      }
    } catch (error) {
      console.error('Error updating follow status:', error);
      // Revert on error
      setIsFollowing(previousState);
    } finally {
      setIsFollowLoading(false);
    }
  };

  return (
    <div className="bg-gradient-to-r from-blue-600/20 to-cyan-600/20 rounded-3xl p-6 border border-blue-500/30 mb-6">
      <div className="flex items-start gap-4 mb-4">
        {userProfile?.profile_picture_url ? (
          <img 
            src={userProfile.profile_picture_url}
            alt={userProfile.nickname}
            className="w-20 h-20 rounded-2xl object-cover flex-shrink-0 border-2 border-blue-500/50"
          />
        ) : (
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center flex-shrink-0 border-2 border-blue-500/50">
            <span className="text-2xl font-bold text-white">{(userProfile?.nickname || 'C').charAt(0)}</span>
          </div>
        )}
        
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <h2 className="text-2xl font-bold text-white">{userProfile?.nickname || 'Creator'}</h2>
            {creatorProfile?.verified && (
              <span className="inline-flex items-center justify-center w-6 h-6 bg-blue-500 rounded-full">
                <Check className="w-4 h-4 text-white" />
              </span>
            )}
          </div>
          <p className="text-cyan-400 text-lg mb-3">{userProfile?.handle || `@${creatorEmail.split('@')[0]}`}</p>
          
          <div className="flex items-center gap-4 text-sm">
            {creatorProfile?.followerCount > 0 && (
              <span className="text-gray-300">
                👥 {creatorProfile.followerCount} {creatorProfile.followerCount === 1 ? 'follower' : 'followers'}
              </span>
            )}
            {creatorProfile?.trust_score > 0 && (
              <span className="text-green-400">
                🛡️ {creatorProfile.trust_score}%
              </span>
            )}
          </div>
        </div>
      </div>

      {creatorProfile?.bio && (
        <p className="text-gray-300 text-sm mb-4">{creatorProfile.bio}</p>
      )}

      <button
        onClick={handleFollow}
        disabled={!user || isFollowLoading}
        className={`w-full py-3 px-4 rounded-2xl font-semibold text-white transition-all flex items-center justify-center gap-2 relative ${
          isFollowing
            ? 'bg-gray-800/60 border border-gray-700/50 hover:bg-gray-800/80'
            : 'bg-gradient-to-r from-pink-500 to-red-500 hover:from-pink-600 hover:to-red-600 shadow-lg shadow-pink-500/30'
        }`}
      >
        <motion.div
          animate={isFollowing ? { scale: [1, 1.2, 1], rotate: [0, 10, -10, 0] } : {}}
          transition={isFollowing ? { duration: 0.6, times: [0, 0.5, 1] } : {}}
        >
          <Heart className={`w-5 h-5 ${isFollowing ? 'fill-current' : ''}`} />
        </motion.div>
        {isFollowing ? 'Following' : 'Follow Creator'}
        {isFollowing && (
          <motion.div
            className="absolute inset-0 rounded-2xl pointer-events-none"
            initial={{ boxShadow: '0 0 0 0 rgba(239, 68, 68, 0.7)' }}
            animate={{ boxShadow: '0 0 0 10px rgba(239, 68, 68, 0)' }}
            transition={{ duration: 0.6 }}
          />
        )}
      </button>
    </div>
  );
}