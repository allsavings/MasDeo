import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus, Server, Upload, Globe, Shield, Trash2, Copy,
  CheckCircle, Link2, Eye, EyeOff, ChevronDown, ChevronUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export default function CreatorEthicalInternet({ user }) {
  const [tab, setTab] = useState('vps');
  const [vpsServers, setVpsServers] = useState([]);
  const [vpnFiles, setVpnFiles] = useState([]);
  const [showVpsForm, setShowVpsForm] = useState(false);
  const [showFileForm, setShowFileForm] = useState(false);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [copiedId, setCopiedId] = useState(null);

  const [vpsForm, setVpsForm] = useState({
    server_name: '', ip_address: '', location: '', os: 'Ubuntu 22.04',
    website_url: '', is_public: false
  });

  const [fileForm, setFileForm] = useState({
    file_name: '', file_type: 'ovpn', server_location: '',
    protocol: 'TCP/UDP', description: '', file_url: '', is_public: false
  });

  useEffect(() => {
    if (user) loadData();
  }, [user]);

  const loadData = async () => {
    const [vps, files] = await Promise.all([
      base44.entities.CreatorVpsServer.filter({ creator_email: user.email }, '-created_date'),
      base44.entities.CreatorVpnFile.filter({ creator_email: user.email }, '-created_date')
    ]);
    setVpsServers(vps);
    setVpnFiles(files);
  };

  const handleSaveVps = async () => {
    await base44.entities.CreatorVpsServer.create({ ...vpsForm, creator_email: user.email });
    setVpsForm({ server_name: '', ip_address: '', location: '', os: 'Ubuntu 22.04', website_url: '', is_public: false });
    setShowVpsForm(false);
    loadData();
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingFile(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setFileForm(f => ({ ...f, file_url }));
    setUploadingFile(false);
  };

  const handleSaveFile = async () => {
    if (!fileForm.file_url) return;
    await base44.entities.CreatorVpnFile.create({ ...fileForm, creator_email: user.email });
    setFileForm({ file_name: '', file_type: 'ovpn', server_location: '', protocol: 'TCP/UDP', description: '', file_url: '', is_public: false });
    setShowFileForm(false);
    loadData();
  };

  const handleDelete = async (entity, id) => {
    await base44.entities[entity].delete(id);
    loadData();
  };

  const copyLink = (url, id) => {
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const togglePublic = async (entity, item) => {
    await base44.entities[entity].update(item.id, { is_public: !item.is_public });
    loadData();
  };

  return (
    <div className="mt-2">
      {/* Creator header */}
      <div className="mx-4 mb-4 bg-gradient-to-r from-purple-900/40 to-blue-900/40 rounded-2xl p-4 border border-purple-500/30">
        <div className="flex items-center gap-2 mb-1">
          <Shield className="w-4 h-4 text-purple-400" />
          <span className="text-sm font-semibold text-purple-300">Creator Dashboard — Ethical Internet</span>
        </div>
        <p className="text-xs text-gray-400">Publish VPS servers & VPN files for your subscribers</p>
        <div className="flex gap-4 mt-3 text-xs text-gray-400">
          <span className="flex items-center gap-1"><Server className="w-3 h-3 text-blue-400" />{vpsServers.length} VPS</span>
          <span className="flex items-center gap-1"><Shield className="w-3 h-3 text-green-400" />{vpnFiles.length} VPN Files</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex mx-4 mb-4 bg-gray-800/40 rounded-xl p-1 gap-1">
        {[{ id: 'vps', label: 'VPS Servers', icon: Server }, { id: 'files', label: 'VPN Files', icon: Shield }].map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-medium transition-all ${
              tab === t.id ? 'bg-white text-gray-900' : 'text-gray-500'
            }`}
          >
            <t.icon className="w-4 h-4" />
            {t.label}
          </button>
        ))}
      </div>

      {/* VPS Tab */}
      {tab === 'vps' && (
        <div className="px-4 space-y-3">
          <button
            onClick={() => setShowVpsForm(v => !v)}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl border border-dashed border-blue-500/50 text-blue-400 text-sm hover:bg-blue-500/10 transition-colors"
          >
            <Plus className="w-4 h-4" /> Add VPS Server
          </button>

          <AnimatePresence>
            {showVpsForm && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="bg-gray-800/60 rounded-2xl p-4 border border-gray-700/50 space-y-3"
              >
                <div className="grid grid-cols-2 gap-2">
                  <Input placeholder="Server Name" value={vpsForm.server_name} onChange={e => setVpsForm(f => ({ ...f, server_name: e.target.value }))} className="bg-gray-900/50 border-gray-700 text-white text-sm" />
                  <Input placeholder="IP Address" value={vpsForm.ip_address} onChange={e => setVpsForm(f => ({ ...f, ip_address: e.target.value }))} className="bg-gray-900/50 border-gray-700 text-white text-sm" />
                  <Input placeholder="Location (e.g. SA)" value={vpsForm.location} onChange={e => setVpsForm(f => ({ ...f, location: e.target.value }))} className="bg-gray-900/50 border-gray-700 text-white text-sm" />
                  <Input placeholder="OS (Ubuntu 22.04)" value={vpsForm.os} onChange={e => setVpsForm(f => ({ ...f, os: e.target.value }))} className="bg-gray-900/50 border-gray-700 text-white text-sm" />
                </div>
                <Input placeholder="Website URL (optional)" value={vpsForm.website_url} onChange={e => setVpsForm(f => ({ ...f, website_url: e.target.value }))} className="bg-gray-900/50 border-gray-700 text-white text-sm" />
                <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
                  <input type="checkbox" checked={vpsForm.is_public} onChange={e => setVpsForm(f => ({ ...f, is_public: e.target.checked }))} className="accent-purple-500" />
                  Make public to subscribers
                </label>
                <div className="flex gap-2">
                  <Button onClick={handleSaveVps} className="flex-1 bg-blue-600 text-sm py-2">Save</Button>
                  <Button onClick={() => setShowVpsForm(false)} variant="outline" className="flex-1 text-sm py-2">Cancel</Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {vpsServers.map((vps, i) => (
            <motion.div key={vps.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
              className="bg-gray-800/40 rounded-2xl p-4 border border-gray-700/50"
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-semibold text-white text-sm">{vps.server_name}</p>
                  <p className="text-xs text-gray-400 font-mono mt-0.5">{vps.ip_address}</p>
                  <div className="flex gap-2 mt-1 flex-wrap">
                    {vps.location && <span className="text-xs bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded-full">{vps.location}</span>}
                    {vps.os && <span className="text-xs bg-gray-700/50 text-gray-400 px-2 py-0.5 rounded-full">{vps.os}</span>}
                    {vps.is_public && <span className="text-xs bg-green-500/20 text-green-400 px-2 py-0.5 rounded-full">Public</span>}
                  </div>
                  {vps.website_url && (
                    <div className="flex items-center gap-1 mt-2">
                      <Link2 className="w-3 h-3 text-cyan-400" />
                      <button onClick={() => copyLink(vps.website_url, vps.id + 'url')} className="text-xs text-cyan-400 underline truncate max-w-[180px]">
                        {copiedId === vps.id + 'url' ? 'Copied!' : vps.website_url}
                      </button>
                    </div>
                  )}
                </div>
                <div className="flex flex-col gap-2">
                  <button onClick={() => togglePublic('CreatorVpsServer', vps)} className="p-1.5 rounded-lg bg-gray-700/50 hover:bg-gray-700 transition-colors">
                    {vps.is_public ? <Eye className="w-4 h-4 text-green-400" /> : <EyeOff className="w-4 h-4 text-gray-500" />}
                  </button>
                  <button onClick={() => handleDelete('CreatorVpsServer', vps.id)} className="p-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 transition-colors">
                    <Trash2 className="w-4 h-4 text-red-400" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
          {vpsServers.length === 0 && (
            <p className="text-center text-gray-600 text-sm py-6">No VPS servers yet. Add your first one above.</p>
          )}
        </div>
      )}

      {/* VPN Files Tab */}
      {tab === 'files' && (
        <div className="px-4 space-y-3">
          <button
            onClick={() => setShowFileForm(v => !v)}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl border border-dashed border-green-500/50 text-green-400 text-sm hover:bg-green-500/10 transition-colors"
          >
            <Upload className="w-4 h-4" /> Upload VPN File
          </button>

          <AnimatePresence>
            {showFileForm && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="bg-gray-800/60 rounded-2xl p-4 border border-gray-700/50 space-y-3"
              >
                <div className="grid grid-cols-2 gap-2">
                  <Input placeholder="File Name" value={fileForm.file_name} onChange={e => setFileForm(f => ({ ...f, file_name: e.target.value }))} className="bg-gray-900/50 border-gray-700 text-white text-sm" />
                  <select value={fileForm.file_type} onChange={e => setFileForm(f => ({ ...f, file_type: e.target.value }))}
                    className="bg-gray-900/50 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm">
                    {['ovpn', 'ssh', 'ssl', 'v2ray', 'wireguard', 'other'].map(t => <option key={t} value={t}>{t.toUpperCase()}</option>)}
                  </select>
                  <Input placeholder="Location" value={fileForm.server_location} onChange={e => setFileForm(f => ({ ...f, server_location: e.target.value }))} className="bg-gray-900/50 border-gray-700 text-white text-sm" />
                  <Input placeholder="Protocol (TCP/UDP)" value={fileForm.protocol} onChange={e => setFileForm(f => ({ ...f, protocol: e.target.value }))} className="bg-gray-900/50 border-gray-700 text-white text-sm" />
                </div>
                <textarea placeholder="Description..." value={fileForm.description} onChange={e => setFileForm(f => ({ ...f, description: e.target.value }))}
                  className="w-full bg-gray-900/50 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm resize-none h-16" />
                <div>
                  <input type="file" id="vpn-file-upload" className="hidden" onChange={handleFileUpload} />
                  <label htmlFor="vpn-file-upload" className="flex items-center justify-center gap-2 border border-dashed border-gray-600 rounded-xl py-3 cursor-pointer hover:border-green-500/50 transition-colors text-sm text-gray-400">
                    <Upload className="w-4 h-4" />
                    {uploadingFile ? 'Uploading...' : fileForm.file_url ? '✓ File ready — change it' : 'Upload .ovpn / config file'}
                  </label>
                </div>
                <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
                  <input type="checkbox" checked={fileForm.is_public} onChange={e => setFileForm(f => ({ ...f, is_public: e.target.checked }))} className="accent-purple-500" />
                  Make public to subscribers
                </label>
                <div className="flex gap-2">
                  <Button onClick={handleSaveFile} disabled={!fileForm.file_url || !fileForm.file_name} className="flex-1 bg-green-600 text-sm py-2 disabled:opacity-50">Save</Button>
                  <Button onClick={() => setShowFileForm(false)} variant="outline" className="flex-1 text-sm py-2">Cancel</Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {vpnFiles.map((file, i) => (
            <motion.div key={file.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
              className="bg-gray-800/40 rounded-2xl p-4 border border-gray-700/50"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-white text-sm">{file.file_name}</p>
                    <span className="text-xs bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded-full">{file.file_type?.toUpperCase()}</span>
                  </div>
                  <div className="flex gap-2 mt-1 flex-wrap">
                    {file.server_location && <span className="text-xs text-gray-400">{file.server_location}</span>}
                    {file.protocol && <span className="text-xs text-gray-500">• {file.protocol}</span>}
                    {file.is_public && <span className="text-xs bg-green-500/20 text-green-400 px-2 py-0.5 rounded-full">Public</span>}
                  </div>
                  {file.file_url && (
                    <button
                      onClick={() => copyLink(file.file_url, file.id)}
                      className="mt-2 flex items-center gap-1 text-xs text-cyan-400 hover:text-cyan-300 transition-colors"
                    >
                      {copiedId === file.id ? <CheckCircle className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      {copiedId === file.id ? 'Link copied!' : 'Copy download link'}
                    </button>
                  )}
                </div>
                <div className="flex flex-col gap-2 ml-2">
                  <button onClick={() => togglePublic('CreatorVpnFile', file)} className="p-1.5 rounded-lg bg-gray-700/50 hover:bg-gray-700 transition-colors">
                    {file.is_public ? <Eye className="w-4 h-4 text-green-400" /> : <EyeOff className="w-4 h-4 text-gray-500" />}
                  </button>
                  <button onClick={() => handleDelete('CreatorVpnFile', file.id)} className="p-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 transition-colors">
                    <Trash2 className="w-4 h-4 text-red-400" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
          {vpnFiles.length === 0 && (
            <p className="text-center text-gray-600 text-sm py-6">No VPN files yet. Upload your first one above.</p>
          )}
        </div>
      )}
    </div>
  );
}