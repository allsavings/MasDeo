import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus, DollarSign, Upload, Trash2, Eye, EyeOff,
  CheckCircle, Copy, Link2, BarChart3, Bot, Radio, TrendingUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const RESOURCE_TYPES = [
  { value: 'forex_signal', label: 'Forex Signal', icon: BarChart3, color: 'from-green-500 to-emerald-500' },
  { value: 'trading_robot', label: 'Trading Robot (EA)', icon: Bot, color: 'from-blue-500 to-cyan-500' },
  { value: 'trading_course', label: 'Trading Course', icon: TrendingUp, color: 'from-amber-500 to-orange-500' },
  { value: 'passive_income', label: 'Passive Income', icon: DollarSign, color: 'from-purple-500 to-pink-500' },
  { value: 'ai_tool', label: 'AI Business Tool', icon: Bot, color: 'from-indigo-500 to-blue-500' },
  { value: 'mentorship', label: 'Mentorship', icon: Radio, color: 'from-rose-500 to-pink-500' },
  { value: 'other', label: 'Other', icon: DollarSign, color: 'from-gray-500 to-gray-600' }
];

export default function CreatorEarnOnline({ user }) {
  const [resources, setResources] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [uploadingThumb, setUploadingThumb] = useState(false);
  const [copiedId, setCopiedId] = useState(null);

  const [form, setForm] = useState({
    title: '', description: '', resource_type: 'forex_signal',
    file_url: '', external_link: '', thumbnail_url: '',
    is_free: false, price: 0, is_published: false, tags: ''
  });

  useEffect(() => {
    if (user) loadResources();
  }, [user]);

  const loadResources = async () => {
    const data = await base44.entities.CreatorResource.filter({ creator_email: user.email }, '-created_date');
    setResources(data);
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingFile(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setForm(f => ({ ...f, file_url }));
    setUploadingFile(false);
  };

  const handleThumbUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingThumb(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setForm(f => ({ ...f, thumbnail_url: file_url }));
    setUploadingThumb(false);
  };

  const handleSave = async () => {
    await base44.entities.CreatorResource.create({ ...form, creator_email: user.email });
    setForm({ title: '', description: '', resource_type: 'forex_signal', file_url: '', external_link: '', thumbnail_url: '', is_free: false, price: 0, is_published: false, tags: '' });
    setShowForm(false);
    loadResources();
  };

  const handleDelete = async (id) => {
    await base44.entities.CreatorResource.delete(id);
    loadResources();
  };

  const togglePublish = async (res) => {
    await base44.entities.CreatorResource.update(res.id, { is_published: !res.is_published });
    loadResources();
  };

  const copyLink = (url, id) => {
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getTypeInfo = (type) => RESOURCE_TYPES.find(t => t.value === type) || RESOURCE_TYPES[6];

  return (
    <div className="mt-2">
      {/* Creator header */}
      <div className="mx-4 mb-4 bg-gradient-to-r from-emerald-900/40 to-cyan-900/40 rounded-2xl p-4 border border-emerald-500/30">
        <div className="flex items-center gap-2 mb-1">
          <DollarSign className="w-4 h-4 text-emerald-400" />
          <span className="text-sm font-semibold text-emerald-300">Creator Dashboard — Earn Online</span>
        </div>
        <p className="text-xs text-gray-400">Publish forex signals, robots, courses & income tools</p>
        <div className="flex gap-4 mt-3 text-xs text-gray-400">
          <span className="flex items-center gap-1"><DollarSign className="w-3 h-3 text-emerald-400" />{resources.length} Resources</span>
          <span className="flex items-center gap-1"><Eye className="w-3 h-3 text-green-400" />{resources.filter(r => r.is_published).length} Published</span>
        </div>
      </div>

      {/* Resource type quick filters */}
      <div className="px-4 mb-4 flex gap-2 overflow-x-auto pb-2 scrollbar-none">
        {RESOURCE_TYPES.slice(0, 5).map(rt => {
          const count = resources.filter(r => r.resource_type === rt.value).length;
          return (
            <div key={rt.value} className={`flex-shrink-0 bg-gradient-to-br ${rt.color} rounded-xl px-3 py-1.5 text-xs text-white font-medium flex items-center gap-1.5`}>
              <rt.icon className="w-3 h-3" />
              {rt.label}
              {count > 0 && <span className="bg-white/20 rounded-full px-1.5">{count}</span>}
            </div>
          );
        })}
      </div>

      <div className="px-4 space-y-3">
        <button
          onClick={() => setShowForm(v => !v)}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl border border-dashed border-emerald-500/50 text-emerald-400 text-sm hover:bg-emerald-500/10 transition-colors"
        >
          <Plus className="w-4 h-4" /> Add Resource / Product
        </button>

        <AnimatePresence>
          {showForm && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="bg-gray-800/60 rounded-2xl p-4 border border-gray-700/50 space-y-3"
            >
              <Input placeholder="Title *" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} className="bg-gray-900/50 border-gray-700 text-white text-sm" />
              <textarea placeholder="Description..." value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                className="w-full bg-gray-900/50 border border-gray-700 rounded-lg px-3 py-2 text-white text-sm resize-none h-16" />

              <div>
                <p className="text-xs text-gray-400 mb-2">Resource Type</p>
                <div className="grid grid-cols-2 gap-2">
                  {RESOURCE_TYPES.map(rt => (
                    <button
                      key={rt.value}
                      onClick={() => setForm(f => ({ ...f, resource_type: rt.value }))}
                      className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium border transition-all ${
                        form.resource_type === rt.value
                          ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300'
                          : 'bg-gray-900/50 border-gray-700 text-gray-400'
                      }`}
                    >
                      <rt.icon className="w-3 h-3" />
                      {rt.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="relative">
                <Link2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cyan-400" />
                <Input placeholder="External link (broker, group, etc.)" value={form.external_link} onChange={e => setForm(f => ({ ...f, external_link: e.target.value }))} className="bg-gray-900/50 border-gray-700 text-white text-sm pl-9" />
              </div>

              <div>
                <input type="file" id="resource-file-upload" className="hidden" onChange={handleFileUpload} />
                <label htmlFor="resource-file-upload" className="flex items-center justify-center gap-2 border border-dashed border-gray-600 rounded-xl py-2 cursor-pointer hover:border-emerald-500/50 transition-colors text-sm text-gray-400">
                  <Upload className="w-4 h-4" />
                  {uploadingFile ? 'Uploading...' : form.file_url ? '✓ File uploaded' : 'Upload file (EA, PDF, zip...)'}
                </label>
              </div>

              <div>
                <input type="file" id="resource-thumb-upload" accept="image/*" className="hidden" onChange={handleThumbUpload} />
                <label htmlFor="resource-thumb-upload" className="flex items-center justify-center gap-2 border border-dashed border-gray-600 rounded-xl py-2 cursor-pointer hover:border-emerald-500/50 transition-colors text-sm text-gray-400">
                  <Upload className="w-4 h-4" />
                  {uploadingThumb ? 'Uploading...' : form.thumbnail_url ? '✓ Thumbnail uploaded' : 'Upload thumbnail (optional)'}
                </label>
              </div>

              <Input placeholder="Tags (comma-separated, e.g. forex, mt4, signals)" value={form.tags} onChange={e => setForm(f => ({ ...f, tags: e.target.value }))} className="bg-gray-900/50 border-gray-700 text-white text-sm" />

              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
                  <input type="checkbox" checked={form.is_free} onChange={e => setForm(f => ({ ...f, is_free: e.target.checked }))} className="accent-emerald-500" />
                  Free resource
                </label>
                {!form.is_free && (
                  <Input type="number" placeholder="Price (R)" value={form.price} onChange={e => setForm(f => ({ ...f, price: Number(e.target.value) }))} className="bg-gray-900/50 border-gray-700 text-white text-sm w-28" />
                )}
              </div>

              <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
                <input type="checkbox" checked={form.is_published} onChange={e => setForm(f => ({ ...f, is_published: e.target.checked }))} className="accent-emerald-500" />
                Publish immediately
              </label>

              <div className="flex gap-2">
                <Button onClick={handleSave} disabled={!form.title} className="flex-1 bg-emerald-600 text-sm py-2 disabled:opacity-50">Save Resource</Button>
                <Button onClick={() => setShowForm(false)} variant="outline" className="flex-1 text-sm py-2">Cancel</Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {resources.map((res, i) => {
          const typeInfo = getTypeInfo(res.resource_type);
          return (
            <motion.div key={res.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
              className="bg-gray-800/40 rounded-2xl overflow-hidden border border-gray-700/50"
            >
              {res.thumbnail_url && (
                <img src={res.thumbnail_url} alt={res.title} className="w-full h-24 object-cover" />
              )}
              <div className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <div className={`w-6 h-6 rounded-lg bg-gradient-to-br ${typeInfo.color} flex items-center justify-center`}>
                        <typeInfo.icon className="w-3 h-3 text-white" />
                      </div>
                      <p className="font-semibold text-white text-sm">{res.title}</p>
                      {res.is_published ? (
                        <span className="text-xs bg-green-500/20 text-green-400 px-2 py-0.5 rounded-full">Live</span>
                      ) : (
                        <span className="text-xs bg-gray-700/50 text-gray-400 px-2 py-0.5 rounded-full">Draft</span>
                      )}
                      {res.is_free ? (
                        <span className="text-xs bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded-full">Free</span>
                      ) : (
                        <span className="text-xs bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full">R{res.price}</span>
                      )}
                    </div>
                    <p className="text-xs text-gray-400 mt-0.5">{typeInfo.label}</p>
                    {res.description && <p className="text-xs text-gray-500 mt-1 line-clamp-1">{res.description}</p>}
                    {res.external_link && (
                      <button onClick={() => copyLink(res.external_link, res.id + 'ext')} className="mt-1.5 flex items-center gap-1 text-xs text-cyan-400">
                        {copiedId === res.id + 'ext' ? <CheckCircle className="w-3 h-3" /> : <Link2 className="w-3 h-3" />}
                        {copiedId === res.id + 'ext' ? 'Copied!' : 'Copy external link'}
                      </button>
                    )}
                    {res.file_url && (
                      <button onClick={() => copyLink(res.file_url, res.id + 'file')} className="mt-1 flex items-center gap-1 text-xs text-emerald-400">
                        {copiedId === res.id + 'file' ? <CheckCircle className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                        {copiedId === res.id + 'file' ? 'Copied!' : 'Copy file link'}
                      </button>
                    )}
                  </div>
                  <div className="flex flex-col gap-2 ml-2">
                    <button onClick={() => togglePublish(res)} className="p-1.5 rounded-lg bg-gray-700/50 hover:bg-gray-700 transition-colors">
                      {res.is_published ? <Eye className="w-4 h-4 text-green-400" /> : <EyeOff className="w-4 h-4 text-gray-500" />}
                    </button>
                    <button onClick={() => handleDelete(res.id)} className="p-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 transition-colors">
                      <Trash2 className="w-4 h-4 text-red-400" />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}

        {resources.length === 0 && (
          <p className="text-center text-gray-600 text-sm py-6">No resources yet. Add your first one above.</p>
        )}
      </div>
    </div>
  );
}