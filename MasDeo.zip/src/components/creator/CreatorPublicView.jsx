import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { ExternalLink, Download, ChevronDown, ChevronUp, Code2, Copy, Check } from 'lucide-react';

export default function CreatorPublicView({ creatorEmail, sectionPage }) {
  const [sections, setSections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState({});
  const [copiedId, setCopiedId] = useState(null);
  const [expandedScript, setExpandedScript] = useState({});

  const copyScript = (id, code) => {
    navigator.clipboard.writeText(code);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  useEffect(() => {
    if (creatorEmail && sectionPage) loadSections();
  }, [creatorEmail, sectionPage]);

  const loadSections = async () => {
    setLoading(true);
    const allSections = await base44.entities.CreatorSection.filter(
      { creator_email: creatorEmail, section_page: sectionPage, is_visible: true }, 'sort_order'
    );
    const withItems = await Promise.all(
      allSections.map(async (sec) => {
        const items = await base44.entities.CreatorItem.filter(
          { section_id: sec.id, is_visible: true }, 'sort_order'
        );
        return { ...sec, items };
      })
    );
    setSections(withItems);
    // Auto-expand all
    const exp = {};
    withItems.forEach(s => { exp[s.id] = true; });
    setExpanded(exp);
    setLoading(false);
  };



  if (loading) {
    return (
      <div className="flex items-center justify-center py-10">
        <div className="w-5 h-5 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (sections.length === 0) {
    return (
      <div className="text-center py-10 text-gray-500 text-sm">
        No content published yet in this section.
      </div>
    );
  }

  return (
    <div className="space-y-6 px-4 pb-6">
      {sections.map((sec, si) => (
        <motion.div key={sec.id} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: si * 0.05 }}>
          {/* Section Header */}
          <button
            onClick={() => setExpanded(e => ({ ...e, [sec.id]: !e[sec.id] }))}
            className="w-full flex items-center justify-between mb-3"
          >
            <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider">{sec.title}</h3>
            {expanded[sec.id]
              ? <ChevronUp className="w-4 h-4 text-gray-500" />
              : <ChevronDown className="w-4 h-4 text-gray-500" />
            }
          </button>

          {expanded[sec.id] && (
            <div className="space-y-3">
              {sec.items.map((item, ii) => (
                <motion.div key={item.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: ii * 0.04 }}>
                  <div className="bg-gray-800/40 rounded-2xl p-4 border border-gray-700/50 hover:border-blue-500/30 transition-all group">
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${item.icon_color || 'from-blue-500 to-cyan-500'} flex items-center justify-center flex-shrink-0 group-hover:scale-105 transition-transform`}>
                        <span className="text-white text-lg font-bold">{item.title.charAt(0)}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-white text-sm mb-0.5">{item.title}</h4>
                        {item.description && <p className="text-xs text-gray-400 line-clamp-2">{item.description}</p>}
                      </div>
                      <div className="flex flex-col gap-1.5 flex-shrink-0">
                       {item.link_url && (
                         <a
                           href={item.link_url}
                           target="_blank"
                           rel="noopener noreferrer"
                           className="p-1.5 bg-blue-500/20 rounded-lg hover:bg-blue-500/30 transition-colors">
                           <ExternalLink className="w-3.5 h-3.5 text-blue-400" />
                         </a>
                       )}
                        {item.file_url && (
                          <a href={item.file_url} target="_blank" rel="noopener noreferrer"
                            className="p-1.5 bg-green-500/20 rounded-lg hover:bg-green-500/30 transition-colors">
                            <Download className="w-3.5 h-3.5 text-green-400" />
                          </a>
                        )}
                        {item.script_code && (
                          <button
                            onClick={() => setExpandedScript(e => ({ ...e, [item.id]: !e[item.id] }))}
                            className="p-1.5 bg-green-500/20 rounded-lg hover:bg-green-500/30 transition-colors">
                            <Code2 className="w-3.5 h-3.5 text-green-400" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Script/Code block */}
                    {item.script_code && expandedScript[item.id] && (
                      <div className="mt-3 bg-black/40 rounded-xl border border-green-500/20 overflow-hidden">
                        <div className="flex items-center justify-between px-3 py-1.5 border-b border-green-500/20">
                          <span className="text-[10px] font-semibold text-green-400 uppercase tracking-wider">
                            {item.script_label || 'Script / Code'}
                          </span>
                          <button
                            onClick={() => copyScript(item.id, item.script_code)}
                            className="flex items-center gap-1 text-[10px] text-gray-400 hover:text-green-400 transition-colors"
                          >
                            {copiedId === item.id ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                            {copiedId === item.id ? 'Copied!' : 'Copy'}
                          </button>
                        </div>
                        <pre className="px-3 py-2 text-[11px] text-green-300 font-mono overflow-x-auto whitespace-pre-wrap break-all leading-relaxed">
                          {item.script_code}
                        </pre>
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      ))}
    </div>
  );
}