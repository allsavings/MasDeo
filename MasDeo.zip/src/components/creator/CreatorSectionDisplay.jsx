import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { ExternalLink, Download, Copy, Check, ArrowLeft, Award, Heart, Eye, Search, X } from 'lucide-react';
import CreatorProfileHeader from './CreatorProfileHeader';

export default function CreatorSectionDisplay({ creatorEmail, sectionPage, theme = 'ethical', onBack, isFreemium, navigate }) {
  const [sections, setSections] = useState({});
  const [loading, setLoading] = useState(true);
  const [copiedScriptId, setCopiedScriptId] = useState(null);
  const [creatorProfile, setCreatorProfile] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [activeSection, setActiveSection] = useState(sectionPage);
  const [itemReactions, setItemReactions] = useState({});
  const [itemViews, setItemViews] = useState({});
  const [searchQuery, setSearchQuery] = useState('');
  const sectionTabs = ['ethical', 'learn', 'earn'];

  useEffect(() => {
    loadAllSections();
    loadCreatorProfile();
  }, [creatorEmail]);

  const loadCreatorProfile = async () => {
    try {
      const [profiles, creators, followers] = await Promise.all([
        base44.entities.UserProfile.filter({ created_by: creatorEmail }),
        base44.entities.CreatorProfile.filter({ user_email: creatorEmail }),
        base44.entities.Follow.filter({ creator_email: creatorEmail })
      ]);
      setUserProfile(profiles[0] || null);
      setCreatorProfile({ ...creators[0], followerCount: followers.length } || null);
    } catch (error) {
      console.error('Error loading creator profile:', error);
    }
  };

  const loadAllSections = async () => {
    setLoading(true);
    try {
      const allSectionsData = {};
      
      await Promise.all(
        sectionTabs.map(async (tab) => {
          const sectionsData = await base44.entities.CreatorSection.filter(
            { creator_email: creatorEmail, section_page: tab, is_visible: true },
            'sort_order'
          );

          const sectionsWithItems = await Promise.all(
            sectionsData.map(async (sec) => {
              const items = await base44.entities.CreatorItem.filter(
                { section_id: sec.id, is_visible: true },
                'sort_order'
              );
              return { ...sec, items };
            })
          );

          allSectionsData[tab] = sectionsWithItems;
        })
      );

      setSections(allSectionsData);
    } catch (error) {
      console.error('Error loading creator sections:', error);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text, itemId) => {
    navigator.clipboard.writeText(text);
    setCopiedScriptId(itemId);
    setTimeout(() => setCopiedScriptId(null), 2000);
  };

  const handleLoveReaction = async (itemId, contentId) => {
    try {
      const user = await base44.auth.me();
      if (!user) return;

      const existingReaction = await base44.entities.ContentReaction.filter({
        content_id: contentId,
        user_email: user.email,
        reaction_type: 'love'
      });

      if (existingReaction.length > 0) {
        await base44.entities.ContentReaction.delete(existingReaction[0].id);
        setItemReactions(prev => ({
          ...prev,
          [itemId]: Math.max(0, (prev[itemId] || 0) - 1)
        }));
      } else {
        await base44.entities.ContentReaction.create({
          content_id: contentId,
          user_email: user.email,
          reaction_type: 'love'
        });
        setItemReactions(prev => ({
          ...prev,
          [itemId]: (prev[itemId] || 0) + 1
        }));
      }
    } catch (error) {
      console.error('Error updating reaction:', error);
    }
  };

  useEffect(() => {
    // Load initial reaction and view counts for all items
    const loadStats = async () => {
      try {
        const allItems = Object.values(sections).flat().flatMap(s => s.items || []);
        const reactionCounts = {};
        const viewCounts = {};
        
        for (const item of allItems) {
          const [reactions, views] = await Promise.all([
            base44.entities.ContentReaction.filter({
              content_id: item.id,
              reaction_type: 'love'
            }),
            base44.entities.ContentView.filter({
              content_id: item.id
            })
          ]);
          reactionCounts[item.id] = reactions.length;
          viewCounts[item.id] = views.length;
        }
        
        setItemReactions(reactionCounts);
        setItemViews(viewCounts);

        // Subscribe to real-time updates
        const unsubscribeReactions = base44.entities.ContentReaction.subscribe((event) => {
          if (event.data.reaction_type === 'love' && reactionCounts.hasOwnProperty(event.data.content_id)) {
            setItemReactions(prev => ({
              ...prev,
              [event.data.content_id]: Math.max(0, (prev[event.data.content_id] || 0) + (event.type === 'create' ? 1 : -1))
            }));
          }
        });

        const unsubscribeViews = base44.entities.ContentView.subscribe((event) => {
          if (viewCounts.hasOwnProperty(event.data.content_id)) {
            setItemViews(prev => ({
              ...prev,
              [event.data.content_id]: (prev[event.data.content_id] || 0) + (event.type === 'create' ? 1 : 0)
            }));
          }
        });

        return () => {
          unsubscribeReactions();
          unsubscribeViews();
        };
      } catch (error) {
        console.error('Error loading stats:', error);
      }
    };

    loadStats();
  }, [sections]);

  const recordView = async (itemId) => {
    try {
      const user = await base44.auth.me();
      if (!user) return;
      
      // Check if user already viewed this item
      const existingView = await base44.entities.ContentView.filter({
        content_id: itemId,
        user_email: user.email
      });
      
      if (existingView.length === 0) {
        await base44.entities.ContentView.create({
          content_id: itemId,
          user_email: user.email
        });
      }
    } catch (error) {
      console.error('Error recording view:', error);
    }
  };

  const handleLinkClick = (e, href) => {
    // Allow target="_blank" links to open naturally without interception
    // Users get the link in new tab, no ad blocking needed for external links
    recordView(e.currentTarget?.dataset?.itemId);
  };



  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const rawSectionData = sections[activeSection] || [];
  const currentSectionData = searchQuery
    ? rawSectionData.map(sec => ({
        ...sec,
        items: (sec.items || []).filter(item =>
          item.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.description?.toLowerCase().includes(searchQuery.toLowerCase())
        )
      })).filter(sec => sec.items.length > 0)
    : rawSectionData;
  const hasSections = Object.values(sections).some(sec => sec && sec.length > 0);

  if (!hasSections) {
    return null;
  }

  return (
    <div>
      {/* Back Button */}
      {onBack && (
        <div className="px-6 pt-4 pb-2">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors text-sm"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Creators
          </button>
        </div>
      )}
      
      {/* Creator Profile Header */}
      <div className="px-6 pt-4">
        <CreatorProfileHeader 
          creatorEmail={creatorEmail}
          userProfile={userProfile}
          creatorProfile={creatorProfile}
        />
      </div>

      {/* Section Tabs */}
      <div className="px-6 py-4 border-b border-gray-800/50 flex gap-2 overflow-x-auto">
        {sectionTabs.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveSection(tab)}
            className={`px-4 py-2 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
              activeSection === tab
                ? 'bg-blue-500/30 text-blue-400 border border-blue-500/50'
                : 'bg-gray-800/40 text-gray-400 border border-gray-700/30 hover:bg-gray-800/60'
            } ${!sections[tab] || sections[tab].length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
            disabled={!sections[tab] || sections[tab].length === 0}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
            {sections[tab] && sections[tab].length > 0 && (
              <span className="ml-2 text-[10px] bg-gray-700/50 px-1.5 py-0.5 rounded">
                {sections[tab].reduce((sum, s) => sum + (s.items?.length || 0), 0)}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Search Bar */}
      <div className="px-6 pt-4 pb-2">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            type="text"
            placeholder="Search by title or description..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-gray-800/60 border border-gray-700/60 rounded-xl pl-9 pr-9 py-2.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-blue-500/60"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2">
              <X className="w-4 h-4 text-gray-500 hover:text-white" />
            </button>
          )}
        </div>
        {searchQuery && (
          <p className="text-xs text-gray-500 mt-1.5">
            {currentSectionData.reduce((sum, s) => sum + s.items.length, 0)} result(s) found
          </p>
        )}
      </div>

      <div className="px-6 space-y-4 py-4">
        {currentSectionData.length === 0 && searchQuery ? (
          <div className="text-center py-8 bg-gray-800/20 rounded-2xl">
            <Search className="w-8 h-8 text-gray-600 mx-auto mb-2" />
            <p className="text-gray-500 text-sm">No items match "{searchQuery}"</p>
          </div>
        ) : null}
        {currentSectionData.map((section, secIndex) => (
        <div key={section.id}>
          <h3 className="font-semibold text-gray-400 text-sm uppercase tracking-wider mb-3">
            {section.title}
          </h3>

          <div className="space-y-3">
            {section.items.map((item, itemIndex) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: (secIndex * 0.1) + (itemIndex * 0.05) }}
                className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50 hover:border-blue-500/50 transition-all cursor-pointer group"
              >
                <div className="flex items-start gap-4">
                  {/* Icon */}
                  {item.icon_image_url ? (
                    <img src={item.icon_image_url} alt={item.title} className="w-12 h-12 rounded-xl object-cover flex-shrink-0 group-hover:scale-110 transition-transform" />
                  ) : (
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${item.icon_color || 'from-blue-500 to-cyan-500'} flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                      <span className="text-lg font-bold text-white">{item.title.charAt(0)}</span>
                    </div>
                  )}

                  {/* Content */}
                  <div className="flex-1">
                    <h4 className="font-semibold text-white mb-1">{item.title}</h4>
                    {item.description && (
                      <p className="text-sm text-gray-400 mb-3">{item.description}</p>
                    )}

                    {/* Script/Code section */}
                    {item.script_code && (
                      <div className="bg-gray-900/50 rounded-lg p-3 mb-3 border border-green-500/20">
                        {item.script_label && (
                          <p className="text-xs font-semibold text-green-400 mb-2">{item.script_label}</p>
                        )}
                        <div className="bg-gray-900 rounded p-2 mb-2 relative group/code">
                          <pre className="text-xs text-green-300 font-mono overflow-x-auto max-h-32">
                            {item.script_code}
                          </pre>
                          <button
                            onClick={() => copyToClipboard(item.script_code, item.id)}
                            className="absolute top-2 right-2 bg-green-600/40 hover:bg-green-600/60 p-1.5 rounded transition-colors opacity-0 group-hover/code:opacity-100"
                            title="Copy code"
                          >
                            {copiedScriptId === item.id ? (
                              <Check className="w-3.5 h-3.5 text-green-300" />
                            ) : (
                              <Copy className="w-3.5 h-3.5 text-green-400" />
                            )}
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Subsections */}
                    {item.subsections && item.subsections.length > 0 && (
                      <div className="bg-gray-900/50 rounded-lg p-3 mb-3 space-y-3">
                        {item.subsections.map((subsec, idx) => (
                          <div key={idx} className="border-l-2 border-purple-500/40 pl-3">
                            {subsec.title && (
                              <p className="text-xs font-semibold text-purple-400 mb-1">{subsec.title}</p>
                            )}
                            {subsec.description && (
                              <p className="text-xs text-gray-400 mb-2">{subsec.description}</p>
                            )}
                            {subsec.features && subsec.features.length > 0 && (
                              <div className="mb-2 space-y-1">
                                {subsec.features.map((feat, fidx) => (
                                  <p key={fidx} className="text-[10px] text-gray-500">✓ {feat}</p>
                                ))}
                              </div>
                            )}
                            {/* Subsection action buttons */}
                            <div className="flex gap-2 flex-wrap">
                              {subsec.download_links && subsec.download_links.length > 0 ? (
                                subsec.download_links.map((dl, didx) => (
                                  <a
                                   key={didx}
                                   href={dl.url}
                                   target="_blank"
                                   rel="noopener noreferrer"
                                   className="flex items-center gap-2 bg-purple-500/20 border border-purple-500/30 rounded-lg px-2 py-1 hover:bg-purple-500/30 transition-colors"
                                  >
                                   <Download className="w-3 h-3 text-purple-400" />
                                   <span className="text-[10px] font-medium text-purple-400">{dl.label}</span>
                                  </a>
                                ))
                              ) : (
                                <>
                                  {subsec.link_url && (
                                   <a
                                     href={subsec.link_url}
                                     target="_blank"
                                     rel="noopener noreferrer"
                                     className="flex items-center gap-2 bg-purple-500/20 border border-purple-500/30 rounded-lg px-2 py-1 hover:bg-purple-500/30 transition-colors"
                                   >
                                     <ExternalLink className="w-3 h-3 text-purple-400" />
                                     <span className="text-[10px] font-medium text-purple-400">Open Link</span>
                                   </a>
                                  )}
                                  {subsec.file_url && (
                                   <a
                                     href={subsec.file_url}
                                     target="_blank"
                                     rel="noopener noreferrer"
                                     className="flex items-center gap-2 bg-purple-500/20 border border-purple-500/30 rounded-lg px-2 py-1 hover:bg-purple-500/30 transition-colors"
                                   >
                                     <Download className="w-3 h-3 text-purple-400" />
                                     <span className="text-[10px] font-medium text-purple-400">Download</span>
                                   </a>
                                  )}
                                </>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Features list */}
                    {item.features && item.features.length > 0 && (
                     <div className="mb-3 space-y-1">
                       {item.features.map((feat, idx) => (
                         <p key={idx} className="text-xs text-gray-400">✓ {feat}</p>
                       ))}
                     </div>
                    )}

                    {/* Action buttons */}
                    <div className="flex gap-2 flex-wrap">
                      {item.download_links && item.download_links.length > 0 ? (
                        item.download_links.map((dl, idx) => (
                          <a
                            key={idx}
                            href={dl.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={() => recordView(item.id)}
                            className="flex items-center gap-2 bg-cyan-500/20 border border-cyan-500/30 rounded-lg px-3 py-1.5 hover:bg-cyan-500/30 transition-colors"
                          >
                            <Download className="w-3.5 h-3.5 text-cyan-400" />
                            <span className="text-xs font-medium text-cyan-400">{dl.label}</span>
                          </a>
                        ))
                      ) : (
                        <>
                          {item.link_url && (
                            <a
                              href={item.link_url}
                              target="_blank"
                              rel="noopener noreferrer"
                              onClick={() => recordView(item.id)}
                              className="flex items-center gap-2 bg-blue-500/20 border border-blue-500/30 rounded-lg px-3 py-1.5 hover:bg-blue-500/30 transition-colors"
                            >
                              <ExternalLink className="w-3.5 h-3.5 text-blue-400" />
                              <span className="text-xs font-medium text-blue-400">Open Link</span>
                            </a>
                          )}
                          {item.file_url && (
                            <a
                              href={item.file_url}
                              target="_blank"
                              rel="noopener noreferrer"
                              onClick={() => recordView(item.id)}
                              className="flex items-center gap-2 bg-cyan-500/20 border border-cyan-500/30 rounded-lg px-3 py-1.5 hover:bg-cyan-500/30 transition-colors"
                            >
                              <Download className="w-3.5 h-3.5 text-cyan-400" />
                              <span className="text-xs font-medium text-cyan-400">Download</span>
                            </a>
                          )}
                        </>
                      )}
                     <div className="flex items-center gap-2">
                       <motion.button
                         onClick={() => handleLoveReaction(item.id, item.id)}
                         className="flex items-center gap-1 px-2 py-1 rounded-lg transition-colors hover:bg-red-500/10 relative"
                       >
                         <motion.div
                           key={`love-${item.id}-${itemReactions[item.id]}`}
                           animate={{ scale: [1, 1.3, 1] }}
                           transition={{ duration: 0.4 }}
                         >
                           <Heart className="w-3 h-3 text-red-400" />
                         </motion.div>
                         <span className="text-[10px] font-medium text-red-400">{itemReactions[item.id] || 0}</span>
                         <motion.div
                           className="absolute inset-0 rounded-lg pointer-events-none"
                           initial={{ boxShadow: '0 0 0 0 rgba(239, 68, 68, 0.6)' }}
                           animate={{ boxShadow: '0 0 0 6px rgba(239, 68, 68, 0)' }}
                           transition={{ duration: 0.5 }}
                         />
                       </motion.button>
                       <div className="flex items-center gap-1 px-2 py-1 text-gray-500">
                         <Eye className="w-3 h-3" />
                         <span className="text-[10px]">{itemViews[item.id] || 0}</span>
                       </div>
                     </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          </div>
          ))}
          </div>
          </div>
          );
          }