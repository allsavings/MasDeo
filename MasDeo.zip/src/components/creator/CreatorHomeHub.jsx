import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Globe, BookOpen, DollarSign, Plus, ChevronRight, Zap } from 'lucide-react';

const sections = [
  {
    id: 'ethical',
    title: 'Ethical Free Internet',
    subtitle: 'VPS Servers & VPN Files',
    description: 'Publish VPN configs and VPS servers for your subscribers',
    icon: Globe,
    color: 'from-blue-500 to-cyan-400',
    border: 'border-blue-500/30',
    glow: 'hover:border-blue-500/60',
    bg: 'from-blue-600/20 to-cyan-600/20',
    page: 'EthicalInternet',
    accent: 'text-blue-400',
  },
  {
    id: 'learn',
    title: 'Learn Digital Skills',
    subtitle: 'Courses & Tutorials',
    description: 'Add your courses via YouTube link or any video URL',
    icon: BookOpen,
    color: 'from-purple-500 to-blue-500',
    border: 'border-purple-500/30',
    glow: 'hover:border-purple-500/60',
    bg: 'from-purple-600/20 to-blue-600/20',
    page: 'LearnSkills',
    accent: 'text-purple-400',
  },
  {
    id: 'earn',
    title: 'Earn Online',
    subtitle: 'Resources & Products',
    description: 'Publish forex signals, robots, courses & income tools',
    icon: DollarSign,
    color: 'from-emerald-500 to-cyan-400',
    border: 'border-emerald-500/30',
    glow: 'hover:border-emerald-500/60',
    bg: 'from-emerald-600/20 to-cyan-600/20',
    page: 'EarnOnline',
    accent: 'text-emerald-400',
  },
];

export default function CreatorHomeHub({ activeSubs }) {
  return (
    <div className="px-4 pb-28">
      {/* Creator Mode Banner */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-4 bg-gradient-to-r from-purple-900/50 to-pink-900/40 rounded-2xl p-4 border border-purple-500/30"
      >
        <div className="flex items-center gap-2 mb-1">
          <Zap className="w-4 h-4 text-purple-400" />
          <span className="text-sm font-bold text-purple-300">Creator Mode Active</span>
        </div>
        <p className="text-xs text-gray-400">Select a section below to manage and publish your content</p>
      </motion.div>

      {/* Section Cards */}
      <div className="space-y-3">
        {sections.map((section, index) => {
          const Icon = section.icon;
          return (
            <motion.div
              key={section.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Link to={createPageUrl(section.page)}>
                <div className={`bg-gradient-to-r ${section.bg} rounded-2xl p-5 border ${section.border} ${section.glow} transition-all duration-300 group`}>
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${section.color} flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <h3 className="font-bold text-white text-sm">{section.title}</h3>
                        <span className={`text-[10px] font-semibold ${section.accent} bg-white/10 px-1.5 py-0.5 rounded-full`}>
                          {section.subtitle}
                        </span>
                      </div>
                      <p className="text-xs text-gray-400 leading-relaxed">{section.description}</p>
                    </div>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <Plus className={`w-4 h-4 ${section.accent}`} />
                      <ChevronRight className="w-4 h-4 text-gray-600 group-hover:text-gray-400 transition-colors" />
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}