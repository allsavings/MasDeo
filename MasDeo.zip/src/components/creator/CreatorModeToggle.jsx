import React from 'react';
import { motion } from 'framer-motion';
import { Zap, ZapOff } from 'lucide-react';

export default function CreatorModeToggle({ isCreatorMode, isCreatorEligible, onToggle }) {
  if (!isCreatorEligible) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="mx-4 mb-4"
    >
      <button
        onClick={() => onToggle()}
        className={`w-full flex items-center justify-between px-5 py-3 rounded-2xl border transition-all duration-300 ${
          isCreatorMode
            ? 'bg-gradient-to-r from-purple-600/30 to-violet-600/30 border-purple-500/50'
            : 'bg-gray-800/40 border-gray-700/50'
        }`}
      >
        <div className="flex items-center gap-3">
          <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
            isCreatorMode ? 'bg-purple-500/30' : 'bg-gray-700/50'
          }`}>
            {isCreatorMode ? (
              <Zap className="w-5 h-5 text-purple-300" />
            ) : (
              <ZapOff className="w-5 h-5 text-gray-500" />
            )}
          </div>
          <div className="text-left">
            <p className={`text-sm font-semibold ${isCreatorMode ? 'text-purple-200' : 'text-gray-300'}`}>
              Creator Mode
            </p>
            <p className="text-xs text-gray-500">
              {isCreatorMode ? 'Active — showing creator tools' : 'Off — tap to enable'}
            </p>
          </div>
        </div>
        {/* Toggle switch */}
        <div className={`relative w-12 h-6 rounded-full transition-all duration-300 ${
          isCreatorMode ? 'bg-purple-500' : 'bg-gray-700'
        }`}>
          <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow-md transition-all duration-300 ${
            isCreatorMode ? 'left-6' : 'left-0.5'
          }`} />
        </div>
      </button>
    </motion.div>
  );
}