import React, { useMemo, useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Shield, Star, Users, Heart, Eye } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import TrustBadge from './TrustBadge';

const SECTION_THEMES = {
  ethical: {
    gradient: 'from-cyan-500 via-blue-500 to-indigo-500',
    glow: 'shadow-cyan-500/20',
    border: 'border-cyan-500/30',
    badge: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
    ring: 'ring-cyan-500/40',
    accent: 'text-cyan-400',
    label: 'Ethical Free Internet',
    emoji: '🛡️',
  },
  learn: {
    gradient: 'from-purple-500 via-violet-500 to-blue-500',
    glow: 'shadow-purple-500/20',
    border: 'border-purple-500/30',
    badge: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
    ring: 'ring-purple-500/40',
    accent: 'text-purple-400',
    label: 'Learn Digital Skills',
    emoji: '📚',
  },
  earn: {
    gradient: 'from-emerald-500 via-teal-500 to-cyan-500',
    glow: 'shadow-emerald-500/20',
    border: 'border-emerald-500/30',
    badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    ring: 'ring-emerald-500/40',
    accent: 'text-emerald-400',
    label: 'Earn Online',
    emoji: '💰',
  },
};

// Map creator_type to section key
const CREATOR_TYPE_TO_SECTION = {
  ethical_free_internet: 'ethical',
  learn_digital_skills: 'learn',
  earn_online: 'earn',
};

function CreatorCard({ creator, theme, index, onSelect }) {
  const t = SECTION_THEMES[theme];
  const nickname = creator.profile?.nickname || creator.user_email.split('@')[0];
  const handle = creator.profile?.handle || `@${creator.user_email.split('@')[0]}`;
  const [viewCount, setViewCount] = useState(0);
  const [loveCount, setLoveCount] = useState(0);

  useEffect(() => {
    const loadStats = async () => {
      try {
        const [views, loves] = await Promise.all([
          base44.entities.ContentView.filter({ user_email: creator.user_email }),
          base44.entities.ContentReaction.filter({ user_email: creator.user_email, reaction_type: 'love' })
        ]);
        setViewCount(views.length);
        setLoveCount(loves.length);
      } catch (error) {
        console.error('Error loading creator stats:', error);
      }
    };

    loadStats();

    // Real-time subscription for views
    const unsubViews = base44.entities.ContentView.subscribe((event) => {
      if (event.data.user_email === creator.user_email) {
        setViewCount(prev => prev + 1);
      }
    });

    // Real-time subscription for loves
    const unsubLoves = base44.entities.ContentReaction.subscribe((event) => {
      if (event.data.user_email === creator.user_email && event.data.reaction_type === 'love') {
        if (event.type === 'create') {
          setLoveCount(prev => prev + 1);
        } else if (event.type === 'delete') {
          setLoveCount(prev => Math.max(0, prev - 1));
        }
      }
    });

    return () => {
      unsubViews();
      unsubLoves();
    };
  }, [creator.user_email]);

  const handleClick = (e) => {
    if (onSelect) {
      e.preventDefault();
      onSelect(creator.user_email);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
    >
      <div
        className="bg-gray-800/40 rounded-2xl p-5 border border-gray-700/50 hover:border-blue-500/50 transition-all cursor-pointer"
        onClick={handleClick}
      >
        <div className="flex items-start gap-4">
          {creator.profile?.profile_picture_url ? (
            <img 
              src={creator.profile.profile_picture_url}
              alt={nickname}
              className="w-14 h-14 rounded-full object-cover flex-shrink-0"
            />
          ) : (
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center flex-shrink-0">
              <Shield className="w-7 h-7 text-white" />
            </div>
          )}
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h4 className="font-semibold text-white">
                {nickname}
              </h4>
              <TrustBadge trustScore={creator.trust_score} verified={creator.verified} />
            </div>
            <p className="text-xs text-gray-400 mb-2">
              {handle}
            </p>
            {creator.bio && (
              <p className="text-sm text-gray-400 mb-2 line-clamp-2">{creator.bio}</p>
            )}
            <div className="flex items-center gap-3 text-xs text-gray-500 flex-wrap">
              {creator.average_rating > 0 && (
                <span className="flex items-center gap-1">
                  <Star className="w-3 h-3 text-amber-400" />
                  {creator.average_rating?.toFixed(1)} ({creator.total_ratings})
                </span>
              )}
              <span className="flex items-center gap-1">
                <Users className="w-3 h-3 text-blue-400" />
                {creator.followerCount} {creator.followerCount === 1 ? 'follower' : 'followers'}
              </span>
              <span className="flex items-center gap-1">
                <Eye className="w-3 h-3 text-cyan-400" />
                {viewCount.toLocaleString()} views
              </span>
              <span className="flex items-center gap-1">
                <Heart className="w-3 h-3 text-red-400" />
                {loveCount.toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

export default function ExploreCreatorsView({ creators, loading, theme = 'ethical', prioritySection, onSelectCreator }) {
  const t = SECTION_THEMES[theme];

  // Sort: prioritize creators whose creator_type matches the current section
  const sortedCreators = React.useMemo(() => {
    if (!prioritySection || creators.length === 0) return creators;
    return [...creators].sort((a, b) => {
      const aMatch = CREATOR_TYPE_TO_SECTION[a.creator_type] === prioritySection ? -1 : 1;
      const bMatch = CREATOR_TYPE_TO_SECTION[b.creator_type] === prioritySection ? -1 : 1;
      return aMatch - bMatch;
    });
  }, [creators, prioritySection]);

  const displayCreators = prioritySection ? sortedCreators : creators;

  return (
    <div className="px-4 pb-8">
      {/* Hero Banner */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className={`relative rounded-3xl overflow-hidden mb-6 shadow-2xl ${t.glow}`}
      >
        <div className={`absolute inset-0 bg-gradient-to-br ${t.gradient} opacity-20`} />
        <div className={`absolute inset-0 border ${t.border} rounded-3xl`} />
        <div className="relative px-6 py-6">
          <div className="flex items-center gap-3 mb-2">
            <div className={`w-11 h-11 rounded-2xl bg-gradient-to-br ${t.gradient} flex items-center justify-center shadow-lg`}>
              <span className="text-xl">{t.emoji}</span>
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Discover Creators</h2>
              <p className={`text-xs font-medium ${t.accent}`}>{t.label}</p>
            </div>
          </div>
          <p className="text-sm text-gray-400 leading-relaxed">
            Browse creators sharing knowledge in <span className="text-white font-medium">{t.label}</span>. Follow them to stay updated with their latest content.
          </p>
        </div>
      </motion.div>

      {/* Loading */}
      {loading ? (
        <div className="flex flex-col items-center justify-center py-16 gap-4">
          <div className={`w-12 h-12 rounded-full border-2 border-t-transparent animate-spin bg-gradient-to-r ${t.gradient} opacity-80`}
            style={{ borderColor: 'transparent', borderTopColor: 'currentColor' }}
          />
          <p className="text-gray-500 text-sm">Finding creators...</p>
        </div>
      ) : creators.length === 0 ? (
        /* Empty State */
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex flex-col items-center justify-center py-16 gap-4 text-center"
        >
          <div className={`w-20 h-20 rounded-3xl bg-gradient-to-br ${t.gradient} opacity-20 flex items-center justify-center`}>
            <Users className="w-10 h-10 text-white opacity-50" />
          </div>
          <div>
            <p className="text-white font-semibold text-base mb-1">No Creators Yet</p>
            <p className="text-gray-500 text-sm max-w-xs">Be the first to go public in this section and start building your audience.</p>
          </div>
        </motion.div>
      ) : (
        <>
          {/* Count badge */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
            className="flex items-center justify-between mb-4"
          >
            <p className="text-gray-400 text-xs uppercase tracking-widest font-semibold">
              {creators.length} Creator{creators.length !== 1 ? 's' : ''} Available
            </p>
            <div className={`flex items-center gap-1 text-xs px-2.5 py-1 rounded-full border ${t.badge}`}>
              <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              Live
            </div>
          </motion.div>

          {/* Creators Grid */}
           <div className="space-y-4">
            {displayCreators.map((creator, i) => (
              <CreatorCard key={creator.id} creator={creator} theme={theme} index={i} onSelect={onSelectCreator} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}