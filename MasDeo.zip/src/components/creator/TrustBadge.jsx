import React from 'react';
import { CheckCircle2 } from 'lucide-react';

export default function TrustBadge({ trustScore = 0, verified }) {
  if (!verified) {
    return null;
  }

  return (
    <div className="inline-flex items-center gap-1 bg-blue-500/20 px-2.5 py-1 rounded-full border border-blue-500/30">
      <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />
      <span className="text-xs text-blue-400 font-semibold">Verified</span>
    </div>
  );
}