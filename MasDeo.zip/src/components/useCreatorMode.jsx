import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { loadCache } from './offlineCache';

/**
 * Hook to manage creator mode state.
 * Returns { isCreatorMode, isCreatorEligible, eligibleSections, toggleCreatorMode, user, loading }
 * 
 * Creator mode is toggled globally via localStorage and requires an active subscription
 * with creator_mode_enabled = true.
 * 
 * eligibleSections: array of plan ids the user is subscribed to (e.g. ['ethical_internet', 'all_in_one'])
 */
export function useCreatorMode() {
  const [user, setUser] = useState(() => loadCache('user'));
  const [subscriptions, setSubscriptions] = useState(() => loadCache('activeSubs') || []);
  const [isCreatorMode, setIsCreatorMode] = useState(() => {
    return localStorage.getItem('creator_mode_active') === 'true';
  });
  const [loading, setLoading] = useState(!loadCache('user'));

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    if (!navigator.onLine) {
      setLoading(false);
      return;
    }
    try {
      const userData = await base44.auth.me();
      setUser(userData);
      const subs = await base44.entities.Subscription.filter({
        user_email: userData.email,
        status: 'active'
      });
      setSubscriptions(subs);
    } catch (e) {
      // not logged in or offline
    }
    setLoading(false);
  };

  // Any active subscription makes user eligible for creator mode
  const isCreatorEligible = subscriptions.length > 0;

  // Which section plans does the user have active subscriptions for
  const activePlans = subscriptions.map(s => s.plan);

  // Can the user use creator mode for a specific section?
  const canCreatorForSection = (section) => {
    if (!isCreatorEligible) return false;
    if (activePlans.includes('all_in_one')) return true;
    return activePlans.includes(section);
  };

  const toggleCreatorMode = (val) => {
    const next = val !== undefined ? val : !isCreatorMode;
    if (next && !isCreatorEligible) return; // guard
    setIsCreatorMode(next);
    localStorage.setItem('creator_mode_active', next ? 'true' : 'false');
  };

  return {
    user,
    subscriptions,
    activePlans,
    isCreatorMode: isCreatorMode && isCreatorEligible,
    isCreatorEligible,
    canCreatorForSection,
    toggleCreatorMode,
    loading
  };
}