import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { Bell, X, CheckSquare, Square, Trash2, User, Globe, Download, ArrowLeft, Package } from 'lucide-react';


const TYPE_COLOR = {
  success: 'border-green-500/40 bg-green-500/10',
  error:   'border-red-500/40 bg-red-500/10',
  warning: 'border-amber-500/40 bg-amber-500/10',
  info:    'border-blue-500/30 bg-blue-500/8',
};

const BELL_COLOR = {
  success: 'from-green-500 to-emerald-600',
  error:   'from-red-500 to-rose-600',
  warning: 'from-amber-500 to-orange-600',
  info:    'from-blue-500 to-purple-600',
};

// ── Full message view when user taps a notification ───────────────────────────
function NotificationDetail({ notif, onClose }) {
  const type = notif.type || 'info';
  return (
    <motion.div
      initial={{ y: '100%' }}
      animate={{ y: 0 }}
      exit={{ y: '100%' }}
      transition={{ type: 'spring', damping: 28, stiffness: 300 }}
      className="fixed inset-0 bg-[#0a0a0f] z-[9100] flex flex-col"
      style={{ paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'calc(env(safe-area-inset-bottom) + 8px)' }}
    >
      {/* Header */}
      <div className="px-4 pt-4 pb-3 flex items-center gap-3 border-b border-gray-700/40 flex-shrink-0">
        <button onClick={onClose} className="p-2 rounded-xl bg-gray-800/60 text-gray-400 hover:text-white transition-colors flex-shrink-0">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${BELL_COLOR[type] || BELL_COLOR.info} flex items-center justify-center flex-shrink-0`}>
          {notif.file_url ? <Package className="w-5 h-5 text-white" /> : <Bell className="w-5 h-5 text-white" />}
        </div>
        <p className="text-base font-bold text-white flex-1 leading-tight">{notif.title}</p>
      </div>

      {/* Body — scrollable, full height */}
      <div className="flex-1 overflow-y-auto px-5 py-5">
        {/* Optional image */}
        {notif.file_url && notif.file_url.match(/\.(jpg|jpeg|png|gif|webp)$/i) && (
          <img src={notif.file_url} alt="attachment" className="w-full rounded-2xl mb-5 object-contain max-h-64 border border-gray-700/40" />
        )}

        {/* Message body — large, readable, full line wrapping */}
        <p className="text-sm text-gray-200 whitespace-pre-line leading-7 tracking-wide">
          {notif.message || notif.body}
        </p>
      </div>

      {/* File download button (only for non-image files) */}
      {notif.file_url && !notif.file_url.match(/\.(jpg|jpeg|png|gif|webp)$/i) && (
        <div className="px-5 pb-3 flex-shrink-0">
          <a href={notif.file_url} target="_blank" rel="noopener noreferrer" download
            className="flex items-center justify-center gap-2 py-3.5 bg-gradient-to-r from-orange-600 to-amber-600 rounded-2xl text-sm font-bold text-white hover:opacity-90 transition-opacity active:scale-95">
            <Download className="w-4 h-4" />
            Download {notif.file_name || 'Config File'}
          </a>
        </div>
      )}

      {/* Back button */}
      <div className="px-5 pb-2 border-t border-gray-700/40 pt-3 flex-shrink-0">
        <button onClick={onClose}
          className="w-full py-3 rounded-xl bg-gray-800/60 border border-gray-700/40 text-sm font-bold text-gray-300 hover:bg-gray-700 transition-colors flex items-center justify-center gap-2">
          <ArrowLeft className="w-4 h-4" /> Back to Notifications
        </button>
      </div>
    </motion.div>
  );
}

export default function NotificationBell() {
  const [open, setOpen] = useState(false);
  // All notifications (not deleted)
  const [personal, setPersonal] = useState([]);
  const [broadcast, setBroadcast] = useState([]);
  // IDs the user has already read (for count purposes only)
  const [readIds, setReadIds] = useState(new Set());
  // IDs the user has locally deleted — never re-add these from remote
  const [deletedIds, setDeletedIds] = useState(new Set());
  const [userEmail, setUserEmail] = useState(null);
  const [selected, setSelected] = useState(new Set());
  const [clearing, setClearing] = useState(false);
  const [tab, setTab] = useState('personal');
  const [detailNotif, setDetailNotif] = useState(null);

  // Keep deletedIds in a ref so subscribe callback can access latest value
  const deletedIdsRef = React.useRef(new Set());

  const load = async () => {
    const user = await base44.auth.me();
    const email = user?.email;
    setUserEmail(email);

    const [p, b] = await Promise.all([
      base44.entities.AppNotification.filter({ user_email: email }, '-created_date', 50),
      base44.entities.AppNotification.filter({ user_email: '' }, '-created_date', 50),
    ]);

    // Filter out anything the user already deleted locally
    const deleted = deletedIdsRef.current;
    setPersonal(p.filter(n => !deleted.has(n.id)));
    setBroadcast(b.filter(n => !deleted.has(n.id)));
    // Track which ones are already read
    setReadIds(prev => {
      const next = new Set(prev);
      [...p, ...b].forEach(n => { if ((n.read_by || []).includes(email)) next.add(n.id); });
      return next;
    });
  };

  useEffect(() => {
    load();
    // Only react to NEW create events — do NOT reload the full list (would undo local deletes)
    const unsub = base44.entities.AppNotification.subscribe((event) => {
      if (event.type === 'create') {
        // Let NotificationListener handle the toast/native notif — just add to list
        const n = event.data;
        if (deletedIdsRef.current.has(n.id)) return;
        base44.auth.me().then(user => {
          const email = user?.email;
          const isBroadcast = !n.user_email || n.user_email === '';
          const isPersonal = n.user_email === email;
          if (!isBroadcast && !isPersonal) return;
          if (isBroadcast) {
            setBroadcast(prev => prev.find(x => x.id === n.id) ? prev : [n, ...prev]);
          } else {
            setPersonal(prev => prev.find(x => x.id === n.id) ? prev : [n, ...prev]);
          }
        });
      }
    });
    return unsub;
  }, []);

  const markRead = async (items) => {
    for (const notif of items) {
      const newReadBy = [...new Set([...(notif.read_by || []), userEmail])];
      await base44.entities.AppNotification.update(notif.id, {
        read_by: newReadBy,
        read_count: newReadBy.length,
      }).catch(() => {});
    }
  };

  const currentList = tab === 'personal' ? personal : broadcast;
  const setCurrentList = tab === 'personal' ? setPersonal : setBroadcast;

  // Unread count = notifications not yet in readIds
  const unreadPersonal = personal.filter(n => !readIds.has(n.id)).length;
  const unreadBroadcast = broadcast.filter(n => !readIds.has(n.id)).length;

  // Track deleted IDs so re-fetches don't bring them back
  const trackDeleted = (ids) => {
    ids.forEach(id => deletedIdsRef.current.add(id));
    setDeletedIds(prev => new Set([...prev, ...ids]));
  };

  // Delete = remove from list entirely (user's choice, like deleting an email)
  const deleteOne = async (notif) => {
    trackDeleted([notif.id]);
    setCurrentList(prev => prev.filter(n => n.id !== notif.id));
    setSelected(prev => { const s = new Set(prev); s.delete(notif.id); return s; });
    if (!readIds.has(notif.id)) {
      setReadIds(prev => new Set([...prev, notif.id]));
      await markRead([notif]);
    }
  };

  const dismissSelected = async () => {
    if (selected.size === 0) return;
    setClearing(true);
    const toRemove = currentList.filter(n => selected.has(n.id));
    trackDeleted(toRemove.map(n => n.id));
    setCurrentList(prev => prev.filter(n => !selected.has(n.id)));
    setReadIds(prev => { const next = new Set(prev); toRemove.forEach(n => next.add(n.id)); return next; });
    setSelected(new Set());
    await markRead(toRemove);
    setClearing(false);
  };

  const dismissAll = async () => {
    setClearing(true);
    const all = [...currentList];
    trackDeleted(all.map(n => n.id));
    setCurrentList([]);
    setReadIds(prev => { const next = new Set(prev); all.forEach(n => next.add(n.id)); return next; });
    setSelected(new Set());
    await markRead(all);
    setClearing(false);
  };

  const toggleSelect = (id) => {
    setSelected(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selected.size === currentList.length) {
      setSelected(new Set());
    } else {
      setSelected(new Set(currentList.map(n => n.id)));
    }
  };

  const switchTab = (t) => { setTab(t); setSelected(new Set()); setDetailNotif(null); };

  const totalUnread = unreadPersonal + unreadBroadcast;

  const openDetail = async (notif) => {
    setDetailNotif(notif);
    setSelected(new Set());
    // Mark as read (count decreases) but notification STAYS in the list
    if (!readIds.has(notif.id)) {
      setReadIds(prev => new Set([...prev, notif.id]));
      const newReadBy = [...new Set([...(notif.read_by || []), userEmail])];
      await base44.entities.AppNotification.update(notif.id, {
        read_by: newReadBy,
        read_count: newReadBy.length,
      }).catch(() => {});
    }
  };

  return (
    <div>
      <button
        onClick={() => setOpen(o => !o)}
        className="relative flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-br from-amber-500/60 to-orange-600/60 border border-amber-500/30 hover:scale-110 transition-transform"
      >
        <Bell className="w-4 h-4 text-amber-300" />
        {totalUnread > 0 && (
          <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-blue-500 border border-[#0a0a0f] rounded-full text-[7px] text-white flex items-center justify-center font-bold">
            {totalUnread > 9 ? '9+' : totalUnread}
          </span>
        )}
      </button>

      <AnimatePresence>
        {open && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 z-[9001] bg-black/60 backdrop-blur-sm"
              onClick={() => { setOpen(false); setDetailNotif(null); }} />

            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 28, stiffness: 300 }}
              className="fixed bottom-0 left-0 right-0 z-[9002] bg-[#0f0f1a] border-t border-gray-700/60 rounded-t-3xl max-h-[80vh] flex flex-col overflow-hidden"
              style={{ paddingBottom: 'calc(env(safe-area-inset-bottom) + 8px)' }}
            >
              {/* Handle */}
              <div className="flex justify-center pt-3 pb-1 flex-shrink-0">
                <div className="w-10 h-1 bg-gray-700 rounded-full" />
              </div>

              {/* Header */}
              <div className="px-4 pt-2 pb-3 flex items-center justify-between border-b border-gray-700/40 flex-shrink-0">
                <div className="flex items-center gap-2">
                  <Bell className="w-4 h-4 text-amber-400" />
                  <p className="text-sm font-bold text-white">Notifications</p>
                  {totalUnread > 0 && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-400 border border-amber-500/30">{totalUnread} unread</span>
                  )}
                </div>
                <button onClick={() => { setOpen(false); setDetailNotif(null); }} className="p-1.5 rounded-xl bg-gray-800/60 text-gray-400">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Tab switcher */}
              <div className="px-4 py-2.5 flex gap-2 border-b border-gray-800/60 flex-shrink-0">
                <button
                  onClick={() => switchTab('personal')}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-bold border transition-all ${tab === 'personal' ? 'bg-violet-500/20 border-violet-500/40 text-violet-300' : 'bg-gray-800/50 border-gray-700/40 text-gray-500'}`}
                >
                  <User className="w-3.5 h-3.5" />
                  Personal
                  {unreadPersonal > 0 && <span className="w-4 h-4 rounded-full bg-violet-500 text-white text-[9px] flex items-center justify-center font-black">{unreadPersonal > 9 ? '9+' : unreadPersonal}</span>}
                </button>
                <button
                  onClick={() => switchTab('broadcast')}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-bold border transition-all ${tab === 'broadcast' ? 'bg-blue-500/20 border-blue-500/40 text-blue-300' : 'bg-gray-800/50 border-gray-700/40 text-gray-500'}`}
                >
                  <Globe className="w-3.5 h-3.5" />
                  Masters DeoVex
                  {unreadBroadcast > 0 && <span className="w-4 h-4 rounded-full bg-blue-500 text-white text-[9px] flex items-center justify-center font-black">{unreadBroadcast > 9 ? '9+' : unreadBroadcast}</span>}
                </button>
              </div>

              {/* Toolbar */}
              {!detailNotif && currentList.length > 0 && (
                <div className="px-4 py-2.5 flex items-center justify-between border-b border-gray-800/60 flex-shrink-0">
                  <button onClick={toggleSelectAll} className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white transition-colors">
                    {selected.size === currentList.length
                      ? <CheckSquare className="w-4 h-4 text-cyan-400" />
                      : <Square className="w-4 h-4" />}
                    {selected.size === currentList.length ? 'Deselect All' : 'Select All'}
                  </button>
                  <div className="flex gap-2">
                    {selected.size > 0 && (
                      <button onClick={dismissSelected} disabled={clearing}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-600/20 border border-red-500/30 text-red-300 text-xs font-bold disabled:opacity-50">
                        <Trash2 className="w-3.5 h-3.5" /> Clear {selected.size}
                      </button>
                    )}
                    <button onClick={dismissAll} disabled={clearing}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gray-700/60 border border-gray-600/40 text-gray-300 text-xs font-bold disabled:opacity-50">
                      <Trash2 className="w-3.5 h-3.5" /> Clear All
                    </button>
                  </div>
                </div>
              )}

              {/* Content area — list OR detail */}
              <div className="flex-1 overflow-y-auto relative">
                {/* Notification list */}
                <div className="px-4 py-3 space-y-2">
                  {currentList.length === 0 ? (
                    <div className="text-center py-10">
                      <Bell className="w-10 h-10 text-gray-700 mx-auto mb-3" />
                      <p className="text-gray-500 text-sm">No {tab === 'personal' ? 'personal' : 'Masters DeoVex'} notifications</p>
                    </div>
                  ) : (
                    <AnimatePresence>
                      {currentList.map(n => {
                        const isSelected = selected.has(n.id);
                        const isRead = readIds.has(n.id);
                        const type = n.type || 'info';
                        const hasFile = !!n.file_url;
                        return (
                          <motion.div key={n.id}
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 20, height: 0, marginBottom: 0 }}
                            className={`flex items-start gap-3 p-3 rounded-2xl border transition-all ${
                              isSelected ? 'border-cyan-500/50 bg-cyan-500/8'
                              : isRead ? 'border-gray-700/30 bg-gray-800/20 opacity-60'
                              : (TYPE_COLOR[type] || TYPE_COLOR.info)
                            }`}
                          >
                            {/* Checkbox */}
                            <button onClick={() => toggleSelect(n.id)} className="flex-shrink-0 mt-0.5 p-0.5">
                              {isSelected
                                ? <CheckSquare className="w-4 h-4 text-cyan-400" />
                                : <Square className="w-4 h-4 text-gray-600" />}
                            </button>

                            {/* Icon */}
                            <div className={`w-8 h-8 rounded-xl bg-gradient-to-br ${isRead ? 'from-gray-600 to-gray-700' : (BELL_COLOR[type] || BELL_COLOR.info)} flex items-center justify-center flex-shrink-0`}>
                              {hasFile ? <Package className="w-4 h-4 text-white" /> : <Bell className="w-4 h-4 text-white" />}
                            </div>

                            {/* Content — tap to open */}
                            <button className="flex-1 min-w-0 text-left" onClick={() => openDetail(n)}>
                              <p className={`text-sm leading-tight ${isRead ? 'font-normal text-gray-400' : 'font-semibold text-white'}`}>{n.title}</p>
                              <p className="text-xs text-gray-500 mt-0.5 leading-relaxed line-clamp-2">{n.message || n.body}</p>
                              {hasFile && !isRead && (
                                <span className="inline-flex items-center gap-1 mt-1 text-[10px] text-orange-400 font-bold">
                                  <Download className="w-3 h-3" /> Tap to open & download file
                                </span>
                              )}
                              {!isRead && <p className="text-[9px] text-gray-600 mt-1">Tap to read →</p>}
                            </button>

                            {/* Per-item delete button */}
                            <button onClick={() => deleteOne(n)} className="flex-shrink-0 p-1 rounded-lg text-gray-700 hover:text-red-400 transition-colors mt-0.5">
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </motion.div>
                        );
                      })}
                    </AnimatePresence>
                  )}
                </div>

                {/* Detail overlay */}
                <AnimatePresence>
                  {detailNotif && (
                    <NotificationDetail
                      notif={detailNotif}
                      onClose={() => setDetailNotif(null)}
                    />
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}