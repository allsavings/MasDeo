import React from 'react';
import { motion } from 'framer-motion';
import { Play, Clock, Lock, DollarSign } from 'lucide-react';

export default function VideoCard({ video, onClick, creditCost = 0.05, userCredits = 0 }) {
  const getThumbnailUrl = (id) => `https://img.youtube.com/vi/${id}/maxresdefault.jpg`;
  const canWatch = userCredits >= creditCost || creditCost === 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      onClick={onClick}
      className="group cursor-pointer"
    >
      <div className="bg-gray-800/40 rounded-2xl overflow-hidden border border-gray-700/50 hover:border-cyan-500/50 transition-all">
        {/* Thumbnail */}
        <div className="relative aspect-video overflow-hidden bg-gray-900">
          <img
            src={getThumbnailUrl(video.youtube_video_id)}
            alt={video.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute inset-0 bg-black/30 group-hover:bg-black/20 transition-all flex items-center justify-center">
            <div className="w-14 h-14 rounded-full bg-white/20 group-hover:bg-cyan-500/40 backdrop-blur-sm flex items-center justify-center transition-all group-hover:scale-110">
              <Play className="w-6 h-6 text-white fill-white" />
            </div>
          </div>

          {/* Badges */}
          <div className="absolute top-2 right-2 flex gap-2 flex-wrap justify-end">
            {video.duration_minutes && (
              <div className="bg-black/60 backdrop-blur-sm rounded-lg px-2 py-1 flex items-center gap-1">
                <Clock className="w-3 h-3 text-white" />
                <span className="text-xs text-white font-medium">{video.duration_minutes}m</span>
              </div>
            )}
            {creditCost > 0 && (
              <div className={`${canWatch ? 'bg-cyan-500/60' : 'bg-red-500/60'} backdrop-blur-sm rounded-lg px-2 py-1 flex items-center gap-1`}>
                {!canWatch ? (
                  <>
                    <Lock className="w-3 h-3 text-white" />
                    <span className="text-xs text-white font-medium">R{creditCost.toFixed(2)}</span>
                  </>
                ) : (
                  <>
                    <DollarSign className="w-3 h-3 text-white" />
                    <span className="text-xs text-white font-medium">R{creditCost.toFixed(2)}</span>
                  </>
                )}
              </div>
            )}
          </div>

          {/* Views */}
          {video.views_count > 0 && (
            <div className="absolute bottom-2 left-2 bg-black/60 backdrop-blur-sm rounded-lg px-2 py-1">
              <p className="text-xs text-gray-300">{video.views_count} views</p>
            </div>
          )}
        </div>

        {/* Info */}
        <div className="p-3">
          <h3 className="text-white font-semibold text-sm mb-1 line-clamp-2 group-hover:text-cyan-400 transition-colors">
            {video.title}
          </h3>
          {video.description && (
            <p className="text-gray-400 text-xs line-clamp-2 mb-2">{video.description}</p>
          )}

          <button
            onClick={(e) => {
              e.stopPropagation();
              onClick?.();
            }}
            disabled={!canWatch}
            className={`w-full py-2 rounded-lg text-xs font-medium transition-all flex items-center justify-center gap-1.5 ${
              canWatch
                ? 'bg-gradient-to-r from-cyan-500/30 to-blue-500/30 border border-cyan-500/50 text-cyan-400 hover:from-cyan-500/40 hover:to-blue-500/40'
                : 'bg-gray-700/30 border border-gray-700/50 text-gray-500 cursor-not-allowed'
            }`}
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            {canWatch ? 'Watch Now' : `Insufficient Credits`}
          </button>
        </div>
      </div>
    </motion.div>
  );
}