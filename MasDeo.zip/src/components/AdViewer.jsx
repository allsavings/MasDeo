import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Play, Volume2, VolumeX } from 'lucide-react';

export default function AdViewer({ onAdComplete, creditReward, videoType = 'reward', adNumber = 1, totalAds = 1 }) {
  const safeReward = (creditReward ?? 0.05);
  const [timeLeft, setTimeLeft] = useState(30);
  const [muted, setMuted] = useState(false);
  const [isSkippable, setIsSkippable] = useState(false);

  useEffect(() => {
    if (timeLeft <= 0) {
      onAdComplete();
      return;
    }

    // After 5 seconds, allow skip
    if (timeLeft === 25) {
      setIsSkippable(true);
    }

    const timer = setInterval(() => {
      setTimeLeft(prev => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, onAdComplete]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-gray-900 rounded-3xl border border-gray-700/50 overflow-hidden w-full max-w-md"
      >
        {/* Ad Container */}
        <div className="bg-gradient-to-br from-gray-800 to-gray-900 aspect-video flex flex-col items-center justify-center relative">
          {/* Sample Ad Content */}
          <div className="text-center">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center mx-auto mb-4">
              <Play className="w-8 h-8 text-white fill-white" />
            </div>
            <h3 className="text-white font-bold text-lg mb-1">Premium Feature Unlock</h3>
            <p className="text-gray-400 text-sm">Watch this quick ad to earn free credits</p>
            {totalAds > 1 && (
              <p className="text-cyan-400 text-xs mt-2 font-medium">Ad {adNumber} of {totalAds}</p>
            )}
          </div>

          {/* Timer Overlay */}
          <div className="absolute top-3 right-3 flex items-center gap-2">
            <div className="bg-black/60 backdrop-blur-sm rounded-lg px-3 py-1.5">
              <p className="text-white font-bold text-sm">{timeLeft}s</p>
            </div>
          </div>

          {/* Mute Button */}
          <button
            onClick={() => setMuted(!muted)}
            className="absolute bottom-3 right-3 p-2 bg-white/10 hover:bg-white/20 rounded-full transition-all"
          >
            {muted ? (
              <VolumeX className="w-4 h-4 text-white" />
            ) : (
              <Volume2 className="w-4 h-4 text-white" />
            )}
          </button>
        </div>

        {/* Info & Controls */}
        <div className="p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              {videoType === 'reward' ? (
                <>
                  <p className="text-gray-400 text-xs">You'll earn</p>
                  <p className="text-emerald-400 font-bold text-lg">+R{safeReward.toFixed(2)}</p>
                </>
              ) : (
                <>
                  <p className="text-gray-400 text-xs">Unlocks video</p>
                  <p className="text-purple-400 font-bold text-lg">-R{safeReward.toFixed(2)}</p>
                </>
              )}
            </div>
            <div className="flex-1 mx-4">
              <div className="w-full h-2 bg-gray-700 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: '100%' }}
                  animate={{ width: `${(timeLeft / 30) * 100}%` }}
                  className="h-full bg-gradient-to-r from-cyan-500 to-blue-500"
                />
              </div>
              <p className="text-[10px] text-gray-500 mt-1 text-center">
                {timeLeft}s remaining
              </p>
            </div>
          </div>

          {isSkippable && (
            <motion.button
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              onClick={onAdComplete}
              className="w-full py-2 bg-gray-700/50 hover:bg-gray-700 rounded-xl text-white text-sm font-medium transition-colors"
            >
              Skip Ad
            </motion.button>
          )}

          {!isSkippable && (
            <p className="text-[10px] text-gray-500 text-center">
              Ad will close in {timeLeft} seconds...
            </p>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}