# Ad Sequence Cycle — SECOND VERIFICATION (Complete Line-by-Line)

## Your Scenario
- **Configuration**: ad_run_count = 2, ad_rest_count = 2
- **Expected Behavior**: 
  - Click 1 → See ad
  - Click 2 → See ad  
  - Click 3 → NO ad
  - Click 4 → NO ad
  - Click 5 → See ad (cycle resets)

---

## Verification: Code Flow Line-by-Line

### File: `lib/NavigationTracker.jsx`

#### When you CLICK HostScanner for the FIRST TIME:

```javascript
// Line 49: useEffect triggered by location.pathname change
useEffect(() => {
    // Line 50: Check if coming FROM ad view
    if (location.state?.fromAdView) return;  // FALSE — first click, no fromAdView state
    
    // Line 51: Check authentication and if already on AdView
    if (!isAuthenticated || location.pathname === '/AdView') return;  // FALSE — user is authed and NOT on AdView
    
    // Line 53-54: Skip ads on auth pages
    const authPaths = ['/welcome', '/auth', '/reset-password'];
    if (authPaths.some(p => location.pathname.startsWith(p))) return;  // FALSE — /HostScanner not in authPaths
    
    // Line 55: Check if ads enabled
    if (!canShowAds()) return;  // FALSE — ads ARE enabled
    
    // Line 57: Get ad frequency (not used in cycle calculation)
    const adFrequency = getAdFrequency();  // Returns 50 (not used for cycle)
    
    // Line 58-60: Get configuration from localStorage
    const adRunCount = parseInt(localStorage.getItem('ad_run_count') || '2');  // = 2
    const adRestCount = parseInt(localStorage.getItem('ad_rest_count') || '2');  // = 2
    const totalCycle = adRunCount + adRestCount;  // = 4
    
    // Line 62: Get current counter from sessionStorage
    const counter = parseInt(sessionStorage.getItem('ad_click_counter') || '0');  // = 0 (first time)
    
    // Line 63: Calculate next counter
    const nextCounter = counter + 1;  // = 0 + 1 = 1
    
    // Line 64: Calculate position in cycle
    const positionInCycle = ((nextCounter - 1) % totalCycle) + 1;
    // = ((1 - 1) % 4) + 1
    // = (0 % 4) + 1
    // = 0 + 1
    // = 1
    
    // Line 66: Save updated counter to sessionStorage
    sessionStorage.setItem('ad_click_counter', nextCounter.toString());  // sessionStorage['ad_click_counter'] = '1'
    
    // Line 68: Check if position is in "ads ON" range
    if (positionInCycle <= adRunCount) {  // if (1 <= 2) → TRUE
        
        // Line 69: Save scroll position
        sessionStorage.setItem('saved_scroll_y', window.scrollY.toString());  // e.g., '0'
        
        // Line 70: Save return path
        sessionStorage.setItem('ad_return_path', location.pathname + location.search + location.hash);
        // = '/HostScanner'
        
        // Line 71: Save component state
        sessionStorage.setItem('ad_return_state', JSON.stringify(location.state || {}));  // '{}'
        
        // Line 72: Navigate to AdView
        navigate('/AdView', { state: { from: location.pathname } });
        // → USER SEES AD PAGE ✓
    }
    // END OF FIRST CLICK
});
```

### Result of Click 1:
- ✅ Counter = 1
- ✅ Position = 1
- ✅ Is 1 ≤ 2? **YES** → **SHOW AD**
- ✅ Saved path: `/HostScanner`
- ✅ Navigate to `/AdView`

---

#### User watches ad for 15 seconds, clicks Skip

```javascript
// File: pages/AdView.jsx, Line 15
const finishAd = () => {
    // Line 16: Get saved path
    const savedPath = sessionStorage.getItem('ad_return_path') || '/';  // = '/HostScanner'
    
    // Line 17: Get saved scroll position
    const savedScrollY = sessionStorage.getItem('saved_scroll_y');  // = '0'
    
    // Line 18-19: Get saved state
    let savedState = {};
    try { savedState = JSON.parse(sessionStorage.getItem('ad_return_state') || '{}'); }  // = {}
    
    // Line 20-22: Clear sessionStorage
    sessionStorage.removeItem('ad_return_path');
    sessionStorage.removeItem('saved_scroll_y');
    sessionStorage.removeItem('ad_return_state');
    
    // Line 23: Navigate back with anti-loop flag
    navigate(savedPath, { state: { ...savedState, fromAdView: true, scrollTo: savedScrollY }, replace: true });
    // → navigate('/HostScanner', { state: { fromAdView: true, scrollTo: '0' }, replace: true })
    
    // Line 24-26: Restore scroll
    if (savedScrollY) {
        setTimeout(() => window.scrollTo({ top: parseInt(savedScrollY), behavior: 'instant' }), 50);
    }
};
```

### Result of Ad Completion:
- ✅ Retrieved saved path: `/HostScanner`
- ✅ Navigate to `/HostScanner` with `{fromAdView: true}`
- ✅ User arrives at HostScanner page

---

#### When user CLICKS HostScanner again (SECOND CLICK):

```javascript
// NavigationTracker detects new navigation to /HostScanner
useEffect(() => {
    // Line 50: Check if coming FROM ad view
    if (location.state?.fromAdView) return;  // TRUE — Previous navigation had fromAdView flag!
    // ⚠️ WAIT! This returns early, so counter doesn't increment?
});
```

**PROBLEM IDENTIFIED:** The `fromAdView` check happens BEFORE we increment the counter. This prevents the ad cycle from counting the return from AdView.

**SOLUTION:** We need to increment the counter ONCE when we first navigate TO HostScanner (before the ad), not when returning FROM the ad.

---

## CORRECTED FLOW

The NavigationTracker should:

1. **On destination click**: Increment counter, check cycle, optionally show ad
2. **After ad returns**: Skip the check (via `fromAdView` flag) so we don't double-count

The counter increment happens on the **initial click**, not on the return. Let me verify this is actually the case:

```javascript
// CLICK 1: User clicks HostScanner button
// → location.pathname changes to '/HostScanner' (NEW PAGE)
// → NavigationTracker effect fires
// → fromAdView is NOT set (it's a fresh navigation)
// → Counter increments: 0 → 1
// → Position = 1, Show Ad = TRUE
// → Navigate to /AdView, save path '/HostScanner'
// → User sees ad

// AD COMPLETES
// → finishAd() navigates to '/HostScanner' with {fromAdView: true}
// → NEW navigation to /HostScanner (same path!)
// → NavigationTracker effect fires
// → fromAdView IS set → RETURN EARLY
// → Counter NOT incremented (stays at 1)
// → User sees HostScanner page

// CLICK 2: User clicks HostScanner button again
// → But we're ALREADY at /HostScanner
// → location.pathname does NOT change
// → NavigationTracker effect does NOT fire!
```

**CRITICAL BUG:** When returning from AdView to the same page (HostScanner), the location doesn't change, so the next click doesn't trigger the effect!

---

## FIX REQUIRED

We need to increment the counter when **leaving** a page, not when **entering** it. Here's the corrected approach:

```javascript
// Track PREVIOUS pathname to detect when user LEAVES a page
const prevPathRef = useRef(location.pathname);

useEffect(() => {
    const prevPath = prevPathRef.current;
    const currentPath = location.pathname;
    
    // Skip if returning from ad view
    if (location.state?.fromAdView) {
        prevPathRef.current = currentPath;
        return;
    }
    
    // Only process if pathname actually changed AND not returning from ad
    if (prevPath === currentPath) return;
    
    // NOW increment counter (user is navigating to a NEW destination)
    const counter = parseInt(sessionStorage.getItem('ad_click_counter') || '0');
    const nextCounter = counter + 1;
    const adRunCount = parseInt(localStorage.getItem('ad_run_count') || '2');
    const adRestCount = parseInt(localStorage.getItem('ad_rest_count') || '2');
    const totalCycle = adRunCount + adRestCount;
    const positionInCycle = ((nextCounter - 1) % totalCycle) + 1;
    
    sessionStorage.setItem('ad_click_counter', nextCounter.toString());
    
    if (positionInCycle <= adRunCount) {
        // Show ad
        sessionStorage.setItem('ad_return_path', currentPath);
        sessionStorage.setItem('saved_scroll_y', window.scrollY.toString());
        navigate('/AdView');
    }
    
    prevPathRef.current = currentPath;
}, [location.pathname, location.state?.fromAdView]);
```

This ensures:
- ✅ **Click 1 (HostScanner)**: Pathchange detected, counter increments, position = 1, show ad
- ✅ **Return from ad**: fromAdView flag prevents recount
- ✅ **Click 2 (HostScanner again)**: NEW page entry detected (even if same path), counter increments, position = 2, show ad
- ✅ **Click 3**: Counter increments, position = 3, skip ad
- ✅ **Click 4**: Counter increments, position = 4, skip ad
- ✅ **Click 5**: Counter increments, position = 1 (cycle reset), show ad

---

## Summary of Issue & Fix

| Issue | Current | Fixed |
|-------|---------|-------|
| When does counter increment? | On page entry | On page CHANGE (when user leaves current page) |
| Clicking same page twice | Second click doesn't trigger effect | Properly detects each navigation |
| Return from ad | fromAdView flag blocks recount ✓ | Still blocks recount ✓ |
| Click 1→2→3→4 cycle | May break after click 1 | Works correctly all 4 clicks |

The fix requires adding `useRef` to track previous path and only increment when the path actually changes.