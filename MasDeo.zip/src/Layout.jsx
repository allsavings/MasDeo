import React, { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Home, Globe, BookOpen, DollarSign, Grid2X2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import NotificationListener from './components/NotificationListener';
import OfflineBanner from './components/OfflineBanner';
import AdSequenceDebugger from './components/AdSequenceDebugger';
import PWAInstallBanner from './components/PWAInstallBanner';

// Independent navigation stack roots for each tab
const TAB_ROOTS = {
  Home:           '/',
  EthicalInternet:'/EthicalInternet',
  LearnSkills:    '/LearnSkills',
  EarnOnline:     '/EarnOnline',
  Profile:        '/Profile',
};

const navItems = [
  { icon: Home,      label: 'Home',    page: 'Home',           path: '/' },
  { icon: Globe,     label: 'Ethical', page: 'EthicalInternet', path: '/EthicalInternet' },
  { icon: BookOpen,  label: 'Learn',   page: 'LearnSkills',    path: '/LearnSkills' },
  { icon: DollarSign,label: 'Earn',    page: 'EarnOnline',     path: '/EarnOnline' },
  { icon: Grid2X2,   label: 'More',    page: 'Profile',        path: '/Profile' },
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const navigate = useNavigate();
  const currentPath = location.pathname;
  const wasAuthed = sessionStorage.getItem('was_authenticated') === 'true';
  const [isAuthed, setIsAuthed] = useState(wasAuthed ? true : null);
  const [tabHistory, setTabHistory] = useState({
    Home: '/',
    EthicalInternet: '/EthicalInternet',
    LearnSkills: '/LearnSkills',
    EarnOnline: '/EarnOnline',
    Profile: '/Profile',
  });

  // Update tab history whenever user navigates within a tab
  useEffect(() => {
    navItems.forEach(item => {
      if (currentPath.startsWith(item.path) && currentPath !== item.path) {
        setTabHistory(prev => ({ ...prev, [item.page]: currentPath }));
      }
    });
  }, [currentPath]);

  useEffect(() => {
    const offlineMode = localStorage.getItem('offline_mode') === 'true';
    if ((offlineMode || !navigator.onLine) && wasAuthed) return;
    base44.auth.isAuthenticated().then(authed => {
      setIsAuthed(authed);
      if (!authed && currentPageName !== 'AuthScreen') {
        if (!wasAuthed) {
          window.location.href = '/welcome';
        }
      } else if (authed) {
        sessionStorage.setItem('was_authenticated', 'true');
      }
    });
  }, [currentPageName]);

  // Allow unauthenticated/auth screens to render without nav and hide ads
  if (
    currentPageName === 'AuthScreen' ||
    currentPageName === 'LogoutConfirm' ||
    currentPath.includes('/welcome') ||
    currentPath.includes('/auth') ||
    currentPath.includes('/reset-password')
  ) {
    return (
      <div
        className="min-h-screen bg-[#0a0a0f]"
        style={{ paddingTop: 'env(safe-area-inset-top)' }}
      >
        {/* Hide ads on auth pages */}
        <style>{`
          [class*="adsterra"], [class*="ad-"], .ad-container, .ad-space {
            display: none !important;
          }
        `}</style>
        {children}
      </div>
    );
  }

  if (isAuthed === null) return null;
  if (isAuthed === false) return null;

  const isActive = (item) => {
    if (item.path === '/' && (currentPath === '/' || currentPath === '/Home')) return true;
    return currentPath.startsWith(item.path) || currentPath.includes(item.page);
  };

  // Tapping the active tab resets to its root; tapping an inactive tab navigates to last visited URL
  const handleTabPress = (item) => {
    if (isActive(item)) {
      // Reset stack: navigate to root of this tab
      navigate(TAB_ROOTS[item.page] ?? item.path, { replace: true });
    } else {
      // Navigate to last visited URL in that tab (from tabHistory)
      navigate(tabHistory[item.page] || item.path);
    }
  };

  // Hide bottom nav on deeper pages
  const hideNav = ['Settings', 'HelpSupport', 'AuthScreen', 'LogoutConfirm', 'Admin']
    .some(p => currentPath.includes(p));

  return (
    <div
      className="min-h-screen bg-[#0a0a0f]"
      style={{ paddingTop: 'env(safe-area-inset-top)' }}
    >
      <NotificationListener />
      <OfflineBanner />
      <PWAInstallBanner />

      {/* Main content — leave room for bottom nav */}
      <div className={!hideNav ? 'pb-safe' : ''}>
        {children}
      </div>

      {!hideNav && (
        <motion.nav
          role="tablist"
          aria-label="Main navigation"
          initial={{ y: 100 }}
          animate={{ y: 0 }}
          className="fixed bottom-0 left-0 right-0 bg-[#0a0a0f]/95 backdrop-blur-xl border-t border-gray-800/50 z-50"
          style={{
            paddingBottom: 'calc(env(safe-area-inset-bottom) + 4px)',
            paddingTop: '4px',
            paddingLeft: '8px',
            paddingRight: '8px',
          }}
        >
          <div className="max-w-lg mx-auto flex items-center justify-around">
            {navItems.map((item) => {
              const active = isActive(item);
              return (
                <button
                  key={item.label}
                  role="tab"
                  aria-selected={active}
                  aria-label={item.label}
                  onClick={() => handleTabPress(item)}
                  onContextMenu={(e) => e.preventDefault()}
                  className="flex-1 flex flex-col items-center justify-center min-h-[44px] min-w-[44px] py-1 px-1 rounded-xl transition-all select-none"
                  style={{ WebkitTapHighlightColor: 'transparent', userSelect: 'none', WebkitUserSelect: 'none', WebkitTouchCallout: 'none' }}
                >
                  <div className={`flex flex-col items-center py-1.5 px-2 rounded-xl transition-all w-full ${
                    active ? 'bg-blue-500/10' : 'hover:bg-gray-800/50'
                  }`}>
                    <item.icon
                      className={`w-5 h-5 mb-0.5 transition-colors ${active ? 'text-cyan-400' : 'text-gray-500'}`}
                      aria-hidden="true"
                    />
                    <span className={`text-[11px] font-medium leading-tight transition-colors ${
                      active ? 'text-cyan-400' : 'text-gray-500'
                    }`}>
                      {item.label}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </motion.nav>
      )}
    </div>
  );
}