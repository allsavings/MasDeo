/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import Admin from './pages/Admin';
import AuthScreen from './pages/AuthScreen';
import BrowseCreators from './pages/BrowseCreators';
import BuyCredits from './pages/BuyCredits';
import CdnWafScanner from './pages/CdnWafScanner';
import CodeBackup from './pages/CodeBackup';
import CreatorDashboard from './pages/CreatorDashboard';
import CreatorEarn from './pages/CreatorEarn';
import CreatorEthical from './pages/CreatorEthical';
import CreatorFiles from './pages/CreatorFiles';
import CreatorLearn from './pages/CreatorLearn';
import CreatorMode from './pages/CreatorMode';
import CreatorProfile from './pages/CreatorProfile';
import CreatorSkills from './pages/CreatorSkills';
import CreatorVps from './pages/CreatorVps';
import CreatorWebsites from './pages/CreatorWebsites';
import Discover from './pages/Discover';
import EarnCredits from './pages/EarnCredits';
import EarnOnline from './pages/EarnOnline';
import EthicalInternet from './pages/EthicalInternet';
import ExploreCreators from './pages/ExploreCreators';
import Following from './pages/Following';
import Forex from './pages/Forex';
import HelpSupport from './pages/HelpSupport';
import Home from './pages/Home';
import HostScanner from './pages/HostScanner';
import InternetProtection from './pages/InternetProtection';
import JsonCleaner from './pages/JsonCleaner';
import LearnSkills from './pages/LearnSkills';
import LetsVPNGoInfo from './pages/LetsVPNGoInfo';
import LogoutConfirm from './pages/LogoutConfirm';
import MySubscription from './pages/MySubscription';
import Premium from './pages/Premium';
import Profile from './pages/Profile';
import ServiceDirectory from './pages/ServiceDirectory';
import ServiceDirectoryItem from './pages/ServiceDirectoryItem';
import Settings from './pages/Settings';
import SetupPin from './pages/SetupPin';
import SniBugScanner from './pages/SniBugScanner';
import Subscribe from './pages/Subscribe';
import TxtCleaner from './pages/TxtCleaner';
import Wallet from './pages/Wallet';
import WithdrawCredits from './pages/WithdrawCredits';
import ZeroRatedScan from './pages/ZeroRatedScan';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Admin": Admin,
    "AuthScreen": AuthScreen,
    "BrowseCreators": BrowseCreators,
    "BuyCredits": BuyCredits,
    "CdnWafScanner": CdnWafScanner,
    "CodeBackup": CodeBackup,
    "CreatorDashboard": CreatorDashboard,
    "CreatorEarn": CreatorEarn,
    "CreatorEthical": CreatorEthical,
    "CreatorFiles": CreatorFiles,
    "CreatorLearn": CreatorLearn,
    "CreatorMode": CreatorMode,
    "CreatorProfile": CreatorProfile,
    "CreatorSkills": CreatorSkills,
    "CreatorVps": CreatorVps,
    "CreatorWebsites": CreatorWebsites,
    "Discover": Discover,
    "EarnCredits": EarnCredits,
    "EarnOnline": EarnOnline,
    "EthicalInternet": EthicalInternet,
    "ExploreCreators": ExploreCreators,
    "Following": Following,
    "Forex": Forex,
    "HelpSupport": HelpSupport,
    "Home": Home,
    "HostScanner": HostScanner,
    "InternetProtection": InternetProtection,
    "JsonCleaner": JsonCleaner,
    "LearnSkills": LearnSkills,
    "LetsVPNGoInfo": LetsVPNGoInfo,
    "LogoutConfirm": LogoutConfirm,
    "MySubscription": MySubscription,
    "Premium": Premium,
    "Profile": Profile,
    "ServiceDirectory": ServiceDirectory,
    "ServiceDirectoryItem": ServiceDirectoryItem,
    "Settings": Settings,
    "SetupPin": SetupPin,
    "SniBugScanner": SniBugScanner,
    "Subscribe": Subscribe,
    "TxtCleaner": TxtCleaner,
    "Wallet": Wallet,
    "WithdrawCredits": WithdrawCredits,
    "ZeroRatedScan": ZeroRatedScan,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
    Layout: __Layout,
};