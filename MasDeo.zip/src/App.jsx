import React, { Suspense, lazy } from 'react';
import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import NavigationTracker from '@/lib/NavigationTracker'
import { BrowserRouter as Router, Route, Routes, Navigate, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import __Layout from './Layout.jsx';
import AdsterraGlobalScripts from '@/components/adsterra/AdsterraGlobalScripts';
import { RouteSecurityGuard } from '@/lib/routeSecurityGuard';
import WIPRouteGuard from '@/lib/WIPRouteGuard';
import { WIPLockProvider } from '@/lib/WIPLockContext';



// ── Lazy-load all pages to reduce initial bundle size ──────────────────────

const Admin               = lazy(() => import('./pages/Admin'));
const AuthScreen          = lazy(() => import('./pages/AuthScreen'));
const BrowseCreators      = lazy(() => import('./pages/BrowseCreators'));
const BuyCredits          = lazy(() => import('./pages/BuyCredits'));
const CdnWafScanner       = lazy(() => import('./pages/CdnWafScanner'));
const CodeBackup          = lazy(() => import('./pages/CodeBackup'));
const CreatorDashboard    = lazy(() => import('./pages/CreatorDashboard'));
const CreatorEarn         = lazy(() => import('./pages/CreatorEarn'));
const CreatorEthical      = lazy(() => import('./pages/CreatorEthical'));
const CreatorFiles        = lazy(() => import('./pages/CreatorFiles'));
const CreatorLearn        = lazy(() => import('./pages/CreatorLearn'));
const CreatorMode         = lazy(() => import('./pages/CreatorMode'));
const CreatorProfile      = lazy(() => import('./pages/CreatorProfile'));
const CreatorSkills       = lazy(() => import('./pages/CreatorSkills'));
const CreatorVps          = lazy(() => import('./pages/CreatorVps'));
const CreatorWebsites     = lazy(() => import('./pages/CreatorWebsites'));
const Discover            = lazy(() => import('./pages/Discover'));
const EarnCredits         = lazy(() => import('./pages/EarnCredits'));
const EarnOnline          = lazy(() => import('./pages/EarnOnline'));
const EthicalInternet     = lazy(() => import('./pages/EthicalInternet'));
const ExploreCreators     = lazy(() => import('./pages/ExploreCreators'));
const Following           = lazy(() => import('./pages/Following'));
const Forex               = lazy(() => import('./pages/Forex'));
const HelpSupport         = lazy(() => import('./pages/HelpSupport'));
const Home                = lazy(() => import('./pages/Home'));
const HostScanner         = lazy(() => import('./pages/HostScanner'));
const InternetProtection  = lazy(() => import('./pages/InternetProtection'));
const JsonCleaner         = lazy(() => import('./pages/JsonCleaner'));
const LearnSkills         = lazy(() => import('./pages/LearnSkills'));
const LetsVPNGoInfo       = lazy(() => import('./pages/LetsVPNGoInfo'));
const LogoutConfirm       = lazy(() => import('./pages/LogoutConfirm'));
const MySubscription      = lazy(() => import('./pages/MySubscription'));
const Premium             = lazy(() => import('./pages/Premium'));
const Profile             = lazy(() => import('./pages/Profile'));
const ServiceDirectory    = lazy(() => import('./pages/ServiceDirectory'));
const ServiceDirectoryItem= lazy(() => import('./pages/ServiceDirectoryItem'));
const Settings            = lazy(() => import('./pages/Settings'));
const SetupPin            = lazy(() => import('./pages/SetupPin'));
const SniBugScanner       = lazy(() => import('./pages/SniBugScanner'));
const Subscribe           = lazy(() => import('./pages/Subscribe'));
const TxtCleaner          = lazy(() => import('./pages/TxtCleaner'));
const Wallet              = lazy(() => import('./pages/Wallet'));
const WithdrawCredits     = lazy(() => import('./pages/WithdrawCredits'));
const ZeroRatedScan       = lazy(() => import('./pages/ZeroRatedScan'));
const PaidVersionSetup     = lazy(() => import('./pages/ISPNodeSetup'));
const Welcome              = lazy(() => import('./pages/Welcome'));
const CustomAuth           = lazy(() => import('./pages/CustomAuth'));
const ResetPassword        = lazy(() => import('./pages/ResetPassword'));
const PaidVersionDashboard = lazy(() => import('./pages/ISPNodeDashboard'));
const PaidVersionAdmin     = lazy(() => import('./pages/ISPNodeAdmin'));

// ── Shared loading fallback ────────────────────────────────────────────────
const PageLoader = () => (
  <div className="fixed inset-0 flex items-center justify-center bg-[#0a0a0f]">
    <div className="w-8 h-8 border-4 border-gray-700 border-t-cyan-400 rounded-full animate-spin" />
  </div>
);

const LayoutWrapper = ({ children, currentPageName }) => (
  <__Layout currentPageName={currentPageName}>{children}</__Layout>
);

const wrap = (Page, pageName) => (
  <LayoutWrapper currentPageName={pageName}>
    <Page />
  </LayoutWrapper>
);

const wrapSecure = (Page, pageName, requiredRole = null) => (
  <RouteSecurityGuard path={pageName} requiredRole={requiredRole}>
    <LayoutWrapper currentPageName={pageName}>
      <Page />
    </LayoutWrapper>
  </RouteSecurityGuard>
);

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();
  const location = useLocation();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return <PageLoader />;
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <WIPRouteGuard>
      <Suspense fallback={<PageLoader />}>
        <AnimatePresence mode="wait">
          <motion.div key={location.pathname} initial={{ x: 100, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: -100, opacity: 0 }} transition={{ duration: 0.25 }}>
            <Routes location={location}>
            {/* Auth pages — no layout wrapping */}
        <Route path="/welcome" element={<Welcome />} />
        <Route path="/auth" element={<CustomAuth />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/login" element={<Navigate to="/welcome" replace />} />


        {/* Landing */}
        <Route path="/"                    element={wrap(Home,               'Home')} />



        {/* All pages — Sensitive routes wrapped with security guards */}
        <Route path="/Admin"               element={wrapSecure(Admin,              'Admin', 'admin')} />
        <Route path="/AuthScreen"          element={wrap(AuthScreen,         'AuthScreen')} />
        <Route path="/BrowseCreators"      element={wrap(BrowseCreators,     'BrowseCreators')} />
        <Route path="/BuyCredits"          element={wrapSecure(BuyCredits,         'BuyCredits')} />
        <Route path="/CdnWafScanner"       element={wrap(CdnWafScanner,      'CdnWafScanner')} />
        <Route path="/CodeBackup"          element={wrapSecure(CodeBackup,         'CodeBackup')} />
        <Route path="/CreatorDashboard"    element={wrapSecure(CreatorDashboard,   'CreatorDashboard')} />
        <Route path="/CreatorEarn"         element={wrapSecure(CreatorEarn,        'CreatorEarn')} />
        <Route path="/CreatorEthical"      element={wrap(CreatorEthical,     'CreatorEthical')} />
        <Route path="/CreatorFiles"        element={wrapSecure(CreatorFiles,       'CreatorFiles')} />
        <Route path="/CreatorLearn"        element={wrapSecure(CreatorLearn,       'CreatorLearn')} />
        <Route path="/CreatorMode"         element={wrapSecure(CreatorMode,        'CreatorMode')} />
        <Route path="/CreatorProfile"      element={wrap(CreatorProfile,     'CreatorProfile')} />
        <Route path="/CreatorSkills"       element={wrapSecure(CreatorSkills,      'CreatorSkills')} />
        <Route path="/CreatorVps"          element={wrapSecure(CreatorVps,         'CreatorVps')} />
        <Route path="/CreatorWebsites"     element={wrapSecure(CreatorWebsites,    'CreatorWebsites')} />
        <Route path="/Discover"            element={wrap(Discover,           'Discover')} />
        <Route path="/EarnCredits"         element={wrapSecure(EarnCredits,        'EarnCredits')} />
        <Route path="/EarnOnline"          element={wrap(EarnOnline,         'EarnOnline')} />
        <Route path="/EthicalInternet"     element={wrap(EthicalInternet,    'EthicalInternet')} />
        <Route path="/ExploreCreators"     element={wrap(ExploreCreators,    'ExploreCreators')} />
        <Route path="/Following"           element={wrap(Following,          'Following')} />
        <Route path="/Forex"               element={wrap(Forex,              'Forex')} />
        <Route path="/HelpSupport"         element={wrap(HelpSupport,        'HelpSupport')} />
        <Route path="/Home"                element={wrap(Home,               'Home')} />
        <Route path="/HostScanner"         element={wrap(HostScanner,        'HostScanner')} />
        <Route path="/InternetProtection"  element={wrap(InternetProtection, 'InternetProtection')} />
        <Route path="/JsonCleaner"         element={wrap(JsonCleaner,        'JsonCleaner')} />
        <Route path="/LearnSkills"         element={wrap(LearnSkills,        'LearnSkills')} />
        <Route path="/LetsVPNGoInfo"       element={wrap(LetsVPNGoInfo,      'LetsVPNGoInfo')} />
        <Route path="/LogoutConfirm"       element={wrapSecure(LogoutConfirm,      'LogoutConfirm')} />
        <Route path="/MySubscription"      element={wrapSecure(MySubscription,     'MySubscription')} />
        <Route path="/Premium"             element={wrap(Premium,            'Premium')} />
        <Route path="/Profile"             element={wrapSecure(Profile,            'Profile')} />
        <Route path="/ServiceDirectory"    element={wrap(ServiceDirectory,   'ServiceDirectory')} />
        <Route path="/ServiceDirectoryItem" element={wrap(ServiceDirectoryItem,'ServiceDirectoryItem')} />
        <Route path="/Settings"            element={wrapSecure(Settings,           'Settings')} />
        <Route path="/SetupPin"            element={wrapSecure(SetupPin,           'SetupPin')} />
        <Route path="/SniBugScanner"       element={wrap(SniBugScanner,      'SniBugScanner')} />
        <Route path="/Subscribe"           element={wrap(Subscribe,          'Subscribe')} />
        <Route path="/TxtCleaner"          element={wrap(TxtCleaner,         'TxtCleaner')} />
        <Route path="/Wallet"              element={wrapSecure(Wallet,             'Wallet')} />
        <Route path="/WithdrawCredits"     element={wrapSecure(WithdrawCredits,    'WithdrawCredits')} />
        <Route path="/ZeroRatedScan"       element={wrap(ZeroRatedScan,      'ZeroRatedScan')} />
        <Route path="/PaidVersionSetup"     element={wrap(PaidVersionSetup,    'PaidVersionSetup')} />
        <Route path="/ISPNodeSetup"        element={wrap(PaidVersionSetup,    'PaidVersionSetup')} />
        <Route path="/PaidVersion"         element={wrap(PaidVersionSetup,    'PaidVersionSetup')} />
        <Route path="/PaidVersionDashboard" element={wrap(PaidVersionDashboard,'PaidVersionDashboard')} />
        <Route path="/ISPNodeDashboard"    element={wrap(PaidVersionDashboard,'PaidVersionDashboard')} />
        <Route path="/PaidVersionAdmin"    element={wrap(PaidVersionAdmin,    'PaidVersionAdmin')} />
        <Route path="/ISPNodeAdmin"        element={wrap(PaidVersionAdmin,    'PaidVersionAdmin')} />

            {/* Wildcard Fallback Routing — Redirect all undefined routes to home */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
          </motion.div>
        </AnimatePresence>
      </Suspense>
    </WIPRouteGuard>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <WIPLockProvider>
        <Router>
          <NavigationTracker />
          <AdsterraGlobalScripts />
          <AuthenticatedApp />
        </Router>
        </WIPLockProvider>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  );
}

export default App;