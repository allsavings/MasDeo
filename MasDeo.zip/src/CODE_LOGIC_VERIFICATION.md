# Code Logic Verification — Line by Line What Happens

## THE CORE CYCLE CALCULATION

This is the **heart** of the ad sequence system. Everything else depends on this.

### Location: `lib/NavigationTracker.jsx` Lines 129-149

```javascript
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// LINE 129-131: Load configuration from localStorage
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
const adRunCount = parseInt(localStorage.getItem('ad_run_count') || '2');
const adRestCount = parseInt(localStorage.getItem('ad_rest_count') || '2');
const totalCycle = adRunCount + adRestCount;

// EXAMPLE: Admin sets ad_run_count=2, ad_rest_count=2
// Result: adRunCount=2, adRestCount=2, totalCycle=4

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// LINE 134-136: Get current counter and calculate position
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
const counter = parseInt(sessionStorage.getItem('ad_click_counter') || '0');
const nextCounter = counter + 1;
const positionInCycle = ((nextCounter - 1) % totalCycle) + 1;

// EXAMPLE PROGRESSION:
// Click 1: counter=0 → nextCounter=1 → position=((0) % 4)+1 = 1
// Click 2: counter=1 → nextCounter=2 → position=((1) % 4)+1 = 2
// Click 3: counter=2 → nextCounter=3 → position=((2) % 4)+1 = 3
// Click 4: counter=3 → nextCounter=4 → position=((3) % 4)+1 = 4
// Click 5: counter=4 → nextCounter=5 → position=((4) % 4)+1 = 1 ← CYCLE RESETS!

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// LINE 139: Store the incremented counter
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
sessionStorage.setItem('ad_click_counter', nextCounter.toString());

// EXAMPLE:
// Click 1: Store '1'
// Click 2: Store '2'
// Click 3: Store '3'
// Click 4: Store '4'
// Click 5: Store '5'
// (These stay in sessionStorage until browser session ends)

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// LINE 142-149: Decision — Show ad or skip?
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
if (positionInCycle <= adRunCount) {
  // SHOW AD BLOCK
  sessionStorage.setItem('saved_scroll_y', window.scrollY.toString());
  sessionStorage.setItem('ad_return_path', currentPath + location.search + location.hash);
  sessionStorage.setItem('ad_return_state', JSON.stringify(location.state || {}));
  navigate('/AdView', { state: { from: currentPath } });
}
// Otherwise (position > adRunCount), do nothing — let navigation continue

// EXAMPLE DECISIONS:
// Position 1: 1 <= 2 ? YES → Show Ad
// Position 2: 2 <= 2 ? YES → Show Ad
// Position 3: 3 <= 2 ? NO  → Skip Ad (implicit — no action taken)
// Position 4: 4 <= 2 ? NO  → Skip Ad (implicit — no action taken)
// Position 1: 1 <= 2 ? YES → Show Ad (cycle repeats)
```

---

## THE RETURN FLOW

After user completes an ad, they must return to their original destination.

### Location: `pages/AdView.jsx` Lines 15-42

```javascript
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// LINE 26-29: Retrieve saved return information
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
const savedPath = sessionStorage.getItem('ad_return_path') || '/';
const savedScrollY = sessionStorage.getItem('saved_scroll_y');
let savedState = {};
try { savedState = JSON.parse(sessionStorage.getItem('ad_return_state') || '{}'); } catch (e) {}

// EXAMPLE:
// User clicked HostScanner → Ad shown → finishAd() called
// savedPath = '/HostScanner' (retrieved!)
// savedScrollY = '0' (or '123' if user scrolled before ad)
// savedState = {} (empty state for this navigation)

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// LINE 32-34: IMPORTANT! Clean up saved data
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
sessionStorage.removeItem('ad_return_path');
sessionStorage.removeItem('saved_scroll_y');
sessionStorage.removeItem('ad_return_state');

// WHY? Prevent accidental reuse if finishAd() somehow called twice
// Session is now clean: only ad_click_counter remains

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// LINE 37: Navigate back to original destination
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
navigate(savedPath, { 
  state: { ...savedState, fromAdView: true, scrollTo: savedScrollY }, 
  replace: true 
});

// EXAMPLE:
// Navigates TO: '/HostScanner' (not Home, not root)
// With state: { fromAdView: true, scrollTo: '0' }
// Using replace: true (browser history replaced, not pushed)

// KEY POINTS:
// • savedPath is EXACTLY where user came from (stored before ad)
// • fromAdView flag set to true (anti-loop protection)
// • replace: true so back button doesn't go to /AdView

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// LINE 40-41: Restore scroll position after page renders
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
if (savedScrollY) {
  setTimeout(() => window.scrollTo({ top: parseInt(savedScrollY), behavior: 'instant' }), 50);
}

// WHY 50ms delay? Gives React time to render the page before scrolling
// EXAMPLE:
// User was scrolled to Y=500 on HostScanner
// Ad plays, user returns
// After 50ms, page scrolls back to Y=500 automatically
```

---

## THE ANTI-LOOP PROTECTION

When user returns from ad, the `fromAdView` flag prevents the counter from being recounted.

### Location: `lib/NavigationTracker.jsx` Lines 93-96

```javascript
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// LINE 93-96: Check for return from ad
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
if (location.state?.fromAdView) {
  prevPathRef.current = currentPath;
  return;
}

// EXAMPLE FLOW:
// 1. User navigates to /HostScanner (normal click)
//    location.state.fromAdView = undefined (or false)
//    → Continue processing, increment counter

// 2. Ad shows, finishAd() called
//    navigate('/HostScanner', { state: { fromAdView: true } })

// 3. NavigationTracker runs again
//    location.pathname = '/HostScanner' (same as before)
//    location.state.fromAdView = true ✓
//    → Update prevPathRef
//    → RETURN (EXIT EARLY)
//    → Skip ALL counter logic, don't increment again

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// WHY THIS MATTERS:
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// WITHOUT this flag:
//   Click 1 → counter=1 → Show Ad → Return → counter=2 (WRONG!)
//   Click 2 → counter=3 → Skip Ad (WRONG! Should be position 2)

// WITH this flag:
//   Click 1 → counter=1 → Show Ad → Return → counter still 1 ✓
//   Click 2 → counter=2 → Show Ad ✓ (CORRECT!)
```

---

## THE REAL-TIME CONFIG SYNC

When admin changes ad_run_count in the UI, the next click uses the new value.

### Location: `hooks/useRealtimeConfig.js` Lines 66-76

```javascript
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// LINE 66-76: Subscribe to database changes in real-time
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
unsub = base44.entities.AppConfig.subscribe((event) => {
  if (event.type === 'update' && event.data?.key === 'global') {
    const merged = merge(event.data);
    cachedConfig = merged;
    setConfig(merged);
    // Keep localStorage in sync for legacy readers
    localStorage.setItem('global_ads_enabled', merged.ads_enabled ? 'true' : 'false');
    localStorage.setItem('ad_run_count', String(merged.ad_run_count));
    localStorage.setItem('ad_rest_count', String(merged.ad_rest_count));
  }
});

// EXAMPLE FLOW:
// Time 1:
//   Admin: I set ad_run_count = 2
//   database AppConfig updated
//   ↓
// Time 2:
//   Real-time event fires
//   localStorage.setItem('ad_run_count', '2')
//   ↓
// Time 3:
//   User navigates
//   NavigationTracker reads: localStorage.getItem('ad_run_count') = '2' ✓
//   Uses new value immediately!

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// WHY REAL-TIME?
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// Each user gets their own connection to the AppConfig entity
// When ANY admin updates the global config:
// - Database updated immediately
// - All users' subscriptions fire
// - All users' localStorage updated
// - All users' next click uses new config
// → Zero reload needed, changes apply instantly!
```

---

## PUTTING IT ALL TOGETHER: ONE COMPLETE CLICK FLOW

Let's trace **CLICK 2** from start to finish with real values.

### SETUP STATE (before Click 2)
```
sessionStorage:
  ad_click_counter: '1' (from Click 1)

localStorage:
  ad_run_count: '2'
  ad_rest_count: '2'

Browser location:
  pathname: '/HostScanner' (user arrived here after Click 1 ad)
  state: { fromAdView: true, ... } (returned from ad)
```

### STEP 1: User Clicks "Learn Skills" Button
```
React Router navigates: /HostScanner → /LearnSkills
  ↓
window.location.pathname changes
  ↓
All useEffect hooks with location dependency re-run
  ↓
NavigationTracker useEffect triggers (Line 88)
```

### STEP 2: NavigationTracker Entry Checks
```javascript
const currentPath = '/LearnSkills'                    // Line 89
const prevPath = prevPathRef.current = '/HostScanner' // Line 90

if (location.state?.fromAdView) return;               // Line 93
  // location.state?.fromAdView is from PREVIOUS navigation
  // Now it's a NEW navigation (different path), so NO fromAdView
  // Continue ✓

if (prevPathRef.current === null) return;             // Line 99
  // prevPathRef was set to '/HostScanner' in Click 1 return
  // NOT null
  // Continue ✓

if (prevPath === currentPath) return;                 // Line 105
  // '/HostScanner' === '/LearnSkills'? NO
  // Continue ✓

// Auth pages, AdView, eligibility all pass
  ✓ CONTINUE TO CYCLE LOGIC
```

### STEP 3: Load Configuration
```javascript
const adRunCount = parseInt(localStorage.getItem('ad_run_count') || '2')
  = parseInt('2') = 2

const adRestCount = parseInt(localStorage.getItem('ad_rest_count') || '2')
  = parseInt('2') = 2

const totalCycle = 2 + 2 = 4
```

### STEP 4: Calculate Cycle Position
```javascript
const counter = parseInt(sessionStorage.getItem('ad_click_counter') || '0')
  = parseInt('1') = 1  ← From Click 1, still in session!

const nextCounter = 1 + 1 = 2

const positionInCycle = ((2 - 1) % 4) + 1
  = (1 % 4) + 1
  = 1 + 1
  = 2

sessionStorage.setItem('ad_click_counter', '2')  ← Update for next time
```

### STEP 5: Decision
```javascript
if (positionInCycle <= adRunCount)  // if (2 <= 2)
  // TRUE ✓ SHOW AD

  sessionStorage.setItem('saved_scroll_y', window.scrollY.toString())
    // Save current scroll (probably 0)

  sessionStorage.setItem('ad_return_path', '/LearnSkills')
    // Save destination: /LearnSkills (NOT Home!)

  sessionStorage.setItem('ad_return_state', '{}')
    // Save state

  navigate('/AdView', { state: { from: '/LearnSkills' } })
    // Redirect to ad page
```

### STEP 6: User Sees Ad
```
Browser shows: /AdView page
DOM: 15-second countdown timer
"Ads keep the app free" message
After 5s: "Skip Ad" button appears
```

### STEP 7: User Clicks Skip or Waits
```javascript
// In AdView.jsx finishAd() function

const savedPath = sessionStorage.getItem('ad_return_path')
  = '/LearnSkills'  ✓ (retrieved!)

sessionStorage.removeItem('ad_return_path')     // Clean up
sessionStorage.removeItem('saved_scroll_y')     // Clean up
sessionStorage.removeItem('ad_return_state')    // Clean up

navigate('/LearnSkills', {
  state: { fromAdView: true, scrollTo: '0' },
  replace: true
})
```

### STEP 8: Returned to Original Destination
```
Browser now shows: /LearnSkills page
URL: /LearnSkills
Content: LearnSkills page loads
Scroll: Restored to previous position (50ms later)
```

### STEP 9: NavigationTracker Detects Return
```javascript
useEffect() triggered again because location changed

const currentPath = '/LearnSkills'
const prevPath = prevPathRef.current = '/HostScanner'

if (location.state?.fromAdView) {               // TRUE ✓
  prevPathRef.current = '/LearnSkills'          // Update
  return;                                        // EXIT!
}

// ❌ All counter logic skipped!
// Counter stays at 2 (not recounted as 3)
```

### Final State After Click 2
```
sessionStorage:
  ad_click_counter: '2' (NOT incremented to 3!)

Browser location:
  pathname: '/LearnSkills'
  state: { fromAdView: true, ... }

Result:
  ✅ User on correct page (/LearnSkills, not Home)
  ✅ Counter is 2 (for next Click 3)
  ✅ Ready for next navigation
```

---

## CLICK 3: PROOF OF SKIP AD

Same as Click 2, but different result:

```javascript
// Click 3: Navigate to /EarnOnline
const counter = 2
const nextCounter = 3
const positionInCycle = ((3 - 1) % 4) + 1 = 3

if (positionInCycle <= adRunCount)  // if (3 <= 2) = FALSE
  // SKIP AD (this block doesn't execute)
  // No navigate() called
  // Navigation continues normally

// Result:
// ✅ User immediately sees /EarnOnline page
// ❌ No /AdView page shown
// ✅ No delay, instant load
```

---

## SUMMARY: PROOF OF CORRECTNESS

| Aspect | Code Location | Verification |
|--------|--------------|--------------|
| Counter increments on path change | Line 135 `nextCounter = counter + 1` | ✅ Only when prev ≠ current |
| Position calculated with modulo | Line 136 `((nextCounter-1) % totalCycle) + 1` | ✅ Resets after totalCycle |
| Shows ad when position ≤ adRunCount | Line 142 `if (positionInCycle <= adRunCount)` | ✅ Positions 1-2 show ads |
| Return path saved before ad | Line 145 `sessionStorage.setItem('ad_return_path', currentPath...)` | ✅ User's exact destination |
| Return path retrieved after ad | Line 26 `const savedPath = sessionStorage.getItem('ad_return_path')` | ✅ Returns to saved path |
| NOT redirected to Home | Line 37 `navigate(savedPath, ...)` | ✅ savedPath, not '/' |
| Anti-loop protection | Line 93 `if (location.state?.fromAdView) { return; }` | ✅ Early exit prevents recount |
| Real-time config | Line 73 `localStorage.setItem('ad_run_count', ...)` | ✅ Instant sync from database |
| Config used on next click | Line 129 `localStorage.getItem('ad_run_count')` | ✅ NavigationTracker reads it |

**All logic verified. System is correct.** ✅