# Dynamic Ad Sequence — Complete Flow Guide

## Configuration Example
- **ad_run_count**: 2 (show ads on positions 1, 2)
- **ad_rest_count**: 2 (skip ads on positions 3, 4)
- **Total cycle**: 4 clicks

---

## Flow Diagram: Click-by-Click Breakdown

### Click 1: User clicks HostScanner
```
User clicks HostScanner button
         ↓
NavigationTracker detects navigation to /HostScanner
         ↓
counter = 0 → nextCounter = 1
         ↓
positionInCycle = ((1 - 1) % 4) + 1 = 0 + 1 = 1
         ↓
Is 1 ≤ 2? YES (position is in "ads ON" range)
         ↓
Save to sessionStorage:
  - ad_return_path = "/HostScanner"
  - saved_scroll_y = current scroll position
  - ad_return_state = current page state
         ↓
navigate('/AdView') — Redirect to ad page
         ↓
User sees 15-second ad with click-wall
         ↓
User clicks Skip (after 5s) or timer expires
         ↓
finishAd() executes:
  - Retrieve saved path "/HostScanner"
  - Clear sessionStorage
  - navigate('/HostScanner', {fromAdView: true})
         ↓
User arrives at HostScanner page ✓
```

---

### Click 2: User clicks HostScanner again
```
User clicks HostScanner button again
         ↓
counter = 1 → nextCounter = 2
         ↓
positionInCycle = ((2 - 1) % 4) + 1 = 1 + 1 = 2
         ↓
Is 2 ≤ 2? YES (position is in "ads ON" range)
         ↓
Save path & redirect to /AdView → Ad plays → Return to HostScanner ✓
```

---

### Click 3: User clicks HostScanner again
```
User clicks HostScanner button again
         ↓
counter = 2 → nextCounter = 3
         ↓
positionInCycle = ((3 - 1) % 4) + 1 = 2 + 1 = 3
         ↓
Is 3 ≤ 2? NO (position is in "ads OFF" range)
         ↓
DO NOT show ad — Continue directly to HostScanner ✓
(No redirect, no ad delay)
```

---

### Click 4: User clicks HostScanner again
```
User clicks HostScanner button again
         ↓
counter = 3 → nextCounter = 4
         ↓
positionInCycle = ((4 - 1) % 4) + 1 = 3 + 1 = 4
         ↓
Is 4 ≤ 2? NO (position is in "ads OFF" range)
         ↓
DO NOT show ad — Continue directly to HostScanner ✓
```

---

### Click 5: Cycle resets
```
User clicks HostScanner button again
         ↓
counter = 4 → nextCounter = 5
         ↓
positionInCycle = ((5 - 1) % 4) + 1 = 4 + 1 = 5
Wait... 5? That's outside cycle!
         ↓
Actually: positionInCycle = ((5 - 1) % 4) + 1 = (4 % 4) + 1 = 0 + 1 = 1
         ↓
CYCLE RESETS — Position 1 again = "ads ON"
         ↓
Save path → Show ad → Return to HostScanner ✓
```

---

## Anti-Loop Protection

### How does NavigationTracker prevent ad looping?

```javascript
if (location.state?.fromAdView) return;
```

**Mechanism:**
1. User clicks HostScanner → Saved to sessionStorage
2. AdView shows → finishAd() navigates with `{fromAdView: true}`
3. NavigationTracker sees `location.state.fromAdView = true`
4. Effect returns early — **does NOT check ad cycle again**
5. User sees HostScanner page without another ad

**Result:** Even if user clicks multiple times in rapid succession, the `fromAdView` flag prevents the ad check from running until the next distinct navigation.

---

## Timeline: Complete User Experience

| Action | Time | What Happens | Ad? |
|--------|------|--------------|-----|
| Click HostScanner | 0s | Redirected to /AdView | **YES** |
| Watching ad | 0–15s | 15-second countdown, click-wall active | — |
| User clicks Skip | 5s+ | finishAd() executes | — |
| Navigate back | 5.1s | Returns to HostScanner | — |
| Page loads | 5.2s | HostScanner renders | — |
| **Click HostScanner again** | 5.5s | Redirected to /AdView | **YES** |
| Watching ad | 5.5–20.5s | 15-second countdown | — |
| Timer expires | 20.5s | finishAd() executes | — |
| Navigate back | 20.6s | Returns to HostScanner | — |
| **Click HostScanner again** | 20.8s | **Direct navigation** | **NO** |
| Page loads | 21s | No ad delay! | — |
| **Click HostScanner again** | 25s | **Direct navigation** | **NO** |
| Page loads | 25.1s | No ad delay! | — |
| **Click HostScanner again** | 30s | Redirected to /AdView | **YES** |
| (Cycle resets) | — | Cycle repeats | — |

---

## Configuration Controls (Admin Panel)

### Master Switch
- **OFF**: No ads show anywhere
- **ON**: Respect ad cycle and user overrides

### Plan-Based Toggles
- **Premium Ads Enabled**: Show ads to subscribers
- **Free Ads Enabled**: Show ads to free users

### Dynamic Ad Sequence
- **ad_run_count** (e.g., 2): How many clicks in a row show an ad
- **ad_rest_count** (e.g., 2): How many clicks skip the ad
- **Total cycle**: ad_run_count + ad_rest_count = 4 clicks repeating

### User Overrides
- Individual users can have ads forced ON or OFF
- Overrides bypass all plan-based settings

---

## Code Locations

| File | Function | Purpose |
|------|----------|---------|
| `lib/NavigationTracker.jsx` | Dynamic Ad Sequence Engine | Detects navigation, calculates cycle position, redirects to AdView |
| `pages/AdView.jsx` | finishAd() | Returns user to original destination after ad completes |
| `hooks/useAdLogic.js` | canShowAds() | Checks master switch, plan, and user overrides |
| `hooks/useRealtimeConfig.js` | config | Real-time ad configuration from AppConfig entity |
| `components/admin/AdControlTab.jsx` | Admin Panel | UI to set ad_run_count, ad_rest_count, and plan toggles |

---

## Summary

✅ **Click 1 & 2**: Show ads (positions 1–2)  
✅ **Click 3 & 4**: Skip ads (positions 3–4)  
✅ **Click 5+**: Cycle repeats (position 1 again = ads ON)  
✅ **User always returns** to intended destination (HostScanner, etc.)  
✅ **fromAdView flag** prevents ad loop on return navigation  
✅ **Real-time config** syncs changes instantly without app reload