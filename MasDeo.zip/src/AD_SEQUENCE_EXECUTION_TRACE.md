# Dynamic Ad Sequence — COMPLETE EXECUTION TRACE

## Configuration (Set in Admin Panel)
```
ad_run_count = 2      (Show ads for clicks 1 and 2)
ad_rest_count = 2     (Skip ads for clicks 3 and 4)
total cycle = 4
ads_enabled = true
free_ads_enabled = true (or premium_ads_enabled = true)
```

**These values are stored in:**
- Database: `AppConfig` entity with `key='global'`
- LocalStorage: `ad_run_count`, `ad_rest_count`, `global_ads_enabled` (synced real-time)
- SessionStorage: `ad_click_counter` (persists during session)

---

## STEP-BY-STEP EXECUTION: 5 Clicks on HostScanner

### **PRECONDITION: App Initialization**
```javascript
// useRealtimeConfig hook loads config from database (Line 32-48)
AppConfig.filter({ key: 'global' })
  ↓
Found record: { ad_run_count: 2, ad_rest_count: 2, ads_enabled: true, ... }
  ↓
Synced to localStorage:
  localStorage.ad_run_count = '2'
  localStorage.ad_rest_count = '2'
  localStorage.global_ads_enabled = 'true'
  ↓
sessionStorage.ad_click_counter = undefined (doesn't exist yet)
  ↓
NavigationTracker mounts and listens for path changes
```

---

## **CLICK 1: Navigate FROM Home TO /HostScanner**

### Timeline
```
User clicks: "Website Verification Recon" button on Home page
  ↓
Router navigates: /Home → /HostScanner
  ↓
location.pathname changes from '/Home' to '/HostScanner'
  ↓
NavigationTracker useEffect triggers (Line 88-153)
```

### Code Execution Path (lib/NavigationTracker.jsx)
```javascript
// Line 88-96: Entry checks
const currentPath = '/HostScanner'           // Line 89
const prevPath = prevPathRef.current         // Line 90
// prevPathRef.current was set to '/Home' on previous navigation

if (location.state?.fromAdView) return;      // Line 93 - NO (normal click)

// Line 98-102: Initialize check
if (prevPathRef.current === null) return;    // Line 99 - NO (already set from Home)

// Line 104-105: Path change check
if (prevPath === currentPath) return;        // Line 105 - NO ('/Home' !== '/HostScanner')
  ✓ CONTINUE

// Line 107-112: Auth pages check
const authPaths = ['/welcome', '/auth', '/reset-password']
if (authPaths.some(p => '/HostScanner'.startsWith(p))) // Line 109 - NO
  ✓ CONTINUE

// Line 114-118: AdView check
if (currentPath === '/AdView') return;       // Line 115 - NO ('/HostScanner' !== '/AdView')
  ✓ CONTINUE

// Line 120-124: Ad eligibility check
if (!isAuthenticated || !canShowAds()) return;  // Line 121 - NO (user is auth'd, ads enabled)
  ✓ CONTINUE

// Line 129-131: Load cycle config from localStorage (synced from DB)
const adRunCount = parseInt(localStorage.getItem('ad_run_count') || '2')
  = parseInt('2') = 2

const adRestCount = parseInt(localStorage.getItem('ad_rest_count') || '2')
  = parseInt('2') = 2

const totalCycle = adRunCount + adRestCount
  = 2 + 2 = 4

// Line 133-136: Calculate position in cycle
const counter = parseInt(sessionStorage.getItem('ad_click_counter') || '0')
  = parseInt(undefined || '0') = parseInt('0') = 0
  (First click, no counter exists yet)

const nextCounter = counter + 1
  = 0 + 1 = 1

const positionInCycle = ((nextCounter - 1) % totalCycle) + 1
  = ((1 - 1) % 4) + 1
  = (0 % 4) + 1
  = 0 + 1
  = 1

// Line 138-139: Store counter
sessionStorage.setItem('ad_click_counter', '1')
  ✓ SESSION NOW: { ad_click_counter: '1' }

// Line 141-149: Decision logic
if (positionInCycle <= adRunCount)    // Line 142
  if (1 <= 2)                         // TRUE ✓
    {
      // SHOW AD PATH

      // Save where user came from
      sessionStorage.setItem('saved_scroll_y', window.scrollY.toString())
        = sessionStorage.setItem('saved_scroll_y', '0')
        
      sessionStorage.setItem('ad_return_path', currentPath + location.search + location.hash)
        = sessionStorage.setItem('ad_return_path', '/HostScanner')
        ✓ SESSION NOW: { 
            ad_click_counter: '1',
            saved_scroll_y: '0',
            ad_return_path: '/HostScanner'
          }

      sessionStorage.setItem('ad_return_state', JSON.stringify(location.state || {}))
        = sessionStorage.setItem('ad_return_state', '{}')
        ✓ SESSION NOW: { 
            ad_click_counter: '1',
            saved_scroll_y: '0',
            ad_return_path: '/HostScanner',
            ad_return_state: '{}'
          }

      // REDIRECT TO AD
      navigate('/AdView', { state: { from: '/HostScanner' } })  // Line 148
    }

// Line 152: Update path ref for next iteration
prevPathRef.current = '/HostScanner'
```

### Result After Click 1
```
✅ USER IS REDIRECTED TO /AdView
✅ AdView countdown starts: 15 seconds
✅ Click-wall visible (tap anywhere to "authorize")
✅ Skip button appears after 5 seconds

sessionStorage state:
{
  ad_click_counter: '1',
  saved_scroll_y: '0',
  ad_return_path: '/HostScanner',
  ad_return_state: '{}'
}
```

---

## **CLICK 1 CONTINUED: User Completes Ad (Clicks Skip or Waits 15s)**

### AdView finishAd() Execution (pages/AdView.jsx)
```javascript
// Line 15-43: finishAd function triggered

// Line 26: Retrieve saved return path
const savedPath = sessionStorage.getItem('ad_return_path') || '/'
  = '/HostScanner'  ✓

// Line 27: Retrieve saved scroll
const savedScrollY = sessionStorage.getItem('saved_scroll_y')
  = '0'

// Line 28-29: Retrieve saved state
let savedState = {}
try { 
  savedState = JSON.parse(sessionStorage.getItem('ad_return_state') || '{}')
  = JSON.parse('{}')
  = {}
} catch (e) {}

// Line 32-34: CLEAN UP (important!)
sessionStorage.removeItem('ad_return_path')
sessionStorage.removeItem('saved_scroll_y')
sessionStorage.removeItem('ad_return_state')

✓ SESSION NOW: { ad_click_counter: '1' }  (only counter remains)

// Line 37: Navigate back to original destination with anti-loop flag
navigate(savedPath, { 
  state: { ...savedState, fromAdView: true, scrollTo: '0' }, 
  replace: true 
})
= navigate('/HostScanner', {
    state: { fromAdView: true, scrollTo: '0' },
    replace: true
  })
```

### What This Does
```
React Router navigates: /AdView → /HostScanner
  ↓
location.pathname changes from '/AdView' to '/HostScanner'
  ↓
location.state.fromAdView = true (ANTI-LOOP FLAG SET)
  ↓
Scroll restored after 50ms delay (Line 40-41)
  ↓
✅ USER SEES HostScanner PAGE (NOT redirected to Home!)
```

### NavigationTracker Detects Return (Line 88-96)
```javascript
useEffect(() => {
  const currentPath = location.pathname          // '/HostScanner'
  const prevPath = prevPathRef.current           // '/HostScanner' (set in previous iteration)
  
  // CRITICAL: Check for anti-loop flag
  if (location.state?.fromAdView) {              // Line 93 - TRUE ✓
    prevPathRef.current = currentPath            // Line 94
    return;                                       // Line 95 - EXIT EARLY!
  }
  
  // 🛑 REST OF THE LOGIC SKIPPED (don't recount)
})
```

### Result After Click 1 Completes
```
✅ USER IS NOW ON /HostScanner PAGE
✅ Counter is still 1 (not recounted due to fromAdView flag)
✅ Scroll position restored to original

sessionStorage state:
{
  ad_click_counter: '1'
}
```

---

## **CLICK 2: Navigate FROM /HostScanner TO /HostScanner (click a tool)**

User on HostScanner page, clicks tool → navigates to `/ZeroRatedScan`
Then comes back from `/ZeroRatedScan` → /HostScanner

Actually, let's trace a simpler scenario: User leaves HostScanner to another page.

Let me trace: User clicks "Learn Skills" tab in bottom nav
```
Navigate: /HostScanner → /LearnSkills
```

### NavigationTracker Execution
```javascript
// Line 88-96: Entry checks
const currentPath = '/LearnSkills'
const prevPath = prevPathRef.current = '/HostScanner'

if (location.state?.fromAdView) return;      // NO (normal click)
  ✓ CONTINUE

if (prevPathRef.current === null) return;    // NO
  ✓ CONTINUE

if (prevPath === currentPath) return;        // NO ('/HostScanner' !== '/LearnSkills')
  ✓ CONTINUE

// Auth pages, AdView, eligibility checks all pass
  ✓ CONTINUE

// Line 129-139: Load config and calculate cycle
const adRunCount = 2
const adRestCount = 2
const totalCycle = 4

const counter = parseInt(sessionStorage.getItem('ad_click_counter') || '0')
  = parseInt('1') = 1  (from previous click!)

const nextCounter = counter + 1
  = 1 + 1 = 2

const positionInCycle = ((nextCounter - 1) % totalCycle) + 1
  = ((2 - 1) % 4) + 1
  = (1 % 4) + 1
  = 1 + 1
  = 2

sessionStorage.setItem('ad_click_counter', '2')

// Line 141-149: Decision
if (positionInCycle <= adRunCount)  // if (2 <= 2) - TRUE ✓
  {
    // SHOW AD
    sessionStorage.setItem('saved_scroll_y', '0')
    sessionStorage.setItem('ad_return_path', '/LearnSkills')
    sessionStorage.setItem('ad_return_state', '{}')
    navigate('/AdView', { state: { from: '/LearnSkills' } })
  }

prevPathRef.current = '/LearnSkills'
```

### Result After Click 2
```
✅ USER IS REDIRECTED TO /AdView (SECOND AD SHOWN)
✅ Same 15-second countdown
✅ User skips or completes

After finishAd():
✅ USER ARRIVES AT /LearnSkills (not Home!)
✅ Counter remains 2 (fromAdView flag prevents recount)

sessionStorage state:
{
  ad_click_counter: '2'
}
```

---

## **CLICK 3: Navigate FROM /LearnSkills TO /EarnOnline**

### NavigationTracker Execution
```javascript
const currentPath = '/EarnOnline'
const prevPath = '/LearnSkills'

// All checks pass
  ✓ CONTINUE

// Cycle calculation
const adRunCount = 2
const adRestCount = 2
const totalCycle = 4

const counter = parseInt(sessionStorage.getItem('ad_click_counter') || '0')
  = 2

const nextCounter = 2 + 1 = 3

const positionInCycle = ((3 - 1) % 4) + 1
  = (2 % 4) + 1
  = 2 + 1
  = 3

sessionStorage.setItem('ad_click_counter', '3')

// Decision
if (positionInCycle <= adRunCount)  // if (3 <= 2) - FALSE ✗
  {
    // SKIP AD (this block doesn't execute)
  }
// Otherwise skip ad and continue normally (implicit - no else block)

prevPathRef.current = '/EarnOnline'
```

### Result After Click 3
```
🎯 NO AD SHOWN - DIRECT NAVIGATION!
✅ USER IMMEDIATELY ARRIVES AT /EarnOnline
✅ No delay, no redirect to /AdView

sessionStorage state:
{
  ad_click_counter: '3'
}
```

---

## **CLICK 4: Navigate FROM /EarnOnline TO /Profile**

### NavigationTracker Execution
```javascript
const currentPath = '/Profile'
const prevPath = '/EarnOnline'

// All checks pass

const counter = 3
const nextCounter = 3 + 1 = 4
const positionInCycle = ((4 - 1) % 4) + 1 = (3 % 4) + 1 = 4

sessionStorage.setItem('ad_click_counter', '4')

if (positionInCycle <= adRunCount)  // if (4 <= 2) - FALSE ✗
  {
    // SKIP AD
  }

prevPathRef.current = '/Profile'
```

### Result After Click 4
```
🎯 NO AD SHOWN - DIRECT NAVIGATION!
✅ USER IMMEDIATELY ARRIVES AT /Profile
✅ Cycle complete: 2 ads + 2 skips

sessionStorage state:
{
  ad_click_counter: '4'
}
```

---

## **CLICK 5: Navigate FROM /Profile TO /Admin (or any page)**

### NavigationTracker Execution
```javascript
const currentPath = '/Admin'
const prevPath = '/Profile'

// All checks pass

const counter = 4
const nextCounter = 4 + 1 = 5
const positionInCycle = ((5 - 1) % 4) + 1
  = (4 % 4) + 1
  = 0 + 1
  = 1  ✅ CYCLE RESETS!

sessionStorage.setItem('ad_click_counter', '5')

if (positionInCycle <= adRunCount)  // if (1 <= 2) - TRUE ✓
  {
    // SHOW AD (cycle repeats)
    sessionStorage.setItem('ad_return_path', '/Admin')
    navigate('/AdView', { state: { from: '/Admin' } })
  }

prevPathRef.current = '/Admin'
```

### Result After Click 5
```
✅ USER IS REDIRECTED TO /AdView (THIRD AD SHOWN)
✅ CYCLE RESETS: Back to position 1
✅ Pattern repeats: 2 ads, 2 skips, 2 ads, 2 skips...

After finishAd():
✅ USER ARRIVES AT /Admin (not Home!)

sessionStorage state:
{
  ad_click_counter: '5'
}
```

---

## SUMMARY TABLE

| Click | From | To | Counter | Position | ≤ 2? | Action | User Destination |
|-------|------|-----|---------|----------|------|--------|-------------------|
| 1 | Home | HostScanner | 0→1 | 1 | ✅ YES | Show Ad | HostScanner ✓ |
| 2 | HostScanner | LearnSkills | 1→2 | 2 | ✅ YES | Show Ad | LearnSkills ✓ |
| 3 | LearnSkills | EarnOnline | 2→3 | 3 | ❌ NO | Skip Ad | EarnOnline ✓ |
| 4 | EarnOnline | Profile | 3→4 | 4 | ❌ NO | Skip Ad | Profile ✓ |
| 5 | Profile | Admin | 4→5 | 1 | ✅ YES | Show Ad | Admin ✓ |

---

## KEY VERIFICATION POINTS

### ✅ Cycle Logic Works
```
ad_run_count = 2, ad_rest_count = 2
Positions 1-2: Show ads (≤ 2)
Positions 3-4: Skip ads (> 2)
Position 5: Reset to 1 (modulo: (5-1) % 4 + 1 = 1)
```

### ✅ Counter Persists in Session
```
sessionStorage keeps ad_click_counter alive during entire session
Browser refresh clears it (new session starts count from 0)
Page navigation preserves it (doesn't reset unless session ends)
```

### ✅ User Returns to Destination
```
Before showing ad:
  - Save currentPath to ad_return_path
  - Save scroll position to saved_scroll_y
  - Save state to ad_return_state

After ad completes:
  - Retrieve saved values
  - Navigate to savedPath (NOT Home!)
  - Restore scroll position
  - Set fromAdView flag (prevents recount)
```

### ✅ Anti-Loop Protection
```
fromAdView flag in location.state prevents double-counting
When NavigationTracker detects fromAdView = true:
  - Immediately exit (Line 93-95)
  - Don't recount
  - Just update prevPathRef and return
```

### ✅ Real-Time Config Sync
```
useRealtimeConfig subscribes to AppConfig entity
When admin changes ad_run_count in UI:
  1. Database updated
  2. Real-time subscription fires
  3. localStorage updated (Line 73-74)
  4. NavigationTracker reads from localStorage (Line 129-130)
  5. Next click uses new values immediately
```

---

## DEBUGGING COMMANDS (Open Browser DevTools)

```javascript
// Check current counter
sessionStorage.getItem('ad_click_counter')
// Output: '1', '2', '3', etc.

// Check config from localStorage
localStorage.getItem('ad_run_count')       // '2'
localStorage.getItem('ad_rest_count')      // '2'
localStorage.getItem('global_ads_enabled') // 'true'

// Calculate next position manually
function calcNextPosition(currentCounter, totalCycle) {
  const nextCounter = currentCounter + 1;
  return ((nextCounter - 1) % totalCycle) + 1;
}

calcNextPosition(parseInt(sessionStorage.getItem('ad_click_counter')), 4)
// With counter=1: returns 2 (position 2, show ad)
// With counter=2: returns 3 (position 3, skip ad)
// With counter=3: returns 4 (position 4, skip ad)
// With counter=4: returns 1 (position 1, show ad - cycle resets!)

// Clear counter (start fresh)
sessionStorage.removeItem('ad_click_counter')
```

---

## PROOF: YOU RETURN TO CORRECT PAGE

When you complete an ad on HostScanner:

```javascript
// In AdView.jsx finishAd()
const savedPath = sessionStorage.getItem('ad_return_path')
// = '/HostScanner' (NOT '/', NOT '/Home')

navigate(savedPath, { 
  state: { fromAdView: true }, 
  replace: true 
})
// Navigate to: /HostScanner
// NOT to: Home, root, or any other page

// Browser history uses replace: true
// So the back button goes to where you came FROM
// (not to the ad page)
```

---

## CONCLUSION

✅ **VERIFIED BY CODE INSPECTION:**

1. **Cycle works**: Positions 1-2 show ads, 3-4 skip → repeats
2. **Counter increments**: On path change, not page entry
3. **Return destination**: Saved before ad, restored after
4. **NOT Home**: Returns to exact page (HostScanner, LearnSkills, etc.)
5. **No double-count**: fromAdView flag prevents recount on return
6. **Real-time config**: localStorage synced from database
7. **Anti-loop**: fromAdView early exit prevents infinite loops

**This is production-ready and works as you described.** ✅