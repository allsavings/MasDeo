# Live Testing Guide — Follow These Steps to Verify the System

## PART 1: SETUP (5 minutes)

### Step 1.1: Open Admin Panel
1. Go to your app → Click **"More"** (bottom nav) → **"Settings"** → **"Admin"**
2. Scroll to **"Ads Control Tab"** (the tab with Zap icon ⚡)

### Step 1.2: Configure Ad Cycle
Look for **"Dynamic Ad Sequence"** section:
- Set **"Ads ON"** slider to **2** (click count=1-2 show ads)
- Set **"Ads OFF"** slider to **2** (click count=3-4 skip ads)
- Make sure **"Master Ad Switch"** is **ENABLED** (blue toggle)
- Make sure **"Free Users"** toggle is **ENABLED** (green star)

Click **"Save Configuration"** button → You should see **"✓ Configuration saved successfully!"**

### Step 1.3: Verify Config Saved to Database
Open **DevTools** (F12 or right-click → Inspect):
1. Go to **Console** tab
2. Paste this command:
```javascript
console.log('ad_run_count:', localStorage.getItem('ad_run_count'));
console.log('ad_rest_count:', localStorage.getItem('ad_rest_count'));
console.log('global_ads_enabled:', localStorage.getItem('global_ads_enabled'));
console.log('session counter:', sessionStorage.getItem('ad_click_counter'));
```
3. You should see:
```
ad_run_count: 2
ad_rest_count: 2
global_ads_enabled: true
session counter: null (doesn't exist yet)
```

### Step 1.4: Clear Session Counter (Fresh Start)
Paste in Console:
```javascript
sessionStorage.removeItem('ad_click_counter');
console.log('Session cleared. Counter is now:', sessionStorage.getItem('ad_click_counter'));
```
Output: `Session cleared. Counter is now: null`

✅ **SETUP COMPLETE**

---

## PART 2: TEST 5 CLICKS (10 minutes)

### CLICK 1: Navigate to HostScanner
**Action**: Go back to home/any page → Click **"Ethical"** tab (bottom nav)
**Expected**:
- ❌ You should NOT see /EthicalInternet page
- ✅ Instead, you should be redirected to **/AdView** (black screen with 15s timer)
- ✅ See "Ads keep the app free" message
- ✅ See "Tap anywhere to authorize connection" text

**Verify in Console**:
```javascript
console.log('Counter after Click 1:', sessionStorage.getItem('ad_click_counter'));
console.log('Saved return path:', sessionStorage.getItem('ad_return_path'));
```
Expected output:
```
Counter after Click 1: 1
Saved return path: /EthicalInternet
```

**Wait for Ad**:
- After 5 seconds, a **"Skip Ad"** button appears in bottom-right
- Click it (or wait 15 seconds for auto-completion)

**After Skip/Complete**:
- ✅ You should arrive at **/EthicalInternet** (NOT Home!)
- ✅ Page content loads normally

**Verify in Console**:
```javascript
console.log('Counter after return:', sessionStorage.getItem('ad_click_counter'));
console.log('Return path cleared:', sessionStorage.getItem('ad_return_path'));
```
Expected:
```
Counter after return: 1 (NOT recounted!)
Return path cleared: null (cleaned up)
```

---

### CLICK 2: Navigate to Another Section
**Action**: Click **"Learn"** tab (bottom nav)
**Expected**:
- ❌ You should NOT see /LearnSkills page
- ✅ Redirected to **/AdView** (SECOND AD)
- ✅ Same 15-second timer

**Verify in Console**:
```javascript
console.log('Counter after Click 2:', sessionStorage.getItem('ad_click_counter'));
console.log('Saved return path:', sessionStorage.getItem('ad_return_path'));
```
Expected:
```
Counter after Click 2: 2
Saved return path: /LearnSkills
```

**Click Skip and Wait for Completion**:
- ✅ You arrive at **/LearnSkills** (NOT Home!)

**Verify in Console**:
```javascript
console.log('Counter still:', sessionStorage.getItem('ad_click_counter'));
```
Expected: `Counter still: 2` (NOT recounted)

---

### CLICK 3: Navigate Again
**Action**: Click **"Earn"** tab (bottom nav)
**Expected**:
- ✅ **NO REDIRECT!** You should see /EarnOnline page **IMMEDIATELY**
- ❌ NO ad page should appear
- ❌ NO 15-second timer
- ✅ Page loads instantly

This is the **first skip in the cycle** (position 3 > 2).

**Verify in Console**:
```javascript
console.log('Counter after Click 3:', sessionStorage.getItem('ad_click_counter'));
console.log('Is ad showing?:', sessionStorage.getItem('ad_return_path'));
```
Expected:
```
Counter after Click 3: 3
Is ad showing?: null (no ad data saved)
```

---

### CLICK 4: Navigate Again
**Action**: Click **"More"** tab (bottom nav)
**Expected**:
- ✅ **NO REDIRECT!** You should see /Profile page **IMMEDIATELY**
- ❌ NO ad should appear
- ✅ **Instant load, no delay**

This is the **second skip in the cycle** (position 4 > 2). **Cycle complete!**

**Verify in Console**:
```javascript
console.log('Counter after Click 4:', sessionStorage.getItem('ad_click_counter'));
```
Expected:
```
Counter after Click 4: 4
```

---

### CLICK 5: Cycle Resets
**Action**: Navigate to any page (e.g., click **"Home"** tab)
**Expected**:
- ❌ You should NOT see Home page
- ✅ Redirected to **/AdView** (THIRD AD - cycle restarted!)
- ✅ 15-second timer appears

This proves the **modulo arithmetic works**: position (5-1) % 4 + 1 = 1

**Verify in Console**:
```javascript
console.log('Counter:', sessionStorage.getItem('ad_click_counter'));
console.log('Position in cycle:', ((5-1) % 4) + 1);
```
Expected:
```
Counter: 5
Position in cycle: 1 (CYCLE RESETS!)
```

**Click Skip and Complete**:
- ✅ You arrive at **Home** (NOT redirected to another page)

---

## PART 3: CHANGE CONFIG AND VERIFY REAL-TIME SYNC (5 minutes)

### Step 3.1: Change ad_run_count to 3
1. Go back to **Admin** → **Ad Control Tab**
2. Change **"Ads ON"** slider to **3**
3. Keep **"Ads OFF"** at **2** (total cycle = 5 now)
4. Click **"Save Configuration"**

### Step 3.2: Clear Counter and Test
Paste in Console:
```javascript
sessionStorage.removeItem('ad_click_counter');
localStorage.getItem('ad_run_count'); // Should be '3'
```

Navigate to 5 different pages:
- **Click 1** → Ad (position 1 ≤ 3) ✅
- **Click 2** → Ad (position 2 ≤ 3) ✅
- **Click 3** → Ad (position 3 ≤ 3) ✅
- **Click 4** → No Ad (position 4 > 3) ✅
- **Click 5** → No Ad (position 5 > 3) ✅
- **Click 6** → Ad (position 1 - cycle resets) ✅

✅ **Real-time config change works!**

---

## PART 4: TEST RETURN DESTINATIONS (5 minutes)

### Scenario: Manually Visit HostScanner
1. Type URL directly: `/HostScanner`
2. You should see HostScanner page (no ad on first entry)
3. Click one of the tools (e.g., **"Zero Rated Scan"**)
4. You should see an ad (if counter position ≤ 2)
5. **Verify**: After ad completes, you should be at `/ZeroRatedScan` tool page, **NOT HostScanner**, NOT Home

**Verify in Console** (while on tool page):
```javascript
window.location.pathname // Should show '/ZeroRatedScan' or similar
```

---

## PART 5: TEST AD DISABLE (3 minutes)

### Step 5.1: Disable Ads
1. Go to **Admin** → **Ad Control Tab**
2. Toggle **"Master Ad Switch"** to **OFF** (red toggle)
3. Click **"Save Configuration"**

### Step 5.2: Try Navigating
Navigate to different pages:
- ✅ **NO ads should appear**, even at positions 1-2
- ✅ All pages load **instantly**
- ❌ No redirect to /AdView at all

### Step 5.3: Re-enable and Verify
1. Toggle **"Master Ad Switch"** back to **ON**
2. Click **"Save Configuration"**
3. Navigate again
- ✅ Ads should appear again (if position ≤ 2 and counter resets)

---

## PART 6: VISUAL VERIFICATION CHECKLIST

### After Each Ad:
- [ ] User sees countdown timer (15s, 14s, 13s...)
- [ ] Timer matches position in cycle
- [ ] "Skip Ad" button appears after 5 seconds
- [ ] Clicking Skip takes you to intended destination
- [ ] Waiting 15s auto-completes and takes you to destination

### Return Destinations:
- [ ] Clicking from EthicalInternet returns to EthicalInternet
- [ ] Clicking from LearnSkills returns to LearnSkills
- [ ] Clicking from tool page returns to tool page (not parent)
- [ ] Scroll position restored to where you were before ad
- [ ] You **never** see unexpected redirect to Home

---

## CONSOLE DEBUG COMMANDS

### Monitor Counter in Real-Time
```javascript
setInterval(() => {
  const counter = sessionStorage.getItem('ad_click_counter') || '0';
  const cycle = ((parseInt(counter)-1) % 4) + 1;
  console.log(`Counter: ${counter}, Position: ${cycle}`);
}, 1000);
```

### Check What Happens on Next Navigation
```javascript
function predictNextClick() {
  const counter = parseInt(sessionStorage.getItem('ad_click_counter') || '0');
  const run = parseInt(localStorage.getItem('ad_run_count') || '2');
  const nextCounter = counter + 1;
  const position = ((nextCounter - 1) % 4) + 1;
  const willShowAd = position <= run;
  console.log(`Next click: counter=${nextCounter}, position=${position}, showAd=${willShowAd}`);
}
predictNextClick();
```

### View All Saved Session Data
```javascript
console.table({
  counter: sessionStorage.getItem('ad_click_counter'),
  returnPath: sessionStorage.getItem('ad_return_path'),
  scrollY: sessionStorage.getItem('saved_scroll_y'),
  returnState: sessionStorage.getItem('ad_return_state'),
  runCount: localStorage.getItem('ad_run_count'),
  restCount: localStorage.getItem('ad_rest_count'),
  enabled: localStorage.getItem('global_ads_enabled')
});
```

---

## SUCCESS CRITERIA

You'll know the system works when:

✅ **Clicks 1-2**: See ads, return to correct page  
✅ **Clicks 3-4**: NO ads, instant load  
✅ **Click 5**: Ad appears again (cycle reset)  
✅ **Real-time config**: Change ad_run_count, next click uses new value  
✅ **Return destinations**: Never redirected to Home, always to intended page  
✅ **Console logs**: Match expected counter/position values  
✅ **Scroll restored**: Your scroll position restored after returning from ad  

---

## TROUBLESHOOTING

### Problem: Ads don't appear on clicks 1-2
**Check**:
1. Is `global_ads_enabled` = 'true' in console?
2. Is `ads_enabled` true in Admin panel?
3. Is your user free/premium (check `free_ads_enabled` or `premium_ads_enabled`)?
4. Clear `sessionStorage` and try fresh: `sessionStorage.removeItem('ad_click_counter')`

### Problem: Counter doesn't increment
**Check**:
1. Are you actually navigating to a DIFFERENT page? (Path must change)
2. Check console: `sessionStorage.getItem('ad_click_counter')` after each click
3. If it's `null`, counter wasn't initialized — try navigating to a different page first

### Problem: Returned to Home instead of HostScanner
**Check**:
1. Is `ad_return_path` being saved? Console: `sessionStorage.getItem('ad_return_path')`
2. Is `finishAd()` being called? (Check if Skip button is clickable)
3. Check NavigationTracker for errors in console

### Problem: fromAdView flag not working (ads shown twice)
**Check**:
1. After returning from ad, does `location.state.fromAdView` = true?
2. Check browser console for any navigation errors
3. Verify `navigate()` includes `state: { fromAdView: true }`

---

## EXPECTED OUTPUT SCREENSHOTS

### Before Click 1
```
Console:
  ad_click_counter: null
  global_ads_enabled: 'true'
  ad_run_count: '2'
```

### Click 1 Triggers Ad
```
Browser shows: /AdView page with black background + 15s timer
Console:
  ad_click_counter: '1'
  ad_return_path: '/HostScanner' (or your destination)
  saved_scroll_y: '0' (or your scroll pos)
```

### After Ad Completes
```
Browser shows: /HostScanner page (or your destination)
Console:
  ad_click_counter: '1' (NOT incremented again!)
  ad_return_path: null (cleaned up)
  location.pathname: '/HostScanner'
```

### Click 3 (Skip)
```
Browser shows: Instant navigation to /EarnOnline
No /AdView redirect at all
Console:
  ad_click_counter: '3'
  ad_return_path: null (no ad data)
```

---

## FINAL CONFIRMATION

After completing all 5 clicks and seeing the pattern:
- **AD, AD, SKIP, SKIP, AD** ✅

You have verified:
1. ✅ Cycle works correctly
2. ✅ Counter persists in session
3. ✅ Position calculation is correct
4. ✅ Ad/skip logic is correct
5. ✅ Return destinations are correct
6. ✅ Real-time config works
7. ✅ Anti-loop protection works

**System is production-ready!** 🎯