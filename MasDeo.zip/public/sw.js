// Masters DeoVex Service Worker — PWA + Offline Vault
const CACHE_NAME = 'mastersdeovex-v2';
const OFFLINE_CACHE = 'mastersdeovex-offline-v1';

// Core assets to pre-cache for offline use
const CORE_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
];

// ── Install: pre-cache core shell ────────────────────────────────────────────
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(CORE_ASSETS).catch(() => {
        // Non-fatal: some assets may not exist yet
      });
    }).then(() => self.skipWaiting())
  );
});

// ── Activate: clean up old caches ────────────────────────────────────────────
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((k) => k !== CACHE_NAME && k !== OFFLINE_CACHE)
          .map((k) => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  );
});

// ── Fetch: network-first with offline fallback ───────────────────────────────
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET, cross-origin API calls (base44 backend), and chrome-extension
  if (
    request.method !== 'GET' ||
    url.pathname.startsWith('/api/') ||
    url.hostname.includes('base44') ||
    url.protocol === 'chrome-extension:'
  ) {
    return;
  }

  // For navigation requests: network-first, fallback to cached index.html
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((res) => {
          // Cache a fresh copy of the page shell
          const clone = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put('/index.html', clone));
          return res;
        })
        .catch(() =>
          caches.match('/index.html').then((cached) => cached || new Response('Offline', { status: 503 }))
        )
    );
    return;
  }

  // For static assets: cache-first
  if (
    url.pathname.match(/\.(js|css|png|jpg|jpeg|svg|ico|woff2?|ttf)$/)
  ) {
    event.respondWith(
      caches.match(request).then((cached) => {
        if (cached) return cached;
        return fetch(request).then((res) => {
          if (res.ok) {
            const clone = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
          }
          return res;
        }).catch(() => cached || new Response('', { status: 503 }));
      })
    );
    return;
  }

  // Default: network-first
  event.respondWith(
    fetch(request).catch(() => caches.match(request))
  );
});

// ── Push Notifications ────────────────────────────────────────────────────────
self.addEventListener('push', (event) => {
  let data = {
    title: 'Masters DeoVex',
    body: 'You have a new notification.',
    icon: '/icons/Icon-192.png',
    badge: '/icons/badge-48.png',
    tag: 'mastersdeovex-push',
    data: { url: '/' },
  };

  if (event.data) {
    try {
      const payload = event.data.json();
      data = {
        title: payload.title || data.title,
        body: payload.body || payload.message || data.body,
        icon: ICON_512,
        // Android badge: must be a small monochrome white icon (Play Store compliant)
        badge: 'https://media.base44.com/images/public/69fbae3c9d10c5e17ae8e806/c666bca50_badge-48.png',
        tag: payload.tag || data.tag,
        data: { url: payload.url || '/' },
        vibrate: [200, 100, 200],
        requireInteraction: false,
      };
    } catch (_) {
      data.body = event.data.text();
    }
  }

  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: data.icon,
      badge: data.badge,
      tag: data.tag,
      data: data.data,
      vibrate: data.vibrate || [200, 100, 200],
      requireInteraction: false,
    })
  );
});

// ── Notification Click: open/focus the app ───────────────────────────────────
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const targetUrl = event.notification.data?.url || '/';

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clients) => {
      for (const client of clients) {
        if (client.url.includes(self.location.origin) && 'focus' in client) {
          client.navigate(targetUrl);
          return client.focus();
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow(targetUrl);
      }
    })
  );
});

// ── Periodic Background Sync: re-sync when user has data ─────────────────────
self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'sync-notifications') {
    // Notify all open clients to re-fetch notifications
    event.waitUntil(
      self.clients.matchAll({ type: 'window' }).then((clients) => {
        clients.forEach((client) => client.postMessage({ type: 'SYNC_NOTIFICATIONS' }));
      })
    );
  }
});

// ── Offline Vault: respond to cache-fill messages from the app ───────────────
self.addEventListener('message', (event) => {
  if (!event.data) return;

  // Fill offline cache with provided URLs
  if (event.data.type === 'OFFLINE_CACHE_URLS') {
    const urls = event.data.urls || [];
    event.waitUntil(
      caches.open(OFFLINE_CACHE).then((cache) => cache.addAll(urls).catch(() => {}))
    );
  }

  // Clear offline cache on demand
  if (event.data.type === 'CLEAR_OFFLINE_CACHE') {
    event.waitUntil(caches.delete(OFFLINE_CACHE));
  }
});
